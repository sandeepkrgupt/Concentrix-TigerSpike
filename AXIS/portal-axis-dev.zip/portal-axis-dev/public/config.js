window.globalConfig = {
  baseUrlFromConfig: {
    prod: "https://10.9.13.153:9443/neofidb",
    dev: "https://10.225.235.21:9444/neofidb",
  },
};
