/*eslint-disable */
import React from "react";
import "./App.css";
import Routes from "./router";
import { StylesProvider } from "@material-ui/core/styles"
import ScrollToTop from './router/scroll_top';
import AlertPopup from "./components/alertPopup/alertPopup";

function App() {
  return (
    <div className="App">
      <StylesProvider injectFirst>
        <ScrollToTop/>
        <AlertPopup/>
        <Routes />
      </StylesProvider> 
    </div>
  );
}

export default App;
