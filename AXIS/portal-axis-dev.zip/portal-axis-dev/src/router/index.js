import React from "react";
import { Switch } from "react-router-dom";
import BillOfEntry from "../modules/boe";
import CompletedTransactions from "../modules/completed_transactions";
import CurrencyConvertor from "../modules/currency_convertor";
import Dashboard from "../modules/dashboard";
import routes from "../utils/routes";
import { PublicRoute } from "./routerComponent";
import TransactionInquiry from "../modules/transaction_inquiry";
import BoeDetails from "../modules/boe/details";
import NoOfBoes from "../modules/boe/no_of_boes";
import MakePayment from "../modules/make_payment";
import AdditionalDetails from "../modules/make_payment/transaction_details/additional_details";
import Login from "../modules/auth";
import SuccessPage from "../components/successcard";
import AuthMatrix from "../modules/make_payment/payment_details/auth-matrix/index.js";
import AuthMatrixSuccess from "../modules/make_payment/payment_details/success/index.js";
import AuthorizeSuccess from "../modules/make_payment/review/success/index.js";
import WorkflowDetails from "../modules/make_payment/review/workflow-details";

const router = () => {
  return (
    <>
      <Switch>
        <PublicRoute exact path={routes.login} component={Login} />
        <PublicRoute exact path={routes.dashboard} component={Dashboard} />
        <PublicRoute
          exact
          path={routes.completedTransactions}
          component={CompletedTransactions}
        />
        <PublicRoute
          exact
          path={routes.currencyConvertor}
          component={CurrencyConvertor}
        />
        <PublicRoute exact path={routes.boe} component={BillOfEntry} />
        <PublicRoute
          exact
          path={routes.transactionInquiry}
          component={TransactionInquiry}
        />
        <PublicRoute exact path={routes.boeDetails} component={BoeDetails} />
        <PublicRoute exact path={routes.boeNo} component={NoOfBoes} />
        <PublicRoute exact path={routes.makePayment} component={MakePayment} />
        <PublicRoute
          exact
          path={routes.additionalDetails}
          component={AdditionalDetails}
        />
        <PublicRoute exact path={routes.authMatrix} component={AuthMatrix} />
        <PublicRoute exact path={routes.success} component={SuccessPage} />
        <PublicRoute
          exact
          path={routes.authMatrixSuccess}
          component={AuthMatrixSuccess}
        />
        <PublicRoute
          exact
          path={routes.authorizeSuccess}
          component={AuthorizeSuccess}
        />

        <PublicRoute
          exact
          path={routes.workflowDetails}
          component={WorkflowDetails}
        />
      </Switch>
    </>
  );
};

export default router;
