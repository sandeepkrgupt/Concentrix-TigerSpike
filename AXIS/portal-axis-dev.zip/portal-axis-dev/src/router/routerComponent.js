import React from "react";
import { Redirect, Route } from "react-router-dom";
import QuickLink from "../components/quicklinks";
// import SideBar from "../components/sidebar";
import './index.css';

export const PrivateRoute = ({ Component, ...rest }) => {
  const sessionId = true;
  return (
    <Route
      {...rest}
      render={(props) =>
        sessionId ? (
          <Component {...props} />
        ) : (
          <Redirect to={{ pathname: "/login" }} />
        )
      }
    />
  );
};
export const PublicRoute = ({ Component, ...rest }) => {

  // function changedWindowSize(){
  //   const drawerWidth = document.getElementsByClassName("drawer")[0].clientWidth;
  //   document.getElementsByClassName("container-component")[0].style.marginLeft = `${drawerWidth}px`;
  // }
  // window.addEventListener("resize", changedWindowSize)
  return (
    <>
      {/* <SideBar/> */}
      {rest.path !== "/"  && <QuickLink />}
      <div 
      className="container-component"
      >
        <Route
          {...rest}
        />
      </div>
    </>
  );
};
