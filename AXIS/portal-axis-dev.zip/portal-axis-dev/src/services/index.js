import axios from "axios";

let BASE_URL;
if (process.env.REACT_APP_ENV === "production") {
  BASE_URL = window.globalConfig.baseUrlFromConfig.prod;
} else if (process.env.REACT_APP_ENV === "development") {
  BASE_URL = window.globalConfig.baseUrlFromConfig.dev;
}

const instance = axios.create({
  baseURL: BASE_URL,
  // timeout: 10000,
  headers: { "Content-Type": "application/json" },
  // withCredentials: true, // uncomment this for enabling cookie based authentication
});

instance.interceptors.response.use(
  (resp) => resp,
  (error) => {
    return error;
  }
);

export default instance;
