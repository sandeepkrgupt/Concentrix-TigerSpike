import React, { useEffect } from 'react';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import { Button } from '../@subzero/glacier/package/lib/components';
import { makeStyles } from '@material-ui/core/styles';
import './index.css';

const useStyles = makeStyles((theme) => ({
    root: {
        '& .MuiDialog-paper':{
            background: "#FFFFFF",
            boxShadow:" 0px 24px 38px rgba(0, 0, 0, 0.14)",
            borderRadius: "16px",
        },
        '& .dialog-title':{
            fontFamily: "Lato",
            fontStyle: "normal",
            fontWeight: "bold",
            fontSize: "24px",
            lineHeight: "30px",
            display: "flex",
            alignItems: "center",
            letterSpacing: "0.2px",
            color: "#282828",
            padding: "16px 24px 0px"
        },
        '& .dialog-content':{
            fontFamily: "Lato",
            fontStyle: "normal",
            fontSize: "16px",
            lineHeight: "24px",
            display: "flex",
            alignItems: "center",
            letterSpacing: "0.16px",
            color: "#404040"
        }
    },
}));

export default function AlertDialog(props) {
  const classes = useStyles();
  const [open, setOpen] = React.useState(props?.show);
  
  const handleClose = () => {
    props?.onClose();
  };

  const handleAction = () =>{
      props?.onAction();
  }

  useEffect(()=>{
    setOpen(props?.show)
  },[props?.show])

  return (
    <div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className={classes.root}
      >
        <DialogTitle id="alert-dialog-title" className="dialog-title">{props?.title}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description" className="dialog-content">
           {props?.content}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose} className="secondaryBtn" color="secondary">
            Cancel
          </Button>
          <Button onClick={handleAction} style={{width: '120px'}}>
            {props?.actionButtonLabel}
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}