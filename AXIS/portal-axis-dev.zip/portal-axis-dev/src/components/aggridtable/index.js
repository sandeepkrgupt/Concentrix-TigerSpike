/*eslint-disable */
import React, { useRef, useState, useEffect } from "react";
import { AgGridColumn, AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-theme-material.css";
import {
  Chip,
  Menu,
  MenuItem,
  styled,
  Tooltip,
  Typography,
} from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import "ag-grid-community/dist/styles/ag-grid.css";
import SideArrowIcon from "../../assets/icons/side-arrow.svg";
import DocumentIcon from "../../assets/icons/doc.svg";
// import DocumentIconActive from '../../assets/icons/doc-active.svg';
import HamburgerIcon from "../../assets/icons/hamburger.svg";
import AddIcon from "../../assets/icons/add.svg";
import WarningIcon from "../../assets/icons/warning.svg";
import FilterIcon from "../../assets/icons/filter.svg";
import RightArrow from "../../assets/icons/arrow-right.svg";
import CloseIcon from "../../assets/icons/close.svg";
import ClearAllIcon from "../../assets/icons/clear.svg";
import OrangeDot from "../../assets/icons/orange-dot.svg";
import IconInfo from "../../assets/icons/icon-2.svg";
import UpArrow from "../../assets/icons/up-arrow.svg";
import DownloadIcon from "../../assets/icons/download.svg";
import DownloadIconActive from "../../assets/icons/active-download.svg";
import Delete from "../../assets/icons/trash-inactive.svg";
import DeleteActive from "../../assets/icons/trash.svg";
import CustomizeIcon from "../../assets/icons/customize.svg";
import TrashIcon from "../../assets/icons/delete.svg";
import {
  Button,
  TextField,
  Datepicker,
  Radio,
  Checkbox,
} from "../@subzero/glacier/package/lib/components";
import { Link } from "react-router-dom";
import CustomToolTip from "./custom_tooltip";
import "./index.css";
import { useHistory } from "react-router-dom";
import TabMobView from "./tab_mob_view";
import TableTop from "./TableTop";
import CustomTableFooter from "./CustomTableFooter";
import { Actions } from "../../store/rootActions";
import { useDispatch, useSelector } from "react-redux";
import customstyles from "./custom.module.css";
import CustomTableHeader from "./CustomTableHeader";
import { withStyles } from "@material-ui/core/styles";
// ToolTip styles
const stacticStyle = {
  "font-family": "Lato !important",
  "font-style": "normal !important",
  "font-weight": "normal !important",
  "font-size": "14px !important",
  "line- height": "20px !important",
  "letter- spacing": "0.26px !important",
  "white-space": "normal !important",
  color: "#404040 !important",
};
//Styling for menu
const useStyles = makeStyles((theme) => ({
  morepopup: {
    "& .MuiPopover-paper": {
      display: "flex",
      marginLeft: "-55px",
      marginTop: "30px",
      flexDirection: "column",
      alignItems: "flex-start",
      padding: "8px 0px",
      width: "auto",
      height: "auto",
      background: "#FFFFFF",
      border: "0.5px solid #F1F1F1",
      boxSizing: "border-box",
      boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.14)",
      borderRadius: "8px",
      textAlign: "center",
    },
    "& .MuiListItem-root": {
      // height: "48px",
      fontFamily: "Lato",
      fontStyle: "normal",
      fontWeight: "normal",
      fontSize: "16px",
      lineHeight: "24px",
      letterSpacing: "0.16px",
      color: "#282828",
      "&:hover": {
        backgroundColor: "#FDE5EE !important",
      },
    },
    "& .Mui-focusVisible": {
      backgroundColor: "transparent",
    },
  },
  viewmore: {
    "& .MuiPopover-paper": {
      marginTop: "20px",
      marginLeft: "-170px",
      width: "auto",
      height: "auto",
      borderRadius: "8px",
    },
    "& .MuiListItem-root": {
      height: "48px",
      fontFamily: "Lato",
      fontStyle: "normal",
      fontWeight: "normal",
      fontSize: "16px",
      lineHeight: "24px",
      letterSpacing: "0.16px",
      "&:hover": {
        backgroundColor: "#FDE5EE !important",
      },
    },
    "& .Mui-focusVisible": {
      backgroundColor: "transparent",
    },
  },
  download: {
    "& .MuiPopover-paper": {
      marginTop: "60px",
      marginLeft: "-0px",
      width: "auto",
      height: "auto",
      borderRadius: "8px",
    },
    "& .MuiListItem-root": {
      height: "48px",
      fontFamily: "Lato",
      fontStyle: "normal",
      fontWeight: "normal",
      fontSize: "16px",
      lineHeight: "24px",
      letterSpacing: "0.16px",
      "&:hover": {
        backgroundColor: "#FDE5EE !important",
      },
    },
    "& .Mui-focusVisible": {
      backgroundColor: "transparent",
    },
  },
  docMenu: {
    "& .MuiPopover-paper": {
      marginTop: "30px",
      marginLeft: "-90px",
      width: "auto",
      height: "auto",
      borderRadius: "8px",
    },
    "& .MuiListItem-root": {
      height: "48px",
      fontFamily: "Lato",
      fontStyle: "normal",
      fontWeight: "normal",
      fontSize: "16px",
      lineHeight: "24px",
      letterSpacing: "0.16px",
      "&:hover": {
        backgroundColor: "#FDE5EE !important",
      },
    },
    "& .Mui-focusVisible": {
      backgroundColor: "transparent",
    },
  },
  chip: {
    background: "#F1F4F7",
    borderRadius: "4px",
    fontFamily: "Lato",
    fontStyle: "normal",
    fontWeight: "normal",
    fontSize: "10px",
    lineHeight: "10px",
    display: "flex",
    alignItems: "center",
    letterSpacing: "0.32px",
    textTransform: "uppercase",
    color: "#282828",
    margin: "10px",
    padding: "2px 8px",
    height: "18px",
  },
}));

const LightTooltip = withStyles({
  tooltip: {
    fontFamily: "Lato",
    fontStyle: "normal",
    fontWeight: "bold",
    fontSize: "12px",
    lineHeight: "16px",
    letterSpacing: "0.32px",
    color: "#282828",
    width: 256,
    height: 104,
    background: "#FFFFFF",
    border: "0.5px solid #F1F1F1",
    boxSizing: "border-box",
    boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.14)",
    borderRadius: 8,
    padding: "12px 16px",
  },
})(Tooltip);

const AgGridTable = (props) => {
  const history = useHistory();
  const classes = useStyles();
  const dispatch = useDispatch();
  const [morePopup, setMorePopup] = useState(false);
  const [anchorElViewMore, setAnchorElViewMore] = useState(null);
  const [anchorElDownload, setAnchorElDownload] = useState(null);
  const [docPopup, setDocPopup] = useState(null);
  const [docItem, setDocItem] = useState({});
  const [delItem, setDelItem] = useState({});
  const [boeList, setBoeList] = useState([]);
  const [item, setItem] = useState({});
  const [selectedRows, setSelectedRows] = useState(0);
  const [selectedList, updateSelectedList] = useState(props?.selectedList);
  const [page, setPage] = React.useState(1);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [startPage, updateStartPage] = useState(1);
  const [endPage, updateEndPage] = useState(5);
  const [totalPage, updatePages] = useState(props?.totalPage);
  const [anchorElRows, setAnchorElRows] = React.useState(null);
  const [gridApi, setGridApi] = useState(null);
  const [actionItem, setActionItem] = useState({});
  const [pagination, setPagination] = useState(!props?.tableOnly);
  const [filterList, setFilterList] = useState(props?.filterOptions);
  const ref = useRef(null);
  const [rows, setRows] = useState(props?.rows);
  const authData = useSelector((state) => state?.auth?.loginData);
  const userId = authData?.userId;
  const appDate = authData?.appDate;
  const showOtherScreen = props?.showOtherScreen;
  const handleRowDeletion = props?.handleRowDeletion;

  useEffect(() => {
    gridApi?.redrawRows();
  }, [props?.reloadTableRows]);

  useEffect(() => {
    setPagination(!props?.tableOnly);
  }, [props?.tableOnly]);

  useEffect(() => {
    updatePages(props?.totalPage);
  }, [props?.totalPage]);

  useEffect(() => {
    setRows(props?.rows);
  }, [props?.rows]);

  useEffect(() => {
    if (page === 1) {
      gridApi?.paginationGoToPage(0);
    }
  }, [page]);

  const onViewMore = (e, values) => {
    e.stopPropagation();
    setAnchorElViewMore(e.currentTarget);
    setBoeList(values?.value);
    setItem(values?.params?.item);
  };
  const onViewMoreClose = () => {
    setAnchorElViewMore(null);
  };

  const onDownload = (e) => {
    e.stopPropagation();
    setAnchorElDownload(e?.currentTarget);
  };

  const onDownloadClose = () => {
    setAnchorElDownload(null);
  };

  const onMoreCellClick = (event, data) => {
    if (
      data?.paymentStatus !== undefined ||
      data?.statusCode?.value?.includes("PRE_ACC")
    ) {
      props?.getItem(data);
    }
    setDelItem(data);
    setMorePopup(event.currentTarget);
  };
  const onCloseMorePopup = () => {
    setMorePopup(false);
  };

  const onWithdrawTransaction = () => {
    const { id } = delItem;
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      fidbtxnId: id?.value,
      userName: authData?.userName,
    };
    // API Call
    dispatch(Actions.withdrawTransaction(req));
    onCloseMorePopup();
  };

  const onRescheduleTransaction = () => {
    props?.openRescheduleTransaction(delItem);
    onCloseMorePopup();
  };

  const tooltipContent = (item, props) => {
    let content = `Charges`;
    let freightCharges = "";
    let insuranceCharges = "";
    let miscellaneousCharges = "";
    if (
      item.field === "outstandingCharges" &&
      props?.data?.invoiceCharges?.value
    ) {
      const values = props?.data?.invoiceCharges?.value;
      values?.map((x) => {
        if (x.chargeType === "Freight Charges") {
          freightCharges =
            "Freight: " +
            x?.invoiceCharges?.currency +
            " " +
            x?.invoiceCharges?.amount;
        } else if (x.chargeType === "Insurance Charges") {
          insuranceCharges =
            "Freight: " +
            x?.invoiceCharges?.currency +
            " " +
            x?.invoiceCharges?.amount;
        } else if (x.chargeType === "Miscellaneous Charges") {
          miscellaneousCharges =
            "Freight: " +
            x?.invoiceCharges?.currency +
            " " +
            x?.invoiceCharges?.amount;
        }
      });
    }
    content = (
      <React.Fragment>
        <Typography color="inherit">
          <b>Charges</b>
        </Typography>
        Insurance: {insuranceCharges}
        <br />
        Freight: {freightCharges}
        <br />
        Miscellaneous: {miscellaneousCharges}
        <br />
      </React.Fragment>
    );
    return content;
  };

  const onEditTransaction = () => {
    dispatch(
      Actions.setRecKey({
        recKey: delItem?.id?.value,
        channelRefNo: delItem?.channelRefNo?.value,
      })
    );
    history.push("/make-payment", {
      data: [
        {
          boeNo: {
            value: delItem?.boeList?.value[0]
              ? delItem?.boeList?.value[0].id
              : "",
          },
          currency: {
            value: delItem?.currency?.value,
          },
        },
      ],
    });
  };

  const onDeleteTransaction = () => {
    const { statusCode, id, channelRefNo } = delItem;
    const req = [
      {
        recordStatus: statusCode?.value,
        id: id?.value,
        userId: userId,
        appDate: appDate,
        refNumber: channelRefNo?.value,
      },
    ];
    // API Call
    dispatch(Actions.deleteTransaction(req));
    onCloseMorePopup();
  };

  const onDeleteTransactions = () => {
    const deleteItems = selectedList?.map((sel) => {
      const { statusCode, id, channelRefNo } = sel;
      return {
        recordStatus: statusCode?.value,
        id: id?.value,
        userId: userId,
        appDate: appDate,
        refNumber: channelRefNo?.value,
      };
    });
    // // API Call
    dispatch(Actions.deleteTransaction(deleteItems));
  };

  const onDocClick = (event, item) => {
    setDocItem(item);
    setDocPopup(event.target);
  };

  const onDocClose = () => {
    setDocPopup(null);
  };

  const onDownloadDocument = (item) => {
    let req = {
      recordStatus: docItem?.statusCode?.value,
      id: docItem?.id?.value,
      refNumber: docItem?.channelRefNo?.value,
    };
    const getStatus = () => {
      let status = "";
      switch (item?.label) {
        case "Attached documents":
          status = "UPLOADATTACH";
          return status;
        case "Channel generated documents":
          status = "CHANNELGENDOC";
          return status;
        case "Customer Request Letter":
          status = "REQUESTLETTER";
          return status;
      }
    };
    // API for document download
    dispatch(Actions.downloadDocuments(req, getStatus()));
    onDocClose();
  };

  const ITEM_HEIGHT = 48;

  function isFirstColumn(params) {
    var displayedColumns = params.columnApi.getAllDisplayedColumns();
    var thisIsFirstColumn =
      displayedColumns[0] === params.column && !props?.noRowSelection;
    return thisIsFirstColumn;
  }

  useEffect(() => {
    setPage(1);
    setFilterList(props?.filterOptions);
  }, [props?.filterOptions]);

  useEffect(() => {
    updateSelectedList(props?.selectedList);
    if (props?.selectedList?.length > 0) {
      let len = props?.selectedList?.length;
      gridApi &&
        gridApi.forEachNode((node) => {
          for (let i = 0; i < len; i++) {
            if (node?.data?.id?.value === props?.selectedList?.[i]?.id?.value) {
              node.setSelected(true);
            }
          }
        });
    } else {
      gridApi &&
        gridApi.forEachNode((node) => {
          node.setSelected(false);
        });
    }
  }, [props?.selectedList]);

  const onGridReady = (params) => {
    setGridApi(params.api);
    // default selection functionality
    let len = props?.selectedList?.length;
    params?.api.forEachNode((node) => {
      for (let i = 0; i < len; i++) {
        if (node?.data?.id?.value === props?.selectedList?.[i]?.id?.value) {
          node.setSelected(true);
        }
      }
    });
    if (props?.rowData && props?.rowData.length === 0) {
      params?.api?.showNoRowsOverlay();
    }
    params?.columnApi?.autoSizeAllColumns();
    if (props?.autoSize) {
      params?.api?.sizeColumnsToFit();
    }
    window.addEventListener("resize", () => {
      if (props?.autoSize) {
        params?.api?.sizeColumnsToFit();
      }
    });
  };
  const handleCloseRows = () => {
    setAnchorElRows(null);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(event.target.value);
    props?.callPaginationApi(1, event.target.value);
    gridApi.paginationSetPageSize(Number(event.target.value));
    setPage(1);
    handleCloseRows();
  };

  // const handleChangePage = (event, newPage) => {
  //   if (newPage >= 1 && newPage <= endPage) {
  //     setPage(newPage);
  //     let newPageVAlue = newPage - 1;
  //     gridApi.paginationGoToPage(newPageVAlue);
  //   } else {
  //     let startIndex = 0;
  //     let endIndex = 0;
  //     if (newPage > endPage) {
  //       //"next page condition"
  //       startIndex = endPage + 1;
  //       if (totalPage <= endPage + 5) {
  //         endIndex = totalPage;
  //       } else {
  //         endIndex = endPage + 5;
  //       }
  //     }
  //     //api call for pagination happens here
  //     props?.callPaginationApi(startIndex, rowsPerPage);
  //     updateStartPage(startIndex);
  //     updateEndPage(endIndex);
  //     setPage(newPage);
  //     // let newPageVAlue = newPage - 1;
  //     // gridApi.paginationGoToPage(newPageVAlue);
  //   }
  // };

  const handleChangePage = async (event, newPage) => {
    // Page index is to get the corresponding reqPageIndex for each pagenumber
    let pageIndex;
    //If pages are 5,10,15
    if (newPage % rowsPerPage === 0) {
      pageIndex = parseInt(rowsPerPage) - 5 + 1;
    } else {
      pageIndex = parseInt(newPage - parseInt(newPage % rowsPerPage)) + 1;
    }
    //ArrIndex is to get the corresponding start index range of the array
    // For example if 1 to 5 pagenumber the arrindex will be 0 and for 6 to 10 it will be 24 and for 11 to 15 it will be 49 etc
    let arrIndex = 0; //0, 24, 49
    if (pageIndex * rowsPerPage - rowsPerPage > 0) {
      arrIndex = parseInt(pageIndex * rowsPerPage) - parseInt(rowsPerPage);
    }
    if (!props?.rows[arrIndex]) {
      //If data doesn't exist on specific index then
      //API call to fetch data
      props?.callPaginationApi(pageIndex, rowsPerPage);
      setPage(newPage);
      // let newPageVAlue = newPage - 1;
      // gridApi?.paginationGoToPage?.(newPageVAlue);
      updateStartPage(pageIndex);
      updateEndPage(pageIndex + 4);
    } else {
      setPage(newPage);
      let newPageVAlue = newPage - 1;
      gridApi?.paginationGoToPage?.(newPageVAlue);
    }
  };

  useEffect(() => {
    let newPageVAlue = page - 1;
    setTimeout(() => {
      gridApi?.paginationGoToPage(newPageVAlue);
    }, 100);
  }, [props?.rows]);

  const onClickRows = (event) => {
    setAnchorElRows(event.currentTarget);
  };

  function debounce(func, wait, immediate) {
    var timeout;

    return function executedFunction() {
      var context = this;
      var args = arguments;

      var later = function () {
        timeout = null;
        if (!immediate) func.apply(context, args);
      };

      var callNow = immediate && !timeout;

      clearTimeout(timeout);

      timeout = setTimeout(later, wait);

      if (callNow) func.apply(context, args);
    };
  }

  let nodesToRedraw = [];

  let debounceRedrawRows = debounce((params) => {
    params.api.redrawRows({
      rowNodes: nodesToRedraw,
    });
    nodesToRedraw = [];
  }, 50);

  const onRowSelect = (event) => {
    if (!props?.noRowSelection) {
      var values = event.api.getSelectedRows();
      // Take unique list from selectedlist and values
      // var arr = props?.selectedList?.length > 0 ? props?.selectedList : values;
      var arr = values;
      // const data = values?.map((val) => {
      //   if (
      //     props?.selectedList?.some((sel) => sel?.id?.value !== val?.id?.value)
      //   ) {
      //     arr.push(val);
      //   }
      // });
      var rowCount = arr?.length;
      setSelectedRows(rowCount);
      if (props?.handleRowSelection) {
        props?.handleRowSelection(arr);
      }
    }
    nodesToRedraw.push(event.node);
    debounceRedrawRows(event);
    props?.getSelectedRows?.(arr);
  };

  const fetchTextFieldValue = (id, key) => {
    let result = "";
    if (rows && rows.length > 0) {
      rows.map((item) => {
        if (item?.[key]?.value == id) {
          result = item?.[key]?.value;
        }
      });
      return result;
    } else {
      return "";
    }
  };

  const clearFilters = () => {
    setFilterList([]);
    props?.clearAll();
    if (props?.defaultDateRange) {
      props?.setStartRange(props?.defaultDateRange?.startRange);
      props?.setEndRange(props?.defaultDateRange?.endRange);
    } else {
      props?.setStartRange("");
      props?.setEndRange("");
    }
  };

  const onDeleteChip = (filter) => {
    props?.deleteFilterChip(filter);
    setFilterList((filters) =>
      filters.filter((filt) => {
        if (filt.key != filter.key) {
          if (filt.id != filter.id) {
            return filt;
          }
        } else {
          if (filt.id != filter.id) {
            return filt;
          }
        }
      })
    );
  };

  const gridOptions = {
    rowClassRules: {
      // row style function
      "row-highlight": function (params) {
        return params?.data?.channelRefNo?.showHighlight;
      },
      "row-non-highlight": function (params) {
        return !params?.data?.channelRefNo?.showHighlight;
      },
    },
    defaultColDef: {
      animateRows: true,
      resizable: true,
      sortable: true,
      headerCheckboxSelection: isFirstColumn,
      checkboxSelection: isFirstColumn,
      tooltipComponent: "customTooltip",
      // cellStyle: { border: 'none' }
    },
  };
  const getHeight = () => {
    let height = "240px";
    if (rowsPerPage < rows?.length) {
      height = `${(rowsPerPage + 1) * 70}px`;
    } else {
      if (rows?.length > 0) {
        height = `${(rows?.length + 1) * 72}px`;
      }
    }
    return height;
  };

  return (
    <>
      {!props?.tableOnly && (
        <TableTop
          onSearch={(e) => {
            props?.onSearch(e);
            setPage(1);
          }}
          lessthanSixMonths={props?.lessthanSixMonths}
          greaterthanSixMonths={props?.greaterthanSixMonths}
          setLessthanSixMonth={props?.setLessthanSixMonth}
          setGreaterthanSixMonth={props?.setGreaterthanSixMonth}
          onFilter={props?.onFilter}
          filterList={filterList}
          setStartRange={props?.setStartRange}
          setEndRange={props?.setEndRange}
          startRange={props?.startRange}
          endRange={props?.endRange}
          clearFilters={clearFilters}
          onDeleteChip={onDeleteChip}
          classes={classes}
          isDefaultDateRange={props?.isDefaultDateRange}
        />
      )}
      <div className="tab-mob-view">
        <TabMobView
          rowData={rows}
          columnData={props?.headCells}
          moreActionMenu={props?.moreActionMenu}
          classes={classes}
          morePopup={morePopup}
          onCloseMorePopup={onCloseMorePopup}
          onMoreCellClick={onMoreCellClick}
          nodesToRedraw={nodesToRedraw}
          fetchTextFieldValue={fetchTextFieldValue}
          debounceRedrawRows={debounceRedrawRows}
          selectedList={selectedList}
          handleSelection={props?.handleRowSelection}
          // handleDeletion={props?.handleRowDeletion}
          noRowSelection={props?.noRowSelection}
          hideActionIcon={props?.hideActionIcon}
          tableOnly={props?.tableOnly}
          expireCount={props?.expireCount}
          ti={props?.ti}
          hideMiniTopContainer={props?.hideMiniTopContainer}
          getSelectedRows={props?.getSelectedRows}
          updateSelectedList={updateSelectedList}
          onDownload={props?.onDownload}
          onDeleteTransaction={onDeleteTransactions}
          showOtherScreen={showOtherScreen}
          hideViewMoreLess={props?.hideViewMoreLess}
        />
      </div>
      <div className="table-web-view">
        {/* AG GRID TABLE */}
        <div className="ag-grid-table-container">
          {!props?.tableOnly && (
            <div className="ag-grid-download-box">
              {props?.expireCount > 0 && (
                <div className="expiring-button">
                  <img src={OrangeDot} />
                  <span>{`02 Expiring`}</span>
                  <img src={UpArrow} />
                </div>
              )}
              {props?.ti && (
                <Button
                  className="download-button"
                  classes={{
                    label:
                      selectedRows > 0
                        ? customstyles.label_medium_active
                        : customstyles.label_medium,
                  }}
                  withIcon
                  color="secondary"
                  disabled={selectedRows > 0 ? false : true}
                  onClick={onDeleteTransactions}
                  endIcon={
                    <img src={selectedRows > 0 ? DeleteActive : Delete} />
                  }
                >
                  {" "}
                  Delete
                </Button>
              )}
              <Button
                className="download-button"
                classes={{
                  label:
                    selectedRows > 0
                      ? customstyles.label_medium_active
                      : customstyles.label_medium,
                }}
                withIcon
                color="secondary"
                disabled={selectedRows > 0 ? false : true}
                onClick={onDownload}
                endIcon={
                  <img
                    src={selectedRows > 0 ? DownloadIconActive : DownloadIcon}
                  />
                }
              >
                {" "}
                Download
              </Button>
              <Button
                classes={{
                  label: customstyles.label_medium_active,
                }}
                withIcon
                color="secondary"
                disabled={false}
                endIcon={<img src={CustomizeIcon} />}
              >
                {" "}
                Customize
              </Button>
            </div>
          )}
          <div
            id="myGrid"
            className="ag-theme-material"
            style={{ height: getHeight(), width: "auto", maxHeight: "400px" }}
          >
            <AgGridReact
              gridOptions={gridOptions}
              rowData={rows}
              onGridReady={onGridReady}
              sortingOrder={["desc", "asc"]}
              onRowSelected={!props?.noRowSelection && onRowSelect}
              rowHeight={70}
              rowSelection={"multiple"}
              pagination={props?.tableOnly ? false : true}
              paginationPageSize={rowsPerPage}
              suppressPaginationPanel={true}
              suppressDragLeaveHidesColumns={true}
              // suppressSizeToFit={true}
              tooltipShowDelay={0}
              frameworkComponents={{
                // customTooltip: CustomToolTip
                agColumnHeader: (prop) => {
                  /* Amount right aligning fix */
                  let rightAligned = false;
                  props?.headCells?.map((heading) => {
                    if (heading?.label === prop?.displayName) {
                      rightAligned = heading?.rightAligned;
                    }
                  });
                  return (
                    <CustomTableHeader
                      props={prop}
                      onSort={props?.onSort}
                      rightAligned={rightAligned}
                    />
                  );
                },
              }}
              overlayNoRowsTemplate={
                props?.overlayNoRowsTemplate
                  ? props?.overlayNoRowsTemplate
                  : '<div style="background-color: transparent;"> ' +
                    `<div  class="no-data-box"> <div class="no-data-img"/></div>` +
                    // `<div class="no-data-text"> No records found</div>` +
                    `</div>`
              }
              // onRowClicked={(params) => {
              //     params.api.redrawRows();
              // }}
              suppressRowClickSelection={true}
              onSelectionChanged={(params) => {}}
            >
              {props.headCells &&
                props.headCells.length > 0 &&
                props.headCells.map((item, index) => {
                  return item?.field === "action" && !props?.hideActionIcon ? (
                    <AgGridColumn
                      key={index}
                      maxWidth={50}
                      headerName={item?.label}
                      sortable={false}
                      pinned={"right"}
                      field=""
                      cellStyle={{ padding: "0" }}
                      cellRendererFramework={(props) => {
                        return (
                          <img
                            onClick={(e) => {
                              e.stopPropagation();
                              onMoreCellClick(e, props?.data);
                            }}
                            style={{ cursor: "pointer" }}
                            className="hamburger-icon"
                            src={HamburgerIcon}
                          />
                        );
                      }}
                    />
                  ) : item?.field === "actionButton" ? (
                    <AgGridColumn
                      key={index}
                      headerName={item?.label}
                      sortable={false}
                      minWidth={120}
                      pinned={"right"}
                      field={item?.field}
                      cellRendererFramework={(props) => {
                        return props?.data?.actionButton;
                      }}
                      cellStyle={{ textAlign: "center" }}
                    />
                  ) : item?.field === "doc" && !props?.hideActionIcon ? (
                    <AgGridColumn
                      key={index}
                      maxWidth={50}
                      headerName={item?.label}
                      sortable={false}
                      pinned={"right"}
                      field=""
                      cellRendererFramework={(props) => {
                        return (
                          <img
                            onClick={(e) => {
                              e.stopPropagation();
                              onDocClick(e, props?.data);
                            }}
                            style={{ cursor: "pointer" }}
                            src={DocumentIcon}
                          />
                        );
                      }}
                    />
                  ) : item?.field === "radio" ? (
                    <AgGridColumn
                      key={index}
                      maxWidth={70}
                      headerName={item?.label}
                      sortable={false}
                      field=""
                      pinned={"left"}
                      cellRendererFramework={(cellData) => {
                        return (
                          <div
                            onClick={() => {
                              // if (cellData?.data[item?.field]?.value) {
                              //     props?.getSelectedRows([]);
                              //     updateSelectedList([]);
                              // } else {
                              props?.getSelectedRows([cellData?.data]);
                              updateSelectedList(cellData?.data);
                              gridApi?.redrawRows();
                              // }
                            }}
                          >
                            <Radio
                              checked={cellData?.data[item?.field]?.value}
                            />
                          </div>
                        );
                      }}
                    />
                  ) : item?.showTooltip ? (
                    <AgGridColumn
                      minWidth={item?.smallCell ? 105 : 200}
                      key={index}
                      tooltipField={item?.field}
                      tooltipComponentParams={{ field: item?.field }}
                      cellStyle={stacticStyle}
                      headerName={item.label}
                      field={item?.field}
                      sortable={false}
                      cellRendererFramework={(props) => {
                        const cellValue = props?.value;
                        return (
                          <div
                            style={{ lineHeight: "normal", textAlign: "left" }}
                          >
                            {cellValue?.value}
                          </div>
                        );
                      }}
                    />
                  ) : item?.textField ? (
                    <AgGridColumn
                      key={index}
                      rowHeight={60}
                      maxWidth={240}
                      minWidth={220}
                      field={item?.field}
                      sortable={false}
                      cellStyle={stacticStyle}
                      headerName={item.label}
                      cellRendererFramework={(props) => {
                        const cellValue = props?.data[item?.field];
                        // const isSelected = props?.node?.selected;
                        return (
                          <div className="ag-textfield aggrid-textfield">
                            {
                              // isSelected &&
                              <TextField
                                type="text"
                                variant="filled"
                                adornmentStart={item?.adornmentStart}
                                value={fetchTextFieldValue(
                                  props.data[item?.field].value,
                                  item?.field
                                )}
                                onClick={(e) => {
                                  e.stopPropagation();
                                }}
                                onChange={(e) => {
                                  // validation added for number only field
                                  if (item?.numberOnly) {
                                    if (
                                      !e.target.value?.match(
                                        /^((?!0)\d{0,20}|0|\.\d{1,2})($|\.$|\.\d{1,2}$)/g
                                      ) &&
                                      e.target.value !== ""
                                    ) {
                                      props.data[item?.field].value =
                                        e.target.value?.slice(0, -1);
                                      e.target.value = e.target.value?.slice(
                                        0,
                                        -1
                                      );
                                    }
                                    e.target.value < 0
                                      ? ((e.target.value = 0),
                                        (props.data[item?.field].value = 0))
                                      : ((e.target.value = e.target.value),
                                        (props.data[item?.field].value =
                                          e.target.value));
                                  } else {
                                    props.data[item?.field].value =
                                      e.target.value;
                                  }
                                }}
                                onBlur={(e) => {
                                  e.stopPropagation();
                                  cellValue?.handleUserInput(
                                    e.target.value,
                                    props?.data?.id?.value,
                                    item?.field,
                                    rows
                                  );
                                  nodesToRedraw.push(props.node);
                                  debounceRedrawRows(props);
                                }}
                              />
                            }
                          </div>
                        );
                      }}
                    />
                  ) : item?.numberField ? (
                    <AgGridColumn
                      key={index}
                      rowHeight={60}
                      maxWidth={240}
                      minWidth={220}
                      field={item?.field}
                      sortable={false}
                      cellStyle={stacticStyle}
                      headerName={item.label}
                      cellRendererFramework={(props) => {
                        const cellValue = props?.data[item?.field];
                        const regexTwentyDigitsTwoDecimal =
                          /^((?!0)\d{0,20}|0|\.\d{1,2})($|\.$|\.\d{1,2}$)/g;
                        let validPaybleAmount = null;
                        // const isSelected = props?.node?.selected;
                        return (
                          <div className="ag-textfield aggrid-textfield">
                            {
                              // isSelected &&
                              <TextField
                                type="number"
                                variant="filled"
                                adornmentStart={item?.adornmentStart}
                                inputProps={{
                                  root: {
                                    textAlign: "end",
                                  },
                                }}
                                value={fetchTextFieldValue(
                                  props.data[item?.field].value,
                                  item?.field
                                )}
                                onClick={(e) => {
                                  e.stopPropagation();
                                }}
                                onChange={(e) => {
                                  if (
                                    props?.data?.invoiceCurrency?.value ===
                                    "JPY"
                                  ) {
                                    if (e.target.value % 1 !== 0) {
                                      e.target.value = parseInt(
                                        Number(e.target.value)
                                      );
                                      cellValue?.showToast(
                                        "For JPY currency, amount can not be in decimal"
                                      );
                                    }
                                  }
                                  if (
                                    !e.target.value?.match(
                                      /^((?!0)\d{0,20}|0|\.\d{1,2})($|\.$|\.\d{1,2}$)/g
                                    ) &&
                                    e.target.value !== ""
                                  ) {
                                    e.target.value = e.target.value?.slice(
                                      0,
                                      -1
                                    );
                                  }
                                  //props.data[item?.field].value = e.target.value;
                                  Number(e.target.value) < 0
                                    ? (e.target.value = 0)
                                    : e.target.value;
                                  props.data[item?.field].value =
                                    e.target.value;
                                }}
                                onBlur={(e) => {
                                  e.stopPropagation();
                                  if (
                                    props?.data?.invoiceCurrency?.value ===
                                    "JPY"
                                  ) {
                                    if (e.target.value % 1 !== 0) {
                                      e.target.value = parseInt(
                                        Number(e.target.value)
                                      );
                                      cellValue?.showToast(
                                        "For JPY currency, amount can not be in decimal"
                                      );
                                    }
                                  }
                                  Number(e.target.value) < 0
                                    ? (e.target.value = 0)
                                    : e.target.value;
                                  cellValue?.handleUserInput(
                                    e.target.value,
                                    props?.data?.id?.value,
                                    item?.field,
                                    props?.data
                                  );
                                  nodesToRedraw.push(props.node);
                                  debounceRedrawRows(props);
                                }}
                              />
                            }
                          </div>
                        );
                      }}
                    />
                  ) : item?.dateField ? (
                    <AgGridColumn
                      key={index}
                      rowHeight={60}
                      maxWidth={240}
                      minWidth={180}
                      field={item?.field}
                      sortable={item?.sortable}
                      cellStyle={stacticStyle}
                      headerName={item.label}
                      cellRendererFramework={(props) => {
                        const cellValue = props?.data[item?.field];
                        // const isSelected = props?.node?.selected;
                        return (
                          <div className="ag-textfield ag-datefield">
                            {
                              // isSelected &&
                              <Datepicker
                                type="inline"
                                placeholder="DD/MM/YYYY"
                                className="datePickerFieldAgGrid"
                                onChange={(e) => {
                                  props.data[item?.field].value =
                                    e.toLocaleDateString("en-GB");
                                  cellValue?.handleUserInput(
                                    e.toLocaleDateString("en-GB"),
                                    props?.data?.id?.value,
                                    item?.field,
                                    props?.data
                                  );
                                }}
                                defaultValue={
                                  `${cellValue.value}` === ""
                                    ? { day: "", month: "", year: "" }
                                    : {
                                        day: Number(
                                          `${cellValue.value}`.split("/")[0]
                                        ),
                                        month: Number(
                                          `${cellValue.value}`.split("/")[1]
                                        ),
                                        year: Number(
                                          `${cellValue.value}`.split("/")[2]
                                        ),
                                      }
                                }
                                variant="outlined"
                                name={`${item?.field}`}
                              />
                            }
                          </div>
                        );
                      }}
                    />
                  ) : item?.deleteButton ? (
                    <AgGridColumn
                      key={index}
                      pinned={"right"}
                      rowHeight={60}
                      maxWidth={item?.smallCell ? 120 : 220}
                      sortable={false}
                      cellStyle={stacticStyle}
                      headerName={""}
                      cellRendererFramework={(props) => {
                        const cellValue = props?.value;
                        return (
                          <>
                            <div
                              className="delete-button"
                              onClick={() => {
                                handleRowDeletion(props?.data?.id?.value);
                              }}
                            >
                              <img src={TrashIcon} />
                              <span>Delete</span>
                            </div>
                          </>
                        );
                      }}
                    />
                  ) : (
                    !item?.hideCell && (
                      <AgGridColumn
                        key={index}
                        rowHeight={60}
                        maxWidth={
                          item?.smallCell ? 125 : item?.flex ? 500 : 225
                        }
                        minWidth={
                          item?.smallCell
                            ? 110
                            : item?.field === "channelRefNo" ||
                              item?.field === "paymentStatus"
                            ? 195
                            : item?.largeCell
                            ? 220
                            : item?.minWidth
                            ? item?.minWidth
                            : 160
                        }
                        width={item?.width ? item?.width : "auto"}
                        flex={item?.flex}
                        sortable={item?.sortable}
                        cellStyle={
                          item?.rightAligned
                            ? {
                                ...stacticStyle,
                                display: "flex !important",
                                justifyContent: "flex-end !important",
                              }
                            : item?.field === "boeNo"
                            ? { ...stacticStyle, width: "220px !important" }
                            : stacticStyle
                        }
                        headerName={item.label}
                        cellRendererFramework={(props) => {
                          const cellValue = props?.value;
                          return cellValue?.statusBox ? (
                            <>
                              <div
                                className={
                                  cellValue?.type === "info"
                                    ? "transaction-status-box  info-status"
                                    : cellValue?.type === "success"
                                    ? "transaction-status-box success-status"
                                    : cellValue?.type === "warning"
                                    ? "transaction-status-box warning"
                                    : cellValue?.type === "processed"
                                    ? "transaction-status-box proccessed-status"
                                    : cellValue?.type === "rejected"
                                    ? "transaction-status-box rejected"
                                    : " transaction-status-box rejected-status"
                                }
                              >
                                <span
                                  className={
                                    cellValue?.type === "info"
                                      ? "status-text info-status"
                                      : cellValue?.type === "success"
                                      ? "status-text success-status"
                                      : cellValue?.type === "warning"
                                      ? "status-text warning"
                                      : cellValue?.type === "processed"
                                      ? "status-text proccessed-status"
                                      : cellValue?.type === "rejected"
                                      ? "status-text rejected"
                                      : "status-text rejected-status"
                                  }
                                >
                                  {cellValue?.value}
                                </span>
                              </div>
                            </>
                          ) : cellValue?.textBox ? (
                            cellValue?.value ? (
                              <div className="custom-input-value">
                                {cellValue?.value}
                              </div>
                            ) : (
                              ""
                            )
                          ) : cellValue?.isLink ? (
                            <div
                              className="table-cell-link"
                              onClick={() => {
                                if (cellValue?.link) {
                                  showOtherScreen?.(
                                    cellValue?.link,
                                    cellValue?.params
                                  );
                                  // history.push(
                                  //     cellValue?.link,
                                  //     cellValue?.params
                                  // );
                                }
                              }}
                            >
                              {/* {" "} */}
                              {cellValue?.value}
                            </div>
                          ) : cellValue?.multiValues ? (
                            <div
                              style={{
                                display: "flex",
                                flexDirection: "column",
                                alignItems: "flex-start",
                              }}
                            >
                              <span
                                className="table-cell-link"
                                onClick={() => {
                                  showOtherScreen(cellValue?.value?.[0]?.link, {
                                    item: cellValue?.params.item,
                                    boeNo: cellValue?.value?.[0]?.id,
                                  });
                                  // history.push(cellValue?.value?.[0]?.link, {
                                  //     item: cellValue?.params.item,
                                  //     boeNo: cellValue?.value?.[0]?.id
                                  // })
                                }}
                              >
                                {cellValue?.value?.[0]?.label}
                              </span>
                              {cellValue?.value?.length > 1 && (
                                <span
                                  className="table-cell-link normal-casing"
                                  onClick={(e) => onViewMore(e, cellValue)}
                                >
                                  View more
                                </span>
                              )}
                            </div>
                          ) : (
                            <div>
                              {item?.field === "outstandingCharges" && (
                                <LightTooltip
                                  title={tooltipContent(item, props)}
                                  placement="left-start"
                                >
                                  <img src={IconInfo} />
                                </LightTooltip>
                              )}{" "}
                              {cellValue?.value}
                            </div>
                          );
                        }}
                        field={item?.field}
                        comparator={(
                          valueA,
                          valueB,
                          nodeA,
                          nodeB,
                          isInverted
                        ) => {
                          if (JSON.stringify(isInverted)) {
                            if (props?.onSort) {
                              return props?.onSort(item?.field, isInverted);
                            }
                          }
                        }}
                      />
                    )
                  );
                })}
            </AgGridReact>
          </div>
          {pagination && (
            <CustomTableFooter
              rowsPerPage={rowsPerPage}
              onClickRows={onClickRows}
              classes={classes}
              anchorElRows={anchorElRows}
              handleCloseRows={handleCloseRows}
              rows={rows}
              page={page}
              handleChangePage={handleChangePage}
              handleChangeRowsPerPage={handleChangeRowsPerPage}
              totalPage={totalPage}
            />
          )}
        </div>
      </div>
      {/* Download Menu */}
      <Menu
        className={classes.download}
        id="simple-menu"
        anchorEl={anchorElDownload}
        keepMounted
        open={Boolean(anchorElDownload)}
        onClose={onDownloadClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "20ch",
          },
        }}
      >
        <MenuItem
          onClick={() => {
            props?.onDownload();
            onDownloadClose();
          }}
        >
          Report
        </MenuItem>
        {/* <MenuItem 
                        onClick={()=>{
                            onDownloadClose();
                        }} 
                        >
                            Template
                        </MenuItem> */}
      </Menu>
      {/* BOE list */}
      <Menu
        className={classes.viewmore}
        id="simple-menu"
        anchorEl={anchorElViewMore}
        keepMounted
        open={Boolean(anchorElViewMore)}
        onClose={onViewMoreClose}
        PaperProps={{
          style: {
            maxHeight: ITEM_HEIGHT * 4.5,
            width: "20ch",
          },
        }}
      >
        {boeList.map((boeItem) => {
          return (
            <MenuItem
              onClick={() => {
                onViewMoreClose();
                showOtherScreen(boeItem.link, {
                  item: item,
                  boeNo: boeItem?.id,
                });
                // history.push(boeItem.link, { item: item, boeNo: boeItem?.id });
              }}
              className="table-cell-link"
            >
              {boeItem.label}
            </MenuItem>
          );
        })}
      </Menu>
      {/* Doc menu items */}
      {props?.docActionMenu && (
        <Menu
          className={classes.docMenu}
          anchorEl={docPopup}
          id="simple-menu"
          keepMounted
          open={Boolean(docPopup)}
          onClose={onDocClose}
        >
          {props.docActionMenu.map((item, key) => (
            <MenuItem key={key} onClick={() => onDownloadDocument(item)}>
              <img src={SideArrowIcon} />
              <span className="doc-menu-item">{item.label}</span>
            </MenuItem>
          ))}
        </Menu>
      )}

      {props?.moreActionMenu?.length > 0 && (
        <Menu
          className={classes.morepopup}
          anchorEl={morePopup}
          id="simple-menu"
          keepMounted
          open={Boolean(morePopup)}
          onClose={onCloseMorePopup}
        >
          {props.moreActionMenu?.map((item, key) => {
            let allowOption = false;
            if (
              item?.label === "Edit" &&
              authData?.userRoleType === "M" &&
              (delItem?.statusCode?.value === "DRAFT" ||
                delItem?.statusCode?.value === "REJ_BO" ||
                (delItem?.statusCode?.value?.includes("APL") &&
                  (((delItem?.requestForwardTo?.value === "SELECT" ||
                    delItem?.requestForwardTo?.value === "") &&
                    authData?.userName !== delItem?.initiatedBy?.value) ||
                    authData?.userName === delItem?.requestForwardTo?.value)) ||
                (delItem?.statusCode?.value === "REJ_CM" &&
                  ((delItem?.requestForwardTo?.value === "" &&
                    authData?.userName !== delItem?.initiatedBy?.value) ||
                    delItem?.initiatedBy?.value ===
                      delItem?.requestForwardTo?.value)))
            ) {
              allowOption = true;
            } else if (
              item?.label === "Withdraw" &&
              (delItem?.statusCode?.value?.includes("PRE_ACC") ||
                authData?.userRoleType === "M")
            ) {
              allowOption = true;
            } else if (item?.label === "Reschedule") {
              allowOption = true;
            } else if (
              item?.label === "Delete" &&
              authData?.userRoleType === "M" &&
              delItem?.initiatedBy?.value === authData?.userName &&
              (delItem?.statusCode?.value === "DRAFT" ||
                delItem?.statusCode?.value === "REJ_BO" ||
                (delItem?.statusCode?.value?.includes("APL") &&
                  (((delItem?.requestForwardTo?.value === "SELECT" ||
                    delItem?.requestForwardTo?.value === "") &&
                    authData?.userName !== delItem?.initiatedBy?.value) ||
                    authData?.userName === delItem?.requestForwardTo?.value)) ||
                (delItem?.statusCode?.value === "REJ_CM" &&
                  ((delItem?.requestForwardTo?.value === "" &&
                    authData?.userName !== delItem?.initiatedBy?.value) ||
                    delItem?.initiatedBy?.value ===
                      delItem?.requestForwardTo?.value)))
            ) {
              allowOption = true;
            }
            if (allowOption) {
              return (
                <MenuItem
                  key={key}
                  onClick={() => {
                    if (item?.label === "Delete") {
                      onDeleteTransaction();
                    } else if (item?.label === "Withdraw") {
                      onWithdrawTransaction();
                    } else if (item?.label === "Reschedule") {
                      onRescheduleTransaction();
                    } else if (item?.label === "Edit") {
                      onEditTransaction();
                    }
                  }}
                >
                  <span className="more-text">{item.label}</span>
                </MenuItem>
              );
            }
          })}
        </Menu>
      )}
    </>
  );
};

export default AgGridTable;
