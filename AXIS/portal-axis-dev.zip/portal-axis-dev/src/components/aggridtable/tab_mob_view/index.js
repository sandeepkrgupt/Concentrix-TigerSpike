/* eslint-disable */
import React, { useEffect, useState } from "react";
import "./index.css";
import {
  Button,
  Checkbox,
} from "../../@subzero/glacier/package/lib/components";
import TableRow from "./TableRow";
import DownloadIcon from "../../../assets/icons/download.svg";
import DownloadIconActive from "../../../assets/icons/active-download.svg";
import AccordionComp from "../../../components/accordion";
import OrangeDot from "../../../assets/icons/orange-dot.svg";
import UpArrow from "../../../assets/icons/up-arrow.svg";
import Delete from "../../../assets/icons/trash-inactive.svg";
import DeleteActive from "../../../assets/icons/trash.svg";

const TabMobView = (props) => {
  const {
    hideMiniTopContainer,
    tableOnly,
    hideActionIcon,
    columnData,
    onMoreCellClick,
    moreActionMenu,
    nodesToRedraw,
    fetchTextFieldValue,
    debounceRedrawRows,
    selectedList,
    handleSelection,
    handleDeletion,
    noRowSelection,
    getSelectedRows,
    updateSelectedList,
    showOtherScreen,
    hideViewMoreLess
  } = props;
  const [viewMore, setViewMore] = useState(false);
  const [rowData, setRowData] = useState(props?.rowData);

  useEffect(() => {
    setRowData(props?.rowData);
  }, [props?.rowData]);

  const handleRowDeletion = (row) => {
    const newArrayList = [];
    const selectedArray = JSON.parse(JSON.stringify(selectedList));

    selectedArray.map((rowItem) => {
      if (rowItem?.id?.value !== row?.id?.value) {
        newArrayList.push(rowItem);
      }

      handleDeletion(newArrayList);
    });
  };

  const handleRowSelection = (row) => {
    const newArrayList = [];
    const selectedArray = JSON.parse(JSON.stringify(selectedList));
    let dataFound = false;
    rowData.map((rowItem) => {
      selectedArray &&
        selectedArray.length > 0 &&
        selectedArray.map((item) => {
          if (item?.id === rowItem?.id?.value && row?.id?.value !== item?.id) {
            newArrayList.push(rowItem);
          }
          if (
            item?.id?.value === rowItem?.id?.value &&
            row?.id?.value !== item?.id?.value
          ) {
            newArrayList.push(rowItem);
          }
          if (row?.id?.value === item?.id?.value) {
            dataFound = true;
          }
        });
    });
    if (!dataFound) {
      newArrayList.push(row);
    }
    handleSelection(newArrayList);
  };

  const isSelected = (id) => {
    let selected = false;
    selectedList &&
      selectedList.length > 0 &&
      selectedList.map((item) => {
        if (item?.id?.value === id) {
          selected = true;
        } else if (item?.id === id) {
          selected = true;
        }
      });
    return selected;
  };

  const handleSelectAll = (event) => {
    if (event.target.checked) {
      handleSelection(rowData);
    } else {
      handleSelection([]);
    }
  };
  return (
    <div className="table-mobile-container">
      {rowData?.length === 0 ? (
        <div>
          <span> No records found! </span>
        </div>
      ) : (
        <>
          {!noRowSelection && !hideMiniTopContainer && (
            <div className="table-top-select-all">
              <div className="sort-container">
                <Checkbox
                  label="Select All"
                  onClick={(e) => {
                    handleSelectAll(e);
                  }}
                  checked={
                    rowData?.length > 0
                      ? selectedList?.length === rowData.length
                      : false
                  }
                />
                <div className="top-action-buttons">
                  {props?.expireCount > 0 && (
                    <div className="expiring-button">
                      <img src={OrangeDot} />
                      <span>{`02 Expiring`}</span>
                      <img src={UpArrow} />
                    </div>
                  )}
                  {props?.ti && (
                    <Button
                      onClick={() => props?.onDeleteTransaction()}
                      className="download-button"
                      withIcon
                      hasIconOnly
                      color="secondary"
                      disabled={selectedList?.length > 0 ? false : true}
                      endIcon={
                        <img
                          src={selectedList?.length > 0 ? DeleteActive : Delete}
                        />
                      }
                    />
                  )}
                  <Button
                    onClick={() => props?.onDownload()}
                    className="download-button"
                    withIcon
                    hasIconOnly
                    color="secondary"
                    disabled={selectedList?.length > 0 ? false : true}
                    endIcon={
                      <img
                        src={
                          selectedList?.length > 0
                            ? DownloadIconActive
                            : DownloadIcon
                        }
                      />
                    }
                  />
                </div>
              </div>
              <span>{rowData && rowData.length} entries found</span>
            </div>
          )}
          {rowData &&
            rowData.length > 0 &&
            rowData.map((item, index) => {
              return (
                <AccordionComp
                  key={index}
                  onViewClick={(viewMore) => {
                    setViewMore(viewMore);
                  }}
                >
                  <TableRow
                    key={index}
                    noRowSelection={noRowSelection}
                    handleRowSelection={handleRowSelection}
                    handleRowDeletion={handleRowDeletion}
                    isSelected={isSelected}
                    item={item}
                    index={index}
                    fetchTextFieldValue={fetchTextFieldValue}
                    moreActionMenu={moreActionMenu}
                    onMoreCellClick={onMoreCellClick}
                    columnData={columnData}
                    nodesToRedraw={nodesToRedraw}
                    debounceRedrawRows={debounceRedrawRows}
                    expired={item?.expired}
                    hideActionIcon={hideActionIcon}
                    getSelectedRows={getSelectedRows}
                    updateSelectedList={updateSelectedList}
                    selectedList={selectedList}
                    showOtherScreen={showOtherScreen}
                    hideViewMoreLess={hideViewMoreLess}
                  />
                </AccordionComp>
              );
            })}
        </>
      )}
    </div>
  );
};
export default TabMobView;
