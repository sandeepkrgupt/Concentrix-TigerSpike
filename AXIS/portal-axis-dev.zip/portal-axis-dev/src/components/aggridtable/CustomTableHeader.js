/*eslint-disable*/
import React, { useEffect, useRef, useState } from "react";
import "./tableHeader.css";
import SortArrow from "../../assets/icons/sortArrow.svg";
const CustomTableHeader = (parentProps) => {
  const { props } = parentProps;
  const [sortValue, setSort] = useState("asc");
  const onSortChanged = () => {
    setSort(props.column.isSortAscending() ? "asc" : "desc");
  };
  const onSortRequested = (order, event) => {
    props.setSort(order, event.shiftKey);
    parentProps?.onSort?.(
      props?.column?.colDef?.field,
      order == "desc" ? false : true
    );
  };
  useEffect(() => {
    props?.column?.addEventListener?.("sortChanged", onSortChanged);
    onSortChanged();
  }, []);
  let sort = null;
  if (props?.enableSorting) {
    sort = (
      <div style={{ display: "inline-block", marginLeft: "-20px"  }}>
        <div className={`customSortDownLabel ${sortValue}`}>
          <img src={SortArrow} />
        </div>
      </div>
    );
  }
  return (
    <div
      className="custom-head"
      /* Amount right aligning fix */
      style={parentProps?.rightAligned ? {display: "flex", justifyContent: "flex-end"} : {}}
      onClick={(event) => {
        event.stopPropagation();
        event.preventDefault();
        if (sortValue == "asc") {
          onSortRequested("desc", event);
        } else {
          onSortRequested("asc", event);
        }
      }}
      onTouchEnd={(event) => {
        if (sortValue == "asc") {
          onSortRequested("desc", event);
        } else {
          onSortRequested("asc", event);
        }
      }}
    >
      <div className="customHeaderLabel" 
      >{props?.displayName}</div>
      {sort}
    </div>
  );
};
export default CustomTableHeader;