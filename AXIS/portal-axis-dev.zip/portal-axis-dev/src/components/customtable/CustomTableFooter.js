import React from 'react';
import Dropdown from '../../assets/icons/dropdown.svg';
import { Pagination } from '@material-ui/lab';
import { Menu, MenuItem } from '@material-ui/core';
const CustomTableFooter = (props) => {

    const { rowsPerPage, onClickRows, classes, anchorElRows,
        handleCloseRows, rows, handleChangePage, handleChangeRowsPerPage
    } = props;
    return (
        <>
            <div className="footer-container">
                <div>
                    <span className="entries">100 entries found</span>
                </div>
                <div className="pagination-container">
                    <span className="per-page">Rows per page</span>
                    <div className="count-dropdown" onClick={onClickRows}>
                        <span>{rowsPerPage}</span>
                        <img src={Dropdown} />
                    </div>
                    <Menu
                        className={classes.menuRows}
                        anchorEl={anchorElRows}
                        id="simple-menu"
                        keepMounted
                        open={Boolean(anchorElRows)}
                        onClose={handleCloseRows}
                    >
                        {
                            [5, 10, 20, 30, 40].map((count, index) => {
                                return (
                                    <MenuItem key={index} value={count} onClick={handleChangeRowsPerPage}>{count}</MenuItem>
                                )
                            })
                        }
                    </Menu>
                    <Pagination onChange={handleChangePage} className={classes.pagination} count={rows.length < rowsPerPage ? 1 : Math.ceil(rows.length / rowsPerPage)} shape="rounded" />
                </div>
            </div>
        </>
    )
}

export default CustomTableFooter;