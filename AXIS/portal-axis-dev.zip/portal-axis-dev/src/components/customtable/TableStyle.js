import { makeStyles } from '@material-ui/core/styles';

const TableStyle = makeStyles((theme) => ({
    root: {
        width: '100%',
        alignItems: 'left',
        overflowX: 'auto',
    },
    paper: {
        width: '100%',
        overflowX: 'auto',
        marginBottom: theme.spacing(2),
    },
    table: {
        minWidth: 750,
        '& .MuiTableCell-stickyHeader': {
            backgroundColor: "#F1F4F7"
        }
    },
    container: {
        maxHeight: 440,
    },
    visuallyHidden: {
        border: 0,
        clip: 'rect(0 0 0 0)',
        height: 1,
        margin: -1,
        overflow: 'hidden',
        padding: 0,
        position: 'absolute',
        top: 20,
        width: 1,
    },

    pagination: {
        '& .Mui-selected': {
            width: '28px',
            height: '28px',
            borderRadius: '8px',
            background: '#282828',
            fontFamily: 'Lato',
            fontStyle: 'normal',
            fontWeight: 'bold',
            fontSize: '12px',
            lineHeight: '16px',
            display: 'flex',
            alignItems: 'center',
            textAlign: 'center',
            letterSpacing: '0.32px',
            color: '#FFFFFF',
        },
        '& .MuiPaginationItem-icon': {
            width: '28px',
            height: '28px',
            borderRadius: '8px',
            background: '#CBCBCB',
        }
    },
    chip: {
        background: '#F1F4F7',
        borderRadius: '4px',
        fontFamily: 'Lato',
        fontStyle: 'normal',
        fontWeight: 'normal',
        fontSize: '10px',
        lineHeight: '10px',
        display: 'flex',
        alignItems: 'center',
        letterSpacing: '0.32px',
        textTransform: 'uppercase',
        color: '#282828',
        margin: '10px',
        padding: '10px'
    },
    menu: {
        '& .MuiPopover-paper': {
            marginTop: "50px",
            marginLeft: "-30px",
            width: "82px",
            height: "160px",
            borderRadius: "0px 0px 8px 8px",
            boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.14)"
        },
        '& .MuiListItem-root': {
            height: '48px',
            fontFamily: 'Lato',
            fontStyle: 'normal',
            fontWeight: 'normal',
            fontSize: '16px',
            lineHeight: '24px',
            letterSpacing: '0.16px',
            color: '#282828',
            '&:hover': {
                backgroundColor: "#F9F9F9 !important"
            },
        },
       
        '& .Mui-focusVisible': {
            backgroundColor: "transparent"
        }
    },
    menuDoc: {
        '& .MuiPopover-paper': {
            marginTop: "20px",
            marginLeft: "-170px",
            width: "295px",
            height: "160px",
            borderRadius: "0px 0px 8px 8px",
            boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.14)"
        },
        '& .MuiListItem-root': {
            height: '48px',
            fontFamily: 'Lato',
            fontStyle: 'normal',
            fontWeight: 'normal',
            fontSize: '16px',
            lineHeight: '24px',
            letterSpacing: '0.16px',
            color: '#145599',
            '&:hover': {
                backgroundColor: "#FDE5EE !important"
            },
        },
        '& .Mui-focusVisible': {
            backgroundColor: "transparent"
        }
    },
    beneficaryPopup: {
        '& .MuiPopover-paper': {
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            padding: "8px 0px",
            width: "215px",
            height: " 80px",
            background: "#FFFFFF",
            border: "0.5px solid #F1F1F1",
            boxSizing: "border-box",
            boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.14)",
            borderRadius: "8px",
            textAlign: "center",

        },

    },
    boePopup: {
        '& .MuiPopover-paper': {
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            padding: "8px 0px",
            width: "93px",
            height: "120px",
            background: "#FFFFFF",
            border: "0.5px solid #F1F1F1",
            boxSizing: "border-box",
            boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.14)",
            borderRadius: "8px",
            textAlign: "center",
        },

    },
    morepopup: {
        '& .MuiPopover-paper': {
            display: "flex",
            marginLeft: "-85px",
            flexDirection: "column",
            alignItems: "flex-start",
            padding: "8px 0px",
            // width: "106px",
            // height: "160px",
            width: "auto",
            height: "auto",
            background: "#FFFFFF",
            border: "0.5px solid #F1F1F1",
            boxSizing: "border-box",
            boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.14)",
            borderRadius: "8px",
            textAlign: "center",
        },
        '& .MuiListItem-root': {
            height: '48px',
            fontFamily: 'Lato',
            fontStyle: 'normal',
            fontWeight: 'normal',
            fontSize: '16px',
            lineHeight: '24px',
            letterSpacing: '0.16px',
            color: '#282828',
            '&:hover': {
                backgroundColor: "#FDE5EE !important"
            },
        },
        '& .Mui-focusVisible': {
            backgroundColor: "transparent"
        }
    },
    menuRows: {
        '& .MuiPopover-paper': {
            marginTop: "50px",
            marginLeft: "0px",
            width: "83px",
            height: "148px",
        },
        '& .MuiListItem-root': {
            height: '44px',
            fontFamily: 'Lato',
            fontStyle: 'normal',
            fontWeight: 'normal',
            fontSize: '14px',
            lineHeight: '20px',
            letterSpacing: '0.26px',
            color: '#404040',
            '&:hover': {
                backgroundColor: "transparent"
            },
        },
        '& .Mui-focusVisible': {
            backgroundColor: "transparent"
        },
        '& .Mui-selected': {
            backgroundColor: "#F9F9F9 !important"
        }
    },
}));

export default TableStyle