/* eslint-disable */
import React from 'react';
import Table from '@material-ui/core/Table';
import TableContainer from '@material-ui/core/TableContainer';
import Paper from '@material-ui/core/Paper';
import './index.css';
import CustomTableHead from './CustomTableHead'
import CustomTableBody from './CustomTableBody';
import CustomTableFooter from './CustomTableFooter';
import CustomTableActions from './CustomTableActions';
import useStyles from './TableStyle';
import FilterIcon from '../../assets/icons/filter.svg';
import DownloadIcon from '../../assets/icons/download.svg';
import DownloadIconActive from '../../assets/icons/download-active.svg';
import RedDot from '../../assets/icons/red-dot.svg';
import { Select, MenuItem, FormControl, InputLabel } from '@material-ui/core';
import { TextField, Datepicker, Dropdown } from '../../components/@subzero/glacier/package/lib/components';

export default function CustomTable(props) {
    const classes = useStyles();
    const [order, setOrder] = React.useState('asc');
    const [orderBy, setOrderBy] = React.useState('calories');
    const [selected, setSelected] = React.useState([]);
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(5);
    const [anchorElDownload, setAnchorElDownload] = React.useState(null);
    const [anchorElRows, setAnchorElRows] = React.useState(null);


    const handleRequestSort = (event, property) => {
        const isAsc = orderBy === property && order === 'asc';
        setOrder(isAsc ? 'desc' : 'asc');
        setOrderBy(property);
    };

    const handleSelectAllClick = (event) => {
        if (event.target.checked) {
            const newSelecteds = props.rows.map((n) => n.refNo);
            setSelected(newSelecteds);
            return;
        }
        setSelected([]);
    };
    const isSelected = (refNo) => selected.indexOf(refNo) !== -1;

    const handleClick = (event, refNo) => {
        const selectedIndex = selected.indexOf(refNo);
        let newSelected = [];
        if (selectedIndex === -1) {
            newSelected = newSelected.concat(selected, refNo);
        } else if (selectedIndex === 0) {
            newSelected = newSelected.concat(selected.slice(1));
        } else if (selectedIndex === selected.length - 1) {
            newSelected = newSelected.concat(selected.slice(0, -1));
        } else if (selectedIndex > 0) {
            newSelected = newSelected.concat(
                selected.slice(0, selectedIndex),
                selected.slice(selectedIndex + 1),
            );
        }

        setSelected(newSelected);
    };

    const handleChangePage = (event, newPage) => {
        // setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        handleCloseRows();
        setRowsPerPage(event.target.value);
        setPage(0);
    };


    const onClickDownload = (event) => {
        setAnchorElDownload(event.currentTarget);
    }

    const handleClose = () => {
        setAnchorElDownload(null);
    }

    const onClickRows = (event) => {
        setAnchorElRows(event.currentTarget);
    }

    const handleCloseRows = () => {
        setAnchorElRows(null);
    }

    return (
        <div className={classes.root}>
            {!props.hideTableActions &&
                <>
                    <div className="table-search">
                        <div className="transaction-search" id="table-search-icon">

                        </div>
                        <TextField label="Search Name" />
                        <div className="action-icons">
                            <img src={FilterIcon} onClick={() => { props.updateFilterDisplay() }} />
                            <img onClick={onClickDownload} src={anchorElDownload ? DownloadIconActive : DownloadIcon} />
                        </div>
                    </div>
                    <div className="date-component">
                        <Datepicker
                            placeholder="04/06/2021-04/06/2022"
                            rangePicker={true} />
                    </div>
                    <div className="filter-component">
                        <div className="transaction-search" id="table-search-icon">
                            <input type="text" placeholder="Search Name" />
                        </div>
                        <div className="action-icons">
                            <img src={FilterIcon} onClick={() => { props.updateFilterDisplay() }} />
                        </div>
                    </div>
                    <div className="resp-table-container">
                        <div className="table-header">
                            <span>100 Entries found</span>
                            <FormControl className={classes.formControl}>
                                <InputLabel id="demo-simple-select-readonly-label">Name</InputLabel>
                                <Select
                                    labelId="demo-simple-select-readonly-label"
                                    id="demo-simple-select-readonly"
                                    // value={age}
                                    // onChange={handleChange}
                                    inputProps={{ readOnly: true }}
                                >
                                    <MenuItem value="">
                                        <em>None</em>
                                    </MenuItem>
                                    <MenuItem value={10}>Ten</MenuItem>
                                    <MenuItem value={20}>Twenty</MenuItem>
                                    <MenuItem value={30}>Thirty</MenuItem>
                                </Select>

                            </FormControl>
                        </div>
                        <div className="table-row">
                            <div className="table-row-heading">
                                <div>
                                    <img className="" src={RedDot} />
                                    <span className=" rejected-by-auth"><span className="status-text rejected-by-auth">02 Days</span></span>
                                </div>

                            </div>
                        </div>
                    </div>
                </>}

            <Paper className={`table-container ${classes.paper}`}>
                {!props.hideTableActions &&
                    <CustomTableActions
                        classes={classes}
                        updateFilterDisplay={props.updateFilterDisplay}
                        handleClose={handleClose}
                        onClickDownload={onClickDownload}
                        anchorElDownload={anchorElDownload}
                        filterValues={props.filterValues}
                        showDelete={false}
                        showEdit={false}
                        showFilter={true}
                        showDownload={true}
                    />}
                <TableContainer className={classes.container}>
                    <Table
                        stickyHeader
                        className={classes.table}
                        aria-labelledby="tableTitle"
                        size={'medium'}
                        aria-label="enhanced table"
                    >
                        <CustomTableHead
                            classes={classes}
                            numSelected={selected.length}
                            order={order}
                            orderBy={orderBy}
                            onSelectAllClick={handleSelectAllClick}
                            onRequestSort={handleRequestSort}
                            rowCount={props.rows.length}
                            headCells={props.headCells}
                        />
                        <CustomTableBody classes={classes}
                            rows={props.rows}
                            order={order}
                            orderBy={orderBy}
                            page={page}
                            rowsPerPage={rowsPerPage}
                            isSelected={isSelected}
                            handleClick={handleClick}
                            moreActionMenu={props.moreActionMenu}
                            hideActionIcon={props.hideActionIcon ? props.hideActionIcon : false}
                        />
                    </Table>
                </TableContainer>
                <CustomTableFooter
                    rowsPerPage={rowsPerPage}
                    onClickRows={onClickRows}
                    classes={classes}
                    anchorElRows={anchorElRows}
                    handleCloseRows={handleCloseRows}
                    rows={props.rows}
                    handleChangePage={handleChangePage}
                    handleChangeRowsPerPage={handleChangeRowsPerPage} />

            </Paper>


        </div >
    );
}
