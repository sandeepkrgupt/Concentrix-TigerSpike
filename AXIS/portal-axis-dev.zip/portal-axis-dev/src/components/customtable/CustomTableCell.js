/* eslint-disable */
import React from 'react'
import TableCell from '@material-ui/core/TableCell';
import RedDot from '../../assets/icons/red-dot.svg';
import { Menu } from '@material-ui/core';

const CustomTableCell = ({ row, cellValue, labelId, classes }) => {

    const handleCellOver = (e, refNo) => {

        if (cellValue.hoverAction) {
            cellValue.onCellHover(e, refNo)
        }

    }

    return (
        <>

            <TableCell width={cellValue.smallCell ? "5%" : ""} align="left" component="th" onMouseEnter={(e) => {
                handleCellOver(e, row["refNo"].value)

            }} >
                {cellValue.statusBox ?
                    <>
                        <span className={row["status"].type === "info"
                            ? "transaction-status-box  info-status"
                            : row["status"].type === "success"
                                ?
                                "payment-status-box success-status"
                                : row["status"].type === "warning"
                                    ? "transaction-status-box warning"
                                    : row["status"].type === "processed"
                                        ? "transaction-status-box proccessed-status"
                                        : row["status"].type === "rejected"
                                            ? "transaction-status-box rejected"
                                            : " payment-status-box rejected-status"}>
                            <span className={row["status"].type === "info"
                                ? "status-text info-status"
                                : row["status"].type === "success"
                                    ? "payment-status-text success-status"
                                    : row["status"].type === "warning" ?
                                        "status-text warning"
                                        :
                                        row["status"].type === "processed"
                                            ? "status-text proccessed-status"
                                            : row["status"].type === "rejected"
                                                ? "status-text rejected"
                                                : "payment-status-text rejected-status"}
                            >{row["status"].label}</span></span>
                    </> :
                    cellValue.textBox ?
                        cellValue.value ?
                            <div className="custom-input-value">{cellValue.value}</div> : "" :
                        <div className={cellValue.isLink ? "table-cell-link" : ""}> {cellValue.value} {cellValue.showHighlight && row["status"].value === "scheduled" && <img className="scheduled-status-dot" src={RedDot} />} </div>}
            </TableCell>
            <Menu
                className={classes.beneficaryPopup}
                anchorEl={cellValue.controlState}
                id="simple-menu"
                keepMounted
                open={Boolean(cellValue.controlState)}
                onClose={() => { cellValue.onMouseLeave() }}
                onMouseOut={() => { cellValue.onMouseLeave() }}
            >
                <span onMouseOut={() => { cellValue.onMouseLeave() }} className={cellValue.isMenuLink ? "popup-text-link" : "popup-text"}>
                    {cellValue.menuValue}
                </span>

            </Menu>


        </>

    )
}

export default CustomTableCell;