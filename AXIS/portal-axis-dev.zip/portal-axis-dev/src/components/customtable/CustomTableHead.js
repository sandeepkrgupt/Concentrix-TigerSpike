import React from 'react';
import PropTypes from 'prop-types';
import TableHead from '@material-ui/core/TableHead';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Checkbox from '@material-ui/core/Checkbox';
import ActionIcon from '../../assets/icons/action.svg';


function CustomTableHead(props) {

    const { classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort, headCells, hideCheckBox } = props;

    const createSortHandler = (property) => (event) => {
        onRequestSort(event, property);
    };
    
    return (
        <>
            <TableHead className="table-head">
                <TableRow>
                    {!hideCheckBox &&
                        <TableCell padding="checkbox">
                            <Checkbox
                                indeterminate={numSelected > 0 && numSelected < rowCount}
                                checked={rowCount > 0 && numSelected === rowCount}
                                onChange={onSelectAllClick}
                                inputProps={{ 'aria-label': 'select all desserts' }}
                            />
                        </TableCell>}
                    {headCells && headCells.length > 0 && headCells.map((headCell) => (
                        !headCell?.hideCell && (
                            <TableCell
                                width={headCell.smallCell ? "5%" : ""}
                                key={headCell.id}
                                // align={headCell.numeric ? 'right' : 'left'}
                                padding={headCell.disablePadding ? 'none' : 'default'}
                                sortDirection={orderBy === headCell.id ? order : false}
                            >
                                <TableSortLabel
                                    active={orderBy === headCell.id}
                                    direction={orderBy === headCell.id ? order : 'asc'}
                                    onClick={createSortHandler(headCell.id)}
                                    className="heading-name"
                                >
                                    {headCell.id === "action" ? <img src={ActionIcon} /> : headCell.label}
                                    {orderBy === headCell.id ? (
                                        <span className={classes.visuallyHidden}>
                                            {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                                        </span>
                                    ) : null}
                                </TableSortLabel>
                            </TableCell>)
                    ))}
                </TableRow>
            </TableHead>

        </>

    );
}
export default CustomTableHead;

CustomTableHead.propTypes = {
    classes: PropTypes.object.isRequired,
    numSelected: PropTypes.number.isRequired,
    onRequestSort: PropTypes.func.isRequired,
    onSelectAllClick: PropTypes.func.isRequired,
    order: PropTypes.oneOf(['asc', 'desc']).isRequired,
    orderBy: PropTypes.string.isRequired,
    rowCount: PropTypes.number.isRequired,
};

