import React from "react";
// import Logo from "../../assets/icons/Axis-Bank-Logo.svg";
import './styles.css';
import Lottie from 'react-lottie';
import animationData from './loader';

const Loader = () => {
  // return (
  //   <div 
  //   className="loader-container"
  //   >
  //     <img src={Logo} className="loader-icon"/>
  //   </div>
  // );
  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: animationData,
    rendererSettings: {
      preserveAspectRatio: "xMidYMid slice"
    }
  };

  return (
    <div>
      <Lottie 
        options={defaultOptions}
        height={200}
        width={200}
      />
    </div>
  );
};
export default Loader;
