import Accordion from './Accordion';
import { AccordionProps } from './Accordion.type';
export type { AccordionProps };
export default Accordion;
