import ProgressIndicator from './ProgressIndicator';
import { ProgressIndicatorProps } from './ProgressIndicator.type';
export type { ProgressIndicatorProps };
export default ProgressIndicator;
