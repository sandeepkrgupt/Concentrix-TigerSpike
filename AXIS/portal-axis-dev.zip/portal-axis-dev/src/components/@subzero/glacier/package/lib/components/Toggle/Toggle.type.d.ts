import { Ref } from 'react';
import { SwitchProps as MuiSwitchProps, SwitchClassKey } from '@material-ui/core';
export interface ToggleStylingProps extends Partial<Record<SwitchClassKey, string>> {
    rootBtn?: string;
    selected?: string;
    unselected?: string;
    switchBtn?: string;
    switchBtn1?: string;
    switchBase?: string;
    switchBase1?: string;
    thumb?: string;
    thumb1?: string;
    unselectedThumb?: string;
    colorSecondary?: string;
    colorSecondary1?: string;
    colorPrimary?: string;
    track?: string;
    unselectedtrack?: string;
    checked?: string;
    checked1?: string;
    ripple?: string;
}
export interface ToggleProps extends MuiSwitchProps {
    innerRef: Ref<HTMLDivElement>;
    checked: boolean;
    onChange?: (value: any) => void;
}
