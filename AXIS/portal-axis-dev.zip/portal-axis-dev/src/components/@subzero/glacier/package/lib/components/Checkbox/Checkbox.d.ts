/// <reference types="react" />
declare const Checkbox: (props: any) => JSX.Element;
export default Checkbox;
