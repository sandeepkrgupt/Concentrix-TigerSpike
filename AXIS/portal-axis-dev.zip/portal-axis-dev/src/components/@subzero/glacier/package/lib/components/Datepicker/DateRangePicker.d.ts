/// <reference types="react" />
declare const _default: import("react").ComponentType<Pick<{
    [x: string]: any;
    classes: any;
    value: any;
    onChange: any;
    labelFunc: any;
    format: any;
    emptyLabel: any;
    autoOk: any;
    onOpen: any;
    onClose: any;
    open: any;
}, string | number> & import("@material-ui/core/styles").StyledComponentProps<"hidden" | "current" | "dateRangePickerDialog" | "day" | "dayDisabled" | "focusedRange" | "beginCap" | "endCap" | "focusedFirst" | "focusedLast">>;
export default _default;
