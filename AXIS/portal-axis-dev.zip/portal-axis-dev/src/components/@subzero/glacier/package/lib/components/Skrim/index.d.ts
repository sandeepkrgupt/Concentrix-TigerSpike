import Skrim from './Skrim';
import { SkrimProps } from './Skrim.type';
export type { SkrimProps };
export default Skrim;
