import Toogle from './Toggle';
import { ToggleProps } from './Toggle.type';
export type { ToggleProps };
export default Toogle;
