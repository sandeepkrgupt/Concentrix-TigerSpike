/// <reference types="react" />
declare const ArrowForwardComp: () => JSX.Element;
export default ArrowForwardComp;
