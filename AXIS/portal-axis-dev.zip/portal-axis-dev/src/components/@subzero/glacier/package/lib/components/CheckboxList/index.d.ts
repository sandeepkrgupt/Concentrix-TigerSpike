import CheckboxList from './CheckboxList';
import { CheckboxListProps } from './CheckboxList.type';
export type { CheckboxListProps };
export default CheckboxList;
