import Header from './Header';
import { HeaderProps } from './Header.type';
export type { HeaderProps };
export default Header;
