import { Ref } from 'react';
import { FabProps as MuiFloatingActionBtnProps, FabClassKey } from '@material-ui/core/Fab';
export interface FloatingActionBtnStylingProps extends Partial<Record<FabClassKey, string>> {
    extended?: string;
    FabDefault?: string;
    FabClose?: string;
    ripple?: string;
    iconText?: string;
    icon?: string;
    iconSmall?: string;
    extendedTextIcon?: string;
    extendedText?: string;
    extendedIconMedium?: string;
    extendedIconSmall?: string;
}
export interface FloatingActionBtnProps extends MuiFloatingActionBtnProps {
    innerRef?: Ref<HTMLButtonElement>;
    size: 'small' | 'medium';
    FabVariant: 'icon' | 'text' | 'iconText';
    FabType: 'close' | 'default';
    onClick?: (e: any) => {};
}
