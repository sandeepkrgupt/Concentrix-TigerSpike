import { FC } from 'react';
import { ProgressTrackerProps } from './ProgressTracker.type';
declare const ProgressTracker: FC<ProgressTrackerProps>;
export default ProgressTracker;
