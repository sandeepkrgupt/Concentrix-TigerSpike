/// <reference types="react" />
declare const CheckUnSelectedComp: () => JSX.Element;
export default CheckUnSelectedComp;
