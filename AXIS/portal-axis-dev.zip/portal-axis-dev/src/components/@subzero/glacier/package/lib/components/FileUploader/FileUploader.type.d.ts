export interface FileUploaderStylingProps {
    fileuploaderInput?: string;
    main?: string;
    fileuploader?: string;
    fileuploaderInputTop?: string;
    fileuploaderInputBottom?: string;
    uploadCard?: string;
    uploadCardLeft?: string;
    uploadCardLeftIcon?: string;
    titles?: string;
    uploadCardRight?: string;
    show?: string;
    hide?: string;
    uploadCardRightCloseButton?: string;
}
export interface FileUploaderProps {
    doneCallback?: (files: any) => void;
    type: 'pdf' | 'doc' | 'docx' | 'xls' | 'xlsx' | 'image' | 'video' | 'audio';
    description?: string;
    value: number;
    error?: boolean;
}
