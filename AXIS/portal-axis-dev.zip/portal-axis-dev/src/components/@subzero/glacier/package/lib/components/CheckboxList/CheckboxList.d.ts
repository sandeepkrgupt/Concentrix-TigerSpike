import { FC } from 'react';
import { CheckboxListProps } from './CheckboxList.type';
declare const CheckboxList: FC<CheckboxListProps>;
export default CheckboxList;
