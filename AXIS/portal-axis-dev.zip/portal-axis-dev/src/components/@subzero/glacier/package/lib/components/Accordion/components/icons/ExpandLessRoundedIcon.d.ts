/// <reference types="react" />
declare const ExpandLessRoundedIcon: () => JSX.Element;
export default ExpandLessRoundedIcon;
