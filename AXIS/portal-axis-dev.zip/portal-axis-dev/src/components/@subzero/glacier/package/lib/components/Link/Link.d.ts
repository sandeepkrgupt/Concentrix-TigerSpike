/// <reference types="react" />
declare const Link: (props: any) => JSX.Element;
export default Link;
