import { FC } from 'react';
import { TypographyProps } from './Typography.type';
declare const Typography: FC<TypographyProps>;
export default Typography;
