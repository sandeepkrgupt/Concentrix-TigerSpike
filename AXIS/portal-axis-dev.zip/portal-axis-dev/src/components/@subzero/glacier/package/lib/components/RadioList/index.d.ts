import RadioList from './RadioList';
import { RadioListProps } from './RadioList.type';
export type { RadioListProps };
export default RadioList;
