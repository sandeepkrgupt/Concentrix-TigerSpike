import { FilledTextFieldProps as MuiDropdownProps, TextFieldClassKey } from '@material-ui/core/TextField';
export interface DropdownStylingProps extends Partial<Record<TextFieldClassKey, string>> {
    item?: string;
    paperRoot?: string;
    rippleClasses?: string;
    margin?: string;
    withoutLabel?: string;
    textField?: string;
    helperText?: string;
    labelRoot?: string;
    labelRootError?: string;
    shrink?: string;
    labelRootFocused?: string;
    labelRootDisabled?: string;
    inputRoot?: string;
    disabled?: string;
    error?: string;
    inputRootDisabled?: string;
    inputAdornment?: string;
    IconButton?: string;
    show?: string;
    hide?: string;
    inputStart?: string;
    focused?: string;
    filled?: string;
}
export interface DropdownProps extends MuiDropdownProps {
    items: any[];
    defaultValue?: any;
    errorMsg?: string;
    onChange: (e: any) => void;
    onBlur: (e: any) => void;
}
