import { FC } from 'react';
import { RadioListProps } from './RadioList.type';
declare const RadioList: FC<RadioListProps>;
export default RadioList;
