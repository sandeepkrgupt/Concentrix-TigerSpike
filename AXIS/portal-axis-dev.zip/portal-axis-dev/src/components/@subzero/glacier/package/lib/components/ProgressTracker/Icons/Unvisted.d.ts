import { FC } from 'react';
import { IconProps } from '../ProgressTracker.type';
declare const Unvisited: FC<IconProps>;
export default Unvisited;
