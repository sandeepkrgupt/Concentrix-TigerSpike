import { FC } from 'react';
import { IconProps } from '../ProgressTracker.type';
declare const SuccessIcon: FC<IconProps>;
export default SuccessIcon;
