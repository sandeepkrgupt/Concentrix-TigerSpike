export interface ClassesDictionary extends Record<string, string> {
    root: string;
}
export declare const mergeClassesObjects: <T = ClassesDictionary, O = T>(baseClassesObj: O extends T ? O : never, overrideClassesObj?: T) => T;
