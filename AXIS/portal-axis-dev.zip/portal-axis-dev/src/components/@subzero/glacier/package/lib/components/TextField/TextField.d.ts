/// <reference types="react" />
declare const TextField: (props: any) => JSX.Element;
export default TextField;
