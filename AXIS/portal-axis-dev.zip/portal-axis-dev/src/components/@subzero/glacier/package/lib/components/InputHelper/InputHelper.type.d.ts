import { Ref } from 'react';
import { TypographyProps as MuiInputHelperProps, TypographyClassKey } from '@material-ui/core';
export interface InputHelperStylingProps extends Partial<Record<TypographyClassKey, string>> {
    inputWraper?: string;
    valueWraper?: string;
    valueWraperSelected?: string;
    rootContainer?: string;
    valueSpan?: string;
    valueSpanSelected?: string;
}
export interface InputHelperProps extends MuiInputHelperProps {
    innerRef?: Ref<HTMLDivElement>;
    inputValues?: [number, number, number];
    prefix?: any;
    suffix?: any;
    trailingIcon?: any;
    label: string;
    helperText?: string;
    placeholder: string;
    onChange?: (value: any) => void;
    defaultValue?: number | string;
}
