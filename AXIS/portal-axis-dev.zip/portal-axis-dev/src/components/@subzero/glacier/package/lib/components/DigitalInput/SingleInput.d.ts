import * as React from 'react';
export interface SingleOTPInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
    focus?: boolean;
}
export declare function SingleOTPInputComponent(props: SingleOTPInputProps): JSX.Element;
export default SingleOTPInputComponent;
