import { FC } from 'react';
import { IconProps } from '../ProgressTracker.type';
declare const CurrentIcon: FC<IconProps>;
export default CurrentIcon;
