import { FC } from 'react';
import { YesNoSwitchProps } from './YesNoSwitch.type';
declare const YesNoSwitch: FC<YesNoSwitchProps>;
export default YesNoSwitch;
