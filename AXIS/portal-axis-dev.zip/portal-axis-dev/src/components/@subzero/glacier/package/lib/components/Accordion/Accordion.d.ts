/// <reference types="react" />
declare const Accordion: (props: any) => JSX.Element;
export default Accordion;
