import Divider from './Divider';
import { DividerProps } from './Divider.type';
export type { DividerProps };
export default Divider;
