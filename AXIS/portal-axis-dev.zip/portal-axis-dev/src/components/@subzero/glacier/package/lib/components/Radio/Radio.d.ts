/// <reference types="react" />
declare const Radio: (props: any) => JSX.Element;
export default Radio;
