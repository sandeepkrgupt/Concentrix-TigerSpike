/// <reference types="react" />
declare const VideoComp: () => JSX.Element;
export default VideoComp;
