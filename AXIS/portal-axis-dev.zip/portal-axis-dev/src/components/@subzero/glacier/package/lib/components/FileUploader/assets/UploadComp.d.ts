/// <reference types="react" />
declare const UploadComp: () => JSX.Element;
export default UploadComp;
