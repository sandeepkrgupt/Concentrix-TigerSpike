import { FC } from 'react';
import { SkrimProps } from './Skrim.type';
declare const Skrim: FC<SkrimProps>;
export default Skrim;
