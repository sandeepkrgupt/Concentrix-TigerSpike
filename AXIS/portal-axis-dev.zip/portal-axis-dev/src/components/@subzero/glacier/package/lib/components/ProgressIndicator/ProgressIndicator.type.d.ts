import { CircularProgressProps as MuiProgressIndicatorProps, CircularProgressClassKey } from '@material-ui/core/CircularProgress';
export interface ProgressIndicatorStylingProps extends Partial<Record<CircularProgressClassKey, string>> {
    stepProgress?: string;
    stepError?: string;
    stepSuccess?: string;
    percentageProgress?: string;
    percentageError?: string;
    percentageSuccess?: string;
    stepProgressLabel?: string;
    stepErrorLabel?: string;
    stepSuccessLabel?: string;
    percentageProgressLabel?: string;
    percentageErrorLabel?: string;
    percentageSuccessLabel?: string;
    label?: string;
    sup?: string;
    outlineStep?: string;
    outlinePercentage?: string;
    stepIcon?: string;
    percentageIcon?: string;
}
export interface ProgressIndicatorProps extends MuiProgressIndicatorProps {
    type?: 'error' | 'success' | 'progress';
    progressIndicatorType: 'step' | 'percentage';
    progressStepLabel?: string;
}
export interface IconProps {
    progressIndicatorType: 'step' | 'percentage';
}
