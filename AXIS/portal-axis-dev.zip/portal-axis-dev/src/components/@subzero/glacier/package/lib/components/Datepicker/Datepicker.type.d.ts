import { FilledTextFieldProps as MuiDatepickerProps, TextFieldClassKey as MuiTextFieldClassKey } from '@material-ui/core/TextField';
export interface DatepickerStylingProps extends Partial<Record<MuiTextFieldClassKey, string>> {
    root: string;
    MuiPickersModal?: string;
    margin?: string;
    withoutLabel?: string;
    textField?: string;
    helperText?: string;
    labelRoot?: string;
    shrink?: string;
    labelRootFocused?: string;
    labelRootDisabled?: string;
    inputRoot?: string;
    disabled?: string;
    inputRootDisabled?: string;
    inputStart?: string;
    inputAdornment?: string;
    IconButton?: string;
    datepicker?: string;
    datepickerHeight?: string;
}
export interface DatepickerProps extends MuiDatepickerProps {
    doneCallback?: () => void;
    adornmentStart?: any;
    adornmentEnd?: any;
    adornmentSuffix?: any;
    rangePicker?: boolean;
    type?: 'default' | 'inline';
    onChange?: (date: any) => void;
    defaultValue?: {
        day: number;
        year: number;
        month: number;
    };
}
