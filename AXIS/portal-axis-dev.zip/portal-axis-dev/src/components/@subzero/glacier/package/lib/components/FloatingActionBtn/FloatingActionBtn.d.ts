/// <reference types="react" />
declare const FloatingActionBtn: (props: any) => JSX.Element;
export default FloatingActionBtn;
