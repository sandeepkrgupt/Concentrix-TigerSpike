import FloatingActionBtn from './FloatingActionBtn';
import { FloatingActionBtnProps } from './FloatingActionBtn.type';
export type { FloatingActionBtnProps };
export default FloatingActionBtn;
