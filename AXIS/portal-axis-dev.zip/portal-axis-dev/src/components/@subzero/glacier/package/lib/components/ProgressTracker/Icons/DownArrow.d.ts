/// <reference types="react" />
declare const DownArrow: () => JSX.Element;
export default DownArrow;
