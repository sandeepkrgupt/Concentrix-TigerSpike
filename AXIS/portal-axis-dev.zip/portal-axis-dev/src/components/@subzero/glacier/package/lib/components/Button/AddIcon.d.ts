/// <reference types="react" />
declare const AddIcon: () => JSX.Element;
export default AddIcon;
