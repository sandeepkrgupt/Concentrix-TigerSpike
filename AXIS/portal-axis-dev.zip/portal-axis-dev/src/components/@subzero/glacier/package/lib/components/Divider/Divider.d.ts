/// <reference types="react" />
declare const Divider: (props: any) => JSX.Element;
export default Divider;
