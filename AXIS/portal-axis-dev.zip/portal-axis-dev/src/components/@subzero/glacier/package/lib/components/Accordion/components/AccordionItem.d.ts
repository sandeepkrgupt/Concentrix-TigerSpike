import { FC } from 'react';
import { AccordionItemProps } from '../Accordion.type';
declare const AccordionItem: FC<AccordionItemProps>;
export default AccordionItem;
