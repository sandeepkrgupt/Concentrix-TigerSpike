import Checkbox from './Checkbox';
import { CheckboxProps } from './Checkbox.type';
export type { CheckboxProps };
export default Checkbox;
