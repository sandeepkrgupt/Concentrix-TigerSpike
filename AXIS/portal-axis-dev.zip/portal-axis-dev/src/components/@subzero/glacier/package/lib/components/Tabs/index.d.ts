import Tabs from './Tabs';
import { TabProps } from './Tabs.type';
export type { TabProps };
export default Tabs;
