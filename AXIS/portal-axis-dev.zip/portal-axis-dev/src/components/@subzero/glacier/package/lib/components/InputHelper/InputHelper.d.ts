/// <reference types="react" />
declare const InputHelper: (props: any) => JSX.Element;
export default InputHelper;
