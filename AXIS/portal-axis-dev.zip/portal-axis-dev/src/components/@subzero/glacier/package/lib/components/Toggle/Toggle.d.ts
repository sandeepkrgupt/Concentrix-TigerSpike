/// <reference types="react" />
declare const Toggle: (props: any) => JSX.Element;
export default Toggle;
