import { RadioProps as MuiRadioProps, RadioClassKey } from '@material-ui/core/Radio';
export interface RadioListStylingProps extends Partial<Record<RadioClassKey, string>> {
    formControl?: string;
    formLabel?: string;
    label?: string;
    disabledChecked?: string;
    checked?: string;
}
export interface RadioListProps extends MuiRadioProps {
    list: {
        title: string;
        defaultValue?: any;
        items: {
            label: string;
            value: any;
            name: string;
            checked?: boolean;
            disabled?: boolean;
        }[];
    };
    onChange?: (radioVal: any) => void;
}
