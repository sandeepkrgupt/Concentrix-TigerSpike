import { Ref } from 'react';
import { CheckboxProps as MuiCheckboxProps, CheckboxClassKey } from '@material-ui/core/Checkbox';
export interface CheckboxStylingProps extends Partial<Record<CheckboxClassKey, string>> {
    root?: string;
    label?: string;
    disabledChecked?: string;
    checked?: string;
}
export interface CheckboxProps extends MuiCheckboxProps {
    innerRef: Ref<HTMLButtonElement>;
    label?: string;
    value?: any;
    onChange?: (value: any) => {};
}
