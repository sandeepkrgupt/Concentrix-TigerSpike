import React, { useEffect, useState } from 'react';
import { Alert } from "@material-ui/lab";
import { makeStyles, Snackbar } from '@material-ui/core';
import CancelIcon from '../../assets/icons/cancel.svg';
import SuccessIcon  from '../../assets/icons/check_circle.svg';
import WarningIcon from '../../assets/icons/warningIndication.svg';
import { useDispatch } from 'react-redux';
import { Actions } from '../../store/rootActions';

const useStyles = makeStyles((theme) => ({
    root:{
        maxWidth: '464px',
        height: '44px',
        display: 'flex',
        float: 'right',
        flexDirection: 'row',
        flexWrap: 'nowrap',
        justifyContent: 'flex-end',
        margin: '55px -10px 0px 0px',
        '@media only screen and (max-width: 767px) and (min-width: 320px)' : {
            width: '288px',
            height: '64px',
        }
    },
    standardSuccess:{
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        padding: '0px 8px 0px 12px',
        position: 'static',
        background: '#404040',
        boxShadow: '0px 0px 10px rgba(0, 0, 0, 0.1)',
        borderRadius: '4px',
        flex: 'none',
        order: '0',
        flexGrow: '0',
        margin: '0px 0px',
        maxWidth: '464px',
        '@media only screen and (max-width: 767px) and (min-width: 320px)' : {
            width: '288px',
            height: '64px',
        }
    },
    message: {
        position: 'static',
        left: '0px',
        top: '12px',
        fontFamily: 'Lato',
        fontStyle: 'normal',
        fontWeight: 'normal',
        fontSize: '14px',
        lineHeight: '20px',
        letterSpacing: '0.26px',
        color: '#FFFFFF',
        flex: 'auto',
        order: '0',
        flexGrow: '1',
        maxWidth: '324px',
        '@media only screen and (max-width: 767px) and (min-width: 320px)': {
            width: '196px',
            height: '40px',
            display: 'flex',
            flexWrap: 'nowrap',
            alignItems: 'center'
        }
    },
    action: {
        color: '#F1F1F1',
        paddingRight: '15.64px',
        paddingLeft: '0px',
        '@media only screen and (max-width: 767px) and (min-width: 320px)': {
            paddingLeft:'0px'
        }
    }
}));

const AlertPopup = (props) => {
    /* Expected Props 
    {   
        alertMsg: "Field position out of range",
        alertType: "warn",
        isAlertOpen: true
    }
    */
    const classes = useStyles();
    const [notify, setNotify] = useState(props);
    const dispatch = useDispatch();

    const onClose = () => {
        setNotify({
            ...notify,
            isAlertOpen:false
        });
        props?.onClose();
        dispatch(Actions.hideToast())
    }
    const icon = props.alertType === 'warn' ?
            WarningIcon : props.alertType === 'success' ? SuccessIcon : CancelIcon

    useEffect(()=>{
        setNotify(props);
    },[props])

    return (
            <Snackbar
                anchorOrigin={{ 
                    horizontal: 'right', 
                    vertical: 'top'
                }}
                onClose={(event, reason) => {
                    // call `event.preventDefault` to only close one Snackbar at a time.
                    event?.preventDefault();
                    if (reason === "escapeKeyDown" || reason === "autoHideDuration" || reason === "timeout") {
                        onClose();
                    }
                }}
                open={notify.isAlertOpen}
                autoHideDuration={3000}
                transitionDuration={300}
                className={classes.root}
            >
                <Alert classes={{standardSuccess : classes.standardSuccess, 
                    message: classes.message, 
                    action: classes.action}} 
                    icon={<img src={icon} />} onClose={onClose}>{notify?.alertMsg}</Alert>
            </Snackbar>
    );
}

export default AlertPopup;