import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
// import CloseIcon from '../../assets/icons/close-icon.svg';
import './index.css';

const useStyles = makeStyles((theme) => ({
    modal: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    paper: {
        backgroundColor: theme.palette.background.paper,
        borderRadius: "16px",
        padding: theme.spacing(2, 4, 3),
        background: "#FFFFFF",
        boxShadow: "0px 24px 38px rgba(0, 0, 0, 0.14)",
        border: "none",
        width: "596px",
        height: "auto",
        '&:focus': {
            border: "none",
            outline: "none"
        }
    },
    closeButton: {
        float: "right",
        color: theme.palette.grey[500],
        cursor: "pointer"
    },


}));

const CustomModal = ({ showModal, closeModal, children }) => {
    const classes = useStyles();
    return (<>
        <Modal
            aria-labelledby="transition-modal-title"
            aria-describedby="transition-modal-description"
            className={classes.modal}
            open={showModal}
            onClose={closeModal}
            closeAfterTransition
            BackdropComponent={Backdrop}
            BackdropProps={{
                timeout: 500,
            }}
        >
            <Fade in={showModal}>
                <div className={classes.paper}>
                    {/* <div className={classes.closeButton} onClick={closeModal}>
                        <img src={CloseIcon} />
                    </div> */}
                    {children}
                </div>
            </Fade>

        </Modal>
    </>);

}

export default CustomModal

