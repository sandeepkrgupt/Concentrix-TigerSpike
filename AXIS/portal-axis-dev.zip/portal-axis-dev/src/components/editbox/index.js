import React, { useState } from 'react'
import { Button, Card } from '../../components/@subzero/glacier/package/lib/components'
import PenIcon from '../../assets/icons/pen-icon.svg';
import './index.css';
import AccordianUpArrow from '../../assets/icons/up-arrow.svg';
import AccordianDownArrow from '../../assets/icons/down-arrow.svg';

const EditBox = (props) => {

    const [showAccordianData, updateAccordianDisplay] = useState(true);

    return (<>
        <Card style={{ width: "100%", marginTop: "20px" }}>
            <div className="edit-box-container">
                <div className="edit-card-header">
                    <span className="header">{props?.title} </span>
                    <div>
                        {!props.hideEditButton &&
                            <Button withIcon onClick={() => { props?.onEdit() }}
                                endIcon={<img src={PenIcon} />}>Edit</Button>}
                        <div className="accordian-arrow-edit-box" onClick={() => { updateAccordianDisplay(!showAccordianData) }}>
                            <img src={showAccordianData ? AccordianUpArrow : AccordianDownArrow} />
                        </div>
                    </div>
                </div>
            </div>
            {showAccordianData &&
                props.children}
        </Card>
    </>)
}

export default EditBox;
