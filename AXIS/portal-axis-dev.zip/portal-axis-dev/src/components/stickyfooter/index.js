import React from 'react';
    
export default function Footer({ children }) {
    return (
        <div className="footer">
            { children }
        </div>
    )
}
