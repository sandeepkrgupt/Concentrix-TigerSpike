import React, { useState, useEffect } from "react";
import CloseIcon from "../../assets/icons/close.svg";
import "./index.css";

const SearchInput = (props) => {
  const { placeholder, getValue, value } = props;
  const [searchVal, setSearchVal] = useState("");

  useEffect(() => {
    getValue(searchVal);
  }, [searchVal]);

  useEffect(() => {
    if (value) {
      setSearchVal(value);
    }
  }, [value]);
  
  return (
    <div className={`search-bank-input ${searchVal && "filled-input"}`}>
      <input
        style={{ width: "90%" }}
        type="text"
        placeholder={placeholder}
        value={searchVal}
        onChange={(e) => setSearchVal(e?.target?.value)}
        onBlur={props?.onBlur}
      />
      <img
        src={CloseIcon}
        onClick={() => {
          setSearchVal("");
          props?.onBlur();
        }}
      />
    </div>
  );
};

export default SearchInput;
