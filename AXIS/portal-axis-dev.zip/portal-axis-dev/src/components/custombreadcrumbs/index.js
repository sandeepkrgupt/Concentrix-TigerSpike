import React, { useEffect, useState } from 'react';
import { Breadcrumbs } from '../@subzero/glacier/package/lib/components';
import styles from './index.module.css';
import { Link } from 'react-router-dom';

const CustomBreadcrumbs = props => {
    const [maxItems, setMaxItems] = useState(props?.items?.length);

    useEffect(() => {
        const handleResize = () => {
            if(window?.outerWidth < 600 || window.innerWidth < 600){
                setMaxItems(2);
            } else {
                setMaxItems(props?.items?.length);
            }
        }
        window.addEventListener('resize', handleResize);
        handleResize();
        return () => {
            window.removeEventListener('resize', handleResize);
        }
    },[])

    return (
        <Breadcrumbs itemsAfterCollapse={1} maxItems={maxItems} 
        // style={{marginLeft: '43px'}}
        > {
            props?.items?.map((item, index, arr) => {
                const lastBreadcrumb = arr.length === index + 1
                return (
                    <Link key={index} 
                        to={item.path}
                        active={lastBreadcrumb}
                        className={`${styles.breadcrumbLink} ${lastBreadcrumb ? styles.activeBreadcrumbLink : ''}`} 
                    >{item.name}</Link>
                )
            })
        }
        </Breadcrumbs>
    )
}

export default CustomBreadcrumbs;