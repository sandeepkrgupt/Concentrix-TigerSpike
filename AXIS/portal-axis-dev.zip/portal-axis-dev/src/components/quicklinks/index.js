import { List, ListItem, Typography } from '@material-ui/core';
import React, { useEffect, useState } from 'react';
import classes from './index.module.css';
import './sticky.css';

const useIsSticky = el => {
  const [isSticky, setIsSticky] = useState(false);
  useEffect(() => {
    const header = document.getElementById(el);
    const sticky = header.offsetTop;
    const scrollCallBack = window.addEventListener("scroll", () => {
      if (window.pageYOffset > sticky) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    });
    return () => {
      window.removeEventListener("scroll", scrollCallBack);
    };
  }, []);
  return isSticky;
};

const QuickLink = (props) => {
  const isSticky = useIsSticky("myHeader");
  const links = [
    { name: "Make payment", link: "" },
    { name: "Bulk upload", link: "" },
    { name: "Completed Transactions", link: "" },
    { name: "Regularise BOE", link: "" },
    { name: "BOE not available", link: "" },
    { name: "other bank boe", link: "" },
    { name: "transaction inquiry", link: "" },
    { name: "exchange rate", link: "" }
  ]
  return (
    <div className={classes.box}>
      <div>
        <header id="myHeader" className={isSticky ? "header sticky" : "header"}>
        <Typography className={classes.label}>
        Quick Links
      </Typography>
      <List className={classes.list}>
        {links.map((item, index) => {
          return (<ListItem key={index} className={classes.listItem}>{item.name}</ListItem>);
        })}
      </List>
        </header>
      </div>
      
    </div>
  )
}

export default QuickLink;