/*eslint-disable*/
import React, { useState, useRef } from "react";
import {
  FileUploader,
  Button,
} from "../../components/@subzero/glacier/package/lib/components";
import "./index.css";
import PropTypes from "prop-types";
import CircularProgress from "@material-ui/core/CircularProgress";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import UploadProgress from "./UploadProgress";
import DocumentCheckList from "./DocumentCheckList";
import ViewDocuments from "./ViewDocuments";
import uploadIcon from "../../assets/icons/cloud-icon.svg";
import { convertFileToBase64 } from "../../utils/Base64Conversion";

function CircularProgressWithLabel(props) {
  return (
    <Box position="relative" display="inline-flex">
      <CircularProgress variant="determinate" {...props} />
      <Box
        top={0}
        left={0}
        bottom={0}
        right={0}
        position="absolute"
        display="flex"
        alignItems="center"
        justifyContent="center"
      >
        <Typography
          variant="caption"
          component="div"
          color="textSecondary"
        >{`${Math.round(props.value)}`}</Typography>
      </Box>
    </Box>
  );
}
CircularProgressWithLabel.propTypes = {
  /**
   * The value of the progress indicator for the determinate variant.
   * Value between 0 and 100.
   */
  value: PropTypes.number.isRequired,
};

const AttachDocuments = (props) => {
  const [showUploading, updateUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadCompleted, updateCompleted] = useState(false);
  const [fileList, updateFileList] = useState([]);
  const inputFile = useRef(null);

  const handleFileUpload = async () => {
    updateUploading(true);
    let newArray = [];
    fileList.map(async (item) => {
      const stringValue = await convertFileToBase64(item?.file);
      // const stringValue = item?.file;
      newArray.push({
        file: stringValue,
        purposeCode: item?.purposeCode,
        classification: item?.classification,
      });
    });
    // props?.updateFormValues({ attachDocuments: newArray });
    const timer = setInterval(() => {
      setProgress((prevProgress) => {
        if (prevProgress >= 100) {
          updateCompleted(true);
          return 0;
        } else return prevProgress + 10;
      });
    }, 1000);

    return () => {
      clearTimeout(timer);
    };
  };

  const handleFileSelection = async (event) => {
    updateFileList([...fileList, { file: event.target.files[0] }]);
  };

  const handleFileDeletion = (fileIndex) => {
    let newArray = JSON.parse(JSON.stringify(fileList));
    newArray.splice(fileIndex, 1);
    updateFileList(newArray);
  };

  const handleUserInput = (value, name, key) => {
    let newArray = JSON.parse(JSON.stringify(fileList));
    newArray.map((item, index) => {
      if (key === index) {
        item[name] = value;
      }
    });
    updateFileList(newArray);
  };

  return (
    <>
      <div className="attach-document-container">
        {!props?.viewMode ? (
          <>
            <h4>Attach Documents</h4>
            <DocumentCheckList />
            <div
              className="file-uplaod-input"
              onClick={(e) => {
                e.stopPropagation()
                inputFile.current.click();
              }}
            >
              <input
                ref={inputFile}
                id="myInput"
                style={{ display: "none" }}
                type={"file"}
                onChange={(e) => {
                  handleFileSelection(e);
                }}
              />
              {/* <input
                type="file"
                id="myFile"
                onChange={(e) => {
                  handleFileSelection(e);
                }}
              /> */}
              <img src={uploadIcon} />
              <label htmlFor="myInput">Choose file</label>
              <span>
                Click to browse or drop here to upload Supported Formats: Excel,
                csv, txt, xml Maximum Individual File size: 4 MB
              </span>
            </div>
            {/* <FileUploader
              classes={{
                main: styles.fileuploader
              }}
              doneCallback={(e) => {
                handleFileSelection(e);
              }}
              fullWidth
              type="image"
              value={100}
              description="Click to browse or drop here to upload Supported Formats:Excel, csv, txt, xmlMaximum Individual File size: 4 MB"
            /> */}
            {fileList && fileList.length > 0 && (
              <div className="upload-list">
                <div className="green-card">
                  <div className="green-card-data">
                    <CircularProgressWithLabel value={50} />
                    <div className="card-text-area">
                      <div>1/4 Uploaded</div>
                      <span>Time remaining: 12 Mins</span>
                    </div>
                  </div>
                </div>
                {fileList.map((item, key) => (
                  <>
                    {!showUploading ? (
                      <UploadProgress
                        showForm={true}
                        item={item}
                        fileIndex={key}
                        onFileDelete={handleFileDeletion}
                        handleUserInput={handleUserInput}
                      />
                    ) : !uploadCompleted ? (
                      <UploadProgress
                        value={progress}
                        item={item}
                        fileIndex={key}
                        onFileDelete={handleFileDeletion}
                      />
                    ) : (
                      <UploadProgress
                        showSelected={true}
                        item={item}
                        fileIndex={key}
                        onFileDelete={handleFileDeletion}
                      />
                    )}
                  </>
                ))}
                {/* <UploadProgress value={90} /> */}
                {!uploadCompleted && (
                  <div className="direction-right">
                    <Button
                      onClick={() => {
                        handleFileUpload();
                      }}
                    >
                      Upload All
                    </Button>
                    <Button className="clear-button" color="secondary">
                      Clear All
                    </Button>
                  </div>
                )}
              </div>
            )}{" "}
          </>
        ) : (
          <ViewDocuments
            viewMode={props?.viewMode}
            showCheckList={props?.showCheckList}
            editMode={props?.editMode}
            userRole={props?.userRole}
            editAttachments={props?.editAttachments}
          />
        )}
      </div>
    </>
  );
};
export default AttachDocuments;
