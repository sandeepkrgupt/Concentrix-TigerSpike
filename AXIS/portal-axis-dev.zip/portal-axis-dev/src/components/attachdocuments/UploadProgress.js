/* eslint-disable */

import React, { useEffect, useState } from "react";
import CloseIcon from "../../assets/icons/close-icon.svg";
import { makeStyles } from "@material-ui/core/styles";
import LinearProgress from "@material-ui/core/LinearProgress";
import ImgFile from "../../assets/icons/image-file.png";
import Customdropdown from "../../components/customdropdown";
import TrashIcon from "../../assets/icons/delete-icon.svg";
import DeleteIcon from "../../assets/icons/delete.svg";
import Grid from "@material-ui/core/Grid";
import { Dropdown } from "../@subzero/glacier/package/lib/components";
import SuccessIcon from "../../assets/icons/success-check.png";

const useStyles = makeStyles({
  root: {
    width: "100%",
    paddingRight: "50px",
    "@media (max-width: 600px) and (min-width: 320px) ": {
      paddingRight: "0px",
    },
    marginTop: "10px",
  },
});

const UploadProgress = (props) => {
  const classes = useStyles();
  const [classficationLabelList, setClassficationLabelList] = useState([]);

  useEffect(() => {
    //creating classification list if available
    const classifications = props?.classifications;
    if (classifications) {
      const newList = classifications.map((item) => item.label);
      setClassficationLabelList(newList);
    }
  }, []);

  const fetchFileSize = (file) => {
    if (!file?.size) {
      return "";
    } else {
      let size = file?.size;
      const fSExt = ["Bytes", "KB", "MB", "GB"];
      let i = 0;
      while (size > 900) {
        size /= 1024;
        i++;
      }
      const exactSize = Math.round(size * 100) / 100 + " " + fSExt[i];
      return exactSize;
    }
  };
  
  return (
    <div className="green-card d-flex">
      <Grid container className="fd-column ">
        <Grid item className="file-box fd-row wd-100" spacing={3}>
          <Grid item className="fd-column wd-100">
            <Grid item className="fd-row wd-100">
              <Grid item lg={3} md={4} sm={5} xs={10} className="fd-row">
                <div>
                  {
                    props?.item?.file?.name.split('.').pop() === 'xlsx' ? (
                      <svg width="21" height="22" viewBox="0 0 21 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M1.85805 1.87624L14.428 0.0812386C14.499 0.071062 14.5713 0.0762543 14.64 0.0964637C14.7088 0.116673 14.7724 0.151427 14.8266 0.198371C14.8807 0.245315 14.9241 0.303351 14.9539 0.368546C14.9837 0.433741 14.9991 0.504572 14.999 0.576239V21.4222C14.999 21.4938 14.9837 21.5645 14.954 21.6297C14.9243 21.6948 14.8809 21.7528 14.8269 21.7997C14.7729 21.8466 14.7094 21.8814 14.6407 21.9017C14.5721 21.9219 14.4999 21.9273 14.429 21.9172L1.85705 20.1222C1.61867 20.0883 1.40054 19.9695 1.24274 19.7876C1.08493 19.6057 0.998049 19.373 0.998047 19.1322V2.86624C0.998049 2.62545 1.08493 2.39275 1.24274 2.21088C1.40054 2.02901 1.61867 1.91019 1.85705 1.87624H1.85805ZM2.99905 3.73424V18.2642L12.999 19.6932V2.30524L2.99905 3.73424ZM15.999 17.9992H18.999V3.99924H15.999V1.99924H19.999C20.2643 1.99924 20.5186 2.1046 20.7062 2.29213C20.8937 2.47967 20.999 2.73402 20.999 2.99924V18.9992C20.999 19.2645 20.8937 19.5188 20.7062 19.7063C20.5186 19.8939 20.2643 19.9992 19.999 19.9992H15.999V17.9992ZM9.19905 10.9992L11.999 14.9992H9.59905L7.99905 12.7132L6.39905 14.9992H3.99905L6.79905 10.9992L3.99905 6.99924H6.39905L7.99905 9.28524L9.59905 6.99924H11.999L9.19905 10.9992Z" fill="#12877F"/>
                      </svg>
                    ) : props?.item?.file?.name.split('.').pop() === 'xml' ? (
                      <svg width="21" height="22" viewBox="0 0 21 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M15.999 17.9992H18.999V3.99924H15.999V1.99924H19.999C20.2643 1.99924 20.5186 2.1046 20.7062 2.29213C20.8937 2.47967 20.999 2.73402 20.999 2.99924V18.9992C20.999 19.2645 20.8937 19.5188 20.7062 19.7063C20.5186 19.8939 20.2643 19.9992 19.999 19.9992H15.999V17.9992ZM1.85805 1.87624L14.428 0.0812386C14.499 0.071062 14.5713 0.0762543 14.64 0.0964637C14.7088 0.116673 14.7724 0.151427 14.8266 0.198371C14.8807 0.245315 14.9241 0.303351 14.9539 0.368546C14.9837 0.433741 14.9991 0.504572 14.999 0.576239V21.4222C14.999 21.4938 14.9837 21.5645 14.954 21.6297C14.9243 21.6948 14.8809 21.7528 14.8269 21.7997C14.7729 21.8466 14.7094 21.8814 14.6407 21.9017C14.5721 21.9219 14.4999 21.9273 14.429 21.9172L1.85705 20.1222C1.61867 20.0883 1.40054 19.9695 1.24274 19.7876C1.08493 19.6057 0.998049 19.373 0.998047 19.1322V2.86624C0.998049 2.62545 1.08493 2.39275 1.24274 2.21088C1.40054 2.02901 1.61867 1.91019 1.85705 1.87624H1.85805ZM2.99905 3.73424V18.2642L12.999 19.6932V2.30524L2.99905 3.73424ZM9.99905 6.99924H11.999V14.9992H9.99905L7.99905 12.9992L5.99905 14.9992H3.99905V6.99924H5.99905L6.00905 11.9992L7.99905 9.99924L9.99905 11.9882V6.99924Z" fill="#12877F"/>
                      </svg>

                    ) : props?.item?.file?.name.split('.').pop() === 'pdf' ? (
                      <svg width="21" height="22" viewBox="0 0 16 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M15.12 6.98235V2.08719C15.121 1.93287 15.0914 1.77989 15.0332 1.63713C14.9749 1.49436 14.889 1.36466 14.7805 1.25554C14.672 1.14641 14.543 1.06004 14.4011 1.00142C14.2591 0.94281 14.107 0.913124 13.9536 0.914085H1.16642C1.01298 0.913124 0.860877 0.94281 0.718931 1.00142C0.576985 1.06004 0.448022 1.14641 0.339521 1.25554C0.23102 1.36466 0.14514 1.49436 0.0868619 1.63713C0.0285835 1.77989 -0.000933542 1.93287 2.25024e-05 2.08719V6.98235C-0.000933542 7.13668 0.0285835 7.28966 0.0868619 7.43242C0.14514 7.57518 0.23102 7.70488 0.339521 7.81401C0.448022 7.92313 0.576985 8.00951 0.718931 8.06812C0.860877 8.12673 1.01298 8.15642 1.16642 8.15546H13.9536C14.107 8.15642 14.2591 8.12673 14.4011 8.06812C14.543 8.00951 14.672 7.92313 14.7805 7.81401C14.889 7.70488 14.9749 7.57518 15.0332 7.43242C15.0914 7.28966 15.121 7.13668 15.12 6.98235ZM4.89602 4.99822C4.53426 5.23761 4.10382 5.34965 3.67202 5.31684H3.00242V6.42477H2.36882V2.64477H3.65762C4.09888 2.60465 4.54004 2.72263 4.90322 2.97788C5.04213 3.10498 5.1501 3.26253 5.21877 3.43833C5.28743 3.61412 5.31496 3.80346 5.29922 3.99167C5.31405 4.17938 5.28535 4.368 5.21539 4.54266C5.14542 4.71733 5.03609 4.87327 4.89602 4.99822ZM8.90641 5.91063C8.45524 6.28549 7.87711 6.46979 7.29361 6.42477H6.04802V2.64477H7.33681C7.89719 2.6075 8.45066 2.78614 8.88481 3.14443C9.06945 3.31884 9.21407 3.53164 9.30857 3.76801C9.40308 4.00438 9.4452 4.25863 9.43201 4.51305C9.4443 4.76979 9.40399 5.02634 9.31357 5.26676C9.22316 5.50718 9.08457 5.72634 8.90641 5.91063ZM12.744 3.23856H10.8792V4.28132H12.5424V4.89684H10.8792V6.45373H10.2456V2.64477H12.7512L12.744 3.23856Z" fill="#12877F"/>
                      </svg>

                    ) : props?.item?.file?.name.split('.').pop() === 'csv' ? (
                      <svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M17 20H1C0.734784 20 0.48043 19.8946 0.292893 19.7071C0.105357 19.5196 0 19.2652 0 19V1C0 0.734784 0.105357 0.48043 0.292893 0.292893C0.48043 0.105357 0.734784 0 1 0H17C17.2652 0 17.5196 0.105357 17.7071 0.292893C17.8946 0.48043 18 0.734784 18 1V19C18 19.2652 17.8946 19.5196 17.7071 19.7071C17.5196 19.8946 17.2652 20 17 20ZM16 18V2H2V18H16ZM5 6C5 5.44772 5.44772 5 6 5H12C12.5523 5 13 5.44772 13 6C13 6.55228 12.5523 7 12 7H6C5.44772 7 5 6.55228 5 6ZM5 10C5 9.44771 5.44772 9 6 9H12C12.5523 9 13 9.44771 13 10C13 10.5523 12.5523 11 12 11H6C5.44772 11 5 10.5523 5 10ZM5 14C5 13.4477 5.44772 13 6 13H9C9.55229 13 10 13.4477 10 14C10 14.5523 9.55229 15 9 15H6C5.44772 15 5 14.5523 5 14Z" fill="#12877F"/>
                      </svg>

                    ) : (
                      <svg width="18" height="22" viewBox="0 0 18 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M1.82905 0.300023V0.300025H12.3184H12.3194V0.500025C12.3667 0.499446 12.4135 0.508812 12.4569 0.527519C12.5003 0.546226 12.5393 0.57386 12.5714 0.608646L1.82905 0.300023ZM1.82905 0.300023L1.82802 0.300028C1.407 0.302205 1.00408 0.471389 0.706721 0.770455C0.409401 1.06948 0.241615 1.47419 0.239456 1.89659H0.239453V1.89761V10.3276C0.239453 10.4763 0.298176 10.6191 0.403069 10.7246C0.507999 10.8302 0.650561 10.8897 0.799453 10.8897C0.948344 10.8897 1.09091 10.8302 1.19584 10.7246C1.30073 10.6191 1.35945 10.4763 1.35945 10.3276V1.89761C1.35945 1.77168 1.4092 1.65113 1.4974 1.56243C1.58556 1.47376 1.70488 1.42416 1.82905 1.42416H11.7594M1.82905 0.300023L11.7594 1.22416M17.1994 5.20792C17.2001 5.13318 17.1854 5.05907 17.1561 4.99029C17.1271 4.92233 17.0846 4.86101 17.031 4.81015L12.7156 0.469937L16.9994 5.20692M17.1994 5.20792C17.1994 5.20839 17.1994 5.20886 17.1994 5.20933L16.9994 5.20692M17.1994 5.20792V5.20692H16.9994M17.1994 5.20792V20.1024V20.1034C17.1973 20.5258 17.0295 20.9305 16.7322 21.2296C16.4348 21.5286 16.0319 21.6978 15.6109 21.7L15.6098 21.7L1.82905 21.7H1.82802C1.407 21.6978 1.00408 21.5286 0.706721 21.2296C0.409402 20.9305 0.241615 20.5258 0.239456 20.1034L0.239451 20.1024L0.239453 16.7414C0.239453 16.5927 0.298176 16.4498 0.403069 16.3443C0.507999 16.2388 0.65056 16.1793 0.799453 16.1793C0.948346 16.1793 1.09091 16.2388 1.19584 16.3443C1.30073 16.4498 1.35945 16.5927 1.35945 16.7414V20.1024C1.35945 20.2283 1.4092 20.3489 1.4974 20.4376C1.58555 20.5263 1.70488 20.5759 1.82905 20.5759H15.6098C15.734 20.5759 15.8533 20.5263 15.9415 20.4376C16.0297 20.3489 16.0794 20.2283 16.0794 20.1024V5.76898M16.9994 5.20692V20.1024C16.9975 20.4725 16.8505 20.8269 16.5903 21.0886C16.3301 21.3502 15.9778 21.4981 15.6098 21.5H1.82905C1.46109 21.4981 1.10874 21.3502 0.848547 21.0886C0.588356 20.8269 0.441345 20.4725 0.439453 20.1024V16.7414C0.439453 16.6454 0.477382 16.5533 0.544895 16.4854C0.612408 16.4175 0.703975 16.3793 0.799453 16.3793C0.89493 16.3793 0.986498 16.4175 1.05401 16.4854C1.12152 16.5533 1.15945 16.6454 1.15945 16.7414V20.1024C1.15945 20.281 1.23 20.4523 1.35557 20.5786C1.48115 20.7049 1.65146 20.7759 1.82905 20.7759H15.6098C15.7874 20.7759 15.9577 20.7049 16.0833 20.5786C16.2089 20.4523 16.2794 20.281 16.2794 20.1024V5.76898H16.0794M16.0794 5.76898V5.56898H12.3194C12.224 5.56898 12.1324 5.53084 12.0649 5.46294C11.9974 5.39504 11.9594 5.30294 11.9594 5.20692V1.42416H11.7594M16.0794 5.76898H12.3194C12.1705 5.76898 12.028 5.70949 11.9231 5.60395C11.8182 5.49846 11.7594 5.35562 11.7594 5.20692V1.42416M11.7594 1.42416V1.22416M11.7594 1.22416H1.82905C1.65146 1.22416 1.48115 1.29511 1.35557 1.42141C1.23 1.54771 1.15945 1.719 1.15945 1.89761V10.3276C1.15945 10.4236 1.12152 10.5157 1.05401 10.5836C0.986498 10.6515 0.89493 10.6897 0.799453 10.6897C0.703975 10.6897 0.612408 10.6515 0.544895 10.5836C0.477382 10.5157 0.439453 10.4236 0.439453 10.3276V1.89761L11.7594 1.22416ZM12.8794 4.64485V2.22311L15.2873 4.64485H12.8794Z" fill="#12877F" stroke="#12877F" stroke-width="0.4"/>
                      </svg>

                    )
                  }
                </div>
                <div className="card-text-area">
                  <div>{props?.item?.file?.name}</div>
                  <span>{fetchFileSize(props?.item?.file)}</span>
                </div>
              </Grid>
              <Grid item lg={3} md={4} sm={5} xs={0}>
                {props.showForm && (
                  <>
                    <div className="document-form green-card-data-expand">
                      <Grid item lg={12} className="mg-rght-10">
                        <Dropdown
                          items={classficationLabelList}
                          // defaultValue="Transport Documents"
                          label="Classification"
                          placeholder="Classification"
                          type="text"
                          variant="filled"
                          onChange={(e) => {
                            props?.handleUserInput(
                              e,
                              "checkList",
                              props?.fileIndex
                            );
                          }}
                          value={props?.item?.checkList}
                          fullWidth
                          name="Classification"
                          isMulti={false}
                        />
                      </Grid>
                    </div>
                  </>
                )}
                {props.showSelected && (
                  <Grid item lg={12} className="selected-details">
                    <div>
                      <span className="hideTab">Classification: </span>
                      {props?.item?.checkList?.label || props?.item?.checkList}
                    </div>
                  </Grid>
                )}
              </Grid>
              <Grid item lg={6} md={4} sm={2} xs={2} className="jc-f-end">
                <div className="as-center">
                  {/*if file is being uploaded or not started uploading, show close button*/}
                  {props.showForm ? (
                    <img
                      className="close-icon"
                      // className="flt-right"
                      src={CloseIcon}
                      onClick={() => {
                        props?.onFileDelete(props.fileIndex);
                      }}
                    />
                  ) : props.value ? (
                    ""
                  ) : (
                    // else show delete button and success icon
                    props.showSelected && (
                      <>
                        <Grid container spacing={2}>
                          <Grid item className="as-center">
                            <div className="delete-button hideMobTab">
                              <img
                                // className="flt-right"
                                src={TrashIcon}
                                onClick={() => {
                                  props?.onFileDelete(props.fileIndex);
                                }}
                              />
                            </div>
                          </Grid>
                          <Grid item className="as-center">
                            <img src={SuccessIcon} />
                          </Grid>
                        </Grid>
                      </>
                    )
                  )}
                </div>
              </Grid>
            </Grid>

            {props.showSelected && (
              <Grid item className="selected-details-mob">
                <div>Classification: {props?.item?.checkList.label}</div>
              </Grid>
            )}
            {/* <Grid item className="selected-details-mob">
              <div>Classification: Invoice Attachments</div>
            </Grid> */}
          </Grid>

          {/* <Grid item></Grid> */}
          {/* <div className="green-card-data wd-100">
            <div>
              <img src={ImgFile} />
            </div>
            <div className="card-text-area">
              <div>{props?.item?.file?.name}</div>
              <span>{fetchFileSize(props?.item?.file)}</span>
            </div> */}
          {/* <> */}
          {/* if file is selected and not started uploading, show classification dropdown */}
          {/* {props.showForm && (
                <>
                  <div className="document-form green-card-data-expand ">
                    <Grid item lg={3} className="mg-rght-10">
                      <Dropdown
                        items={[
                          "Transport Documents",
                          "Invoice Documents",
                          "Additional",
                        ]}
                        // defaultValue="Transport Documents"
                        label="Classification"
                        placeholder="Classification"
                        type="text"
                        variant="filled"
                        onChange={(e) => {
                          props?.handleUserInput(
                            e,
                            "classification",
                            props?.fileIndex
                          );
                        }}
                        value={props?.item?.classification}
                        fullWidth
                        name="Classification"
                        isMulti={false}
                      />
                    </Grid>
                  </div>
                </>
              )} */}
          {/* </> */}
          {/* </div> */}

          {/* {!props.showForm && !props.value && (
            <Grid item lg={2} className="selected-details">
              <div>Classification: Invoice Attachments</div>
            </Grid>
          )} */}
          {/* <div className="green-card-data-short"></div> */}
          {/* {props.showForm && (
        <div className="document-form">
          <Grid item lg={3} className="mg-rght-10">
            <Dropdown
              items={["Transport Documents", "Invoice Documents", "Additional"]}
              defaultValueTrashIconled"
              fullWidth
              name="Classification"
              isMulti={false}
            />
          </Grid>
        </div>
      )} */}

          {/* show linearprogress if uploading on progress */}

          {/* for different uploading progress and uploading complete colors */}
          {/* {props.value &&
        (props.value < 100 ? (
          <div className={classes.root}>
            <LinearProgress
              variant="determinate"
              color="secondary"
              value={props.value}
            />
          </div>
        ) : (
          <div className={classes.root}>
            <LinearProgress variant="determinate" value={props.value} />
          </div>
        ))} */}
        </Grid>
        <Grid item>
          <div className="green-card-data-short">
            {props.showForm && (
              <Dropdown
                items={classficationLabelList}
                // defaultValue="Transport Documents"
                label="Classification"
                placeholder="Classification"
                type="text"
                variant="filled"
                onChange={(e) => {
                  props?.handleUserInput(e, "checkList", props?.fileIndex);
                }}
                value={props?.item?.checkList}
                fullWidth
                name="Classification"
                isMulti={false}
              />
            )}
          </div>
        </Grid>
        {props.showSelected && (
          <>
            <Grid item className="fd-row jc-f-end">
              <div
                className="viewMobTab-flex delete-btn"
                onClick={() => {
                  props?.onFileDelete(props.fileIndex);
                }}
              >
                <img
                  style={{ alignSelf: "center" }}
                  // className="flt-right"
                  src={DeleteIcon}
                />
                <span className="delete-file">Delete</span>
              </div>
            </Grid>
          </>
        )}

        <Grid item className="fd-row">
          {props.value && (
            <div className={classes.root}>
              <LinearProgress variant="determinate" value={props.value} />
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  );
};

export default UploadProgress;
