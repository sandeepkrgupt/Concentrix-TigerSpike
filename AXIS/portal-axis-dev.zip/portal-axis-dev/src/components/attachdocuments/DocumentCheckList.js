import React, { useState } from "react";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import "./index.css";
import AccordianUpArrow from "../../assets/icons/up-arrow.svg";
import AccordianDownArrow from "../../assets/icons/down-arrow.svg";
import { Grid } from "@material-ui/core";

const DocumentCheckList = (props) => {
  const { headCells, rows } = props.data;

  const [showAccordianData, updateAccordianDisplay] = useState(false);
  return (
    <>
      <div className="document-checklist">
        <div className="document-checklist-title ">
          <h5>Document Checklist</h5>
          <div
            className="accordian-arrow"
            onClick={() => {
              updateAccordianDisplay(!showAccordianData);
            }}
          >
            <img
              src={showAccordianData ? AccordianUpArrow : AccordianDownArrow}
            />
          </div>
        </div>
        {showAccordianData && (
          <>
            <div div className="document-cecklist-items hideMob">
              {headCells.map((title) => (
                <div className="mg-10" key={title.id}>
                  <span className="list-heading">{title.label}</span>
                  <List dense={true}>
                    {rows.map((row, index) => (
                      <ListItem key={index}>
                        <ListItemText primary={row[title.id]} />
                      </ListItem>
                    ))}
                  </List>
                </div>
              ))}
            </div>
            <div div className="viewMob">
              {rows.map((rows) => (
                <Grid item className="check-list-boxes-mob" key={rows.boeNo}>
                  <Grid item className="fd-column">
                    <Grid item className="fd-row">
                      <Grid item xs="6" className="fd-column jc-fs">
                        <span className="list-heading">BOE Number</span>
                        <span className="list-data">{rows.boeNo}</span>
                      </Grid>
                      <Grid item xs="6" className="fd-column jc-fs">
                        <span className="list-heading">
                          Additional Mandatory Documents
                        </span>
                        <span className="list-data">{rows.addMandDocs}</span>
                      </Grid>
                    </Grid>
                    <Grid item className="fd-row">
                      <Grid item className="fd-column jc-fs">
                        <span className="list-heading">Description</span>

                        <span className="list-data">{rows.description}</span>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              ))}
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default DocumentCheckList;
