import React from "react";
import "./index.css";
import GreenTick from "../../assets/icons/green-tick.svg";
import CircleIcon from "../../assets/icons/circle.svg";
import { Button } from "../@subzero/glacier/package/lib/components";
import DownloadIcon from "../../assets/icons/download-active.svg";
import CopyIcon from "../../assets/icons/copy.svg";

const SuccessCard = (props) => {
  return (
    <>
      <div className="parent-container">
        <div className="success-box-container">
          <div className="success-icon">
            <img src={CircleIcon} />
            <img src={GreenTick} />
          </div>
          <h3>Success</h3>
          <p>
            FIDB Payment transaction with reference number{" "}
            <span>AX-584638</span> has been successfully submited to the checker
            for authorization.
          </p>
          <div className="success-action-box">
            <div className="success-download-box">
              <span>Service Request</span>
              <Button
                withIcon
                color="secondary"
                endIcon={<img src={DownloadIcon} />}
              >
                Download
              </Button>
            </div>
            <div className="success-copy-box">
              <span>AX-584638</span>
              <span>
                Copy <img src={CopyIcon} />
              </span>
            </div>
          </div>

          <Button className="lrge-btn">Initiate New Payment</Button>
        </div>
      </div>
    </>
  );
};

export default SuccessCard;
