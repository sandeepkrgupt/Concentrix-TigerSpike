/*eslint-disable */
import React, { useState, useEffect } from "react";
import { Grid } from "@material-ui/core";
import { withStyles } from "@material-ui/core/styles";
import { TextField } from "../@subzero/glacier/package/lib/components";
import Slider from "@material-ui/core/Slider";
import "./index.css";

const PrettoSlider = withStyles({
  root: {
    color: "#ED1164",
    height: 8
  },
  thumb: {
    height: 24,
    width: 24,
    backgroundColor: "#fff",
    border: "1px solid #E2E2E2",
    boxSizing: "border-box",
    boxShadow: "0px 0px 4px rgba(0, 0, 0, 0.12)",
    borderRadius: "14px",
    marginTop: -8,
    marginLeft: -12,
    "&:focus, &:hover, &$active": {
      boxShadow: "inherit"
    }
  },
  active: {},
  valueLabel: {
    left: "calc(-50% + 4px)"
  },
  track: {
    height: 12,
    borderRadius: 4
  },
  rail: {
    height: 12,
    borderRadius: 4,
    opacity: 1,
    color: "#E2E2E2"
  }
})(Slider);

const CustomSlider = (props) => {
  const [minValue, setMinValue] = useState(null);
  const [maxValue, setMaxValue] = useState(null);
  const [value, setValue] = useState([minValue, maxValue]);

  const handleChange = (event, newValue) => {
    setMinValue(JSON.stringify(newValue[0]));
    setMaxValue(JSON.stringify(newValue[1]));
  };

  const numberWithCommas = (x) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };
  useEffect(() => {
    setValue([minValue, maxValue]);
    if (parseInt(minValue) > parseInt(maxValue)) {
      props?.disableFilter(true);
    } else if (minValue !== null && maxValue === null) {
      props?.disableFilter(true);
    } else {
      props?.disableFilter(false);
    }
  }, [minValue, maxValue]);

  useEffect(() => {
    if (props?.appliedFilter) {
      //if(value[0] === null || isNaN(value[0])){
      //  value[0] = 0;
      //}

      if (value[0] === null && value[1] > 0) {
        value[0] = 0;
      }
      props?.getValue(value);
    }
  }, [props?.appliedFilter]);

  useEffect(() => {
    const amt = props?.selectedAmounts;
    setValue(amt);
    setMinValue(amt[0]);
    setMaxValue(amt[1]);
  }, [props?.selectedAmounts]);

  return (
    <div div className="custom-slider">
      <p>{props.title}</p>
      <div>
        <PrettoSlider
          min={0}
          max={999999999999999}
          value={value}
          onChangeCommitted={handleChange}
          valueLabelDisplay="off"
          aria-labelledby="range-slider"
        />
      </div>

      <Grid container className="custom-field">
        <Grid md={5} sm={5} xs={12}>
          <TextField
            value={minValue}
            onChange={(e) => {
              if (parseInt(e?.target?.value) < 0) {
                setMinValue("");
              } else if (isNaN(e?.target?.value)) {
                setMinValue("");
              } else {
                e.target.value = `${e?.target?.value}`.slice(0, 15);
                // e.target.value = Math.max(0, parseInt(e.target.value) ).toString().slice(0,15)
                setMinValue(parseInt(e?.target?.value));
              }
            }}
            label="Min"
            type="number"
            variant="filled"
          />
        </Grid>
        <Grid className="hyphen" md={2} sm={2} xs={12}>
          {" "}
          _
        </Grid>
        <Grid md={5} sm={5} xs={12}>
          <TextField
            onChange={(e) => {
              if (parseInt(e?.target?.value) < 0) {
                setMaxValue("");
              } else if (isNaN(parseInt(e?.target?.value))) {
                setMaxValue(null);
              } else {
                e.target.value = `${e?.target?.value}`.slice(0, 15);
                // e.target.value = Math.max(0, parseInt(e.target.value) ).toString().slice(0,15)
                setMaxValue(parseInt(e?.target?.value));
              }
            }}
            value={maxValue}
            label="Max"
            type="number"
            variant="filled"
          />
        </Grid>
      </Grid>
      {minValue !== null && maxValue === null && (
        <span style={{ color: "red", fontSize: "14px" }}>
          Max Amount cannot be empty
        </span>
      )}
      {parseInt(minValue) > parseInt(maxValue) && (
        <span style={{ color: "red", fontSize: "14px" }}>
          Min Amount cannot be greater than Max Amount
        </span>
      )}
    </div>
  );
};

export default CustomSlider;
