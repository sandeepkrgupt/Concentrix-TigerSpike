const routes = {
  login: "/",
  dashboard: "/dashboard",
  completedTransactions: "/completed-transactions",
  currencyConvertor: "/currency-convertor",
  boe: "/boe",
  boeDetails: "/boe-details/:id",
  boeNo: "/no-of-boes",
  transactionInquiry: "/transaction-inquiry",
  makePayment: "/make-payment",
  additionalDetails: "/additional-details",
  success: "/success",
  authMatrix: "/auth-matrix",
  authMatrixSuccess: "/auth-matrix-success",
  authorizeSuccess: "/authorize-success",
  workflowDetails: "/workflow-details",
};

export default routes;
