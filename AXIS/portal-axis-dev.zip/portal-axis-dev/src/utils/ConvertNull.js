// This is generic function to convert null values received from api to human readable data.
// @params value - represents value received from api, type represents whether it's a text value or amount

export const convertNull = (value, type) => {
  if (type === "amount") {
    if (value === "null" || value === "null null") {
      return "0.0";
    } else if (value === "USD null") {
      return "USD 0.0";
    } else if (value === "INR null") {
      return "INR 0.0";
    } else if(value?.includes("null")){
      value = value.replace("null", "")
      if(value.trim() === ""){
        return "0.0";
      }else{
        return value;
      }
    } else return value;
  } else if (type === "text") {
    if (value === "null" || value === "null null") {
      return "";
    } else return value;
  }
};
