export const colors = [
  "#F1F4F7",
  "#F9F1EB",
  "#F9F6EB",
  "#EFF9EB",
  "#EBF9F8",
  "#EBF0F9",
  "#F4EBF9",
  "#F9EBEF",
  "#F2F7F6"
];

export const chkerColors = ["#F9EBEF", "#F9F1EB", "#EFF9EB"];

export const boeColors = ["#E7F3F2", "#EBF0F9", "#F9F1EB", "#F9F6EB"];

export const chckrBoeColors = ["#F9F1EB", "#F9F6EB", "#F1F4F7", "#E7F3F2"];

export const miniColors = ["#D0E7E5", "#D8E6FF"];

export const chkrMiniColors = ["#FFD1AE", "#FFEDA9"];

export const boeInqColors = ["#F9F1EB", "#F9F6EB", "#F1F4F7", "#E7F3F2"];

export const boeInqMiniColors = ["#FFD1AE", "#FFEDA9"];

export const boeInqBorderColors = ["#FC984E", "#F0C836", "#64A6E9", "#32CBC0"];

export const tiColors = [
  "#F1F4F7",
  "#EBF9F8",
  "#F9EBEF",
  "#F9F1EB",
  "#F4EBF9",
  "#F9F6EB",
  "#EFF9EB",
  "#EBF0F9"
];

export const tiBorderColors = [
  "#64A6E9",
  "#3DD1C7",
  "#EF82A2",
  "#FC984E",
  "#C16BF1",
  "#F0C836",
  "#82D361",
  "#639BFE"
];
