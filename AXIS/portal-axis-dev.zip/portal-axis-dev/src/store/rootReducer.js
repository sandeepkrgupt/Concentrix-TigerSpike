import { combineReducers } from "redux";
import dashboard from "./dashboard/reducer";
import auth from "./auth/reducer";
import transaction from "./transaction/reducer";
import boe from "./boe/reducer";
import toast from "./toast/reducer";
import paymentReviewData from "./payment_review/reducer";
import payment from "./payment/reducer";
import transactionDetails from './transaction-details/reducer';
import attachDocuments from "./attach_documents/reducer";

const reducers = combineReducers({
  dashboard,
  auth,
  transaction,
  boe,
  toast,
  paymentReviewData,
  payment,
  transactionDetails,
  attachDocuments
});

export default reducers;
