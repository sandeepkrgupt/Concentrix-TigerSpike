import * as TYPES from "../../utils/types";

const initialState = {
  transDetails: [],
  additionalDetails: {},
  saveAddDetails: "",
  recKey: "",
  proceedFromTrans: "",
  hsCode: {},
  saveCounter: 0,
  totalRemittance: 0,
  selectBeneValue: [],
  currency: "",
  standardProcessing: false,
  utilizedAmount: [],
  goodsType: "",
  loader: false,
  showSaveDraftMsg: false,
  OFACCheck: "Success",
  invoiceEarMarking: null,
  channelRefNo: null,
  ieCodes: [],
  subCustIds: [],
  defaultApplicantDetails: {},
  custIdAndIeCode : {
    custId: "",
    ieCode: ""
  },
  totalAmountValidation: null
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQUEST_TRANS_DETAILS:
    case TYPES.REQUEST_UPDATED_ADD_DETAILS:
    case TYPES.TOTAL_AMOUNT_VALIDATION:
    case TYPES.FETCH_INVOICE_CHARGES:
      return { ...state, loader: false };
    case TYPES.PROCEED_FROM_TRANS:
    case TYPES.PROCEED_FROM_TRANS_DRAFT:
    case TYPES.SAVE_AS_DRAFT:
    case TYPES.DELETE_TRANS:
      return { ...state, loader: false };
    case TYPES.GET_HSCODE:
      return { ...state, loader: false };
    case TYPES.FETCH_UTILIZED_AMOUNT:
    case TYPES.INVOICE_EAR_MARKING:
      return { ...state, loader: false };
    case TYPES.TRANS_DETAILS_SUCCESS:
      return {
        ...state,
        transDetails: action.payload,
        loader: false,
      };
    case TYPES.REQUEST_ADD_DETAILS:
      return { ...state, loader: false };
    case TYPES.ADD_DETAILS_SUCCESS:
      return {
        ...state,
        additionalDetails: action.payload,
        loader: false,
      };
    case TYPES.SAVE_ADD_DETAILS:
      return { ...state, loader: true };
    case TYPES.SAVE_ADD_DETAILS_SUCCESS:
      return {
        ...state,
        recKey: action.payload.recKey,
        saveCounter: state.saveCounter + 1,
        loader: false,
      };
    case TYPES.REQUEST_UPDATED_ADD_DETAILS_SUCCESS:
      return {
        ...state,
        additionalDetails: action.payload,
        loader: false,
      };
    case TYPES.PROCEED_FROM_TRANS_SUCCESS:
      return {
        ...state,
        proceedFromTrans: action.payload,
        loader: false,
      };
    case TYPES.DELETE_TRANS_SUCCESS:
      return {
        ...state,
        loader: false,
      };
    case TYPES.GET_HSCODE_SUCCESS:
      return {
        ...state,
        hsCode: action.payload,
        loader: false,
      };
    case TYPES.CLEAR_SAVE_COUNTER:
      return {
        ...state,
        saveCounter: 0,
      };
    case TYPES.CLEAR_SUCCESS_STATE:
      return {
        ...state,
        proceedFromTrans: "",
        recKey: "",
        totalRemittance: 0,
        selectBeneValue: "",
        currency: "",
      };
    case TYPES.CLEAR_STATUS:
      return {
        ...state,
        proceedFromTrans: "",
      };
    case TYPES.SAVE_REMITTANCE_AMOUNT_AND_BENE:
      return {
        ...state,
        totalRemittance: action.payload.totalRemittance,
        selectBeneValue: action.payload.beneficiaryName,
        goodsType: action.payload.goodsType,
      };
    case TYPES.SAVE_CURRENCY:
      return {
        ...state,
        currency: action.payload,
      };
    case TYPES.FETCH_UTILIZED_AMOUNT_SUCCESS:
      return {
        ...state,
        utilizedAmount: action.payload,
        loader: false,
      };
    case TYPES.SWITCH_STANDARD_PROCESSING:
      return {
        ...state,
        standardProcessing: action.payload,
      };
    case TYPES.CLEAR_TRANS:
      return {
        ...state,
        transDetails: [],
      };
    case TYPES.SAVE_AS_DRAFT_SUCCESS:
      return {
        ...state,
        recKey: action.payload.recKey,
        loader: false,
      };
    case TYPES.PROCEED_FROM_TRANS_DRAFT_SUCCESS:
      return {
        ...state,
        showSaveDraftMsg: action.isButtonClick,
      };
    case TYPES.CLEAR_TRANS_MSG_STATUS:
      return {
        ...state,
        showSaveDraftMsg: false,
      };
    case TYPES.OFAC_COUNTRY_CHECK:
      return {
        ...state,
        OFACCheck: "Success",
      };
    case TYPES.OFAC_COUNTRY_CHECK_SUCCESS:
      return {
        ...state,
        OFACCheck: action?.payload?.status,
      };
    case TYPES.INVOICE_EAR_MARKING_SUCCESS:
      return {
        ...state,
        invoiceEarMarking: action?.payload,
      };
    case TYPES.SET_REC_KEY:
      return {
        ...state,
        recKey: action?.payload?.recKey,
        channelRefNo: action?.payload?.channelRefNo,
      };
    case TYPES.CLEAR_CHANNEL_REF_NO:
      return {
        ...state,
        channelRefNo: null,
      };
      case TYPES.GET_SUB_CUST_IDS:
      case TYPES.GET_IE_CODE:
      case TYPES.GET_DEFAULT_APPLICANT_DETAILS:
        return {
            ...state
        }
      case TYPES.GET_SUB_CUST_IDS_SUCCESS:
        return {
            ...state,
            subCustIds: action.payload,
        }
      case TYPES.GET_IE_CODE_SUCCESS:
        return {
            ...state,
            ieCodes: action.payload,
        }
      case TYPES.GET_DEFAULT_APPLICANT_DETAILS_SUCCESS:
        return {
          ...state,
          defaultApplicantDetails: action.payload,
        }
      case TYPES.SET_CUST_ID_AND_IE_CODE:
        return {
          ...state,
          custIdAndIeCode: action.payload,
        }
      case TYPES.TOTAL_AMOUNT_VALIDATION_SUCCESS:
        return {
          ...state,
          totalAmountValidation: action.payload,
        }
      case TYPES.FETCH_INVOICE_CHARGES_SUCCESS:
        return {
          ...state,
          invoiceCharges: action.payload,
        }
    default:
      return { ...state };
  }
}
