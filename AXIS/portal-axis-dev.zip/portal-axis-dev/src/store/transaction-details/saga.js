import * as TYPES from "../../utils/types";
import { takeLatest, put, takeEvery } from "redux-saga/effects";
import {getTransDetail, 
  getAddDetail, 
  saveAddDetail,
   getUpdatedAddDetail, 
   proceedFromTransaction,
   deleteTransRec,
  getHSCodes,
  fetchUtilizedAmt,
  saveDrafts,
  checkOFACCountry,
  invoiceEarMark,
  getDefaultApplicantDetailsAPI,
  getSubCustsIdAPI,
  getIECodesAPI,
  totalAmtValAPI,
  fetchInvChargesAPI } from "./service";

function* trans(action) {
    try {
      const params = action.payload;
      const response = yield getTransDetail(params);
      const data = response?.data;
      if(response?.status === 200){
        yield put({
            type: TYPES.TRANS_DETAILS_SUCCESS,
            payload: data,
        });
      }
    } catch (error) {
      yield put({
        type: TYPES.TRANS_DETAILS_ERROR,
        payload: error,
      });
    }
  }

export function* getTransDetails() {
    yield takeLatest(TYPES.REQUEST_TRANS_DETAILS, trans);
}


function* additionalDetails(action){
  try {
    const params = action.payload;
    const response = yield getAddDetail(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.ADD_DETAILS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.TRANS_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getAdditionalDetails(){
  yield takeLatest(TYPES.REQUEST_ADD_DETAILS, additionalDetails)
}

function* saveAdditionalDetail(action){
  try {
    const params = action.payload;
    const response = yield saveAddDetail(params);
    const data = {};
    data.recKey = response?.data;
    data.boeNumber = params.boeNumber;
    if(response?.status === 200){
      yield put({
          type: TYPES.SAVE_ADD_DETAILS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.SAVE_ADD_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* saveAdditionalDetails(){
  yield takeLatest(TYPES.SAVE_ADD_DETAILS, saveAdditionalDetail)
}

function* updatedAdditionalDetail(action){
  try {
    const params = action.payload;
    const response = yield getUpdatedAddDetail(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.REQUEST_UPDATED_ADD_DETAILS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REQUEST_UPDATED_ADD_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* updatedAdditionalDetails(){
  yield takeLatest(TYPES.REQUEST_UPDATED_ADD_DETAILS, updatedAdditionalDetail)
}

function* proceedFromTrans(action){
  try {
    const params = action.payload;
    const response = yield proceedFromTransaction(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.PROCEED_FROM_TRANS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PROCEED_FROM_TRANS_ERROR,
      payload: error,
    });
  }
}

export function* proceedFromTransactionDetails(){
  yield takeLatest(TYPES.PROCEED_FROM_TRANS, proceedFromTrans)
}

function* deleteTrans(action){
  try {
    const params = action.payload;
    const response = yield deleteTransRec(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.DELETE_TRANS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DELETE_TRANS_ERROR,
      payload: error,
    });
  }
}

export function* deleteTransRecord(){
  yield takeLatest(TYPES.DELETE_TRANS, deleteTrans)
}

function* getCode(action){
  try {
    const params = action.payload;
    const response = yield getHSCodes(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.GET_HSCODE_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_HSCODE_ERROR,
      payload: error,
    });
  }
}

export function* getHSCode(){
  yield takeLatest(TYPES.GET_HSCODE, getCode)
}

function* fetchUtilized(action){
  try {
    const params = action.payload;
    const response = yield fetchUtilizedAmt(params);
    const data = response?.data?.invoiceDetails || [];
    if(response?.status === 200){
      yield put({
          type: TYPES.FETCH_UTILIZED_AMOUNT_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.FETCH_UTILIZED_AMOUNT_ERROR,
      payload: error,
    });
  }
}

export function* fetchUtilizedAmount(){
  yield takeLatest(TYPES.FETCH_UTILIZED_AMOUNT, fetchUtilized)
}

function* proceedTransDraft(action){
  try {
    const params = action.payload;
    const response = yield proceedFromTransaction(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.PROCEED_FROM_TRANS_DRAFT_SUCCESS,
          payload: data,
          isButtonClick : action?.isButtonClick
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PROCEED_FROM_TRANS_DRAFT_ERROR,
      payload: error,
    });
  }
}

export function* proceedTransactionDetailsDraft(){
  yield takeLatest(TYPES.PROCEED_FROM_TRANS_DRAFT, proceedTransDraft)
}

function* saveDraft(action){
  try {
    const params = action.payload;
    const response = yield saveDrafts(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.SAVE_AS_DRAFT_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.SAVE_AS_DRAFT_ERROR,
      payload: error,
    });
  }
}

export function* saveAsDraft(){
  yield takeLatest(TYPES.SAVE_AS_DRAFT, saveDraft)
}

function* OFACCountryCheck(action){
  try {
    const params = action.payload;
    const response = yield checkOFACCountry(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.OFAC_COUNTRY_CHECK_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.OFAC_COUNTRY_CHECK_ERROR,
      payload: error,
    });
  }
}

export function* OFACCountry(){
  yield takeLatest(TYPES.OFAC_COUNTRY_CHECK, OFACCountryCheck)
}

function* invEarMarking(action){
  try {
    const params = action.payload;
    const response = yield invoiceEarMark(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.INVOICE_EAR_MARKING_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.INVOICE_EAR_MARKING_ERROR,
      payload: error,
    });
  }
}

export function* invoiceEarMarking(){
  yield takeLatest(TYPES.INVOICE_EAR_MARKING, invEarMarking)
}

function* getDefaultApplicantDetails(action){
  try {
    const params = action.payload;
    const response = yield getDefaultApplicantDetailsAPI(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.GET_DEFAULT_APPLICANT_DETAILS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_DEFAULT_APPLICANT_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getDefApplicantDetails(){
  yield takeLatest(TYPES.GET_DEFAULT_APPLICANT_DETAILS, getDefaultApplicantDetails)
}

function* getSubCustsId(action){
  try {
    const params = action.payload;
    const response = yield getSubCustsIdAPI(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.GET_SUB_CUST_IDS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_SUB_CUST_IDS_ERROR,
      payload: error,
    });
  }
}

export function* getSubCusts(){
  yield takeLatest(TYPES.GET_SUB_CUST_IDS, getSubCustsId)
}

function* getIECode(action){
  try {
    const params = action.payload;
    const response = yield getIECodesAPI(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.GET_IE_CODE_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_IE_CODE_ERROR,
      payload: error,
    });
  }
}

export function* getIECodes(){
  yield takeLatest(TYPES.GET_IE_CODE, getIECode)
}

function* totalAmtVal(action){
  try {
    const params = action.payload;
    const response = yield totalAmtValAPI(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.TOTAL_AMOUNT_VALIDATION_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.TOTAL_AMOUNT_VALIDATION_ERROR,
      payload: error,
    });
  }
}

export function* totalAmtValidation(){
  yield takeEvery(TYPES.TOTAL_AMOUNT_VALIDATION, totalAmtVal)
}

function* fetchInvCharge(action){
  try {
    const params = action.payload;
    const response = yield fetchInvChargesAPI(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.FETCH_INVOICE_CHARGES_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.FETCH_INVOICE_CHARGES_ERROR,
      payload: error,
    });
  }
}

export function* fetchInvCharges(){
  yield takeEvery(TYPES.FETCH_INVOICE_CHARGES, fetchInvCharge)
}
