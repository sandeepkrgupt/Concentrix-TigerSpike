import * as TYPES from "../../utils/types";

export const getTransactions = (data) => ({
  type: TYPES.REQUEST_TRANS_DETAILS,
  payload: data,
});

export const getAddDetails = (data) => ({
  type: TYPES.REQUEST_ADD_DETAILS,
  payload: data,
});

export const getUpdatedAddDetails = (data) => ({
  type: TYPES.REQUEST_UPDATED_ADD_DETAILS,
  payload: data,
});

export const saveAddDetails = (data) => ({
  type: TYPES.SAVE_ADD_DETAILS,
  payload: data,
});

export const proceedFromTrans = (data) => ({
  type: TYPES.PROCEED_FROM_TRANS,
  payload: data,
});

export const deleteTransactions = (data) => ({
  type: TYPES.DELETE_TRANS,
  payload: data,
});

export const getHSCodes = (data) => ({
  type: TYPES.GET_HSCODE,
  payload: data,
});

export const clearSaveCounter = () => ({
  type: TYPES.CLEAR_SAVE_COUNTER,
});

export const clearSuccessStatus = () => ({
  type: TYPES.CLEAR_SUCCESS_STATE,
});

export const saveTotalRemittanceAndBene = (data) => ({
  type: TYPES.SAVE_REMITTANCE_AMOUNT_AND_BENE,
  payload: data,
});

export const saveCurrency = (data) => ({
  type: TYPES.SAVE_CURRENCY,
  payload: data,
});

export const clearStatus = () => ({
  type: TYPES.CLEAR_STATUS,
});

export const fetchUtilizedAmount = (data) => ({
  type: TYPES.FETCH_UTILIZED_AMOUNT,
  payload: data,
});

export const switchStandardProcessing = (data) => ({
  type: TYPES.SWITCH_STANDARD_PROCESSING,
  payload: data,
});

export const clearTrans = () => ({
  type: TYPES.CLEAR_TRANS,
});

export const proceedFromTransDraft = (data, isButtonClick) => ({
  type: TYPES.PROCEED_FROM_TRANS_DRAFT,
  payload: data,
  isButtonClick: isButtonClick,
});

export const saveAsDraft = (data) => ({
  type: TYPES.SAVE_AS_DRAFT,
  payload: data,
});

export const clearTransDraftMsgStatus = () => ({
  type: TYPES.CLEAR_TRANS_MSG_STATUS,
});

export const OFACCountryCheck = (data) => ({
  type: TYPES.OFAC_COUNTRY_CHECK,
  payload: data,
});

export const invoiceEarmarking = (data) => ({
  type: TYPES.INVOICE_EAR_MARKING,
  payload: data,
});

export const setRecKey = (data) => ({
  type: TYPES.SET_REC_KEY,
  payload: data,
});

export const clearChannelRefNo = () => ({ type: TYPES.CLEAR_CHANNEL_REF_NO });

export const getDefaultApplicantDetails = (data) => ({
    type: TYPES.GET_DEFAULT_APPLICANT_DETAILS,
    payload: data
})

export const getSubCustIds = (data) => ({
    type: TYPES.GET_SUB_CUST_IDS,
    payload: data
})

export const getIeCodes = (data) => ({
    type: TYPES.GET_IE_CODE,
    payload: data
})

export const setCustIdAndIeCode = (data) => ({
    type: TYPES.SET_CUST_ID_AND_IE_CODE,
    payload: data
})

export const totalAmountValidation = (data) => ({
  type: TYPES.TOTAL_AMOUNT_VALIDATION,
  payload: data
})

export const fetchInvoiceCharges = (data) => ({
  type: TYPES.FETCH_INVOICE_CHARGES,
  payload: data
})
