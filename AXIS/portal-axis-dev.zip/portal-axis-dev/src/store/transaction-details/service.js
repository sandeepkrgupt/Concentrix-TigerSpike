import instance from "../../services";

export const getTransDetail = (data) => {
    return instance
      .post(`/payment-transaction/boe-list`, data)
      .then((res) => res)
      .catch((err) => err);
};

export const getAddDetail = (data) => {
  return instance
      .post(`/payment-transaction/additional-details`, data)
      .then((res) => res)
      .catch((err) => err);
};

export const saveAddDetail = (data) => {
  return instance
    .post(`/payment-transaction/save-boe`, data)
    .then((res) => res)
    .catch((err) => err);
}

export const getUpdatedAddDetail = (data) => {
  return instance
  .post(`/payment-transaction/update-details`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const proceedFromTransaction = (data)=>{
  return instance
  .post(`/payment-transaction/proceed`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const deleteTransRec = (data)=>{
  return instance
  .post(`/reviewSubmit/deleteTxnRecords`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const getHSCodes = (data)=>{
  return instance
  .post(`/payment-transaction/get-hscode-details`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const fetchUtilizedAmt = (data) =>{
  return instance
  .post(`/payment-transaction/utilized-amount`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const saveDrafts = (data) =>{
  return instance
  .post(`saveAsDraft/txnSaveAsDraft`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const checkOFACCountry = (data) => {
  return instance
  .post(`/payment-transaction/checkOFACValidation`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const invoiceEarMark = (data) => {
  return instance
  .post(`/earmarking/earmarkingInvoice`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const getDefaultApplicantDetailsAPI = (data) => {
  return instance
  .post(`/reviewSubmit/getDefaultApplicantDetails`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const getSubCustsIdAPI = (data) => {
  return instance
  .post(`/payment-transaction/getSubCustIds`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const getIECodesAPI = (data) => {
  return instance
  .post(`/payment-transaction/getIECodes`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const totalAmtValAPI = (data) => {
  return instance
  .post(`/payment-transaction/totalAmountValidation`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const fetchInvChargesAPI = (data) => {
  return instance
  .post(`/payment-transaction/fetchInvoiceCharges`, data)
  .then((res) => res)
  .catch((err) => err);
}