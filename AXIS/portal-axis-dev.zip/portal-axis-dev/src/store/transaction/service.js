import instance from "../../services";

export const getTransactionsList = (data, action) => {
  return instance
    .post(`/transaction/inquiry/${action}`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getExport = (data, action) => {
  return instance
    .post(`/transaction/export`, data, {responseType: 'blob'})
    .then((response) => {
      const authData = JSON.parse(localStorage.getItem('authData'));
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `FIDB_PAYMENT_REPORT_${authData?.appDate}.xlsx`);// or any other extension
      document.body.appendChild(link);
      link.click();
    })
    .catch((err) => err);
};

 export const getDownloadDoc =(data, action)=>{
  return instance
    .post(`/transaction/download-document/${action}`, data,
     {responseType: 'blob'} 
     )
    .then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `${action}_${data?.refNumber}.zip`);// or any other extension
      document.body.appendChild(link);
      link.click();
    })
    .catch((err) => err);
};


export const getStatistics = (data) => {
  return instance
    .post(`transaction/statistics`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getTransactionFiltersList = (data, action) => {
  return instance
    .post(`/transaction/filter-dropdown/${action}`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getTiBoeDetailsList = (data) => {
  return instance
    .post(`/boeinquiry/transInq`, data)
    .then((res) => res)
    .catch((err) => err);
};


export const delTransaction = (data) => {
  return instance
    .post(`/transaction/delete`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const withdrawTrans = (data)=>{
  return instance
  .post(`/reviewSubmit/withdrawn`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const validatePayDate = (data)=>{
  return instance
  .post(`/payment-transaction/validateRescheduleDate`, data)
  .then((res) => res)
  .catch((err) => err);
}

export const reschedulePay = (data)=>{
  return instance
  .post(`/payment-transaction/reschedulePaymentDate`, data)
  .then((res) => res)
  .catch((err) => err);
}