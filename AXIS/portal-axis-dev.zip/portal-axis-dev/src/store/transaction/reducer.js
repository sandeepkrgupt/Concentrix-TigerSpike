import * as TYPES from "../../utils/types";

const initialState = {
  loader: false,
  transactions: [],
  statistics: [],
  transactionFilters: {},
  tiBoeDetails: {},
  deleteTransaction: false,
  withdrawTransaction: false,
  withdrawTransactionMessage: null,
  isValidStatus: "",
  isDateValidated: "",
};
export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQUEST_TRANSACTION_INQUIRY:
      return { ...state, loader: true, deleteTransaction: false };
    case TYPES.TRANSACTION_INQUIRY_SUCCESS: {
      return {
        ...state,
        transactions: action.payload?.transactionList,
        totalPage: action?.payload?.transactionPagination?.totalRecordSize,
        loader: false,
      };
    }
    case TYPES.REQUEST_TRANSACTION_STATISTICS:
      return { ...state, loader: true, statistics: [] };
    case TYPES.TRANSACTION_STATISTICS_SUCCESS: {
      return {
        ...state,
        statistics: action.payload,
        loader: false,
      };
    }
    case TYPES.REQUEST_TRANSACTION_FILTERS:
      return { ...state, loader: true };
    case TYPES.TRANSACTION_FILTERS_SUCCESS: {
      return {
        ...state,
        transactionFilters: action.payload,
        loader: false,
      };
    }
    case TYPES.REQUEST_TIBOE_DETAILS:
      return { ...state, loader: true };
    case TYPES.TIBOE_DETAILS_SUCCESS: {
      return {
        ...state,
        tiBoeDetails: action.payload,
        loader: false,
      };
    }
    case TYPES.REQUEST_DELETE_TRANSACTION: {
      return {
        ...state,
        deleteTransaction: false,
      };
    }
    case TYPES.DELETE_TRANSACTION_SUCCESS: {
      return {
        ...state,
        deleteTransaction: true,
      };
    }
    case TYPES.DELETE_TRANSACTION_ERROR: {
      return {
        ...state,
        deleteTransaction: false,
      };
    }
    case TYPES.REQUEST_WITHDRAW_TRANSACTION: {
      return {
        ...state,
        withdrawTransaction: false,
        withdrawTransactionMessage: null,
      };
    }
    case TYPES.WITHDRAW_TRANSACTION_SUCCESS: {
      return {
        ...state,
        withdrawTransaction: true,
        withdrawTransactionMessage: action?.payload?.status,
      };
    }
    case TYPES.WITHDRAW_TRANSACTION_ERROR: {
      return {
        ...state,
        withdrawTransaction: false,
        withdrawTransactionMessage: null,
      };
    }
    case TYPES.RESCHEDULE_PAY_DATE:
      return {
        ...state,
        loader: false,
      };
    case TYPES.VALIDATE_RESCHEDULE_PAY_DATE:
      return {
        ...state,
        loader: false,
      };
    case TYPES.RESCHEDULE_PAY_DATE_SUCCESS:
      return {
        ...state,
        isDateValidated: action?.payload?.status,
      };
    case TYPES.VALIDATE_RESCHEDULE_PAY_DATE_SUCCESS:
      return {
        ...state,
        isValidStatus: action?.payload?.status,
      };
    case TYPES.CLEAR_RESCHEDULE_DATE_STATUS:
      return {
        ...state,
        isValidStatus: "",
        isDateValidated: "",
      };
    case TYPES.CLEAR_WITHDRAW_STATUS:
      return {
        ...state,
        withdrawTransaction: false,
        withdrawTransactionMessage: null,
      }
    default:
      return { ...state };
  }
}
