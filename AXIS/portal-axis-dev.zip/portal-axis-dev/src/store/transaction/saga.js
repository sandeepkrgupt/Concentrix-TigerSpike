import * as TYPES from "../../utils/types";
import { takeLatest, put } from "redux-saga/effects";
import {
  getTransactionsList,
  getStatistics,
  getExport,
  getTransactionFiltersList,
  getTiBoeDetailsList,
  getDownloadDoc,
  delTransaction,
  withdrawTrans,
  reschedulePay,
  validatePayDate,
} from "./service";

function* transactions(action) {
  try {
    const params = action.payload;
    const status = action?.action;
    const response = yield getTransactionsList(params, status);
    const data = response?.data?.responseBody;
    if (response?.status === 200) {
      yield put({
        type: TYPES.TRANSACTION_INQUIRY_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.TRANSACTION_INQUIRY_ERROR,
      payload: error,
    });
  }
}

export function* getTransactions() {
  yield takeLatest(TYPES.REQUEST_TRANSACTION_INQUIRY, transactions);
}

function* transactionStatistics(action) {
  try {
    const params = action.payload;
    const response = yield getStatistics(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.TRANSACTION_STATISTICS_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.TRANSACTION_STATISTICS_ERROR,
      payload: error,
    });
  }
}

export function* getTransactionStatistics() {
  yield takeLatest(TYPES.REQUEST_TRANSACTION_STATISTICS, transactionStatistics);
}

function* exportRec(action) {
  try {
    const params = action.payload;
    const status = action?.action;
    const response = yield getExport(params, status);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.EXPORT_RECORD_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.EXPORT_RECORD_ERROR,
      payload: error,
    });
  }
}

export function* exportRecords() {
  yield takeLatest(TYPES.REQUEST_EXPORT_RECORD, exportRec);
}

function* downloadDoc(action) {
  try {
    const params = action.payload;
    const status = action?.action;
    const response = yield getDownloadDoc(params, status);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DOWNLOAD_DOCUMENTS_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DOWNLOAD_DOCUMENTS_ERROR,
      payload: error,
    });
  }
}

export function* downloadDocs() {
  yield takeLatest(TYPES.REQUEST_DOWNLOAD_DOCUMENTS, downloadDoc);
}

function* transactionFilters(action) {
  try {
    const params = action.payload;
    const status = action?.action;
    const response = yield getTransactionFiltersList(params, status);
    const data = response?.data?.responseBody;
    if (response?.status === 200) {
      yield put({
        type: TYPES.TRANSACTION_FILTERS_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.TRANSACTION_FILTERS_ERROR,
      payload: error,
    });
  }
}

export function* getTransactionFilters() {
  yield takeLatest(TYPES.REQUEST_TRANSACTION_FILTERS, transactionFilters);
}

function* tiBoeDetails(action) {
  try {
    const params = action.payload;
    const response = yield getTiBoeDetailsList(params);
    const data = response?.data?.fidbTransactionInquiryResponse;
    if (response?.status === 200) {
      yield put({
        type: TYPES.TIBOE_DETAILS_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.TIBOE_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getTiBoeDetails() {
  yield takeLatest(TYPES.REQUEST_TIBOE_DETAILS, tiBoeDetails);
}

function* deleteTransaction(action) {
  try {
    const params = action.payload;
    const response = yield delTransaction(params);
    if (response?.status === 200) {
      yield put({
        type: TYPES.DELETE_TRANSACTION_SUCCESS,
        // payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DELETE_TRANSACTION_ERROR,
      payload: error,
    });
  }
}

export function* deleteTransactions() {
  yield takeLatest(TYPES.REQUEST_DELETE_TRANSACTION, deleteTransaction);
}

function* withdrawTxn(action) {
  try {
    const params = action?.payload;
    const response = yield withdrawTrans(params);
    if (response?.status === 200) {
      console.log(response);
      yield put({
        type: TYPES.WITHDRAW_TRANSACTION_SUCCESS,
        payload: response?.data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.WITHDRAW_TRANSACTION_ERROR,
      payload: error,
    });
  }
}

export function* withdrawTransaction() {
  yield takeLatest(TYPES.REQUEST_WITHDRAW_TRANSACTION, withdrawTxn);
}

function* reschedulePayDate(action) {
  try {
    const params = action?.payload;
    const response = yield reschedulePay(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.RESCHEDULE_PAY_DATE_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.RESCHEDULE_PAY_DATE_ERROR,
      payload: error,
    });
  }
}

export function* rescheduleDate() {
  yield takeLatest(TYPES.RESCHEDULE_PAY_DATE, reschedulePayDate);
}

function* validateReschedulePayDate(action) {
  try {
    const params = action?.payload;
    const response = yield validatePayDate(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.VALIDATE_RESCHEDULE_PAY_DATE_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.VALIDATE_RESCHEDULE_PAY_DATE_ERROR,
      payload: error,
    });
  }
}

export function* validateRescheduleDate() {
  yield takeLatest(
    TYPES.VALIDATE_RESCHEDULE_PAY_DATE,
    validateReschedulePayDate
  );
}
