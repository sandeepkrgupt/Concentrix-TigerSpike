import * as TYPES from "../../utils/types";

export const getTransactionInquiry = (data, action) => ({
  type: TYPES.REQUEST_TRANSACTION_INQUIRY,
  payload: data,
  action
});

export const getTransactionStatistics = (data) => ({
  type: TYPES.REQUEST_TRANSACTION_STATISTICS,
  payload: data,
});

export const exportRecord = (data, action)=>({
  type: TYPES.REQUEST_EXPORT_RECORD,
  payload: data,
  action
})

export const downloadDocuments = (data, action)=>({
  type: TYPES.REQUEST_DOWNLOAD_DOCUMENTS,
  payload: data,
  action
})


export const getTransactionFilters=(data, action)=>({
  type: TYPES.REQUEST_TRANSACTION_FILTERS,
  payload: data,
  action
})

export const getTiBoeDetails =(data)=>({
  type: TYPES.REQUEST_TIBOE_DETAILS,
  payload: data
})

export const deleteTransaction=(req)=>({
  type: TYPES.REQUEST_DELETE_TRANSACTION,
  payload: req
})

export const withdrawTransaction=(req)=>({
  type: TYPES.REQUEST_WITHDRAW_TRANSACTION,
  payload: req
})

export const reschedulePaymentDate = (req) => ({
  type: TYPES.RESCHEDULE_PAY_DATE,
  payload: req
});

export const validateRescheduleDate = (req) => ({
  type: TYPES.VALIDATE_RESCHEDULE_PAY_DATE,
  payload: req
});

export const clearRescheduleDateStatus = () => ({
  type: TYPES.CLEAR_RESCHEDULE_DATE_STATUS
});

export const clearWithdrawMsg = () => ({
  type: TYPES.CLEAR_WITHDRAW_STATUS
})