import instance from "../../services";

export const loginService = (data) => {
  return instance
    .post("/login", data)
    .then((res) => res)
    .catch((err) => err);
};

export const lastLoginService = (data) => {
  return instance
    .post("/lastLogin", data)
    .then((res) => res)
    .catch((err) => err);
};
