import * as TYPES from "../../utils/types";

export const requestLogin = (data) => ({
  type: TYPES.REQUEST_LOGIN,
  payload: data
});

export const getLastLogin=(data)=>({
  type: TYPES.REQUEST_LAST_LOGIN,
  payload: data
})