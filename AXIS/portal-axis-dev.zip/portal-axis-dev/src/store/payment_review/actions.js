import * as TYPES from "../../utils/types";

export const getTransactionReviewData = (data) => ({
  type: TYPES.REQUEST_TRANSACTION_REVIEW,
  payload: data,
});

export const getpaymentReviewData = (data) => ({
  type: TYPES.REQUEST_PAYMENT_REVIEW,
  payload: data,
});

export const getBeneficiaryReviewData = (data) => ({
  type: TYPES.REQUEST_BENEFICIARY_REVIEW,
  payload: data,
});

export const getAttachDocumentsReviewData = (data) => ({
  type: TYPES.REQUEST_ATTACHDOCUMENT_REVIEW,
  payload: data,
});

export const downloadAttachedDocuments = (data) => ({
  type: TYPES.REQUEST_DOWNLOAD_ATTACHED_DOC,
  payload: data,
});

export const getTransactionWorkflowDetails = (data) => ({
  type: TYPES.REQUEST_TRANSACTION_WORKFLOW,
  payload: data,
});

export const getWorkflowGroup = (data) => ({
  type: TYPES.REQUEST_WORKFLOW_GROUP,
  payload: data,
});

export const getWorkflowUserList = (data) => ({
  type: TYPES.REQUEST_WORKFLOW_USERLIST,
  payload: data,
});

export const getdefaultWorkflow = (data) => ({
  type: TYPES.REQUEST_DEFAULT_WORKFLOW,
  payload: data,
});

export const submitWorkflow = (data) => {
  return {
    type: TYPES.REQUEST_WORKFLOW_SUBMIT,
    payload: data,
  };
};

export const fetchWorkflowDetails = (data) => ({
  type: TYPES.REQUEST_WORKFLOW_DETAILS,
  payload: data,
});

export const getBookRate = (data) => {
  return {
    type: TYPES.REQUEST_BOOK_RATE,
    payload: data,
  };
};

export const getFxRateMarginValidation = (data) => {
  return {
    type: TYPES.REQUEST_FX_RATE_MARGIN,
    payload: data,
  };
};

export const bookFxRate = (data) => {
  return {
    type: TYPES.BOOK_FX_RATE,
    payload: data,
  };
};
export const validateDeals = (data) => ({
  type: TYPES.VALIDATE_DEALS,
  payload: data,
});

export const validateTxnAmountRange = (data) => ({
  type: TYPES.VALIDATE_TXN_AMOUNT_RANGE,
  payload: data,
});

export const clearTxmAmtAndDealsStatus = (data) => ({
  type: TYPES.VALIDATE_TXN_AMOUNT_RANGE_AND_DEALS,
});

export const acceptReject = (data) => {
  return {
    type: TYPES.ACCEPT_REJECT,
    payload: data,
  };
};

export const addBeneDetailsOnCheckerApproval = (data) => {
  return {
    type: TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL,
    payload: data,
  };
};

export const getBeneficiarytDetails = (data) => {
  return {
    type: TYPES.GET_BENEFICIARY_DETAILS,
    payload: data,
  };
};

export const saveComments = (data) => {
  return {
    type: TYPES.SAVE_COMMENTS,
    payload: data,
  };
};

export const getAccountDetails = (data) => {
  return {
    type: TYPES.GET_ACCOUNT_DETAILS,
    payload: data,
  };
};

export const clearPaymentReview = () => {
  return {
    type: TYPES.CLEAR_PAYMENT_REVIEW_DATA,
  };
};

export const updateFxRateAmount = (data) => ({
  type: TYPES.UPDATE_FXRATEAMOUNT,
  payload: data,
});

export const fetchComments = (data) => ({
  type: TYPES.FETCH_COMMENTS,
  payload: data,
});

export const getCardRate = (data) => ({
  type: TYPES.GET_CARD_RATE,
  payload: data,
});

export const totalAmountValidation = (data) => ({
  type: TYPES.TOTAL_AMOUNT_VALIDATOIN,
  payload: data,
});

export const dealAmountValidation = (data) => ({
  type: TYPES.DEAL_AMOUNT_VALIDATION,
  payload: data,
});
