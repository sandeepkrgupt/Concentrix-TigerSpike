import * as TYPES from "../../utils/types";

const initialState = {
  loader: false,
  transactionDetails: null,
  paymentDetails: null,
  beneficiaryDetails: null,
  attchedDocuments: null,
  transactionWorkflow: null,
  paymentSuccess: false,
  paymentFail: false,
  workflowDetails: null,
  submitResponse: null,
  bookRate: null,
  displayRate: null,
  fxRateMessageId: null,
  fxRateStatus: null,
  fxRateAmount: null,

  fidbMargin: null,
  branchCode: null,
  currency: null,
  fxRateResponse: null,

  tridbNumber: null,
  // bookRateType:null,
  convertedAmount: null,
  beneAccDetails: null,
  beneDetails: null,

  validateDeals: {},
  validateTxnAmt: {},
  remarks: null,
  comments: {},
  cardRate: null,
  cardRateStatus: null,
  totalAmountValidationStatus: null,
  totalAmountValidationInvoiceNo: null,
  dealAmountValidationStatus: null,
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQUEST_WORKFLOW_USERLIST ||
      TYPES.REQUEST_TRANSACTION_REVIEW ||
      TYPES.REQUEST_PAYMENT_REVIEW ||
      TYPES.REQUEST_BENEFICIARY_REVIEW ||
      TYPES.REQUEST_ATTACHDOCUMENT_REVIEW ||
      TYPES.REQUEST_DEFAULT_WORKFLOW ||
      TYPES.REQUEST_TRANSACTION_WORKFLOW ||
      TYPES.REQUEST_WORKFLOW_GROUP ||
      TYPES.REQUEST_WORKFLOW_SUBMIT ||
      TYPES.REQUEST_WORKFLOW_DETAILS ||
      TYPES.VALIDATE_DEALS ||
      TYPES.VALIDATE_TXN_AMOUNT_RANGE ||
      TYPES.GET_ACCOUNT_DETAILS ||
      TYPES.GET_BENEFICIARY_DETAILS ||
      TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL ||
      TYPES.UPDATE_FXRATEAMOUNT ||
      TYPES.GET_CARD_RATE ||
      TYPES.TOTAL_AMOUNT_VALIDATOIN ||
      TYPES.DEAL_AMOUNT_VALIDATION ||
      TYPES.SAVE_COMMENTS: {
      return { ...state, loader: true };
    }

    case TYPES.REVIEW_TRANSACTION_SUCCESS: {
      return {
        ...state,
        transactionDetails: action?.payload,
        loader: false,
      };
    }

    case TYPES.REVIEW_PAYMENT_SUCCESS: {
      return {
        ...state,
        paymentDetails: action?.payload,
        loader: false,
      };
    }

    case TYPES.REVIEW_BENEFICIARY_SUCCESS: {
      return {
        ...state,
        beneficiaryDetails: action?.payload,
        loader: false,
      };
    }

    case TYPES.REVIEW_ATTACHEMENTS_SUCCESS: {
      return {
        ...state,
        attchedDocuments: action?.payload,
        loader: false,
      };
    }

    case TYPES.TRANSACTION_WORKFLOW_SUCCESS: {
      return {
        ...state,
        transactionWorkflow: action?.payload,
        loader: false,
      };
    }

    case TYPES.WORKFLOW_GROUP_SUCCESS: {
      return {
        ...state,
        transactionWorkflow: {
          ...state?.transactionWorkflow,
          workflowGroupList: action?.payload,
        },
        loader: false,
      };
    }
    case TYPES.WORKFLOW_USERLIST_SUCCESS: {
      return {
        ...state,
        transactionWorkflow: {
          ...state?.transactionWorkflow,
          workflowUserList: action?.payload,
        },
        loader: false,
      };
    }

    case TYPES.DEFAULT_WORKFLOW_SUCCESS: {
      return {
        ...state,
        transactionWorkflow: {
          ...state?.transactionWorkflow,
          workflowUserList: action?.payload,
        },
      };
    }

    case TYPES.WORKFLOW_SUBMIT_SUCCESS: {
      if (action?.payload.action === "reject") {
        return {
          ...state,
          paymentFail: true,
          submitResponse: action?.payload?.data,
          loader: false,
        };
      } else {
        return {
          ...state,
          paymentSuccess: true,
          submitResponse: action?.payload?.data,
          loader: false,
        };
      }
    }

    case TYPES.WORKFLOW_DETAILS_SUCCESS: {
      return { ...state, workflowDetails: action?.payload, loader: false };
    }

    case TYPES.REVIEW_DATA_ERROR:
      return { ...state, loader: false };

    case TYPES.REQUEST_BOOK_RATE:
      return {
        ...state,
        loader: true,
      };
    case TYPES.REQUEST_BOOK_RATE_SUCCESS:
      return {
        ...state,
        loader: false,
        bookRate: action?.payload,
      };
    case TYPES.REQUEST_BOOK_RATE_ERROR:
      return {
        ...state,
        loader: false,
        bookRate: 1000, // dummy value
      };

    case TYPES.REQUEST_FX_RATE_MARGIN:
      return {
        ...state,
        loader: true,
      };
    case TYPES.REQUEST_FX_RATE_MARGIN_SUCCESS:
      return {
        ...state,
        loader: false,
        displayRate: action?.payload?.displayRate,
        fxRateMessageId: action?.payload?.fxRateMessageId,
        fxRateStatus: action?.payload?.status,
        fidbMargin: action?.payload?.fidbMargin,
        fxRateResponse: action?.payload?.fxRateResponse,
        // branchCode: action?.payload?.branchCode,
        // currency: action?.payload?.currency,
      };
    case TYPES.REQUEST_FX_RATE_MARGIN_ERROR:
      return {
        ...state,
        loader: false,
        displayRate: null,
        fxRateMessageId: null,
        fxRateStatus: null,
        fidbMargin: null,
        // branchCode: null,
        // currency: null,
        fxRateResponse: null,
      };

    case TYPES.BOOK_FX_RATE:
      return {
        ...state,
        loader: true,
      };
    case TYPES.BOOK_FX_RATE_SUCCESS: {
      return {
        ...state,
        loader: false,
        tridbNumber: action?.payload?.fxDealBookingId,
        convertedAmount: action?.payload?.convertedAmount,
      };
    }

    case TYPES.BOOK_FX_RATE_ERROR:
      return {
        ...state,
        loader: false,
        tridbNumber: null,
        convertedAmount: null,
      };

    case TYPES.ACCEPT_REJECT:
      return {
        ...state,
        loader: true,
      };
    case TYPES.ACCEPT_REJECT_SUCCESS: {
      // if isBulk set, it will be coming from bulk reject
      if (action?.payload?.isBulk) {
        return {
          ...state,
          loader: false,
          paymentFail: true,
        };
      } else {
        return {
          ...state,
          loader: false,
          paymentSuccess: true,
        };
      }
    }
    case TYPES.ACCEPT_REJECT_ERROR: {
      return {
        ...state,
        loader: false,
      };
    }

    case TYPES.CLEAR_PAYMENT_REVIEW_DATA:
    case TYPES.CLEAR_PAYMENT_REVIEW_DATA_SUCCESS:
    case TYPES.CLEAR_PAYMENT_REVIEW_DATA_ERROR:
      return {
        ...state,
        loader: false,
        transactionDetails: null,
        paymentDetails: null,
        beneficiaryDetails: null,
        attchedDocuments: null,
        transactionWorkflow: null,
        paymentSuccess: false,
        paymentFail: false,
        workflowDetails: null,
        submitResponse: null,
        bookRate: null,
        displayRate: null,
        fxRateMessageId: null,
        fxRateStatus: null,
        fxRateAmount: null,
        tridbNumber: null,
        convertedAmount: null,
        beneAccDetails: null,
        beneDetails: null,
        validateDeals: {},
        validateTxnAmt: {},
      };

    case TYPES.VALIDATE_DEALS_SUCCESS:
      return {
        ...state,
        loader: false,
        validateDeals: action?.payload,
      };
    case TYPES.VALIDATE_DEALS_ERROR:
      return {
        ...state,
        loader: false,
        validateDeals: action?.payload,
      };
    case TYPES.VALIDATE_TXN_AMOUNT_RANGE_SUCCESS:
      return {
        ...state,
        loader: false,
        validateTxnAmt: action?.payload,
      };
    case TYPES.VALIDATE_TXN_AMOUNT_RANGE_ERROR:
      return {
        ...state,
        loader: false,
        validateTxnAmt: action?.payload,
      };
    case TYPES.VALIDATE_TXN_AMOUNT_RANGE_AND_DEALS:
      return {
        ...state,
        loader: false,
        validateTxnAmt: {},
        validateDeals: {},
      };
    case TYPES.GET_ACCOUNT_DETAILS_SUCCESS:
      return {
        ...state,
        loader: false,
        beneAccDetails: action?.payload,
      };
    case TYPES.GET_ACCOUNT_DETAILS_ERROR:
      return {
        ...state,
        loader: false,
        beneAccDetails: null,
      };
    case TYPES.GET_BENEFICIARY_DETAILS_SUCCESS:
      return {
        ...state,
        loader: false,
        beneDetails: action?.payload,
      };
    case TYPES.GET_BENEFICIARY_DETAILS_ERROR:
      return {
        ...state,
        loader: false,
        beneDetails: null,
      };
    case TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL_SUCCESS:
      return {
        ...state,
        loader: false,
      };
    case TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL_ERROR:
      return {
        ...state,
        loader: false,
      };
    case TYPES.UPDATE_FXRATEAMOUNT_SUCCESS:
      return {
        ...state,
        loader: false,
        fxRateAmount: action?.payload,
      };
    case TYPES.UPDATE_FXRATEAMOUNT_ERROR:
      return {
        ...state,
        loader: false,
        fxRateAmount: null,
      };
    case TYPES.GET_CARD_RATE_SUCCESS: {
      console.log(action?.payload);
      return {
        ...state,
        loader: false,
        cardRate: action?.payload?.cardRate,
        cardRateStatus: action?.payload?.status,
      };
    }
    case TYPES.GET_CARD_RATE_ERROR:
      return {
        ...state,
        loader: false,
        cardRate: null,
        cardRateStatus: null,
      };
    case TYPES.TOTAL_AMOUNT_VALIDATOIN_SUCCESS:
      return {
        ...state,
        loader: false,
        totalAmountValidationStatus: action?.payload?.statusMessage,
        totalAmountValidationInvoiceNo: action?.payload?.invoiceNo,
      };
    case TYPES.TOTAL_AMOUNT_VALIDATOIN_ERROR:
      return {
        ...state,
        loader: false,
        totalAmountValidationStatus: null,
        totalAmountValidationInvoiceNo: null,
      };
    case TYPES.DEAL_AMOUNT_VALIDATION_SUCCESS:
      return {
        ...state,
        loader: false,
        dealAmountValidationStatus: action?.payload?.statusMessage,
      };
    case TYPES.DEAL_AMOUNT_VALIDATION_ERROR:
      return {
        ...state,
        loader: false,
        dealAmountValidationStatus: null,
      };
    case TYPES.SAVE_COMMENTS_SUCCESS: {
      const newRemarks = [...state?.remarks];
      newRemarks[action?.payload?.id] = action?.payload?.remarks;
      return {
        ...state,
        loader: false,
        remarks: [...newRemarks],
      };
    }

    case TYPES.SAVE_COMMENTS_ERROR:
    case TYPES.FETCH_COMMENTS:
      return {
        ...state,
        loader: false,
      };
    case TYPES.FETCH_COMMENTS_SUCCESS:
      switch (action?.payload?.id) {
        case "0":
          return {
            ...state,
            comments: {
              ...state.comments,
              trans: action.payload.comment,
            },
          };
        case "1":
          return {
            ...state,
            comments: {
              ...state.comments,
              bene: action.payload.comment,
            },
          };
        case "2":
          return {
            ...state,
            comments: {
              ...state.comments,
              payment: action.payload.comment,
            },
          };
        case "3":
          return {
            ...state,
            comments: {
              ...state.comments,
              attachment: action.payload.comment,
            },
          };
        case "4":
          return {
            ...state,
            comments: {
              ...state.comments,
              overall: action.payload.comment,
            },
          };
      }
      break;
    default:
      return { ...state };
  }
}
