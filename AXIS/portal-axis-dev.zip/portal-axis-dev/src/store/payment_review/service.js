import instance from "../../services";

export const transactionReviewService = (data) => {
  return instance
    .post("/review/transaction", data)
    .then((res) => res)
    .catch((err) => err);
};

export const paymentReviewService = (data) => {
  return instance
    .post("/review/payment", data)
    .then((res) => res)
    .catch((err) => err);
};

export const beneficiaryReviewService = (data) => {
  return instance
    .post("/review/beneficiary", data)
    .then((res) => res)
    .catch((err) => err);
};

export const attachmentReviewService = (data) => {
  return instance
    .post("/payment/attachments", data)
    .then((res) => res)
    .catch((err) => err);
};

export const downloadDocService = (data, action) => {
  return instance
    .post("/payment/download", data, {
      responseType: "blob",
    })
    .then((response) => {
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute("download", `${data?.fileName}`); // or any other extension
      document.body.appendChild(link);
      link.click();
    })
    .catch((err) => err);
};

export const trnsactionWorkflowService = (data) => {
  return instance
    .post("/workflow/transaction-workflow", data)
    .then((res) => res)
    .catch((err) => err);
};

export const workFlowGroupService = (data) => {
  return instance
    .post("/workflow/workflow-change", data)
    .then((res) => res)
    .catch((err) => err);
};

export const workFlowUserListService = (data) => {
  return instance
    .post("/workflow/workflow-group-change", data)
    .then((res) => res)
    .catch((err) => err);
};

export const defaultWorkFlowService = (data) => {
  return instance
    .post("/workflow/default-workflow ", data)
    .then((res) => res)
    .catch((err) => err);
};

export const submitWorkflowService = (data) => {
  return instance
    .post("/reviewSubmit/submitDetails", data)
    .then((res) => res)
    .catch((err) => err);
};

export const workflowDetailsService = (data) => {
  return instance
    .post("/workflow/workflow-details", data)
    .then((res) => res)
    .catch((err) => err);
};

export const getBookRateService = (data) => {
  return instance
    .post(`/paymentDetails/bookFxRate`, data) // @todo confirm end point
    .then((res) => res)
    .catch((err) => err);
};

export const getFxRateMarginValidationService = (data) => {
  return instance
    .post(`/paymentDetails/getFxRateMarginValidation`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getAccountDetailsService = (data) => {
  return instance
    .post(`/beneficiaryDetails/getAccountDetails`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getBeneficiarytDetailsService = (data) => {
  return instance
    .post(`/beneficiaryDetails/getBeneficiarytDetails`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const bookFxRateService = (data) => {
  return instance
    .post(`/paymentDetails/bookFxRate`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const acceptRejectService = (data) => {
  return instance
    .post(`/reviewSubmit/approval-reject`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const saveCommentsService = (data) => {
  return instance
    .post(`/comments/saveComments`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const addBeneDetailsOnCheckerApprovalService = (data) => {
  return instance
    .post(`/beneficiaryDetails/addBeneDetailsOnCheckerApproval`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const validateDeal = (data) => {
  return instance
    .post(`/reviewSubmit/validateDeals`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const validateTxnAmountRangeService = (data) => {
  return instance
    .post(`/reviewSubmit/validateTxnAmountRange`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const fetchCommAPI = (data) => {
  return instance
    .post(`/comments/fetchComments`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getCardRate = (data) => {
  return instance
    .post(`/paymentDetails/getCardRate`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const totalAmountValidationService = (data) => {
  return instance
    .post(`/payment-transaction/totalAmountValidation`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const dealAmountValidationService = (data) => {
  return instance
    .post(`/paymentDetails/dealAmountValidation`, data)
    .then((res) => res)
    .catch((err) => err);
};
