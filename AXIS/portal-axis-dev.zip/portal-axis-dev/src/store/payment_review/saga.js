import * as TYPES from "../../utils/types";
import { takeLatest, put, takeEvery } from "redux-saga/effects";
import {
  transactionReviewService,
  paymentReviewService,
  beneficiaryReviewService,
  attachmentReviewService,
  downloadDocService,
  trnsactionWorkflowService,
  workFlowGroupService,
  workFlowUserListService,
  defaultWorkFlowService,
  submitWorkflowService,
  workflowDetailsService,
  getBookRateService,
  getFxRateMarginValidationService,
  bookFxRateService,
  validateDeal,
  validateTxnAmountRangeService,
  acceptRejectService,
  getAccountDetailsService,
  getBeneficiarytDetailsService,
  addBeneDetailsOnCheckerApprovalService,
  saveCommentsService,
  fetchCommAPI,
  getCardRate,
  totalAmountValidationService,
  dealAmountValidationService,
} from "./service";

// TRANSACTION REVIEW
function* transactionReview(action) {
  try {
    const params = action.payload;
    const response = yield transactionReviewService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.REVIEW_TRANSACTION_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchTransactionReviewDetails() {
  yield takeLatest(TYPES.REQUEST_TRANSACTION_REVIEW, transactionReview);
}

// PAYMENT REVIEW
function* paymentReview(action) {
  try {
    const params = action.payload;
    const response = yield paymentReviewService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.REVIEW_PAYMENT_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchPaymentReviewDetails(params) {
  yield takeLatest(TYPES.REQUEST_PAYMENT_REVIEW, paymentReview);
}

// BENEFICIARY REVIEW
function* beneficiaryReview(action) {
  try {
    const params = action.payload;
    const response = yield beneficiaryReviewService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.REVIEW_BENEFICIARY_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchBenficiaryReviewDetails() {
  yield takeLatest(TYPES.REQUEST_BENEFICIARY_REVIEW, beneficiaryReview);
}

// ATTACH DOCUMENTS REVIEW
function* attachmentReview(action) {
  try {
    const params = action.payload;
    const response = yield attachmentReviewService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.REVIEW_ATTACHEMENTS_SUCCESS,
        payload: data?.attachmentPayload,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchAttachmentsReviewDetails() {
  yield takeLatest(TYPES.REQUEST_BENEFICIARY_REVIEW, attachmentReview);
}

// DOWNLOAD ATTACHED DOCUMENTS
function* attachedDocDownload(action) {
  try {
    const params = action.payload;
    const status = action?.action;
    const response = yield downloadDocService(params, status);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DOWNLOAD_DOCUMENTS_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DOWNLOAD_DOCUMENTS_ERROR,
      payload: error,
    });
  }
}

export function* downloadAttachedDoc() {
  yield takeLatest(TYPES.REQUEST_DOWNLOAD_ATTACHED_DOC, attachedDocDownload);
}

// TRANSACTION WORKFLOW DETAILS
function* getTransactionWorkflow(action) {
  try {
    const params = action.payload;
    const response = yield trnsactionWorkflowService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.TRANSACTION_WORKFLOW_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchTransactionWorkflowDetails() {
  yield takeLatest(TYPES.REQUEST_TRANSACTION_WORKFLOW, getTransactionWorkflow);
}

// TRANSACTION WORKFLOW  GROUP LIST
function* getWorkflowGroup(action) {
  try {
    const params = action.payload;
    const response = yield workFlowGroupService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.WORKFLOW_GROUP_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchWorkflowGroup() {
  yield takeLatest(TYPES.REQUEST_WORKFLOW_GROUP, getWorkflowGroup);
}

// TRANSACTION WORKFLOW  USER LIST
function* getWorkflowUserList(action) {
  try {
    const params = action.payload;
    const response = yield workFlowUserListService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.WORKFLOW_USERLIST_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchWorkflowUserList() {
  yield takeLatest(TYPES.REQUEST_WORKFLOW_USERLIST, getWorkflowUserList);
}

// TRANSACTION  DEFAULT WORKFLOW
function* getDefaultWorkFlow(action) {
  try {
    const params = action.payload;
    const response = yield defaultWorkFlowService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DEFAULT_WORKFLOW_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* fetchDefaultWorkFlow() {
  yield takeLatest(TYPES.REQUEST_DEFAULT_WORKFLOW, getDefaultWorkFlow);
}

// WORKFLOW SUBMIT / SUBMIT MAKE PAYMENT
function* workFlowSubmit(action) {
  try {
    const params = action.payload;
    const response = yield submitWorkflowService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.WORKFLOW_SUBMIT_SUCCESS,
        payload: { data, action: params.action },
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* submitWorkflowDetails() {
  yield takeLatest(TYPES.REQUEST_WORKFLOW_SUBMIT, workFlowSubmit);
}

// WORKFLOW DETAILS
function* fetchWorkflowDetails(action) {
  try {
    const params = action.payload;
    const response = yield workflowDetailsService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.WORKFLOW_DETAILS_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REVIEW_DATA_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* getWorkflowDetails() {
  yield takeLatest(TYPES.REQUEST_WORKFLOW_DETAILS, fetchWorkflowDetails);
}

function* getBookRateSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield getBookRateService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.REQUEST_BOOK_RATE_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REQUEST_BOOK_RATE_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REQUEST_BOOK_RATE_ERROR,
      payload: error,
    });
  }
}

export function* getBookRateSaga() {
  yield takeLatest(TYPES.REQUEST_BOOK_RATE, getBookRateSagaCallBack);
}

function* getFxRateMarginValidationSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield getFxRateMarginValidationService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.REQUEST_FX_RATE_MARGIN_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.REQUEST_FX_RATE_MARGIN_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.REQUEST_FX_RATE_MARGIN_ERROR,
      payload: error,
    });
  }
}

export function* getFxRateMarginValidationSaga() {
  yield takeLatest(
    TYPES.REQUEST_FX_RATE_MARGIN,
    getFxRateMarginValidationSagaCallBack
  );
}

function* bookFxRateSagaCallback(action) {
  try {
    const params = action.payload;
    const response = yield bookFxRateService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.BOOK_FX_RATE_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.BOOK_FX_RATE_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.BOOK_FX_RATE_ERROR,
      payload: error,
    });
  }
}

export function* bookFxRateSaga() {
  yield takeLatest(TYPES.BOOK_FX_RATE, bookFxRateSagaCallback);
}

function* acceptRejectSagaCallback(action) {
  try {
    const params = action.payload;
    const response = yield acceptRejectService(params);
    const data = response?.data;
    data.isBulk = params?.isBulk;
    if (response?.status === 200) {
      yield put({
        type: TYPES.ACCEPT_REJECT_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.ACCEPT_REJECT_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.ACCEPT_REJECT_ERROR,
      payload: error,
    });
  }
}

export function* acceptRejectSaga() {
  yield takeLatest(TYPES.ACCEPT_REJECT, acceptRejectSagaCallback);
}

function* addBeneDetailsOnCheckerApprovalSagaCallback(action) {
  try {
    const params = action.payload;
    const response = yield addBeneDetailsOnCheckerApprovalService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL_ERROR,
      payload: error,
    });
  }
}

export function* addBeneDetailsOnCheckerApprovalSaga() {
  yield takeLatest(
    TYPES.ADD_BENE_DETAILS_ON_CHECKER_APPROVAL,
    addBeneDetailsOnCheckerApprovalSagaCallback
  );
}

function* clearPaymentReviewSagaCallBack(action) {
  try {
    yield put({
      type: TYPES.CLEAR_PAYMENT_REVIEW_DATA_SUCCESS,
    });
  } catch (error) {
    yield put({
      type: TYPES.CLEAR_PAYMENT_REVIEW_DATA_ERROR,
      payload: error,
    });
  }
}

export function* clearPaymentReviewSaga() {
  yield takeLatest(
    TYPES.CLEAR_PAYMENT_REVIEW_DATA,
    clearPaymentReviewSagaCallBack
  );
}

function* validateDealsFn(action) {
  try {
    const params = action.payload;
    const response = yield validateDeal(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.VALIDATE_DEALS_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.VALIDATE_DEALS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.VALIDATE_DEALS_ERROR,
      payload: error,
    });
  }
}

export function* validateDeals() {
  yield takeLatest(TYPES.VALIDATE_DEALS, validateDealsFn);
}

function* validateTxnAmountRange(action) {
  try {
    const params = action.payload;
    const response = yield validateTxnAmountRangeService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.VALIDATE_TXN_AMOUNT_RANGE_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.VALIDATE_TXN_AMOUNT_RANGE_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.VALIDATE_TXN_AMOUNT_RANGE_ERROR,
      payload: error,
    });
  }
}

export function* validateTxnAmountRanges() {
  yield takeLatest(TYPES.VALIDATE_TXN_AMOUNT_RANGE, validateTxnAmountRange);
}

function* getAccountDetailsSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield getAccountDetailsService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.GET_ACCOUNT_DETAILS_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.GET_ACCOUNT_DETAILS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_ACCOUNT_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getAccountDetailsSaga() {
  yield takeLatest(TYPES.GET_ACCOUNT_DETAILS, getAccountDetailsSagaCallBack);
}

function* getBeneficiarytDetailsSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield getBeneficiarytDetailsService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.GET_BENEFICIARY_DETAILS_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.GET_BENEFICIARY_DETAILS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_BENEFICIARY_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getBeneficiarytDetailsSaga() {
  yield takeLatest(
    TYPES.GET_BENEFICIARY_DETAILS,
    getBeneficiarytDetailsSagaCallBack
  );
}

function* saveCommentsSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield saveCommentsService(params);
    if (response?.status === 200) {
      yield put({
        type: TYPES.SAVE_COMMENTS_SUCCESS,
        payload: {
          id: action?.payload?.sectionId,
          remarks: action?.payload?.comments,
        },
      });
    } else {
      yield put({
        type: TYPES.SAVE_COMMENTS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.SAVE_COMMENTS_ERROR,
      payload: error,
    });
  }
}

export function* saveCommentsSaga() {
  yield takeLatest(TYPES.SAVE_COMMENTS, saveCommentsSagaCallBack);
}

function* updateFxRateAmountSagaCallback(action) {
  try {
    const data = action.payload;
    yield put({
      type: TYPES.UPDATE_FXRATEAMOUNT_SUCCESS,
      payload: data,
    });
  } catch (error) {
    yield put({
      type: TYPES.UPDATE_FXRATEAMOUNT_ERROR,
      payload: error,
    });
  }
}

export function* updateFxRateAmountSaga() {
  yield takeLatest(TYPES.UPDATE_FXRATEAMOUNT, updateFxRateAmountSagaCallback);
}

function* fetchComm(action) {
  try {
    const params = action.payload;
    const response = yield fetchCommAPI(params);
    const reqParams = JSON.parse(response?.config?.data);
    const data = action.payload;
    if (response?.status === 200) {
      yield put({
        type: TYPES.FETCH_COMMENTS_SUCCESS,
        payload: {
          id: reqParams?.sectionId,
          comment: data?.comments,
        },
      });
    } else {
      yield put({
        type: TYPES.FETCH_COMMENTS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.FETCH_COMMENTS_ERROR,
      payload: error,
    });
  }
}

export function* fetchComment() {
  yield takeEvery(TYPES.FETCH_COMMENTS, fetchComm);
}

function* getCardRateSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield getCardRate(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.GET_CARD_RATE_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.GET_CARD_RATE_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_CARD_RATE_ERROR,
      payload: error,
    });
  }
}

export function* getCardRateSaga() {
  yield takeEvery(TYPES.GET_CARD_RATE, getCardRateSagaCallBack);
}

function* totalAmountValidationSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield totalAmountValidationService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.TOTAL_AMOUNT_VALIDATOIN_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.TOTAL_AMOUNT_VALIDATOIN_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.TOTAL_AMOUNT_VALIDATOIN_ERROR,
      payload: error,
    });
  }
}

export function* totalAmountValidationSaga() {
  yield takeEvery(
    TYPES.TOTAL_AMOUNT_VALIDATOIN,
    totalAmountValidationSagaCallBack
  );
}

function* dealAmountValidationSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield dealAmountValidationService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DEAL_AMOUNT_VALIDATION_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.DEAL_AMOUNT_VALIDATION_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DEAL_AMOUNT_VALIDATION_ERROR,
      payload: error,
    });
  }
}

export function* dealAmountValidationSaga() {
  yield takeEvery(
    TYPES.DEAL_AMOUNT_VALIDATION,
    dealAmountValidationSagaCallBack
  );
}
