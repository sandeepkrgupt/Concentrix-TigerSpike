import * as TYPES from "../../utils/types";
import { takeLatest, put } from "redux-saga/effects";
import {
  getBranches,
  checkPaymentDate,
  getBoeNumbers,
  getDelayReasons,
  getIsDelayReasonAllowed,
  getPaymentModeList,
  checkAccountBalance,
  getCurrencyConvert,
  fetchDueDate,
  paymentModeSelect,
  getDisplayCharges,
  getChargesAccountService,
  getAllAccountsService,
  getGSTNoService,
  searchTextDrawer,
  preDealBook,
  fwcBook,
  getPreBookedDealsService,
  getFWCService,
  savePaymentDetails,
  fntCntEarMarkingAPI,
  deleteDealAPI
} from "./service";

function* branchNames(action) {
  try {
    const params = action.payload;
    const response = yield getBranches(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.PAYMENT_BRANCH_NAME_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PAYMENT_BRANCH_NAME_ERROR,
      payload: error,
    });
  }
}

export function* getBranchName() {
  yield takeLatest(TYPES.REQ_PAYMENT_BRANCH_NAME, branchNames);
}

function* dateCheck(action) {
  try {
    const params = action.payload;
    const response = yield checkPaymentDate(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.PAYMENT_DATE_CHECK_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PAYMENT_DATE_CHECK_ERROR,
      payload: error,
    });
  }
}

export function* paymentDateCheck() {
  yield takeLatest(TYPES.REQUEST_PAYMENT_DATE_CHECK, dateCheck);
}

function* boeNumbers(action) {
  try {
    const params = action.payload;
    const response = yield getBoeNumbers(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.BOE_NUMBERS_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.BOE_NUMBERS_ERROR,
      payload: error,
    });
  }
}

export function* paymentBOENumbers() {
  yield takeLatest(TYPES.REQUEST_BOE_NUMBERS, boeNumbers);
}

function* delayReasons(action) {
  try {
    const params = action.payload;
    const response = yield getDelayReasons(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DELAY_REASONS_SUCCESS,
        payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DELAY_REASONS_ERROR,
      payload: error,
    });
  }
}

export function* paymentDelayReasons() {
  yield takeLatest(TYPES.REQUEST_DELAY_REASONS, delayReasons);
}

function* isDelayReason(action) {
  try {
    const params = action.payload;
    const response = yield getIsDelayReasonAllowed(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.IS_DELAY_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.IS_DELAY_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.IS_DELAY_ERROR,
      payload: error,
    });
  }
}

export function* isDelayReasonAllowed() {
  yield takeLatest(TYPES.REQUEST_IS_DELAY, isDelayReason);
}

function* paymentList(action) {
  try {
    const params = action.payload;
    const response = yield getPaymentModeList(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.PAYMENT_MODE_LIST_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.PAYMENT_MODE_LIST_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PAYMENT_MODE_LIST_ERROR,
      payload: error,
    });
  }
}

export function* paymentModeList() {
  yield takeLatest(TYPES.REQUEST_PAYMENT_MODE_LIST, paymentList);
}

function* balanceCheck(action) {
  try {
    const params = action.payload;
    const response = yield checkAccountBalance(params);
    const data = response?.data;
    if (response?.status === 200) {
      if (action?.accType === "eefc") {
        yield put({
          type: TYPES.BALANCE_CHECK_EEFC_SUCCESS,
          payload: data,
        });
      }
      if (action?.accType === "operative") {
        yield put({
          type: TYPES.BALANCE_CHECK_OPERATIVE_SUCCESS,
          payload: data,
        });
      }
      if (action?.accType === "charges") {
        yield put({
          type: TYPES.BALANCE_CHECK_CHARGES_SUCCESS,
          payload: data,
        });
      }
    } else {
      yield put({
        type: TYPES.BALANCE_CHECK_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.BALANCE_CHECK_ERROR,
      payload: error,
    });
  }
}

export function* accountBalanceCheck() {
  yield takeLatest(TYPES.REQUEST_BALANCE_CHECK, balanceCheck);
}

function* currencyConvert(action) {
  try {
    const params = action.payload;
    const response = yield getCurrencyConvert(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.PAYMENT_CURRENCY_CONVERT_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.PAYMENT_CURRENCY_CONVERT_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PAYMENT_CURRENCY_CONVERT_ERROR,
      payload: error,
    });
  }
}

export function* paymentCurrencyConvert() {
  yield takeLatest(TYPES.REQUEST_PAYMENT_CURRENCY_CONVERT, currencyConvert);
}

function* dueDate(action) {
  try {
    const params = action.payload;
    const response = yield fetchDueDate(params);
    const data = response?.data?.dueDate;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DUE_DATE_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.DUE_DATE_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DUE_DATE_ERROR,
      payload: error,
    });
  }
}

export function* getDueDate() {
  yield takeLatest(TYPES.REQUEST_DUE_DATE, dueDate);
}

function* paymentMode(action) {
  try {
    const params = action.payload;
    const response = yield paymentModeSelect(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.SELECT_PAYMENT_MODE_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.SELECT_PAYMENT_MODE_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.SELECT_PAYMENT_MODE_ERROR,
      payload: error,
    });
  }
}

export function* selectPaymentMode() {
  yield takeLatest(TYPES.REQUEST_SELECT_PAYMENT_MODE, paymentMode);
}

function* displayCharges(action) {
  try {
    const params = action.payload;
    const response = yield getDisplayCharges(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DISPLAY_CHARGES_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.DISPLAY_CHARGES_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DISPLAY_CHARGES_ERROR,
      payload: error,
    });
  }
}

export function* paymentDisplayCharges() {
  yield takeLatest(TYPES.REQUEST_DISPLAY_CHARGES, displayCharges);
}

function* getChargesAccount(action) {
  try {
    const params = action.payload;
    const response = yield getChargesAccountService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.CHARGES_ACCOUNT_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.CHARGES_ACCOUNT_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.CHARGES_ACCOUNT_ERROR,
      payload: error,
    });
  }
}

export function* fetchChargesAccount() {
  yield takeLatest(TYPES.REQUEST_CHARGES_ACCOUNT, getChargesAccount);
}

function* getAllAccounts(action) {
  try {
    const params = action.payload;
    const response = yield getAllAccountsService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.GET_ALL_ACCOUNTS_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.GET_ALL_ACCOUNTS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_ALL_ACCOUNTS_ERROR,
      payload: error,
    });
  }
}

export function* fetchAllAccounts() {
  yield takeLatest(TYPES.REQUEST_GET_ALL_ACCOUNTS, getAllAccounts);
}

function* getGSTNoList(action) {
  try {
    const params = action.payload;
    const response = yield getGSTNoService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.GET_GST_NO_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.GET_GST_NO_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_GST_NO_ERROR,
      payload: error,
    });
  }
}

export function* fetchGstNoList() {
  yield takeLatest(TYPES.REQUEST_GST_NO, getGSTNoList);
}

function* getsearchTextinDrawer(action) {
  try {
    const params = action.payload;
    const response = yield searchTextDrawer(params);
    const data = response?.data ? [response?.data] : [];
    if (response?.status === 200) {
      yield put({
        type: TYPES.SEARCH_TEXT_IN_DRAWER_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.SEARCH_TEXT_IN_DRAWER_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.SEARCH_TEXT_IN_DRAWER_ERROR,
      payload: error,
    });
  }
}

export function* searchTextinDrawer() {
  yield takeLatest(TYPES.SEARCH_TEXT_IN_DRAWER, getsearchTextinDrawer);
}

function* preBook(action) {
  try {
    const params = action.payload;
    const response = yield preDealBook(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.PREBOOKDEAL_BOOK_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.PREBOOKDEAL_BOOK_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PREBOOKDEAL_BOOK_ERROR,
      payload: error,
    });
  }
}

export function* prebookdealBook() {
  yield takeLatest(TYPES.REQUEST_PREBOOKDEAL_BOOK, preBook);
}

function* bookFwc(action) {
  try {
    const params = action.payload;
    const response = yield fwcBook(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.FWC_BOOK_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.FWC_BOOK_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.FWC_BOOK_ERROR,
      payload: error,
    });
  }
}

export function* FWCBook() {
  yield takeLatest(TYPES.REQUEST_FWC_BOOK, bookFwc);
}

// get prebook deals
function* getPreBookedDealsCallback(action) {
  try {
    const params = action.payload;
    const response = yield getPreBookedDealsService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.PREBOOKED_DEALS_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.PREBOOKED_DEALS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PREBOOKED_DEALS_ERROR,
      payload: error,
    });
  }
}

export function* getPreBookedDeals() {
  yield takeLatest(TYPES.REQUEST_PREBOOKED_DEALS, getPreBookedDealsCallback);
}

// get FWC
function* getFWCCallback(action) {
  try {
    const params = action.payload;
    const response = yield getFWCService(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.FWC_SUCCESS,
        payload: data,
      });
    } else {
      yield put({
        type: TYPES.FWC_ERROR,
        payload: data, // @toupdate
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.FWC_ERROR,
      payload: error, // @toupdate
    });
  }
}

export function* getFWC() {
  yield takeLatest(TYPES.REQUEST_FWC, getFWCCallback);
}

function* savePayment(action) {
  try {
    const params = action.payload;
    const response = yield savePaymentDetails(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.SAVE_PAYMENT_DETAILS_SUCCESS,
        payload: data,
        isButtonClick: action?.isButtonClick,
      });
    } else {
      yield put({
        type: TYPES.SAVE_PAYMENT_DETAILS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.SAVE_PAYMENT_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* savePaymentInfo() {
  yield takeLatest(TYPES.REQUEST_SAVE_PAYMENT_DETAILS, savePayment);
}

function* updateFxAmountUtilizedCallback(action) {
  try {
    const data = action.payload;

    yield put({
      type: TYPES.UPDATE_FX_AMOUNT_UTILIZED_SUCCESS,
      payload: data,
    });
  } catch (error) {
    yield put({
      type: TYPES.UPDATE_FX_AMOUNT_UTILIZED_ERROR,
      payload: error,
    });
  }
}

export function* updateFxAmountUtilized() {
  yield takeLatest(
    TYPES.UPDATE_FX_AMOUNT_UTILIZED,
    updateFxAmountUtilizedCallback
  );
}

function* updateFcCreditAmountCallback(action) {
  try {
    const data = action.payload;

    yield put({
      type: TYPES.UPDATE_FC_CREDIT_AMOUNT_SUCCESS,
      payload: data,
    });
  } catch (error) {
    yield put({
      type: TYPES.UPDATE_FC_CREDIT_AMOUNT_ERROR,
      payload: error,
    });
  }
}

export function* updateFcCreditAmount() {
  yield takeLatest(TYPES.UPDATE_FC_CREDIT_AMOUNT, updateFcCreditAmountCallback);
}

function* fntCntEarMarking(action) {
  try {
    const params = action.payload;
    const response = yield fntCntEarMarkingAPI(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.FWD_CNT_EARMARKING_SUCCESS,
        payload: data
      });
    } else {
      yield put({
        type: TYPES.FWD_CNT_EARMARKING_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.FWD_CNT_EARMARKING_ERROR,
      payload: error,
    });
  }
}

export function* fntCntEarMark() {
  yield takeLatest(TYPES.FWD_CNT_EARMARKING, fntCntEarMarking);
}

function* preBookEarMarking(action) {
  try {
    const params = action.payload;
    const response = yield fntCntEarMarkingAPI(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.PRE_BOOK_EARMARKING_SUCCESS,
        payload: data
      });
    } else {
      yield put({
        type: TYPES.PRE_BOOK_EARMARKING_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.PRE_BOOK_EARMARKING_ERROR,
      payload: error,
    });
  }
}

export function* preBookEM() {
  yield takeLatest(TYPES.PRE_BOOK_EARMARKING, preBookEarMarking);
}

function* deleteDeals(action) {
  try {
    const params = action.payload;
    const response = yield deleteDealAPI(params);
    const data = response?.data;
    if (response?.status === 200) {
      yield put({
        type: TYPES.DELETE_DEAL_SUCCESS,
        payload: data
      });
    } else {
      yield put({
        type: TYPES.DELETE_DEAL_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DELETE_DEAL_ERROR,
      payload: error,
    });
  }
}

export function* deleteDeal() {
  yield takeLatest(TYPES.DELETE_DEAL, deleteDeals);
}