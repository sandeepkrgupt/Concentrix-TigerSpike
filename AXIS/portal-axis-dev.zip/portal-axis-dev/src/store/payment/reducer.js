import * as TYPES from "../../utils/types";

const initialState = {
  loader: false,
  branchNames: [],
  validPaymentDate: null,
  boeNumbers: [],
  delayReasons: [],
  isDelayReason: null,
  paymentModeList: [],
  balanceAmountEefc: "",
  balanceAmountOperative: "",
  balanceAmountCharges: "",
  inrAmount: "0.0",
  dueDate: "",
  modeAccNumbers: [],
  displayCharge: "",
  chargesAccount: [],
  gstNo: [],
  textSearchResults: [],
  prebookdealBookSuccess: null,
  fwcBookSuccess: null,
  preBookedDeals: [],
  fwcList: [],
  showSaveDraftMsg: false,
  eefcAccounts: [],
  operativeAccounts: [],
  fxAmountUtilized: "",
  fcCreditAmount: "",
  preBookEarMark: null,
  fwdCntEarMark: null
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQ_PAYMENT_BRANCH_NAME:
      return { ...state, loader: true };
    case TYPES.PAYMENT_BRANCH_NAME_SUCCESS:
      return { ...state, loader: false, branchNames: action?.payload };
    case TYPES.PAYMENT_BRANCH_NAME_ERROR:
      return { ...state, loader: false, branchNames: [] };
    case TYPES.REQUEST_PAYMENT_DATE_CHECK ||
      TYPES.REQUEST_CHARGES_ACCOUNT ||
      TYPES.REQUEST_GST_NO:
      return { ...state, loader: true };
    case TYPES.PAYMENT_DATE_CHECK_SUCCESS:
      return {
        ...state,
        loader: false,
        validPaymentDate: action?.payload?.paymentDate,
      };
    case TYPES.PAYMENT_DATE_CHECK_ERROR:
      return { ...state, loader: false, validPaymentDate: false };
    case TYPES.REQUEST_BOE_NUMBERS:
    case TYPES.FWD_CNT_EARMARKING:
    case TYPES.PRE_BOOK_EARMARKING:
    case TYPES.DELETE_DEAL:
      return {
        ...state,
        loader: true,
      };
    case TYPES.BOE_NUMBERS_SUCCESS:
      return {
        ...state,
        loader: false,
        boeNumbers: action?.payload,
      };
    case TYPES.BOE_NUMBERS_ERROR:
      return {
        ...state,
        loader: false,
        boeNumbers: [],
      };
    case TYPES.REQUEST_DELAY_REASONS:
      return {
        ...state,
        loader: true,
      };

    case TYPES.DELAY_REASONS_SUCCESS:
      return {
        ...state,
        loader: false,
        delayReasons: action?.payload,
      };
    case TYPES.DELAY_REASONS_ERROR:
      return {
        ...state,
        loader: false,
        delayReasons: [],
      };
    case TYPES.REQUEST_IS_DELAY:
      return {
        ...state,
        loader: true,
        isDelayReason: null,
      };

    case TYPES.IS_DELAY_SUCCESS:
      return {
        ...state,
        loader: false,
        isDelayReason: action?.payload,
      };
    case TYPES.IS_DELAY_ERROR:
      return {
        ...state,
        loader: false,
        isDelayReason: null,
      };
    case TYPES.REQUEST_PAYMENT_MODE_LIST:
      return {
        ...state,
        loader: true,
      };
    case TYPES.PAYMENT_MODE_LIST_SUCCESS:
      return {
        ...state,
        loader: false,
        paymentModeList: action?.payload,
      };
    case TYPES.PAYMENT_MODE_LIST_ERROR:
      return {
        ...state,
        loader: false,
        paymentModeList: [],
      };
    case TYPES.REQUEST_BALANCE_CHECK:
      return {
        ...state,
        loader: true,
      };
    case TYPES.BALANCE_CHECK_EEFC_SUCCESS:
      return {
        ...state,
        loader: false,
        balanceAmountEefc: action?.payload,
      };
    case TYPES.BALANCE_CHECK_OPERATIVE_SUCCESS:
      return {
        ...state,
        loader: false,
        balanceAmountOperative: action?.payload,
      };
    case TYPES.BALANCE_CHECK_CHARGES_SUCCESS:
      return {
        ...state,
        loader: false,
        balanceAmountCharges: action?.payload,
      };
    case TYPES.BALANCE_CHECK_ERROR:
      return {
        ...state,
        loader: false,
        balanceAmountEefc: "",
        balanceAmountOperative: "",
        balanceAmountCharges: "",
      };
    case TYPES.REQUEST_PAYMENT_CURRENCY_CONVERT:
      return {
        ...state,
        loader: true,
      };
    case TYPES.PAYMENT_CURRENCY_CONVERT_SUCCESS:
      return {
        ...state,
        loader: false,
        inrAmount: action?.payload,
      };
    case TYPES.PAYMENT_CURRENCY_CONVERT_ERROR:
      return {
        ...state,
        loader: false,
        inrAmount: "0.0",
      };
    case TYPES.REQUEST_DUE_DATE:
      return {
        ...state,
        loader: true,
      };
    case TYPES.DUE_DATE_SUCCESS:
      return {
        ...state,
        loader: false,
        dueDate: action?.payload,
      };
    case TYPES.DUE_DATE_ERROR:
      return {
        ...state,
        loader: false,
        dueDate: "",
      };
    case TYPES.REQUEST_SELECT_PAYMENT_MODE:
      return {
        ...state,
        loader: true,
      };
    case TYPES.SELECT_PAYMENT_MODE_SUCCESS:
      return {
        ...state,
        loader: false,
        modeAccNumbers: action?.payload,
      };
    case TYPES.SELECT_PAYMENT_MODE_ERROR:
      return {
        ...state,
        loader: false,
        modeAccNumbers: [],
      };
    case TYPES.REQUEST_DISPLAY_CHARGES:
      return {
        ...state,
        loader: true,
      };
    case TYPES.DISPLAY_CHARGES_SUCCESS:
      return {
        ...state,
        loader: false,
        displayCharge: action?.payload,
      };
    case TYPES.DISPLAY_CHARGES_ERROR:
      return {
        ...state,
        loader: false,
        displayCharge: "",
      };
    case TYPES.CHARGES_ACCOUNT_SUCCESS: {
      return {
        ...state,
        loader: false,
        chargesAccount: action?.payload,
      };
    }

    case TYPES.CHARGES_ACCOUNT_ERROR: {
      return {
        ...state,
        loader: false,
        chargesAccount: [],
      };
    }
    case TYPES.GET_ALL_ACCOUNTS_SUCCESS: {
      const allAccounts = action?.payload;
      let eefcAccounts = [];
      let operativeAccounts = [];

      allAccounts?.filter((item) => {
        if (item?.accountType === "CAA") {
          item?.accounts?.map((acc) => {
            acc.accountNumber = item?.accountDetails?.[acc?.id]?.accountNumber;
            acc.availableBalance =
              item?.accountDetails?.[acc?.id]?.availableBalance;
            acc.currencyCode = item?.accountDetails?.[acc?.id]?.currencyCode;
            return acc;
          });
          eefcAccounts = item?.accounts;
        }
        return item;
      });
      allAccounts?.map((item) => {
        if (item?.accountType === "CCA") {
          item?.accounts?.map((acc) => {
            acc.accountNumber = item?.accountDetails?.[acc?.id]?.accountNumber;
            acc.availableBalance =
              item?.accountDetails?.[acc?.id]?.availableBalance;
            acc.currencyCode = item?.accountDetails?.[acc?.id]?.currencyCode;
            return acc;
          });
          operativeAccounts = item?.accounts;
        }
        return item;
      });
      return {
        ...state,
        loader: false,
        allAccounts: allAccounts,
        eefcAccounts: eefcAccounts,
        operativeAccounts: operativeAccounts,
      };
    }

    case TYPES.GET_ALL_ACCOUNTS_ERROR: {
      return {
        ...state,
        loader: false,
        allAccounts: [],
      };
    }

    case TYPES.GET_GST_NO_SUCCESS: {
      return {
        ...state,
        loader: false,
        gstNo: action?.payload,
      };
    }

    case TYPES.GET_GST_NO_ERROR: {
      return {
        ...state,
        loader: false,
        gstNo: [],
      };
    }
    case TYPES.SEARCH_TEXT_IN_DRAWER:
      return {
        ...state,
        loader: true,
      };
    case TYPES.SEARCH_TEXT_IN_DRAWER_SUCCESS:
      return {
        ...state,
        loader: false,
        textSearchResults: action?.payload,
      };
    case TYPES.SEARCH_TEXT_IN_DRAWER_ERROR:
      return {
        ...state,
        loader: false,
        textSearchResults: [],
      };
    case TYPES.REQUEST_PREBOOKDEAL_BOOK:
      return {
        ...state,
        loader: true,
        prebookdealBookSuccess: null,
      };
    case TYPES.PREBOOKDEAL_BOOK_SUCCESS:
      return {
        ...state,
        loader: false,
        prebookdealBookSuccess: true,
      };
    case TYPES.PREBOOKDEAL_BOOK_ERROR:
      return {
        ...state,
        loader: false,
        prebookdealBookSuccess: false,
      };
    case TYPES.REQUEST_FWC_BOOK:
      return {
        ...state,
        loader: true,
        fwcBookSuccess: null,
      };
    case TYPES.FWC_BOOK_SUCCESS:
      return {
        ...state,
        loader: false,
        fwcBookSuccess: true,
      };
    case TYPES.FWC_BOOK_ERROR:
      return {
        ...state,
        loader: false,
        fwcBookSuccess: false,
      };
    case TYPES.REQUEST_PREBOOKED_DEALS:
      return {
        ...state,
        loader: true,
      };
    case TYPES.PREBOOKED_DEALS_SUCCESS: {
      return {
        ...state,
        loader: false,
        preBookedDeals: [...action?.payload],
        textSearchResults: [],
      };
    }

    case TYPES.PREBOOKED_DEALS_ERROR:
      return {
        ...state,
        loader: false,
        textSearchResults: [],
        preBookedDeals: [],
      };

    case TYPES.REQUEST_FWC:
      return {
        ...state,
        loader: true,
      };
    case TYPES.FWC_SUCCESS: {
      return {
        ...state,
        loader: false,
        fwcList: [...action?.payload],
        textSearchResults: [],
      };
    }

    case TYPES.FWC_ERROR:
      return {
        ...state,
        loader: false,
        textSearchResults: [],
        fwcList: [],
      };
    case TYPES.REQUEST_SAVE_PAYMENT_DETAILS:
      return {
        ...state,
        loader: true,
      };
    case TYPES.SAVE_PAYMENT_DETAILS_SUCCESS:
      return {
        ...state,
        loader: false,
        showSaveDraftMsg: action?.isButtonClick,
      };
    case TYPES.CLEAR_PAY_DRAFT_MSG_STATUS:
      return {
        ...state,
        showSaveDraftMsg: false,
      };
    case TYPES.SAVE_PAYMENT_DETAILS_ERROR:
      return {
        ...state,
        loader: false,
      };
    case TYPES.UPDATE_FX_AMOUNT_UTILIZED:
    case TYPES.UPDATE_FX_AMOUNT_UTILIZED_ERROR:
      return {
        ...state,
        loader: false,
      };
    case TYPES.UPDATE_FX_AMOUNT_UTILIZED_SUCCESS: {
      return {
        ...state,
        fxAmountUtilized: action?.payload?.fxAmountUtilized,
        loader: false,
      };
    }
    case TYPES.UPDATE_FC_CREDIT_AMOUNT:
    case TYPES.UPDATE_FC_CREDIT_AMOUNT_ERROR:
      return {
        ...state,
        loader: false,
      };
    case TYPES.UPDATE_FC_CREDIT_AMOUNT_SUCCESS: {
      return {
        ...state,
        fcCreditAmount: action?.payload?.fcCreditAmount,
        loader: false,
      };
    }
    case TYPES.PRE_BOOK_EARMARKING_SUCCESS:
      return {
        ...state,
        preBookEarMark: action?.payload
      };
    case TYPES.FWD_CNT_EARMARKING_SUCCESS:
      return {
        ...state,
        fwdCntEarMark: action?.payload
      };
    default:
      return { ...state };
  }
}
