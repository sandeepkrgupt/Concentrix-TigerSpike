import * as TYPES from "../../utils/types";

export const paymentBranchName = (data) => ({
  type: TYPES.REQ_PAYMENT_BRANCH_NAME,
  payload: data,
});

export const paymentDateCheck = (data) => ({
  type: TYPES.REQUEST_PAYMENT_DATE_CHECK,
  payload: data,
});

export const boeNumbers = (data) => ({
  type: TYPES.REQUEST_BOE_NUMBERS,
  payload: data,
});

export const delayReasons = (data) => ({
  type: TYPES.REQUEST_DELAY_REASONS,
  payload: data,
});

export const isDelayReasonAllowed = (data) => ({
  type: TYPES.REQUEST_IS_DELAY,
  payload: data,
});

export const paymentModeList = (data) => ({
  type: TYPES.REQUEST_PAYMENT_MODE_LIST,
  payload: data,
});

export const balanceCheck = (data, accType) => ({
  type: TYPES.REQUEST_BALANCE_CHECK,
  payload: data,
  accType,
});

export const currencyConvert = (data) => ({
  type: TYPES.REQUEST_PAYMENT_CURRENCY_CONVERT,
  payload: data,
});

export const getDueDate = (data) => ({
  type: TYPES.REQUEST_DUE_DATE,
  payload: data,
});

export const selectPaymentMode = (data) => ({
  type: TYPES.REQUEST_SELECT_PAYMENT_MODE,
  payload: data,
});

export const displayCharges = (data) => ({
  type: TYPES.REQUEST_DISPLAY_CHARGES,
  payload: data,
});

export const getChargesAccount = (data) => ({
  type: TYPES.REQUEST_CHARGES_ACCOUNT,
  payload: data,
});

export const getAllAcc = (data) => ({
  type: TYPES.REQUEST_GET_ALL_ACCOUNTS,
  payload: data,
});

export const getGstNo = (data) => ({
  type: TYPES.REQUEST_GST_NO,
  payload: data,
});

export const searchTextInDrawer = (data) => ({
  type: TYPES.SEARCH_TEXT_IN_DRAWER,
  payload: data,
});

export const preBookDealBook = (data) => ({
  type: TYPES.REQUEST_PREBOOKDEAL_BOOK,
  payload: data,
});

export const fwcBook = (data) => ({
  type: TYPES.REQUEST_FWC_BOOK,
  payload: data,
});

export const getPreBookedDeals = (data) => {
  return {
    type: TYPES.REQUEST_PREBOOKED_DEALS,
    payload: data,
  };
};

export const getFWCList = (data) => {
  return {
    type: TYPES.REQUEST_FWC,
    payload: data,
  };
};

export const savePaymentDetails = (data, isButtonClick) => {
  return {
    type: TYPES.REQUEST_SAVE_PAYMENT_DETAILS,
    payload: data,
    isButtonClick: isButtonClick,
  };
};

export const clearPayDraftMsgStatus = () => {
  return {
    type: TYPES.CLEAR_PAY_DRAFT_MSG_STATUS,
  };
};

export const updateFxAmountUtilized = (data) => {
  return {
    type: TYPES.UPDATE_FX_AMOUNT_UTILIZED,
    payload: data,
  };
};

export const updateFcCreditAmount = (data) => {
  return {
    type: TYPES.UPDATE_FC_CREDIT_AMOUNT,
    payload: data,
  };
};

export const fwdCntEarMarking = (data) => {
  return {
    type: TYPES.FWD_CNT_EARMARKING,
    payload: data,
  };
};

export const preBookEarMarking = (data) => {
  return {
    type: TYPES.PRE_BOOK_EARMARKING,
    payload: data,
  };
};

export const deleteDeal = (data) => {
  return {
    type: TYPES.DELETE_DEAL,
    payload: data,
  };
};