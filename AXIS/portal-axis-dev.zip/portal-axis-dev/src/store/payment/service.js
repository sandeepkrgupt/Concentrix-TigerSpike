import instance from "../../services";

export const getBranches = (data) => {
  return instance
    .post(`/paymentDetails/fetchBranchDetails`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const checkPaymentDate = (data) => {
  return instance
    .post(`/paymentDetails/paymentDates`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getBoeNumbers = (data) => {
  return instance
    .post(`/paymentDetails/billOfEntryNumbers`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getDelayReasons = (data) => {
  return instance
    .post(`/paymentDetails/delayReasons`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getIsDelayReasonAllowed = (data) => {
  return instance
    .post(`/paymentDetails/isDelayReasonAllowed`, data)
    .then((res) => {
      return res;
    })
    .catch((err) => {
      return err;
    });
};

export const getPaymentModeList = (data) => {
  return instance
    .post(`/paymentDetails/paymentMode`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const checkAccountBalance = (data) => {
  return instance
    .post(`/paymentDetails/balanceCheck`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getCurrencyConvert = (data) => {
  return instance
    .post(`/paymentDetails/get-currency-convert`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const fetchDueDate = (data) => {
  return instance
    .post(`/paymentDetails/getDueDates`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const paymentModeSelect = (data) => {
  return instance
    .post(`/paymentDetails/selectPaymentModes`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getDisplayCharges = (data) => {
  return instance
    .post(`/paymentDetails/display-charges-label/${data}`)
    .then((res) => res)
    .catch((err) => err);
};

export const getChargesAccountService = (data) => {
  return instance
    .post(`/paymentDetails/getChargesAccountNo`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getAllAccountsService = (data) => {
  return instance
    .post(`/paymentDetails/getAllAccounts`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getGSTNoService = (data) => {
  return instance
    .post(`/paymentDetails/getGSTNo`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const searchTextDrawer = (data) => {
  return instance
    .post(`/paymentDetails/get-search-dealid`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const preDealBook = (data) => {
  return instance
    .post(`/paymentDetails/fetchPreBookDealId`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const fwcBook = (data) => {
  return instance
    .post(`/paymentDetails/fetchFWCBookDealId`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getPreBookedDealsService = (data) => {
  return instance
    .post(`/paymentDetails/get-preBooked-Details`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getFWCService = (data) => {
  return instance
    .post(`/paymentDetails/get-forward-contract-details`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const savePaymentDetails = (data) => {
  return instance
    .post(`/paymentDetails/savePaymentDetails`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const fntCntEarMarkingAPI = (data) => {
  return instance
    .post(`/earmarking/earmarkingDeals`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const deleteDealAPI = (data) => {
  return instance
    .post(`/paymentDetails/deleteDeal`, data)
    .then((res) => res)
    .catch((err) => err);
};