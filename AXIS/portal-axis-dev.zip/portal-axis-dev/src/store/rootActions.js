import * as dashboard from "./dashboard/actions";
import * as auth from "./auth/actions";
import * as transaction from "./transaction/actions";
import * as boe from "./boe/actions";
import * as toast from "./toast/actions";
import * as paymentReview from "./payment_review/actions";
import * as payment from "./payment/actions";
import * as transactionDetails from "./transaction-details/actions";
import * as attachDocuments from "./attach_documents/actions";

export const Actions = Object.assign(
  {},
  dashboard,
  auth,
  transaction,
  boe,
  toast,
  payment,
  paymentReview,
  transactionDetails,
  attachDocuments
);
