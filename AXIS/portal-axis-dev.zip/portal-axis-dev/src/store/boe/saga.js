/* eslint-disable */
import * as TYPES from "../../utils/types";
import { takeLatest, put } from "redux-saga/effects";
import { 
  getBoesList, getNoOfBoesList, getBoeFiltersList,
  getBoeDetailsList, getBenefDropdownList, getFetchBenefDropdownList,
  getBenefDetailsList, getBenefCountryDropdownOptions,
  fetchBankDetailsOptions, fetchAddBank, swiftCodeDetails,
  updateBeneAccApi, addBeneApi, saveBeneApi, checkBeneExistOrNot,
  addBankBeneToTempAPI
} from "./service";

function* boes(action) {
  try {
    const params = action.payload;
    const status = action?.action
    const response = yield getBoesList(params, status);
    const data = response?.data?.responseBody;
    if(response?.status === 200){
      yield put({
          type: TYPES.BOE_INQUIRY_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.BOE_INQUIRY_ERROR,
      payload: error,
    });
  }
}

export function* getBoes() {
  yield takeLatest(TYPES.REQUEST_BOE_INQUIRY, boes);
}

function* noOfBoes(action) {
  try {
    const params = action.payload;
    const response = yield getNoOfBoesList(params);
    const data = response?.data?.responseBody;
    if(response?.status === 200){
      yield put({
          type: TYPES.NO_OF_BOES_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.NO_OF_BOES_ERROR,
      payload: error,
    });
  }
}

export function* getNoOfBoes() {
  yield takeLatest(TYPES.REQUEST_NO_OF_BOES, noOfBoes);
}

function* boeFilters(action) {
  try {
    const params = action.payload;
    const status = action?.action
    const response = yield getBoeFiltersList(params, status);
    const data = response?.data?.responseBody;
    if(response?.status === 200){
      yield put({
          type: TYPES.BOE_FILTERS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.BOE_FILTERS_ERROR,
      payload: error,
    });
  }
}

export function* getBoeFilters() {
  yield takeLatest(TYPES.REQUEST_BOE_FILTERS, boeFilters);
}


function* boeDetails(action) {
  try {
    const params = action.payload;
    const response = yield getBoeDetailsList(params);
    const data = response?.data?.fidbBoedtlresp;
    if(response?.status === 200){
      yield put({
          type: TYPES.BOE_DETAILS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    
    yield put({
      type: TYPES.BOE_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getBoeDetails() {
  yield takeLatest(TYPES.REQUEST_BOE_DETAILS, boeDetails);
}

function* benefDropdown(action) {
  try {
    const params = action.payload;
    const response = yield getBenefDropdownList(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.BENEF_DROPDOWN_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.BENEF_DROPDOWN_ERROR,
      payload: error,
    });
  }
}

export function* getBenefDropdown() {
  yield takeLatest(TYPES.REQUEST_BENEF_DROPDOWN, benefDropdown);
}

function* fetchBenefDropdown(action) {
  try {
    const params = action.payload;
    const response = yield getFetchBenefDropdownList(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.FETCH_BENEF_DROPDOWN_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    
    yield put({
      type: TYPES.FETCH_BENEF_DROPDOWN_ERROR,
      payload: error,
    });
  }
}

export function* getFetchBenefDropdown() {
  yield takeLatest(TYPES.REQUEST_FETCH_BENEF_DROPDOWN, fetchBenefDropdown);
}

function* benefDetails(action) {
  try {
    const params = action.payload;
    const response = yield getBenefDetailsList(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.BENEF_DETAILS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    
    yield put({
      type: TYPES.BENEF_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getBenefDetails() {
  yield takeLatest(TYPES.REQUEST_BENEF_DETAILS, benefDetails);
}

function* benefCountryDropdown(action) {
  try {
    const params = action.payload;
    const response = yield getBenefCountryDropdownOptions(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.BENEF_COUNTRY_OPTIONS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    
    yield put({
      type: TYPES.BENEF_COUNTRY_OPTIONS_ERROR,
      payload: error,
    });
  }
}

export function* getBenefCountryDropdown() {
  yield takeLatest(TYPES.REQUEST_BENEF_COUNTRY_OPTIONS, benefCountryDropdown);
}

function* fetchBankDetails(action) {
  try {
    const params = action.payload;
    const response = yield fetchBankDetailsOptions(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.FETCH_BANK_DETAILS_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    
    yield put({
      type: TYPES.FETCH_BANK_DETAILS_ERROR,
      payload: error,
    });
  }
}

export function* getFetchBankDetails() {
  yield takeLatest(TYPES.REQUEST_FETCH_BANK_DETAILS, fetchBankDetails);
}

function* addBank(action) {
  try {
    const params = action.payload;
    const isCorresponding = action?.corresponding;
    const { bankName,address1, bicCode, country  } = params;
    // Assigning data as request instead of add bank API call as per Seeni's instruction
    const data = {
      "bankName": bankName,
      "bankAddress": address1,
      "bankSwiftCode": bicCode,
      "bankCountry": country
    }
    // const response = yield fetchAddBank(params);
    // const data = response?.data;
    // if(response?.status === 200){
      if(isCorresponding){
        yield put({
          type: TYPES.ADD_BANK_CORR_SUCCESS,
          payload: data,
        });
        yield put({
          type: TYPES.SHOW_TOAST,
          toastMessage: "Corresponding Bank Details added",
          toastType: "success"
        });
      }
      else{
        yield put({
          type: TYPES.ADD_BANK_SUCCESS,
          payload: data,
        });
        yield put({
          type: TYPES.SHOW_TOAST,
          toastMessage: "Beneficiary Bank Details added",
          toastType: "success"
        });
      }
    // }
  } catch (error) {
    
    yield put({
      type: TYPES.ADD_BANK_ERROR,
      payload: error,
    });
  }
}

export function* getAddBank() {
  yield takeLatest(TYPES.REQUEST_ADD_BANK, addBank);
}

function* bankSwiftCode(action) {
  try {
    const params = action.payload;
    const isCorresponding = action?.corresponding;
    const response = yield swiftCodeDetails(params);
    const data = response?.data;
    if(response?.status === 200){
      if(isCorresponding){
        yield put({
          type: TYPES.BANK_SWIFT_CODE_CORRESPONDING_SUCCESS,
          payload: data,
        });
      }
      else{
        yield put({
          type: TYPES.BANK_SWIFT_CODE_SUCCESS,
          payload: data,
        });
      }
    }
  } catch (error) {
    
    yield put({
      type: TYPES.BANK_SWIFT_CODE_ERROR,
      payload: error,
    });
  }
}

export function* getBankSwiftCode() {
  yield takeLatest(TYPES.REQUEST_BANK_SWIFT_CODE, bankSwiftCode);
}

function* updateBeneAccount(action) {
  try {
    const params = action.payload;
    const response = yield updateBeneAccApi(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.UPDATE_BENE_ACC_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.UPDATE_BENE_ACC_ERROR,
      payload: error,
    });
  }
}

export function* updateBeneAcc() {
  yield takeLatest(TYPES.REQUEST_UPDATE_BENE_ACC, updateBeneAccount);
}

function* saveBeneficiary(action) {
  try {
    const params = action.payload;
    const response = yield saveBeneApi(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.SAVE_BENE_SUCCESS,
          payload: data,
          isButtonClick: action?.isButtonClick
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.SAVE_BENE_ERROR,
      payload: error,
    });
  }
}

export function* saveBene() {
  yield takeLatest(TYPES.REQUEST_SAVE_BENE, saveBeneficiary);
}

function* addBeneficiary(action) {
  try {
    const params = action.payload;
    const response = yield addBeneApi(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.ADD_BENE_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.ADD_BENE_ERROR,
      payload: error,
    });
  }
}

export function* addBene() {
  yield takeLatest(TYPES.REQUEST_ADD_BENE, addBeneficiary);
}

function* beneExistCheck(action) {
  try {
    const params = action.payload;
    const response = yield checkBeneExistOrNot(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.CHECK_BENE_IF_EXIST_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.CHECK_BENE_IF_EXIST_ERROR,
      payload: error,
    });
  }
}

export function* checkBeneExist() {
  yield takeLatest(TYPES.CHECK_BENE_IF_EXIST, beneExistCheck);
}

function* addBankBeneToTemp(action) {
  try {
    const params = action.payload;
    const response = yield addBankBeneToTempAPI(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.ADD_BENE_BANK_TEMP_SUCCESS,
          payload: data,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.ADD_BENE_BANK_TEMP_ERROR,
      payload: error,
    });
  }
}

export function* addtoTemp() {
  yield takeLatest(TYPES.ADD_BENE_BANK_TEMP, addBankBeneToTemp);
}