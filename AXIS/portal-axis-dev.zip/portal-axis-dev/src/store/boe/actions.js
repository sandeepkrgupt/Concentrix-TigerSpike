import * as TYPES from "../../utils/types";

export const getBoeInquiry = (data, action) => ({
  type: TYPES.REQUEST_BOE_INQUIRY,
  payload: data,
  action
});

export const getBoeFilters = (data, action) => ({
  type: TYPES.REQUEST_BOE_FILTERS,
  payload: data,
  action
});

export const getNoOfBoes =(data)=>({
  type: TYPES.REQUEST_NO_OF_BOES,
  payload: data
})

export const getBoeDetails =(data)=>({
  type: TYPES.REQUEST_BOE_DETAILS,
  payload: data
})

export const getBenefDropdown=(data)=>({
  type: TYPES.REQUEST_BENEF_DROPDOWN,
  payload: data
})

export const getFetchBenefDropdown=(data)=>({
  type: TYPES.REQUEST_FETCH_BENEF_DROPDOWN,
  payload: data
})


export const getBenefDetails=(data)=>({
  type: TYPES.REQUEST_BENEF_DETAILS,
  payload: data
})

export const getBenefCountryDropdown=(data)=>({
  type: TYPES.REQUEST_BENEF_COUNTRY_OPTIONS,
  payload: data
})

export const fetchBankDetails=(data)=>({
  type: TYPES.REQUEST_FETCH_BANK_DETAILS,
  payload: data,
})

export const addBank=(data, corr)=>({
  type: TYPES.REQUEST_ADD_BANK,
  payload: data,
  corresponding: corr
})

export const bankSwiftCode=(data, corr)=>({
  type: TYPES.REQUEST_BANK_SWIFT_CODE,
  payload: data,
  corresponding: corr
})

export const updateBeneAcc=(data)=>({
  type: TYPES.REQUEST_UPDATE_BENE_ACC,
  payload: data
})

export const saveBene=(data, isButtonClick)=>({
  type: TYPES.REQUEST_SAVE_BENE,
  payload: data,
  isButtonClick: isButtonClick
})

export const addBene=(data)=>({
  type: TYPES.REQUEST_ADD_BENE,
  payload: data
})

export const clearBeneDraftMsgStatus = () => ({
  type: TYPES.CLEAR_BENE_DRAFT_MSG_STATUS,
})

export const checkBeneIfExist = (data) => ({
  type: TYPES.CHECK_BENE_IF_EXIST,
  payload: data
})

export const addBeneOrBankToTemp = (data) => ({
  type: TYPES.ADD_BENE_BANK_TEMP,
  payload: data
})

export const clearFetchBankDetails=()=>({
  type: TYPES.CLEAR_FETCH_BANK_DETAILS,
})

export const clearBeneAccNewDetails=()=>({
  type: TYPES.CLEAR_BENE_ACC_NEW_DETAILS,
})