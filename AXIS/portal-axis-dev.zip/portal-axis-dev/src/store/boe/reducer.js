import * as TYPES from "../../utils/types";

const initialState = {
  loader: false,
  boes:[],
  noOfBoes: [],
  boeFilters: {},
  boeDetails: {},
  benefOptions:[],
  benefDetails:{},
  benefCountryOptions:[],
  fetchBankDetails:{},
  bankSwiftCodeDetails:{},
  bankSwiftCodeCorrDetails:{},
  bankDetails:{},
  showSaveDraftMsg: false,
  bankBeneStatus: {},
  bankNewDetails: {},
};
export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQUEST_BOE_INQUIRY:
      return { ...state, loader: true };
    case TYPES.BOE_INQUIRY_SUCCESS: {
      return {
        ...state,
        boes: action.payload?.boeList,
        totalPage: action?.payload?.boePagination?.totalRecordSize,
        loader: false
      };
    }
    case TYPES.REQUEST_NO_OF_BOES:
      return { ...state, loader: true };
    case TYPES.NO_OF_BOES_SUCCESS: {
      return {
        ...state,
        noOfBoes: action.payload?.boeList,
        loader: false
      };
    }
    case TYPES.REQUEST_BOE_FILTERS:
      return { ...state, loader: true };
    case TYPES.BOE_FILTERS_SUCCESS: {
      return {
        ...state,
        boeFilters: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_BOE_DETAILS:
      return { ...state, loader: true };
    case TYPES.BOE_DETAILS_SUCCESS: {
      return {
        ...state,
        boeDetails: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_BENEF_DROPDOWN:
      return { ...state, loader: true };
    case TYPES.BENEF_DROPDOWN_SUCCESS: {
      return {
        ...state,
        benefOptions: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_FETCH_BENEF_DROPDOWN:
      return { ...state, loader: true };
    case TYPES.FETCH_BENEF_DROPDOWN_SUCCESS: {
      return {
        ...state,
        benefOptions: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_BENEF_DETAILS:
      return { ...state, loader: true };
    case TYPES.BENEF_DETAILS_SUCCESS: {
      return {
        ...state,
        benefDetails: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_BENEF_COUNTRY_OPTIONS:
      return { ...state, loader: true };
    case TYPES.BENEF_COUNTRY_OPTIONS_SUCCESS: {
      return {
        ...state,
        benefCountryOptions: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_FETCH_BANK_DETAILS:
      return { ...state, loader: true };
    case TYPES.FETCH_BANK_DETAILS_SUCCESS: {
      return {
        ...state,
        fetchBankDetails: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_BANK_SWIFT_CODE:{
      return{
        ...state,
        loader: true
      }
    }
    case TYPES.BANK_SWIFT_CODE_SUCCESS:{
      return{
        ...state,
        loader: false,
        bankSwiftCodeDetails: action.payload,
      }
    }
    case TYPES.BANK_SWIFT_CODE_CORRESPONDING_SUCCESS:{
      return{
        ...state,
        laoder: false,
        bankSwiftCodeCorrDetails: action?.payload
      }
    }
    case TYPES.REQUEST_UPDATE_BENE_ACC:{
      return{
        ...state,
        loader: true
      }
    }
    case TYPES.UPDATE_BENE_ACC_SUCCESS:{
      return{
        ...state,
        loader: false,
        bankNewDetails: action?.payload
      }
    }
    case TYPES.CLEAR_BENE_ACC_NEW_DETAILS:{
      return{
        ...state,
        bankNewDetails: {}
      }
    }
    case TYPES.REQUEST_ADD_BANK:{
      return{
        ...state,
        loader: true
      }
    }
    case TYPES.ADD_BANK_SUCCESS:{
      return{
        ...state,
        loader: false,
        bankDetails: action?.payload,
        bankSwiftCodeDetails:{}
      }
    }
    case TYPES.ADD_BANK_CORR_SUCCESS:{
      return{
        ...state,
        loader: false,
        bankCorrDetails: action?.payload,
        bankSwiftCodeCorrDetails:{}
      }
    }
    case TYPES.SAVE_BENE_SUCCESS:
      return {
        ...state,
        showSaveDraftMsg: action?.isButtonClick
      }
    case TYPES.CLEAR_BENE_DRAFT_MSG_STATUS:
      return {
        ...state,
        showSaveDraftMsg: false
      }
    case TYPES.CHECK_BENE_IF_EXIST:
      return {
        ...state
      }
    case TYPES.CHECK_BENE_IF_EXIST_SUCCESS:
      return {
        ...state,
        bankBeneStatus: action?.payload
      }
    case TYPES.ADD_BENE_BANK_TEMP:
      return {
        ...state
      }
    case TYPES.ADD_BENE_BANK_TEMP_SUCCESS:
      return {
        ...state,
        tempInsertStatus: action?.payload
      }
    case TYPES.CLEAR_FETCH_BANK_DETAILS:
      return {
        ...state,
        fetchBankDetails:{}
      }
    default:
      return { ...state };
  }
}