import instance from "../../services";

export const getBoesList = (data, action) => {
  return instance
    .post(`/boe/${action}`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getNoOfBoesList = (data) => {
  return instance
    .post('/boe/boe-count', data)
    .then((res) => res)
    .catch((err) => err);
};


export const getBoeFiltersList = (data, action) => {
  return instance
    .post(`/boe/filter-dropdown/${action}`, data)
    .then((res) => res)
    .catch((err) => err);
};


export const getBoeDetailsList = (data) => {
  return instance
    .post(`/boeinquiry/boedetails`, data)
    .then((res) => res)
    .catch((err) => err);
};

export const getBenefDropdownList = (data)=>{
  return instance
  .post('/beneficiaryDetails/fetchFuzzy', data)
  .then((res) => res)
  .catch((err) => err);
}

export const getFetchBenefDropdownList = (data)=>{
  return instance
  .post('/beneficiaryDetails/fetchBeneficiary', data)
  .then((res) => res)
  .catch((err) => err);
}

export const getBenefDetailsList = (data)=>{
  return instance
  .post('/beneficiaryDetails/selectBeneficiary', data)
  .then((res) => res)
  .catch((err) => err);
}

export const getBenefCountryDropdownOptions = (data)=>{
  return instance
  .post('/beneficiaryDetails/countryCode', data)
  .then((res) => res)
  .catch((err) => err);
}

export const fetchBankDetailsOptions = (data)=>{
  return instance
  .post('/beneficiaryDetails/fetchBankDetailsV2', data)
  .then((res) => res)
  .catch((err) => err);
}

export const fetchAddBank = (data)=>{
  return instance
  .post('/beneficiaryDetails/addBank', data)
  .then((res) => res)
  .catch((err) => err);
}

export const swiftCodeDetails = (data)=>{
  return instance
  .post('/beneficiaryDetails/getDetailsOnSwiftcode', data)
  .then((res) => res)
  .catch((err) => err);
}

export const updateBeneAccApi = (data)=>{
  return instance
  .post('/beneficiaryDetails/updateBeneAccount', data)
  .then((res) => res)
  .catch((err) => err);
}

export const saveBeneApi = (data)=>{
  return instance
  .post('/beneficiaryDetails/saveBeneficaryDetails', data)
  .then((res) => res)
  .catch((err) => err);
}

export const addBeneApi = (data)=>{
  return instance
  .post('/beneficiaryDetails/addBeneficiary', data)
  .then((res) => res)
  .catch((err) => err);
}

export const checkBeneExistOrNot = (data) => {
  return instance
  .post('/beneficiaryDetails/checkBeneAccountDetails', data)
  .then((res) => res)
  .catch((err) => err);
}

export const addBankBeneToTempAPI = (data) => {
  return instance
  .post('/beneficiaryDetails/addBeneAccountDetailInTemp', data)
  .then((res) => res)
  .catch((err) => err);
}