import * as TYPES from "../../utils/types";
import { takeLatest, put } from "redux-saga/effects";
import { getDashboardBoeList, getDashboardTasksList } from "./service";

// DASHBOARD TASKS
function* dashboardTasks(action) {
  try {
    const params = action.payload;
    const response = yield getDashboardTasksList(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.DASHBOARD_TASKS_SUCCESS,
          payload: data,
      });
    }
    else{
      yield put({
        type: TYPES.DASHBOARD_TASKS_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DASHBOARD_TASKS_ERROR,
      payload: error,
    });
  }
}

export function* getDashboardTasks() {
  yield takeLatest(TYPES.REQUEST_DASHBOARD_TASKS, dashboardTasks);
}

// DASHBOARD BOE 
function* dashboardBoe(action) {
  try {
    const params = action.payload;
    const response = yield getDashboardBoeList(params);
    const data = response?.data;
    if(response?.status === 200){
      yield put({
          type: TYPES.DASHBOARD_BOE_SUCCESS,
          payload: data,
      });
    }
    else{
      yield put({
        type: TYPES.DASHBOARD_BOE_ERROR,
        payload: response,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DASHBOARD_BOE_ERROR,
      payload: error,
    });
  }
}

export function* getDashboardBoe() {
  yield takeLatest(TYPES.REQUEST_DASHBOARD_BOE, dashboardBoe);
}