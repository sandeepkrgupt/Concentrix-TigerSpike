import * as TYPES from "../../utils/types";

export const getDashboardTasks = (data) => ({
  type: TYPES.REQUEST_DASHBOARD_TASKS,
  payload: data
});

export const getDashboardBoe = (data) => ({
  type: TYPES.REQUEST_DASHBOARD_BOE,
  payload: data
});
