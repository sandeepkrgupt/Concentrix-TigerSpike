import * as TYPES from "../../utils/types";

const initialState = {
  loader: false,
  dashboardTasks: [],
  dashboardBoe: [],
};
export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQUEST_DASHBOARD_TASKS:
      return { ...state, loader: true };
    case TYPES.DASHBOARD_TASKS_SUCCESS: {
      const tiTasks = action?.payload?.filter((item)=>{
         return item?.label !== "Completed";
      });
      return {
        ...state,
        dashboardTasks: action.payload,
        tiTasks: tiTasks,
        loader: false
      };
    }
    case TYPES.DASHBOARD_TASKS_ERROR:
      return { ...state, loader: false };
    case TYPES.REQUEST_DASHBOARD_BOE:
      return { ...state, loader: true };
    case TYPES.DASHBOARD_BOE_SUCCESS: {
      return {
        ...state,
        dashboardBoe: action.payload,
        loader: false
      };
    }
    case TYPES.DASHBOARD_BOE_ERROR:
      return { ...state, loader: false };
    default:
      return { ...state };
  }
}
