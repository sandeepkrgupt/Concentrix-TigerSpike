import instance from "../../services";

export const getDashboardTasksList = (data) => {
  return instance
    .post("/dashboard/task", data)
    .then((res) => res)
    .catch((err) => err);
};

export const getDashboardBoeList = (data) => {
  return instance
    .post("/dashboard/boe", data)
    .then((res) => res)
    .catch((err) => err);
};
