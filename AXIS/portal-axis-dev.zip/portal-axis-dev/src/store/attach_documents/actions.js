import * as TYPES from "../../utils/types";

export const uploadDocuments = (data) => ({
  type: TYPES.UPLOAD_DOCUMENTS,
  payload: data,
});

export const getDocCheckList = () => {
  return {
    type: TYPES.GET_DOC_CHECKLIST,
  };
};

export const checkDocumentCheckList = (data) => {
  return {
    type: TYPES.CHECK_DOC_CHECKLIST,
    payload: data,
  };
};

// delete individual uploaded files
export const deleteUploadedDoc = (data) => ({
  type: TYPES.DELETE_DOCUMENT,
  payload: data,
});

// delete all uploaded files
export const deleteAllUploadedDoc = (data) => ({
  type: TYPES.DELETE_ALL_DOCUMENT,
  payload: data,
});

// get all attachments
export const getAllAttachments = (data) => {
  return {
    type: TYPES.GET_ALL_ATTACHMENTS,
    payload: data,
  };
};

// get all attachments
export const updateFileData = (data) => {
  return {
    type: TYPES.UPDATE_FILE_DATA,
    payload: data,
  };
};
