import * as TYPES from "../../utils/types";
import { takeLatest, takeEvery, put } from "redux-saga/effects";
import {
  uploadDocumentService,
  getDocumentCheckListService,
  deleteUploadedFileService,
  deleteAllUploadedFileService,
  getAllAttachmentsService,
  checkDocumentCheckListService,
} from "./service";

// UPLOAD DOCUMENT
function* uploadDocs(action) {
  try {
    const params = action.payload;
    const response = yield uploadDocumentService(params);

    if (response?.data?.status === "Success") {
      yield put({
        type: TYPES.UPLOAD_DOCUMENTS_SUCCESS,
        payload: { data: response?.data, fileIndex: params.fileIndex },
      });
    } else {
      yield put({
        type: TYPES.UPLOAD_DOCUMENTS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.UPLOAD_DOCUMENTS_ERROR,
      payload: error,
    });
  }
}

export function* uploadDocuments() {
  yield takeEvery(TYPES.UPLOAD_DOCUMENTS, uploadDocs);
}

// GET CLASSIFICATION LIST
function* getClassifications() {
  try {
    const response = yield getDocumentCheckListService();
    if (response?.data?.length > 0) {
      yield put({
        type: TYPES.GET_DOC_CHECKLIST_SUCCESS,
        payload: response?.data,
      });
    } else {
      yield put({
        type: TYPES.GET_DOC_CHECKLIST_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_DOC_CHECKLIST_ERROR,
      payload: error,
    });
  }
}

export function* getClassificationsList() {
  yield takeLatest(TYPES.GET_DOC_CHECKLIST, getClassifications);
}

function* checkDocumentCheckListSagaCallBack(action) {
  try {
    const params = action.payload;
    const response = yield checkDocumentCheckListService(params);

    if (response?.data?.status === "Success") {
      yield put({
        type: TYPES.CHECK_DOC_CHECKLIST_SUCCESS,
        payload: response?.data,
      });
    } else {
      yield put({
        type: TYPES.CHECK_DOC_CHECKLIST_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.CHECK_DOC_CHECKLIST_ERROR,
      payload: error,
    });
  }
}

export function* checkDocumentCheckListSaga() {
  yield takeLatest(
    TYPES.CHECK_DOC_CHECKLIST,
    checkDocumentCheckListSagaCallBack
  );
}

// delete single uploaded file
function* delUplFile(action) {
  try {
    const params = action.payload;
    const response = yield deleteUploadedFileService(params);
    if (response?.data[0]?.status === "Success") {
      yield put({
        type: TYPES.DELETE_DOCUMENT_SUCCESS,
        payload: params.fileIndex,
      });
    } else {
      yield put({
        type: TYPES.DELETE_DOCUMENT_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DELETE_DOCUMENT_ERROR,
      payload: error,
    });
  }
}

export function* deleteUploadedFile() {
  yield takeLatest(TYPES.DELETE_DOCUMENT, delUplFile);
}

// delete all uploaded files
function* delAllUplFile(action) {
  try {
    const params = action.payload;
    const response = yield deleteAllUploadedFileService(params);
    if (response?.data[0]?.status === "Success") {
      yield put({
        type: TYPES.DELETE_ALL_DOCUMENT_SUCCESS,
      });
    } else {
      yield put({
        type: TYPES.DELETE_ALL_DOCUMENT_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.DELETE_ALL_DOCUMENT_ERROR,
      payload: error,
    });
  }
}

export function* deleteAllUploadedFile() {
  yield takeLatest(TYPES.DELETE_ALL_DOCUMENT, delAllUplFile);
}

// get all attachments
function* getAttachments(action) {
  try {
    const params = action.payload;
    const response = yield getAllAttachmentsService(params);
    if (response?.data?.errorResponse === null) {
      yield put({
        type: TYPES.GET_ALL_ATTACHMENTS_SUCCESS,
        payload: response.data.attachmentPayload.responseBody,
      });
    } else {
      yield put({
        type: TYPES.GET_ALL_ATTACHMENTS_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.GET_ALL_ATTACHMENTS_ERROR,
      payload: error,
    });
  }
}

export function* getAllAttachmentsSaga() {
  yield takeLatest(TYPES.GET_ALL_ATTACHMENTS, getAttachments);
}

// // updFilDat
function* updFilDat(action) {}

export function* updateFileData() {
  yield takeLatest(TYPES.UPDATE_FILE_DATA, updFilDat);
}
