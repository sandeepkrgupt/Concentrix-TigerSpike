import * as TYPES from "../../utils/types";

const initialState = {
  documents: [],
  documentCheckList: [],
  checkDocumentCheckList: [],
  attachments: [],
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.UPLOAD_DOCUMENTS:
      return {
        ...state,
        documents: [
          ...state.documents,
          {
            file: action.payload.uploadFile,
            checkList: action.payload.checkList.id,
          },
        ],
      };
    case TYPES.UPLOAD_DOCUMENTS_SUCCESS: {
      const newDocList = state.documents.map((item, index) => {
        if (index === action.payload.fileIndex) {
          return { ...item, id: action.payload.data.id };
        } else {
          return item;
        }
      });

      return { ...state, documents: newDocList };
    }
    case TYPES.UPLOAD_DOCUMENTS_ERROR:
      return { ...state };

    case TYPES.GET_DOC_CHECKLIST ||
      TYPES.CHECK_DOC_CHECKLIST ||
      TYPES.CHECK_DOC_CHECKLIST_ERROR:
      return { ...state };
    case TYPES.GET_DOC_CHECKLIST_SUCCESS: {
      return { ...state, documentCheckList: action.payload };
    }
    case TYPES.GET_DOC_CHECKLIST_ERROR:
      return { ...state };

    case TYPES.CHECK_DOC_CHECKLIST_SUCCESS: {
      return { ...state, checkDocumentCheckList: action.payload };
    }

    case TYPES.DELETE_DOCUMENT:
      return {
        ...state,
      };
    case TYPES.DELETE_DOCUMENT_SUCCESS: {
      // filter out deleted file
      const newDocList = state.documents.filter(
        (item, index) => index !== action.payload
      );
      return { ...state, documents: newDocList };
      // return { ...state };
    }
    case TYPES.DELETE_DOCUMENT_ERROR:
      return { ...state };

    case TYPES.DELETE_ALL_DOCUMENT:
      return {
        ...state,
      };
    case TYPES.DELETE_ALL_DOCUMENT_SUCCESS: {
      return { ...state, documents: [] };
    }
    case TYPES.DELETE_ALL_DOCUMENT_ERROR:
      return { ...state };

    case TYPES.GET_ALL_ATTACHMENTS:
      return {
        ...state,
      };
    case TYPES.GET_ALL_ATTACHMENTS_SUCCESS: {
      const newList = action.payload.map((item) => {
        return {
          file: { name: item.fileName },
          id: item.id,
          checkList: { label: item.checkList, id: item.checkList },
          showUploading: false,
          uploadCompleted: true,
        };
      });
      return { ...state, attachments: [...newList] };
    }
    case TYPES.GET_ALL_ATTACHMENTS_ERROR:
      return { ...state };

    case TYPES.UPDATE_FILE_DATA: {
      return { ...state, documents: [...action.payload] };
    }

    default:
      return { ...state };
  }
}
