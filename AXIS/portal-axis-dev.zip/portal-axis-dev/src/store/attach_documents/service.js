import instance from "../../services";

// upload a file
export const uploadDocumentService = (data) => {
  // create FormData to avoid CORS policy errors
  var bodyFormData = new FormData();
  bodyFormData.append("bankCode", data.bankCode);
  bodyFormData.append("checkList", data.checkList.id);
  bodyFormData.append("recKey", data.recKey);
  bodyFormData.append("uploadFile", data.uploadFile);

  const timeStarted = new Date();
  const config = {
    onUploadProgress: (progressEvent) => {
      // passing upload progress back to component

      data.uploadPrgress(
        data.uploadFile.size,
        timeStarted,
        progressEvent.loaded,
        (progressEvent.loaded / progressEvent.total) * 100,
        data.fileIndex
      );
    },
    headers: {
      "Content-Type": "multipart/form-data",
    },
  };
  return instance
    .post("/payment/upload", bodyFormData, config)
    .then((res) => res)
    .catch((err) => err);
};

// get classification list
export const getDocumentCheckListService = () => {
  return instance
    .get("/payment/checklist")
    .then((res) => res)
    .catch((err) => err);
};

// delete a file
export const deleteUploadedFileService = (data) => {
  return instance
    .post("/payment/delete", [data])
    .then((res) => res)
    .catch((err) => err);
};

// delete all files
export const deleteAllUploadedFileService = (data) => {
  return instance
    .post("/payment/delete", data)
    .then((res) => res)
    .catch((err) => err);
};

// get all attachments
export const getAllAttachmentsService = (data) => {
  return instance
    .post("/payment/attachments", data)
    .then((res) => res)
    .catch((err) => err);
};

// get document check list
export const checkDocumentCheckListService = (data) => {
  return instance
    .post("/documentCheckList/check-documentCheckList", data)
    .then((res) => res)
    .catch((err) => err);
};
