import * as TYPES from "../../utils/types";

export const hideToast=()=>({
    type: TYPES.HIDE_TOAST
})