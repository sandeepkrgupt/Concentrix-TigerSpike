import * as TYPES from "../../utils/types";

const initialState = {
    showToast: false,
    toastMessage: "",
    toastType:""
}

export default function reducer(state = initialState, action) {
    switch (action.type) {
      case TYPES.SHOW_TOAST:
        return { ...state, showToast: true, toastMessage: action?.toastMessage, toastType: action?.toastType};
        case TYPES.HIDE_TOAST:
            return { ...state, showToast: false};
        default: return { ...state };
    }
}