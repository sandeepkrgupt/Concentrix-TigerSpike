import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import CloseIcon from '../../assets/icons/close.svg';
import ConvertorIcon from '../../assets/icons/convertor.svg';
// import CountryIcon from '../../assets/icons/country.svg';
import FavIcon from '../../assets/icons/fav.svg';
import TrashIcon from '../../assets/icons/trash.svg';
import { TextField, Button, Dropdown} from '../../components/@subzero/glacier/package/lib/components';
import './index.css';

const useStyles = makeStyles({
  paper:{
    width: '100%',
    height: '92%',
    background: '#FFFFFF',
    borderRadius: '24px 24px 0px 0px',
  },
  dropdown:{
    '& .Dropdown_show__21pcz':{
      position:"absolute",
      zIndex: "999",
    }
  }

});

const data = {
  favCurrencies:[
    {
      country: "USA",
      currency: "USD",
      amount: 77
    },
    {
      country: "Japan",
      currency: "JPY",
      amount: 0.69
    },
    {
      country: "France",
      currency: "EUR",
      amount: 77
    },
    {
      country: "British",
      currency: "GBP",
      amount: 101
    },
    {
      country: "Kuwait",
      currency: "KD",
      amount: 248
    }
  ]
}

const CurrencyConvertor = () => {
  const classes = useStyles();
  const [openModal, setOPenModal] = React.useState(true);
  const [selectedCurrency] = React.useState("United Kingdom/UK");
  const [selectedAmount, setSelectedAmount] = React.useState("1.0");
  const [convertedAmount, setConvertedAmount] = React.useState("");
  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }
    setOPenModal(open);
  };
  const checkExcludedList=(val)=>{
    if((val === "USD") || (val === "EUR") || (val === "GBP")){
      return true;
    }
    else{
      return false;
    }
  }
  const convert=()=>{
    // API CALL & Update convertedAMount
    setConvertedAmount('');
  }
  const addToFav=()=>{
    // Add to fav API
  }
  const removeFav=()=>{
    // Remove from fav API
  }
  return (
        <div>
        <React.Fragment>
          <Button onClick={toggleDrawer(true)}>OPEN</Button>
          <Drawer classes={{
            paper: classes.paper
          }} anchor={"bottom"} open={openModal} onClose={toggleDrawer(false)}>
            <div onClick={toggleDrawer(false)} className="close">
              <img src={CloseIcon} className="close-icon"/>
            </div>
            <div className="convertor-container">
              <span className="foreign-heading">
                Foreign Currency Exchange Rate*
              </span>
              <span className="rates">
                *Rates are indicative
              </span>
              <div className="currency-convertor-container">
                <span className="currency-convertor">
                  Currency Convertor
                </span>
                <div className="operation-container">
                  <div className="dropdown">
                    <Dropdown
                    className="mb"
                      items={
                          [
                              'United Kingdom / UK',
                              'United States of America / USD',
                              'Kuwait / KD'
                          ]
                      }
                      label="Country / Currency"
                      type="text"
                      variant="filled"
                      inputText={selectedCurrency}
                      // onChange={}
                      />
                    <TextField
                      className="mb"
                      label="Amount"
                      type="text"
                      variant="filled"
                      value={`${selectedCurrency.split('/')[1]} ${selectedAmount}`}
                      onChange={(e)=> setSelectedAmount(e?.target?.value)}
                    />
                  </div>
                  <img className="convertor-icon" src={ConvertorIcon} onClick={convert}/>
                  <div className="dropdown">
                    <Dropdown
                    className="mb"
                      items={
                          [
                            'India/INR',
                            'United Kingdom / UK',
                            'United States of America / USD',
                            'Kuwait / KD'
                          ]
                      }
                      label="Country / Currency"
                      type="text"
                      variant="filled"
                      // onChange
                      />
                    <TextField
                      className="mb"
                      label="Amount"
                      type="text"
                      variant="filled"
                      value={convertedAmount}
                    />
                  </div>
                </div>
                <div className="add-fav">
                  <Button
                    color="secondary"
                    size="small"
                    variant="text"
                    withIcon
                    endIcon={<img className="fav-icon" src={FavIcon}/>}
                    onClick={addToFav}
                  >
                    Add to Favourites
                  </Button>
                </div>
              </div>
              <div className="currency-convertor-container">
                <span className="currency-convertor">Favourite Currency</span>
                <div className="fav-list">
                {
                  data?.favCurrencies.map((fav, id)=>{
                    return(
                      <div key={id} className="fav-list-item">
                        <div className="fav-currency-container">
                          <div className="country-currency">
                            {/* <img className="country-icon" src={CountryIcon}/> */}
                            <span className="country-curr">{`${fav.country}/${fav.currency}`}</span>
                          </div>
                          <div>
                            <span className="curr-amount">
                              {`${fav.currency} 1 = INR ${fav.amount}`}
                            </span>
                          </div>
                        </div>
                        <Button
                        style={{visibility:  checkExcludedList(fav.currency) ? "hidden": "visible"}}
                         className="trash-icon"
                         color="secondary"
                         size="small"
                         variant="text"
                         hasIconOnly
                         endIcon={<img src={TrashIcon}/>}
                         onClick={removeFav}
                       />
                       </div>
                    )
                  })
                }
                </div>
              </div>
            </div>
          </Drawer>
        </React.Fragment>
    </div>
    );
};

export default CurrencyConvertor;

