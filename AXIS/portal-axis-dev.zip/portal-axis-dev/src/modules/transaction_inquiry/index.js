/*eslint-disable */
import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Breadcrumbs,
  Dropdown,
  Button,
} from "../../components/@subzero/glacier/package/lib/components";
import Drawer from "@material-ui/core/Drawer";
import CloseIcon from "../../assets/icons/close.svg";
import PreviousIcon from "../../assets/icons/prev-icon.svg";
import CustomIcon from "../../assets/icons/custom-icon.svg";
import Grid from "@material-ui/core/Grid";
import "./index.css";
import CustomizeStatusTitles from "./CustomizeStatusTitles";
import { tiColors, tiBorderColors } from "../../utils/colors";
import { useLocation, useHistory } from "react-router-dom";
import AllTransactions from "./all_transactions";
import Drafts from "./drafts";
import RejectedByAuth from "./rejected_auth";
import RejectedByBank from "./rejected_bank";
import PendingWithAuth from "./pending_with_auth";
import PendingWithBank from "./pending_with_bank";
import Scheduled from "./scheduled";
import ApproveReject from "./approve_reject";
import { useSelector, useDispatch } from "react-redux";
import { Actions } from "../../store/rootActions";
import Loader from "../../components/loader";
import { Link } from "react-router-dom";

let foundNonAuthorizableSelectedTransaction;

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
}));

const TransactionInquiry = () => {
  const classes = useStyles();
  const location = useLocation();
  const history = useHistory();
  const [showCustomizePopup, updateCustomizePopupDisplay] = useState(false);
  const [activeTI, setActiveTI] = useState(location?.state?.status);
  const [action, setAction] = useState(location?.state?.action);
  const [transaction, setTransaction] = useState("All Transactions");
  const [userRole] = useState("maker");
  const [selRows, setSelRows] = useState([]);
  const [rows, setRows] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [approve, setApprove] = useState(false);
  const state = useSelector((state) => state?.transaction);
  const [tasks, setTasks] = useState(
    useSelector((state) => state?.transaction?.statistics)
  );
  const dispatch = useDispatch();
  const authData = useSelector((state) => state?.auth?.loginData);

  useEffect(() => {
    getStatistics();
    dispatch(Actions.clearChannelRefNo());
  }, []);

  useEffect(() => {
    foundNonAuthorizableSelectedTransaction = null;
    if (selRows && selRows?.length > 0) {
      // add condition to check whether selected row has no bookFxRateAmount pending
      foundNonAuthorizableSelectedTransaction = selRows?.find((item) => {
        return item?.isBookRate?.value === false;
      });
    }
  }, [selRows]);

  useEffect(() => {
    const updatedTasks = state?.statistics?.map((item, ind) => {
      item.color = tiColors[ind];
      item.borderColor = tiBorderColors[ind];
      return item;
    });
    setTasks(updatedTasks);
  }, [state]);

  useEffect(() => {
    getStatistics();
  }, [transaction]);

  useEffect(() => {
    setAction(location?.state?.action);
  }, [location?.state?.action]);

  const getStatistics = () => {
    const toggleType = transaction === "All Transactions" ? "ALL" : "MY";
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      appDate: authData?.appDate,
      ieCode: authData?.ieCode,
      userRoleType: authData?.userRoleType,
      toggleType: toggleType,
    };
    dispatch(Actions.getTransactionStatistics(req));
  };

  const fetchTables = () => {
    switch (activeTI) {
      case "All Tasks":
        return (
          <AllTransactions
            selRows={(rows) => setSelRows(rows)}
            rows={(data) => setRows(data)}
            transaction={transaction}
            action={action}
            user={userRole}
          />
        );
      case "Drafts":
        return (
          <Drafts
            selRows={(rows) => setSelRows(rows)}
            rows={(data) => setRows(data)}
            transaction={transaction}
            action={action}
            user={userRole}
          />
        );
      case "Rejected by Auth":
        return (
          <RejectedByAuth
            selRows={(rows) => setSelRows(rows)}
            rows={(data) => setRows(data)}
            transaction={transaction}
            action={action}
            user={userRole}
          />
        );
      case "Rejected by Bank":
        return (
          <RejectedByBank
            selRows={(rows) => setSelRows(rows)}
            rows={(data) => setRows(data)}
            transaction={transaction}
            action={action}
            user={userRole}
          />
        );
      case "Pending with Auth": {
        console.log(rows);
        console.log(selRows);
        console.log(transaction);
        return (
          <PendingWithAuth
            selRows={(rows) => setSelRows(rows)}
            rows={(data) => setRows(data)}
            transaction={transaction}
            action={action}
            user={userRole}
          />
        );
      }

      case "Pending with Bank":
        return (
          <PendingWithBank
            selRows={(rows) => setSelRows(rows)}
            rows={(data) => setRows(data)}
            transaction={transaction}
            action={action}
            user={userRole}
          />
        );
      case "Scheduled":
        return (
          <Scheduled
            selRows={(rows) => setSelRows(rows)}
            rows={(data) => setRows(data)}
            transaction={transaction}
            action={action}
            user={userRole}
          />
        );
      case "Bulk Upload Queue":
        return <p>Coming Soon...</p>;
      default:
        return null;
    }
  };
  const toggleDrawer = (open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    setShowModal(open);
  };
  const ApproveRejectModal = () => {
    return (
      <Drawer
        classes={{
          paper: classes.paper,
        }}
        anchor={"bottom"}
        open={true}
        onClose={toggleDrawer(false)}
      >
        <div onClick={toggleDrawer(false)} className="close">
          <img src={CloseIcon} className="close-icon" />
        </div>
        <div className="modal-container">
          <ApproveReject
            approve={approve}
            transaction={transaction}
            data={selRows}
            toggleModal={(val) => setShowModal(val)}
          />
        </div>
      </Drawer>
    );
  };
  // if(loader){
  //     return <Loader/>
  // }
  return (
    <div className="transaction-inquiry-container">
      <div className="heading-container">
        <div className="left-container">
          {/*<div className="left-img-container">
            <img src={PreviousIcon} onClick={() => history.goBack()} />
  </div> */}
          <div className="breadcrumb-container">
            <Breadcrumbs itemsAfterCollapse={3} maxItems={3}>
              <Link className="breadcrumb-link" to="/dashboard">
                Trade Overview
              </Link>
              <Link className="breadcrumb-link active-breadcrumb-link" active>
                Transaction Inquiry
              </Link>
            </Breadcrumbs>
            <span className="heading-text">Transaction Inquiry</span>
          </div>
        </div>
        <div className="right-container">
          <Dropdown
            items={
              userRole === "maker"
                ? ["All Transactions", "My Transactions"]
                : ["All Transactions"]
            }
            defaultValue={transaction}
            value={transaction}
            label=""
            placeholder=""
            type="text"
            variant="filled"
            fullWidth
            name="All Transactions"
            onChange={(e) => {
              setTransaction(e);
            }}
          />
        </div>
      </div>
      <div className="sub-heading-container">
        <div className="left-container">
          <span className="sub-heading-text">Transaction Status</span>
        </div>
        <div className="sub-right-container">
          <div
            className="customize-button"
            onClick={() => {
              // updateCustomizePopupDisplay(true)
            }}
          >
            {" "}
            Customize &nbsp;
            <img src={CustomIcon} />
          </div>
        </div>
      </div>

      <Grid container spacing={1}>
        {tasks?.map((task, ind) => {
          return (
            <Grid
              key={ind}
              item
              // lg={2} sm={3} xs={6}
            >
              <div
                className={`card-container transaction-stats-box`}
                style={{
                  backgroundColor: task.color,
                  border:
                    activeTI === task?.label
                      ? `3px solid ${task?.borderColor}`
                      : null,
                }}
                onClick={() => {
                  setActiveTI(task?.label);
                  setAction(task?.action);
                }}
              >
                <div className="card-sub-container">
                  <span className="transaction-count">{task.count}</span>
                  <span className="transaction-status">{task.label}</span>
                </div>
                <div></div>
              </div>
            </Grid>
          );
        })}
      </Grid>
      <div className="boe-table">{fetchTables()}</div>
      {authData?.userRoleType === "C" && (
        <div className="selected">
          <span>{`Transaction Selected: ${selRows?.length}`}</span>
          <div className="payment-button">
            <Button
              className="reject-button"
              color="secondary"
              disabled={
                selRows?.length <= 0 ||
                foundNonAuthorizableSelectedTransaction !== undefined ||
                foundNonAuthorizableSelectedTransaction !== null
              }
              onClick={() => {
                setApprove(false);
                setShowModal(true);
              }}
            >
              Reject
            </Button>
            <Button
              disabled={
                selRows?.length <= 0 ||
                foundNonAuthorizableSelectedTransaction !== undefined ||
                foundNonAuthorizableSelectedTransaction !== null
              }
              onClick={() => {
                setApprove(true);
                setShowModal(true);
              }}
            >
              Authorize
            </Button>
          </div>
        </div>
      )}
      {showModal && <ApproveRejectModal />}
      {showCustomizePopup && (
        <CustomizeStatusTitles
          showDrawer={showCustomizePopup}
          toggleDrawer={() => {
            updateCustomizePopupDisplay(false);
          }}
        />
      )}
      {state?.loader && <Loader />}
    </div>
  );
};
export default TransactionInquiry;
