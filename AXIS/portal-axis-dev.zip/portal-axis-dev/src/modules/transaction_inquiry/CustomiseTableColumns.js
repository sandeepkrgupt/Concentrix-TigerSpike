import React from "react"
import { Drawer } from '@material-ui/core'
import closeIcon from '../../assets/icons/close-icon.svg';
import { TextField, Button } from '../../components/@subzero/glacier/package/lib/components';
import CustomDragNDrop from "../../components/customdragndrop";


const CustomiseTableColumns = (props) => {

    const titleList =
        [
            { value: 'refNo', checked: true, label: 'Chanel Ref.No.' },
            { value: 'paymentRefNo', checked: true, label: 'Payment Ref.No.' },
            { value: 'beneficiaryName', checked: true, label: 'Beneficiary Name' },
            { value: 'currency', checked: true, label: 'Currency' },
            { value: 'payment amount', checked: true, label: 'Payment Amount' },
            { value: 'paymentDate', checked: false, label: 'Payment Date' },
            { value: 'status', checked: false, label: 'Payment Status' },
            { value: 'boe', checked: false, label: 'BOE No.' },
            { value: 'amount', checked: false, label: 'Amount' },
            { value: 'documents', checked: false, label: 'Documents' },
        ];

    // const listValue = { title: "", items: titleList }

    return (
        <Drawer anchor="right" open={props.showDrawer} className="transaction-title-container" >
            <div className="transaction-title-component">
                <div className="title-component-header">
                    <h3> Customise Transaction Inquiry Table Columns</h3>
                    <span className="drawer-close-icon" onClick={() => { props.toggleDrawer() }}><img src={closeIcon} /></span>
                </div>

                <div className="transaction-search" id="search-icon" >
                    <TextField label="Find Field Name" />

                </div>
                {/* <CheckboxList list={listValue} /> */}
                <CustomDragNDrop list={titleList} />
            </div>
            <div className="selected">
                <span>
                    3 of 9 entries selected
                </span>
                <div className="filter-buttons">

                    <span className="reset-link">Reset</span>
                    <Button>Apply</Button>
                </div>

            </div>
        </Drawer >
    )
}

export default CustomiseTableColumns;