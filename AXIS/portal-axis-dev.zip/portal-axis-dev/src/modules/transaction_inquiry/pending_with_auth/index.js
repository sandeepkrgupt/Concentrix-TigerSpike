/*eslint-disable */
import React, { useState, useEffect } from "react";
import AgGridTable from "../../../components/aggridtable";
import FilterComponent from "../filter";
import { useDispatch, useSelector } from "react-redux";
import { useHistory } from "react-router-dom";
import { Actions } from "../../../store/rootActions";
import "../index.css";
import BoeDetails from "../../boe/details";
import BoeNo from "../../boe/no_of_boes";
import moment from "moment";
import AlertPopup from "../../../components/alertPopup/alertPopup";

const PendingWithAuth = (props) => {
  const history = useHistory();
  const [rowList, updateRowList] = useState([]);
  const [showFilter, updateFilterDisplay] = React.useState(false);
  const [filterList, setFilterList] = useState([]);
  const [deleteFilterChip, setDeleteFilterChip] = useState({});
  const [clearAll, setClearAll] = useState(false);
  const [startRange, setStartRange] = useState("");
  const [endRange, setEndRange] = useState("");
  const [selectedRows, updateSelectedRows] = React.useState([]);
  const [searchText, setSearchText] = useState("");
  const state = useSelector((state) => state?.transaction);
  const authData = useSelector((state) => state?.auth?.loginData);
  const [transactions, setTransactions] = useState(
    useSelector((state) => state?.transaction?.transactions)
  );
  const [paymentReviewDetails, setPaymentReviewDetails] = useState(
    state?.paymentDetails
  );
  const [alertStatus, setAlertStatus] = useState(false);
  const [alertMsg, setAlertMessage] = useState("");
  const [totalPage, setTotalPage] = useState(
    useSelector((state) => state?.transaction?.totalPage)
  );
  const [filterAPIOptions, setFilterAPIOptions] = useState({});
  const [sortInfo, setSortInfo] = useState({});
  const [paginationInfo, setPaginationInfo] = useState({
    recordsPerPage: 5,
    reqPageIndex: 1,
  });
  const [showBoeDetails, setShowBoeDetails] = useState(false);
  const [boeDetailsParams, setBoeDetailsParams] = useState(null);

  const [showBoeNo, setShowBoeNo] = useState(false);
  const [boeNoParams, setBoeNoParams] = useState(null);
  const dispatch = useDispatch();
  const [actionItemMenu, setActionItemMenu] = useState([]);
  // Load data initially
  useEffect(() => {
    getTransactions();
    getFilterOptions();
    dispatch(Actions.clearWithdrawMsg());
  }, []);

  // Load data when transaction dropdown value changes
  useEffect(() => {
    getTransactions();
  }, [filterAPIOptions]);

  useEffect(() => {
    getTransactions();
    getFilterOptions();
  }, [props?.transaction]);

  useEffect(() => {
    const message = state?.withdrawTransactionMessage;
    if (message) {
      if (message === "Success") {
        setAlertMessage("Selected transaction withdrawn successfully");
        getTransactions();
        getFilterOptions();
      } else {
        setAlertMessage("Selected transaction withdrawn failed");
      }
      setAlertStatus(true);
    }
  }, [state?.withdrawTransactionMessage]);

  //Update transactions when change in reducer
  useEffect(() => {
    setTransactions(state?.transactions);
    setTotalPage(state?.totalPage);
  }, [state]);

  //Update table data when response data changes
  useEffect(() => {
    generateTableRowValues();
  }, [transactions]);

  useEffect(() => {
    getTransactions();
  }, [searchText, sortInfo, paginationInfo]);

  useEffect(() => {
    if (startRange && endRange) {
      getTransactions();
    }
  }, [startRange, endRange]);

  const getFilterOptions = () => {
    const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY";
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      toggleType: toggleType,
    };
    dispatch(Actions.getTransactionFilters(req, props?.action));
  };

  //Get data from API
  const getTransactions = () => {
    const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY";
    let filterOptions = filterAPIOptions;
    filterOptions["searchText"] = searchText;
    if (startRange && endRange) {
      filterOptions["startDate"] = moment(startRange).format("YYYY-MM-DD");
      filterOptions["endDate"] = moment(endRange).format("YYYY-MM-DD");
    }
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      toggleType: toggleType,
      searchCriteriaInfo: filterOptions,
      sortInfo: sortInfo,
      paginationInfo: paginationInfo,
    };
    dispatch(Actions.getTransactionInquiry(req, props?.action));
  };

  function createData(
    id,
    statusCode,
    channelRefNo,
    paymentRefNo,
    beneficiaryName,
    currency,
    amount,
    paymentDate,
    boeList,
    awbNo,
    rateInstruction,
    initiatedBy,
    requestForwardTo,
    isBookRate
  ) {
    return {
      id,
      statusCode,
      channelRefNo,
      paymentRefNo,
      beneficiaryName,
      currency,
      amount,
      paymentDate,
      boeList,
      awbNo,
      rateInstruction,
      initiatedBy,
      requestForwardTo,
      isBookRate,
    };
  }

  const getRows = () => {
    if (transactions?.length > 0) {
      return transactions?.map((resp) => {
        const {
          id,
          statusCode,
          channelRefNo,
          paymentRefNo,
          beneficiaryName,
          currency,
          amount,
          paymentDate,
          boeNumbers,
          awbNo,
          rateInstruction,
          initiatedBy,
          requestForwardTo,
          isBookRate,
        } = resp;
        const updatedBoeList = [...boeNumbers]?.map((item) => {
          item.link = `boe-details`;
          return item;
        });
        // const updatedChannelRefNo = { ...channelRefNo, link: "channelRefNo" };
        return createData(
          id,
          statusCode,
          channelRefNo,
          paymentRefNo,
          beneficiaryName,
          currency,
          amount,
          paymentDate,
          updatedBoeList,
          awbNo,
          rateInstruction,
          initiatedBy,
          requestForwardTo,
          isBookRate
        );
      });
    } else {
      return [];
    }
  };
  const searchCriteria = (filterApiOpts) => {
    Object.keys(filterApiOpts).forEach((key) => {
      if (Array.isArray(filterApiOpts[key])) {
        if (filterApiOpts[key]?.length > 0) {
          let arr = [];
          filterApiOpts[key]?.map((filt) => {
            arr.push(filt.id);
          });
          filterApiOpts[key] = arr;
        }
      }
    });
    setFilterAPIOptions(filterApiOpts);
  };

  const headCells = [
    { field: "channelRefNo", label: "Channel Ref. No." },
    { field: "paymentRefNo", label: "Payment Ref. No." },
    { field: "beneficiaryName", label: "Beneficiary Name", showTooltip: true },
    { field: "currency", label: "Currency", smallCell: true, sortable: true },
    { field: "amount", label: "Amount", sortable: true, rightAligned: true },
    { field: "paymentDate", label: "Payment Date", sortable: true },
    { field: "boeList", label: "BOE No." },
    { field: "awbNo", label: "AWB/BL No." },
    { field: "rateInstruction", label: "Is Rate Instruction required?" },
    {
      field: "initiatedBy",
      label: "Initiated By",
      hideCell:
        props?.user === "maker"
          ? props?.transaction === "My Transactions"
          : true,
    },
    { field: "doc", label: "" },
    { field: "action", label: "" },
  ];

  const generateTableRowValues = () => {
    const rows = getRows();
    let newArray = [...rows];
    let resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        let value = rowItem[key];
        switch (key) {
          case "channelRefNo":
            return (newObject[key] = {
              value: value?.label,
              isLink: true,
              link: `channelRefNo`,
              params: {
                recKey: rowItem?.id,
                statusCode: rowItem?.statusCode,
                channelRefNo: rowItem?.channelRefNo,
              },
            });
          // return (newObject[key] = {
          //   value: value?.label ? value?.label : "NA",
          //   isLink: value?.label ? true : false,
          //   label: value?.label,

          //   value: value,
          //   isLink: true,
          //   link: "/channelRefNo",
          // });
          case "paymentRefNo":
            return (newObject[key] = {
              value: value?.label ? value?.label : "NA",
              isLink: false,
            });
          case "boeCount":
            return (newObject[key] = {
              value: value,
              isLink: true,
              link: "/no-of-boes",
              params: { id: rowItem?.id },
            });
          case "boeList":
            return (newObject[key] = {
              value: value,
              multiValues: true,
              params: { item: rowItem },
            });
          case "currency":
            return (newObject[key] = { value: value, smallCell: true });
          case "rateInstruction":
            return (newObject[key] = { value: value ? "Yes" : "False" });
          default:
            return (newObject[key] = { value: value });
        }
      });
      resultArray.push(newObject);
    });
    if (paginationInfo?.reqPageIndex == 1) {
      updateRowList(resultArray);
      props?.rows(resultArray);
    } else {
      // updateRowList(rowList.concat(resultArray));
      // props?.rows(rowList.concat(resultArray));
      if (paginationInfo?.reqPageIndex !== 1) {
        // for pagination functionality binding previous data
        const arrayIndex =
          parseInt(
            paginationInfo?.reqPageIndex * paginationInfo?.recordsPerPage
          ) - parseInt(paginationInfo?.recordsPerPage);
        const mergedArray = [...rowList];
        mergedArray.length = totalPage;
        mergedArray.splice(arrayIndex, 25, ...resultArray);
        updateRowList(mergedArray);
        props?.rows(mergedArray);
      } else {
        updateRowList(resultArray);
        props?.rows(resultArray);
      }
    }
  };

  const handleRowSelection = (selctedRow) => {
    // props?.fxRateAmount > 0 &&
    //   props?.paymentMode !== "EEFC Account" &&
    //   props?.statusCode?.slice(0, 7) === "PRE_ACC" &&
    //   props?.statusCode?.slice(7) === authData?.checkerCount?.toString() &&
    //   "";
    if (paymentReviewDetails) {
      // ================== updateFxRateAmount should be called only once

      if (count1 === 0) {
        count1++;
        // if paymentMode !== "EEFC Account" cacluate fxRateAmount
        if (paymentReviewDetails?.paymentMode !== "EEFC Account") {
          // fxRateAmount = osremittance_amount(outstanding_amount) - sum of utilized amount in the deals level
          let fxRateAmountCalculated;
          // fxRateAmountCalculated =
          //   paymentReviewDetails?.fxrateInstructionDetails[0]
          //     ?.outstandingAmount; // to do - this needs to updated , dont depend on fxrateInstructionDetails param

          fxRateAmountCalculated = paymentReviewDetails?.operativeAmount; // to do - need to confirm
          paymentReviewDetails?.prebookInstructionDetails?.map((item) => {
            fxRateAmountCalculated =
              fxRateAmountCalculated - item?.amountToBeUtilized;
          });
          paymentReviewDetails?.fwcInstructionDetails?.map((item) => {
            fxRateAmountCalculated =
              fxRateAmountCalculated - item?.amountToBeUtilized;
          });
          dispatch(Actions.updateFxRateAmount(fxRateAmountCalculated));
        }
      }
    }

    console.log(selctedRow);
    const newArrayList = [];
    selctedRow &&
      selctedRow.length > 0 &&
      selctedRow.map((item) => {
        rowList.map((rowItem) => {
          if (item?.id?.value == rowItem?.id?.value) {
            newArrayList.push(rowItem);
          }
        });
      });
    updateSelectedRows(newArrayList);
  };

  const download = () => {
    //API Call
    const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY";
    const action = props?.action;
    const actionRequests = [];
    selectedRows?.map((selRow) => {
      actionRequests.push({
        id: selRow?.id?.value,
      });
    });
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      toggleType: toggleType,
      actionRequests: actionRequests,
    };
    dispatch(Actions.exportRecord(req, action));
  };

  const getSorted = (sortBy, desc) => {
    const receivedSortInfo = {
      sortBy: sortBy,
      sortType: desc ? "DESC" : "ASC",
    };
    if (JSON.stringify(receivedSortInfo) !== JSON.stringify(sortInfo)) {
      setSortInfo({
        sortBy: sortBy,
        sortType: desc ? "DESC" : "ASC",
      });
    }
  };

  const callPaginationApi = (pageNo, recordsPerPage) => {
    const paginationInfo = {
      recordsPerPage: recordsPerPage,
      reqPageIndex: pageNo,
    };
    setPaginationInfo(paginationInfo);
  };

  const showOtherScreen = (link, params) => {
    if (link === "channelRefNo") {
      history.push("/make-payment", {
        activeStep: 4,
        recKey: params?.recKey,
        statusCode: params?.statusCode,
        fromChannelRefNo: true,
        channelRefNo: params?.channelRefNo,
      });
    }
    if (link === "boe-details") {
      setShowBoeDetails(true);
      setBoeDetailsParams(params);
    }
    if (link === "/no-of-boes") {
      setShowBoeNo(true);
      setBoeNoParams(params);
    }
  };

  return (
    <div className="boe-table">
      {showBoeDetails && (
        <BoeDetails
          onClose={() => setShowBoeDetails(false)}
          params={boeDetailsParams}
        />
      )}
      {showBoeNo && (
        <BoeNo onClose={() => setShowBoeNo(false)} params={boeNoParams} />
      )}
      <AgGridTable
        onFilter={() => {
          updateFilterDisplay(!showFilter);
        }}
        selectedList={selectedRows}
        handleRowSelection={handleRowSelection}
        startRange={startRange}
        endRange={endRange}
        setStartRange={(startRange) => {
          setStartRange(startRange);
        }}
        setEndRange={(endRange) => {
          setEndRange(endRange);
        }}
        onSearch={(search) => {
          setSearchText(search.target.value);
          callPaginationApi(1, paginationInfo?.recordsPerPage);
        }}
        headCells={headCells}
        rows={rowList}
        moreActionMenu={props?.user === "checker" ? [] : actionItemMenu}
        getItem={(item) => {
          const paymentDate = item?.paymentDate?.value;
          if (paymentDate) {
            let convertedDate = paymentDate?.split("/");
            convertedDate = convertedDate
              ? `${convertedDate[1]}/${convertedDate[0]}/${convertedDate[2]}`
              : paymentDate;
            if (new Date(convertedDate) > new Date(authData?.appDate)) {
              setActionItemMenu([{ label: "Withdraw", link: "" }]);
            }
          } else {
            setActionItemMenu([]);
          }
        }}
        docActionMenu={[
          {
            label: "Attached documents",
            link: "",
          },
          {
            label: "Channel generated documents",
            link: "",
          },
          {
            label: "Customer Request Letter",
            link: "",
          },
        ]}
        filterOptions={filterList}
        deleteFilterChip={(filterChip) => setDeleteFilterChip(filterChip)}
        clearAll={() => {
          setClearAll(true);
        }}
        getSelectedRows={(selRows) => {
          props?.selRows(selRows);
        }}
        ti={props?.user === "maker" ? true : false}
        onDownload={() => download()}
        onSort={(sortBy, desc) => {
          getSorted(sortBy, desc);
        }}
        callPaginationApi={callPaginationApi}
        totalPage={totalPage}
        showOtherScreen={showOtherScreen}
      />
      <FilterComponent
        showDrawer={showFilter}
        toggleDrawer={() => {
          updateFilterDisplay(!showFilter);
          setClearAll(false);
        }}
        getFilterList={(list) => {
          callPaginationApi(1, paginationInfo?.recordsPerPage);
          setFilterList(list);
        }}
        deleteFilterChip={deleteFilterChip}
        clearAll={clearAll}
        apiFilterOpts={(filterApiOpts) => {
          searchCriteria(filterApiOpts);
        }}
      />

      {alertStatus && (
        <AlertPopup
          alertMsg={alertMsg}
          alertType={"warn"}
          isAlertOpen={true}
          onClose={() => {
            setAlertStatus(false);
          }}
        />
      )}
    </div>
  );
};
export default PendingWithAuth;
