/* eslint-disable */
import React, { useEffect, useState } from "react";
import { Divider, Drawer, makeStyles, TextField } from "@material-ui/core";
import AddIcon from "../../../assets/icons/add-icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";

import {
  Button,
  Checkbox,
  Datepicker,
} from "../../../components/@subzero/glacier/package/lib/components";
import BuildingIcon from "../../../assets/icons/building.svg";
import InfoIcon from "../../../assets/icons/info-icon.svg";
import Grid from "@material-ui/core/Grid";

import styles from "../../make_payment/review/review.module.css";
import "../../make_payment/review/index.css";
import BookRateView from "../../make_payment/payment_details/BookRateView";
import PreBookedDealsView from "../../make_payment/payment_details/PrebookedDealsView";
import ForwardContractView from "../../make_payment/payment_details/ForwardContractView";
import CloseIcon from "../../../assets/icons/close.svg";
import { useHistory } from "react-router-dom";
import AlertPopup from "../../../components/alertPopup/alertPopup";

const useStyles = makeStyles({
  root: {
    background: "#F9F9F9",
    borderRadius: "8px",
    marginTop: "16px",
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
    padding: "50px 140px",
  },
  dropdown: {
    "& .Dropdown_show__21pcz": {
      position: "absolute",
      zIndex: "999",
    },
  },
});

const RescheduleTrans = (props) => {
  const classes = useStyles();
  const history = useHistory();
  const [showRemarkForm, updateFormDisplay] = React.useState([
    false,
    false,
    false,
    false,
    false,
  ]);
  const [showRemarkButton, updateButtonDisplay] = React.useState([
    true,
    true,
    true,
    true,
    true,
  ]);
  const dispatch = useDispatch();
  const state = useSelector((state) => state?.paymentReviewData);
  const authData = useSelector((state) => state?.auth?.loginData);
  const [paymentReviewDetails, setPaymentReviewDetails] = useState(
    state?.paymentDetails
  );
  const [dateValue, setDateValue] = useState("");
  const transState = useSelector((state) => state?.transaction);
  const [alert, setAlert] = useState({
    alertMsg: "",
    alertType: "warn",
    isAlertOpen: false,
  });

  useEffect(() => {
    if (props?.req?.id?.value) {
      const req = {
        corpId: authData?.corpId,
        userId: authData?.userId,
        bankCode: authData?.bankCode,
        recKey: props?.req?.id?.value,
      };
      //CALL PAYMENT REVIEW API
      dispatch(Actions.getpaymentReviewData(req));
    }
  }, [props?.req]);

  useEffect(() => {
    const { paymentDetails } = state;
    setPaymentReviewDetails(paymentDetails);
  }, [state]);

  const updateRemarksDisplay = (id, value) => {
    const newArrForm = [...showRemarkForm];
    const newArrButton = [...showRemarkForm];
    newArrForm[id] = value;
    newArrButton[id] = false;
    updateButtonDisplay(newArrButton);
    updateFormDisplay(newArrForm);
  };

  const onProceedHandler = () => {
    if (transState?.isDateValidated === "Success") {
      props?.onClose();
      history.push("/auth-matrix", {
        from: "/transaction-inquiry",
        action: props?.prevPage,
        recKey: props?.req?.id?.value,
      });
    } else {
      setAlert({
        alertMsg: "Please select a valid payment date",
        alertType: "warn",
        isAlertOpen: true,
      });
    }
  };

  const paymentDateCheck = (e) => {
    dispatch(Actions.clearRescheduleDateStatus());
    if (props?.req?.id?.value) {
      const req = {
        recKey: props?.req?.id?.value,
        paymentDate: e,
      };
      dispatch(Actions.reschedulePaymentDate(req));
    }
  };

  useEffect(() => {
    if (transState?.isDateValidated === "Success") {
      setAlert({
        alertMsg: "Payment date successfully updated",
        alertType: "success",
        isAlertOpen: true,
      });
    } else if (transState?.isDateValidated !== "") {
      setAlert({
        alertMsg: transState?.isDateValidated,
        alertType: "warn",
        isAlertOpen: true,
      });
    }
  }, [transState?.isDateValidated]);

  const onChangeValue = (e) => {
    setDateValue(e);
  };

  return (
    <>
      <Drawer
        classes={{
          paper: classes.paper,
        }}
        anchor={"bottom"}
        open={props?.open}
        onClose={props?.onClose}
      >
        <div
          onClick={props?.onClose}
          className="close"
          style={{ marginTop: "-35px" }}
        >
          <img src={CloseIcon} className="close-icon" />
        </div>
        <div className="review-container">
          <div className="row-sub-container">
            <span className="review-text">{`Reschedule Payment- ${
              props?.req?.channelRefNo?.value || ""
            }`}</span>
          </div>
          <div className="review-border-container">
            <div className="info-container" style={{ marginLeft: "0px" }}>
              <img src={InfoIcon} />
              <span className="warning-text">
                Please remember to choose a template with similar headers before
                uploading a file.
              </span>
            </div>
            <div
              className="review-column"
              style={{ marginTop: "20px", marginBottom: "0px" }}
            >
              <Datepicker
                label="New Payment Date"
                name="New Payment Date"
                type="default"
                variant="filled"
                defaultValue={
                  dateValue
                    ? {
                        day: new Date(dateValue).getDate(),
                        month: new Date(dateValue).getMonth() + 1,
                        year: new Date(dateValue).getFullYear(),
                      }
                    : {
                        day: "",
                        month: "",
                        year: "",
                      }
                }
                value={dateValue}
                onChange={(e) => {
                  //Payment date check API
                  const dt = new Date(e).toLocaleDateString();
                  onChangeValue(dt);
                  e = `${e.getDate()}-${e.getMonth() + 1}-${e.getFullYear()}`;
                  paymentDateCheck(e);
                }}
                // error={fieldsToBeValidated?.paymentDate?.validationFailed}
                error={false}
                errormessage={"Mandatory Field"}
              />
            </div>
          </div>

          <div className="review-border-container">
            <div className="row-sub-container">
              <span className="trans-details-text">Payment Details</span>
            </div>
            <Divider className="review-divider" />

            <div className="review-column-mid-width">
              <span className="review-column-heading">Amount Details</span>
              <Grid container spacing={3}>
                <Grid
                  className="review-grid-container"
                  item
                  lg={12}
                  md={12}
                  sm={12}
                  xs={12}
                >
                  <span className="grid-content-header">
                    Total Remitance Amount
                  </span>
                  <span className="grid-content-text">
                    {`${paymentReviewDetails?.currency || ""} ${
                      paymentReviewDetails?.amount || 0
                    }`}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={3}
                  md={4}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">
                    Tenor Period (in days)
                  </span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.tenorPeriod}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={3}
                  md={4}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Tenor Indicator</span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.tenorIndicator}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={6}
                  md={4}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Due Date </span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.dueDate}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={3}
                  md={4}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Payment Date</span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.paymentDate}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={9}
                  md={8}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">
                    Branch Name (Optional){" "}
                  </span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.branchName}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={12}
                  md={12}
                  sm={4}
                  xs={6}
                >
                  <span className="grid-content-header">Payment Mode</span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.paymentMode}
                  </span>
                </Grid>
              </Grid>
            </div>

            <div className="mt-4 mx-5 mb-20 eefc-container">
              {paymentReviewDetails?.eefcAccount?.length > 0 && (
                <>
                  <span className="d-flex mtb-16 payment-mode-subheader">
                    <img src={BuildingIcon} />
                    EEFC Account (Amount Payable:{" "}
                    {paymentReviewDetails?.currency +
                      " " +
                      `${
                        paymentReviewDetails?.eefcAmount
                          ? paymentReviewDetails?.eefcAmount
                          : 0
                      }`}
                    )
                  </span>
                  <Grid spacing={3} container>
                    {paymentReviewDetails?.eefcAccount?.map((item) => (
                      <>
                        <Grid
                          className="review-grid-container"
                          item
                          lg={3}
                          md={6}
                          sm={6}
                          xs={6}
                        >
                          <span className="grid-content-header">
                            Account Number
                          </span>
                          <span className="grid-content-text">
                            {item?.accountNumber}
                          </span>
                        </Grid>
                        <Grid
                          className="review-grid-container"
                          item
                          lg={9}
                          md={6}
                          sm={6}
                          xs={6}
                        >
                          <span className="grid-content-header">Amount</span>
                          <span className="grid-content-text">
                            {paymentReviewDetails?.currency +
                              " " +
                              item?.amount}
                          </span>
                        </Grid>
                      </>
                    ))}
                  </Grid>
                </>
              )}
              {paymentReviewDetails?.currentAccountNumber && (
                <>
                  <span className="d-flex mt-4 mb-3">
                    <img src={BuildingIcon} />
                    Operative Account
                  </span>
                  <Grid spacing={3} container>
                    <Grid
                      className="review-grid-container"
                      item
                      lg={3}
                      md={6}
                      sm={6}
                      xs={6}
                    >
                      <span className="grid-content-header">
                        Account Number
                      </span>
                      <span className="grid-content-text">
                        {paymentReviewDetails?.currentAccountNumber}
                      </span>
                    </Grid>
                    <Grid
                      className="review-grid-container"
                      item
                      lg={9}
                      md={6}
                      sm={6}
                      xs={6}
                    >
                      <span className="grid-content-header">Amount</span>
                      <span className="grid-content-text">
                        {paymentReviewDetails?.currency +
                          " " +
                          `${
                            paymentReviewDetails?.operativeAmount
                              ? paymentReviewDetails?.operativeAmount
                              : 0
                          }`}
                      </span>
                    </Grid>

                    <Grid
                      className="review-grid-container"
                      item
                      lg={12}
                      md={12}
                      sm={12}
                      xs={12}
                    >
                      {paymentReviewDetails?.opeartiveAccountRemarks && (
                        <>
                          <span className="grid-content-header">
                            Remarks (Reason of low / insufficient fund)
                          </span>
                          <span className="grid-content-text">
                            {paymentReviewDetails?.opeartiveAccountRemarks}
                          </span>
                        </>
                      )}
                      <div className="checkbox-use-as-charges-account d-flex-row">
                        <Checkbox checked={true} disabled={true} />
                        <span className="third-party-text">
                          Use as Charges Account
                        </span>
                      </div>
                    </Grid>
                  </Grid>
                </>
              )}
            </div>
            <div className="review-column-mid-width">
              <span className="review-column-heading">Charges</span>
              <Grid container spacing={3}>
                <Grid
                  className="review-grid-container"
                  item
                  lg={3}
                  md={4}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">
                    Charges Account Number
                  </span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.chargesAccount}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={3}
                  md={4}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">
                    Foreign Bank Charges{" "}
                  </span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.foreignBankCharges}
                  </span>
                  <span className="grid-content-footer">
                    To be paid by Beneficiary{" "}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={6}
                  md={4}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">
                    Selected GST Number (Optional)
                  </span>
                  <span className="grid-content-text">
                    {paymentReviewDetails?.gstNumber}
                  </span>
                </Grid>
              </Grid>
            </div>

            <Divider className="review-divider" />

            <div className="row-sub-container rate-instruction-main-container">
              <span className="trans-details-text">Rate Instruction</span>
              {authData?.userRoleType === "C" && (
                <div className="checkbox-use-as-charges-account d-flex-row">
                  <Checkbox
                    disabled={true}
                    checked={paymentReviewDetails?.delegateToChecker}
                  />
                  <span className="third-party-text">Delegate to Checker</span>
                </div>
              )}
            </div>
            <div className="rate-instruction-container">
              {paymentReviewDetails?.prebookInstructionDetails?.length > 0 && (
                <Grid>
                  <PreBookedDealsView
                    delegateChecker={paymentReviewDetails?.delegateToChecker}
                    instructionDetails={
                      paymentReviewDetails?.prebookInstructionDetails
                    }
                  />
                </Grid>
              )}
              {paymentReviewDetails?.fwcInstructionDetails?.length > 0 && (
                <Grid>
                  <ForwardContractView
                    delegateChecker={paymentReviewDetails?.delegateToChecker}
                    instructionDetails={
                      paymentReviewDetails?.fwcInstructionDetails
                    }
                  />
                </Grid>
              )}
              {paymentReviewDetails?.fxrateInstructionDetails && (
                <Grid>
                  <BookRateView
                    delegateChecker={paymentReviewDetails?.delegateToChecker}
                    instructionDetails={
                      paymentReviewDetails?.fxrateInstructionDetails
                    }
                    userType={authData?.userRoleType}
                  />
                </Grid>
              )}
            </div>
            {paymentReviewDetails?.delayReasons?.length > 0 && (
              <>
                <div className="row-sub-container">
                  <span className="trans-details-text">
                    Bill Of Entry- Delay Reasons
                  </span>
                </div>
                <div className="ml-10">
                  <Grid
                    container
                    spacing={3}
                    className={styles.reviewGreyContainer}
                  >
                    {paymentReviewDetails?.delayReasons?.map((delayReason) => (
                      <>
                        <Grid
                          className="review-grid-container"
                          item
                          lg={4}
                          md={6}
                          sm={12}
                          xs={12}
                        >
                          <span className="grid-content-header">
                            Bill Of Entry Number
                          </span>
                          <span className="grid-content-text">
                            {delayReason?.boeNumber}
                          </span>
                        </Grid>
                        <Grid
                          className="review-grid-container"
                          item
                          lg={4}
                          md={6}
                          sm={12}
                          xs={12}
                        >
                          <span className="grid-content-header">
                            Delay Reason
                          </span>
                          <span className="grid-content-text">
                            {delayReason?.delayReason}
                          </span>
                        </Grid>
                        <Grid
                          className="review-grid-container"
                          item
                          lg={6}
                          md={12}
                          sm={12}
                          xs={12}
                        >
                          <span className="grid-content-header">
                            Specify Delay Reason
                          </span>
                          <span className="grid-content-text">
                            {delayReason?.specifyDelayReason}
                          </span>
                        </Grid>
                        <Divider className="review-divider" />
                      </>
                    ))}
                  </Grid>
                </div>
              </>
            )}

            {paymentReviewDetails?.otherDetails && (
              <div className="mt-5">
                <div className="row-sub-container">
                  <span className="trans-details-text">Other Details</span>
                </div>
                <div className="ml-10">
                  <Grid
                    container
                    spacing={3}
                    className={styles.reviewGreyContainer}
                  >
                    <Grid
                      className="review-grid-container"
                      item
                      lg={12}
                      md={12}
                      sm={12}
                      xs={12}
                    >
                      <span className="grid-content-header">
                        Sender to Receiver Instruction (Optional)
                      </span>
                      <span className="grid-content-text">
                        {paymentReviewDetails?.otherDetails}
                      </span>
                    </Grid>
                  </Grid>
                </div>
              </div>
            )}

            {/* Checker Review (Using faster processing (Paper-based) as master) start */}
            {showRemarkForm[2] && (
              <Grid container>
                <Grid item lg={12} md={12} className="remark-box">
                  <TextField
                    fullWidth
                    label="Remarks"
                    value="Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam"
                    type="text"
                    variant="filled"
                  />
                </Grid>{" "}
              </Grid>
            )}
            {authData?.userRoleType === "C" && showRemarkButton[2] && (
              <span
                className="add-new"
                onClick={() => {
                  updateRemarksDisplay(2, true);
                }}
              >
                <img src={AddIcon} />
                Add Remarks
              </span>
            )}
            {/* Checker Review (Using faster processing (Paper-based) as master) end */}
          </div>

          <div className="review-container"></div>
        </div>
        <div className="close-container" style={{ marginBottom: "0px" }}>
          <Button color="secondary" onClick={props?.onClose}>
            Close
          </Button>
          <Button onClick={onProceedHandler}>Proceed</Button>
        </div>
        <AlertPopup
          {...alert}
          onClose={() => {
            setAlert({ ...alert, isAlertOpen: false });
          }}
        />
      </Drawer>
    </>
  );
};

export default RescheduleTrans;
