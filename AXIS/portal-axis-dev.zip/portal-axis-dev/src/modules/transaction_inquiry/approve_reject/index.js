/* eslint-disable */
import React, { useState } from "react";
import AgGridTable from "../../../components/aggridtable";
import "../index.css";
import { Button } from "../../../components/@subzero/glacier/package/lib/components";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import DialogTitle from "@material-ui/core/DialogTitle";
import Slide from "@material-ui/core/Slide";
import { TextField } from "@material-ui/core";
import { useHistory } from "react-router-dom";

const headCells = [
  { field: "channelRefNo", label: "Channel Ref. No." },
  { field: "paymentRefNo", label: "Payment Ref. No." },
  { field: "beneficiaryName", label: "Beneficiary", showTooltip: true },
  { field: "currency", label: "Currency", smallCell: true },
  { field: "amount", label: "Amount", rightAligned: true },
  { field: "paymentDate", label: "Payment Date" },
];

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const ApproveReject = (props) => {
  const history = useHistory();
  const [selRows, setSelRows] = useState(props?.data);
  const [showPopup, setShowPopup] = useState(false);
  const [showApprovePopup, setShowApprovePopup] = useState(false);
  const onClickButton = () => {
    if (props?.approve) {
      // Do API Call or navigate
      console.log("approve");
      setShowApprovePopup(true);
    } else {
      setShowPopup(true);
    }
  };

  const RejectPopup = (props) => {
    const [reasonForRejection, setReasonForRejection] = useState("");
    const onReasonForRejectionChange = (e) => {
      setReasonForRejection(e?.target?.value);
    };
    const rejectFromReasonForRejection = () => {
      const recKeyList = selRows.map((item) => item?.id?.value);
      const channelRefNoList = selRows.map((item) => item?.channelRefNo?.value);

      history.push("/workflow-details", {
        recKeyList,
        channelRefNoList,
      });
    };

    return (
      <Dialog
        open={showPopup}
        TransitionComponent={Transition}
        keepMounted
        onClose={() => setShowPopup(false)}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">
          Reject Transactions
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            Reason for Rejection
          </DialogContentText>
          {/* <TextField
            inputMode="none"
            label=""
            name="Reason for rejection"
            type="text"
            variant="filled"
            value={reasonForRejection}
            onChange={(e) => onReasonForRejectionChange(e)}
          /> */}
          <textarea
            type="text"
            className="reject-input"
            rows="5"
            value={reasonForRejection}
            onChange={(e) => onReasonForRejectionChange(e)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowPopup(false)} color="secondary">
            Cancel
          </Button>
          <Button
            onClick={() => {
              rejectFromReasonForRejection();
              setShowPopup(false);
            }}
            color="primary"
          >
            Reject
          </Button>
        </DialogActions>
      </Dialog>
    );
  };

  const AcceptPopup = (props) => {
    const [reasonForApproval, setReasonForApproval] = useState("");
    const onReasonForApprovalChange = (e) => {
      setReasonForApproval(e?.target?.value);
    };

    const approveFromReasonForApproval = () => {
      // const recKeyList = selRows.map((item) => item?.id?.value);
      const channelRefNoList = selRows.map((item) => item?.channelRefNo?.value);

      // redirecting to success page after succesfull authorization/rejection
      history.push({
        pathname: "/authorize-success",
        state: {
          channelRefNoList: channelRefNoList,
          status: "",
        },
      });
    };

    return (
      <Dialog
        open={showApprovePopup}
        TransitionComponent={Transition}
        keepMounted
        onClose={() => setShowApprovePopup(false)}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">
          Approve Transactions
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            Reason for Approval
          </DialogContentText>
          {/* <TextField
            inputMode="none"
            label=""
            name="Reason for rejection"
            type="text"
            variant="filled"
            value={reasonForRejection}
            onChange={(e) => onReasonForRejectionChange(e)}
          /> */}
          <textarea
            type="text"
            className="reject-input"
            rows="5"
            value={reasonForApproval}
            onChange={(e) => onReasonForApprovalChange(e)}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowApprovePopup(false)} color="secondary">
            Cancel
          </Button>
          <Button
            onClick={() => {
              approveFromReasonForApproval();
              setShowApprovePopup(false);
            }}
            color="primary"
          >
            Submit
          </Button>
        </DialogActions>
      </Dialog>
    );
  };

  return (
    <>
      <div className="payment-heading-container">
        <span className="modal-heading">{`Selected Transactions - ${props?.transaction}`}</span>
      </div>
      <AgGridTable
        tableOnly={true}
        headCells={headCells}
        rows={props?.data}
        selectedList={props?.data}
        getSelectedRows={(selRows) => {
          setSelRows(selRows);
        }}
      />
      <div className="selected-payment">
        <span>{`Transaction selected: ${selRows?.length}`}</span>
        <div className="payment-buttons">
          <Button
            color="secondary"
            className="cancel-button"
            onClick={() => props?.toggleModal(false)}
          >
            Cancel
          </Button>
          <Button disabled={selRows?.length <= 0} onClick={onClickButton}>
            {props?.approve ? "Approve" : "Reject"}
          </Button>
        </div>
      </div>
      {showPopup && <RejectPopup />}
      {showApprovePopup && <AcceptPopup />}
    </>
  );
};

export default ApproveReject;
