/*eslint-disable */
import React, { useState, useEffect } from 'react';
import AgGridTable from '../../../components/aggridtable';
import FilterComponent from '../filter';
import { useDispatch, useSelector } from "react-redux";
import { Actions } from '../../../store/rootActions';
import '../index.css';
import BoeDetails from '../../boe/details';
import BoeNo from '../../boe/no_of_boes';
import moment from 'moment';
import { useHistory } from 'react-router-dom';

const Drafts = (props) => {
    const history = useHistory();
    const [rowList, updateRowList] = useState([]);
    const [showFilter, updateFilterDisplay] = React.useState(false);
    const [filterList, setFilterList] = useState([]);
    const [deleteFilterChip, setDeleteFilterChip] = useState({});
    const [clearAll, setClearAll] = useState(false);
    const [startRange, setStartRange] = useState('')
    const [endRange, setEndRange] = useState('')
    const [selectedRows, updateSelectedRows] = React.useState([])
    const [searchText, setSearchText] = useState('');
    const state = useSelector((state)=> state?.transaction);
    const authData = useSelector((state)=> state?.auth?.loginData)
    const [transactions, setTransactions] = useState(useSelector((state)=> state?.transaction?.transactions));
    const [totalPage, setTotalPage] = useState(useSelector((state)=> state?.transaction?.totalPage));
    const [filterAPIOptions, setFilterAPIOptions] = useState({});
    const [sortInfo, setSortInfo] = useState({});
    const [paginationInfo, setPaginationInfo] = useState({
        "recordsPerPage": 5,
        "reqPageIndex": 1
    });
    const [showBoeDetails, setShowBoeDetails] = useState(false);
    const [boeDetailsParams, setBoeDetailsParams] = useState(null);

    const [showBoeNo, setShowBoeNo] = useState(false);
    const [boeNoParams, setBoeNoParams] = useState(null);
    const dispatch = useDispatch();

    // Load data initially
    useEffect(() => {
        getTransactions();
        getFilterOptions();
        dispatch(Actions.clearWithdrawMsg());
    }, []);

    // Load data when transaction dropdown value changes
    useEffect(() => {
        getTransactions();
    }, [filterAPIOptions]);
    
    useEffect(() => {
        getTransactions();
        getFilterOptions();
    }, [props?.transaction]);

    //Update transactions when change in reducer
    useEffect(()=>{
        setTransactions(state?.transactions);
        setTotalPage(state?.totalPage);
    },[state])
    
    //Update table data when response data changes
    useEffect(()=>{
        generateTableRowValues();
    },[transactions])

    useEffect(()=>{
        getTransactions();
    },[searchText, sortInfo, paginationInfo])

    useEffect(()=>{
        if(startRange && endRange ){
            getTransactions()
        }
    },[startRange, endRange])

    const getFilterOptions=()=>{
        const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY";
        const req = {
            "userId": authData?.userId,
            "corpId": authData?.corpId,
            "bankCode": authData?.bankCode,
            "toggleType": toggleType
        }
        dispatch(Actions.getTransactionFilters(req, props?.action))
    }

    //Get data from API
   const getTransactions=()=>{
       const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY"
       let filterOptions = filterAPIOptions;
       filterOptions['searchText'] = searchText;
       if(startRange && endRange){
           filterOptions['startDate'] = moment(startRange).format("YYYY-MM-DD");
           filterOptions['endDate'] = moment(endRange).format("YYYY-MM-DD");
       } 
       const req = {
            "userId": authData?.userId,
            "corpId": authData?.corpId,
            "bankCode": authData?.bankCode,
            "toggleType": toggleType,
            "searchCriteriaInfo": filterOptions,
            "sortInfo": sortInfo,
            "paginationInfo": paginationInfo
        }
        dispatch(Actions.getTransactionInquiry(req, props?.action))
    }
    
    function createData(id,statusCode, channelRefNo, paymentRefNo, beneficiaryName, currency, amount, paymentDate, boeList, awbNo, initiatedBy, requestForwardTo) {
        return { id,statusCode, channelRefNo, paymentRefNo, beneficiaryName, currency, amount, paymentDate, boeList, awbNo, initiatedBy,requestForwardTo };
    }

    const getRows =()=>{
        if(transactions?.length > 0){
            return transactions?.map((resp)=>{
                const {id,statusCode,channelRefNo, paymentRefNo, beneficiaryName, currency, amount, paymentDate, boeNumbers, awbNo, initiatedBy, requestForwardTo} = resp;
                const updatedBoeList = [...boeNumbers]?.map((item)=>{
                    item.link = `boe-details`;
                    return item;
                })
                return createData(id,statusCode,channelRefNo, paymentRefNo, beneficiaryName, currency, amount, paymentDate, updatedBoeList, awbNo, initiatedBy, requestForwardTo);
            })
        }
        else{
            return [];
        }
    } 

    const searchCriteria=(filterApiOpts)=>{
        Object.keys(filterApiOpts).forEach((key)=>{
            if(Array.isArray(filterApiOpts[key])){
                if(filterApiOpts[key]?.length > 0){
                    let arr = [];
                    filterApiOpts[key]?.map((filt)=>{
                        arr.push(filt.id);
                    })
                    filterApiOpts[key] = arr;
                }
            }
        })
        setFilterAPIOptions(filterApiOpts)
    }
    
    const headCells = [
        { field: 'channelRefNo', label: 'Channel Ref. No.' },
        { field: 'paymentRefNo', label: 'Payment Ref. No.' },
        { field: 'beneficiaryName', label: 'Beneficiary Name', showTooltip: true },
        { field: 'currency', label: 'Currency', smallCell: true, sortable: true },
        { field: 'amount', label: 'Amount', sortable: true, rightAligned: true },
        { field: 'paymentDate', label: 'Payment Date', sortable: true },
        { field: 'boeList', label: 'BOE No.' },
        { field: 'awbNo', label:'AWB/BL No.' },
        {field: 'initiatedBy', label: 'Initiated By', hideCell: props?.user === "maker" ? props?.transaction === "My Transactions" : false},
        { field: 'doc', label: '' },
        { field: 'action', label: '' },

    ];

    const generateTableRowValues = () => {
        const rows = getRows();
        let newArray = [...rows]
        let resultArray = [];
        newArray.map((rowItem) => {
            const newObject = {}
            Object.keys(rowItem)?.map(key => {
                let value = rowItem[key];
                switch (key) {
                    case "channelRefNo":
                        return newObject[key] = { value: value?.label ? value?.label: "NA", isLink: value?.label ? true : false, link: `channelRefNo`,
                        params: { recKey: rowItem?.id, statusCode: rowItem?.statusCode } };
                    case "paymentRefNo":
                        return newObject[key] = { value: value?.label ? value?.label: "NA", isLink: false, };
                    case "boeCount":
                        return newObject[key] = { value: value, isLink: true, link: '/no-of-boes', params: {id: rowItem?.id} };
                    case "boeList":
                        return newObject[key] = { value: value, multiValues: true, params: {item: rowItem}}
                    case 'currency':
                        return newObject[key] = { value: value, smallCell: true }
                    default:
                        return newObject[key] = { value: value }

                }
            })
            resultArray.push(newObject)
        })
        if(paginationInfo?.reqPageIndex == 1){
            updateRowList(resultArray);
            props?.rows(resultArray);
        }
        else{
            // updateRowList(rowList.concat(resultArray));
            // props?.rows(rowList.concat(resultArray));
            if (paginationInfo?.reqPageIndex !== 1) {
                // for pagination functionality binding previous data
                const arrayIndex =
                  parseInt(
                    paginationInfo?.reqPageIndex * paginationInfo?.recordsPerPage
                  ) - parseInt(paginationInfo?.recordsPerPage);
                const mergedArray = [...rowList];
                mergedArray.length = totalPage;
                mergedArray.splice(arrayIndex, 25, ...resultArray);
                updateRowList(mergedArray);
                props?.rows(mergedArray);
              } else {
                updateRowList(resultArray);
                props?.rows(resultArray);
              }
        }
    }
    const handleRowSelection = (selctedRow) => {
        const newArrayList = []
        selctedRow && selctedRow.length > 0 && selctedRow.map((item) => {

            rowList.map((rowItem) => {
                if (item?.id?.value == rowItem?.id?.value) {
                    newArrayList.push(rowItem)
                }
            })

        })
        updateSelectedRows(newArrayList)
    }
    const download = ()=>{
        //API Call
        const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY";
        const action = props?.action;
        const actionRequests = [];
        selectedRows?.map((selRow)=>{
            actionRequests.push({
                id: selRow?.id?.value
            })
        })
        const req = {
            "userId": authData?.userId,
            "corpId": authData?.corpId,
            "bankCode": authData?.bankCode,
            "toggleType": toggleType,
            "actionRequests": actionRequests
        }
        dispatch(Actions.exportRecord(req, action))
    }
    const getSorted=(sortBy, desc)=>{
        const receivedSortInfo = {
            "sortBy": sortBy,
            "sortType": desc ? "DESC" : "ASC"
        }
        if(JSON.stringify(receivedSortInfo) !== JSON.stringify(sortInfo)){
            setSortInfo({
                "sortBy": sortBy,
                "sortType": desc ? "DESC" : "ASC"
            })
        }
    }
    
    const callPaginationApi=(pageNo, recordsPerPage)=>{
        const paginationInfo = {
            "recordsPerPage": recordsPerPage,
            "reqPageIndex": pageNo
        }
        setPaginationInfo(paginationInfo);
    }

    const showOtherScreen=(link, params)=>{
        if(link === "boe-details"){
            setShowBoeDetails(true);
            setBoeDetailsParams(params);
        }
        if(link === "/no-of-boes"){
            setShowBoeNo(true);
            setBoeNoParams(params);
        }
        if (link === "channelRefNo") {
            history.push("/make-payment", {
              activeStep: 4,
              recKey: params?.recKey,
              statusCode: params?.statusCode,
              fromChannelRefNo: true
            });
          }
    }
    return (
            <div className="boe-table">
                {showBoeDetails && <BoeDetails onClose={()=> setShowBoeDetails(false)} params={boeDetailsParams}/>}
                {showBoeNo && <BoeNo onClose={()=> setShowBoeNo(false)} params={boeNoParams}/>}
                <AgGridTable 
                    onFilter={()=>{
                            updateFilterDisplay(!showFilter);
                    }}
                    selectedList={selectedRows}
                    handleRowSelection={handleRowSelection}
                    startRange={startRange}
                    endRange={endRange}
                    setStartRange={(startRange)=>{setStartRange(startRange)}}
                    setEndRange={(endRange)=>{setEndRange(endRange)}}
                    onSearch={(search)=> {
                        setSearchText(search.target.value);
                        callPaginationApi(1, paginationInfo?.recordsPerPage);
                    }}
                    headCells={headCells} 
                    rows={rowList}
                    moreActionMenu={
                        props?.user === "checker" ? [] : [
                            { label: "Edit", link: "" },
                            { label: "Delete", link: "" },
                        ]
                        
                    } 
                    docActionMenu={[
                        {
                            label: "Attached documents", link: ""
                        },
                        {
                            label: "Channel generated documents", link: ""
                        },
                        {
                            label: "Customer Request Letter", link: ""
                        },
                    ]}
                    filterOptions={filterList}
                    deleteFilterChip={(filterChip) => setDeleteFilterChip(filterChip)}
                    clearAll={()=> {setClearAll(true)}}
                    getSelectedRows={(selRows)=> {props?.selRows(selRows)}}
                    ti={props?.user === "maker" ? true : false}
                    onDownload={()=> download()}
                    onSort={(sortBy, desc)=>{
                        getSorted(sortBy, desc);
                    }}
                    callPaginationApi={callPaginationApi}
                    totalPage={totalPage}
                    showOtherScreen={showOtherScreen}
                />
                
                <FilterComponent
                    showDrawer={showFilter}
                    toggleDrawer={()=>{updateFilterDisplay(!showFilter); setClearAll(false)}}
                    getFilterList={(list)=> {
                        callPaginationApi(1, paginationInfo?.recordsPerPage);
                        setFilterList(list)
                    }
                    }
                    deleteFilterChip={deleteFilterChip}
                    clearAll={clearAll}
                    apiFilterOpts={(filterApiOpts)=>{
                        searchCriteria(filterApiOpts)
                    }}
                />
            </div>
    );
}
export default Drafts;



