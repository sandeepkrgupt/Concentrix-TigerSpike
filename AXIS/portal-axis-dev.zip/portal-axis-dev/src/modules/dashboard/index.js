/*eslint-disable */
import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Card from "../../components/card";
import "./index.css";
import {
  colors,
  boeColors,
  miniColors,
  chkerColors,
  chckrBoeColors,
  chkrMiniColors,
} from "../../utils/colors";
import { useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../store/rootActions";
import Loader from "../../components/loader";

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    display: 'flex',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'flex-start',
  },
  btnRoot: {
    backgroundColor: "blue !important",
  },
  boeSubCard1: {
    border: "2px solid #747474",
    borderRadius: "4px",
  },
  boeSubCard2: {
    border: "2px solid #ddd",
    borderRadius: "4px",
  },
}));

const Dashboard = () => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const state = useSelector((state) => state?.dashboard);
  const [loader, setLoader] = useState(false);
  const [dashboardTasks, setDashboardTasks] = useState(state.dashboardTasks);
  const [dashboardBoe, setDashboardBoe] = useState(
    useSelector((state) => state.dashboard.dashboardBoe)
  );

  const history = useHistory();
  const authData = useSelector((state) => state?.auth?.loginData);

  let [lessthanSixMonths, setLessthanSixMonth] = useState(false);
  let [greaterthanSixMonths, setGreaterthanSixMonth] = useState(false);

  useEffect(() => {
    //CALL lastlogin API
    const req = {
      corpId: authData?.corpId,
      userId: authData?.userId,
      bankCode: authData?.bankCode,
      isCorpId: true,
    };
    dispatch(Actions.getLastLogin(req));

    //clear paymentreview data store
    dispatch(Actions.clearPaymentReview());
  }, []);

  useEffect(() => {
    const reqBody = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      appDate: authData?.appDate,
      ieCode: authData?.ieCode,
      userRoleType: authData?.userRoleType,
    };
    setLoader(true);
    const updatedTasks = dashboardTasks?.map((item, ind) => {
      item.color = colors[ind];
      return item;
    });
    const updatedBoe = dashboardBoe?.map((item, ind) => {
      item.color = boeColors[ind];
      if (item?.expired) {
        item.miniColor = miniColors[ind];
      }
      return item;
    });
    setDashboardTasks(updatedTasks);
    setDashboardBoe(updatedBoe);
    dispatch(Actions.getDashboardTasks(reqBody));
    dispatch(Actions.getDashboardBoe(reqBody));
  }, [authData]);

  useEffect(() => {
    const { dashboardTasks, dashboardBoe, loader } = state;
    const updatedTasks = dashboardTasks?.map((item, ind) => {
      if (
        authData?.userRoleType === "C" &&
        item.label === "Pending with Auth"
      ) {
        item.color = chkerColors[0];
      } else if (
        authData?.userRoleType === "C" &&
        (item.label === "Bulk Upload Queue" ||
          item.label === "Bulk Upload Approvals")
      ) {
        item.color = chkerColors[1];
        item.label = "Bulk Upload Approvals";
      } else if (authData?.userRoleType === "C" && item.label === "Scheduled") {
        item.color = chkerColors[2];
      } else {
        item.color = colors[ind];
      }
      return item;
    });
    const updatedBoe = dashboardBoe?.map((item, ind) => {
      if (authData?.userRoleType === "C") {
        item.color = chckrBoeColors[ind];
      } else {
        item.color = boeColors[ind];
      }

      if (item?.expired) {
        if (authData?.userRoleType === "C") {
          item.miniColor = chkrMiniColors[ind];
        } else {
          item.miniColor = miniColors[ind];
        }
      }
      return item;
    });

    setDashboardTasks(updatedTasks);
    setDashboardBoe(updatedBoe);
    setLoader(loader);
  }, [state]);

  const onClickCount = (task) => {
    switch (task?.label) {
      case "All Tasks":
        history.push("/transaction-inquiry", {
          status: "All Tasks",
          action: task?.action,
        });
        break;
      case "Drafts":
        history.push("/transaction-inquiry", {
          status: "Drafts",
          action: task?.action,
        });
        break;
      case "Rejected by Auth":
        history.push("/transaction-inquiry", {
          status: "Rejected by Auth",
          action: task?.action,
        });
        break;
      case "Rejected by Bank":
        history.push("/transaction-inquiry", {
          status: "Rejected by Bank",
          action: task?.action,
        });
        break;
      case "Pending with Auth":
        history.push("/transaction-inquiry", {
          status: "Pending with Auth",
          action: task?.action,
        });
        break;
      case "Pending with Bank":
        history.push("/transaction-inquiry", {
          status: "Pending with Bank",
          action: task?.action,
        });
        break;
      case "Scheduled":
        history.push("/transaction-inquiry", {
          status: "Scheduled",
          action: task?.action,
        });
        break;
      case "Bulk Upload Queue":
        history.push("/transaction-inquiry", {
          status: "Bulk Upload Queue",
          action: task?.action,
        });
        break;
      case "Completed":
        history.push("/completed-transactions", { action: task?.action });
        break;
      case "Outstanding as per IDPMS":
        history.push("/boe", {
          status: "Outstanding as per IDPMS",
          action: task?.action,
        });
        break;
      case "Outstanding as per Portal":
        history.push("/boe", {
          status: "Outstanding as per Portal",
          action: task?.action,
        });
        break;
      case "Transaction Work in Progress":
        history.push("/boe", {
          status: "Transaction Work in Progress",
          action: task?.action,
        });
        break;
      case "Regularised BOE":
        history.push("/boe", {
          status: "Regularised BOE",
          action: task?.action,
        });
        break;
    }
  };
  const onClickCardExp = (e, task) => {
    switch (task?.label) {
      case "Outstanding as per IDPMS":
        history.push("/boe", {
          status: "Outstanding as per IDPMS",
          action: task?.expired?.action,
        });
        break;
      case "Outstanding as per Portal":
        history.push("/boe", {
          status: "Outstanding as per Portal",
          action: task?.expired?.action,
        });
        break;
      case "Transaction Work in Progress":
        history.push("/boe", {
          status: "Transaction Work in Progress",
          action: task?.action,
        });
        break;
      case "Regularised BOE":
        history.push("/boe", {
          status: "Regularised BOE",
          action: task?.action,
        });
        break;
    }
    e.stopPropagation();
  };

  const isCardShow = (task) => {
    if (authData.userRoleType === "M") {
      return true;
    } else if (authData.userRoleType === "C") {
      if (
        task.label === "Pending with Auth" ||
        task.label === "Scheduled" ||
        task.label === "Bulk Upload Approvals"
      ) {
        return true;
      } else {
        return false;
      }
    }
  };

  const onClickCardNonExp = (e, task) => {
    switch (task?.label) {
      case "Outstanding as per IDPMS":
        history.push("/boe", {
          status: "Outstanding as per IDPMS",
          action: task?.nonExpired?.action,
        });
        break;
      case "Outstanding as per Portal":
        history.push("/boe", {
          status: "Outstanding as per Portal",
          action: task?.nonExpired?.action,
        });
        break;
      case "Transaction Work in Progress":
        history.push("/boe", {
          status: "Transaction Work in Progress",
          action: task?.action,
        });
        break;
      case "Regularised BOE":
        history.push("/boe", {
          status: "Regularised BOE",
          action: task?.action,
        });
        break;
    }
    e.stopPropagation();
  };

  if (loader) {
    return <Loader />;
  }
  return (
    <div className="trade-container">
      <span className="trade-summary">Trade Overview</span>
      <span className="tasks">Tasks</span>
      <div className={classes.root}>
        {dashboardTasks?.map((task, ind) => {
          return isCardShow(task) ? (
            <div
              onClick={() => onClickCount(task)}
              key={ind}
              className={"cardsDiv"}
            >
              <Card task={task} ind={ind} />
            </div>
          ) : (
            ""
          );
        })}
      </div>
      <span className="boe">Bill Of Entry</span>
      <div className={classes.root}>
        {dashboardBoe?.map((task, ind) => {
          const { expired } = task;
          return (
            <div
              onClick={() => onClickCount(task)}
              key={ind}
              className={"cardsDiv"}
            >
              <Card
                onClickNonExpired={(e) => {
                  onClickCardNonExp(e, task);
                  setLessthanSixMonth(lessthanSixMonths, true);
                  setGreaterthanSixMonth(greaterthanSixMonths, false);
                }}
                onClickExpired={(e) => {
                  onClickCardExp(e, task);
                  setGreaterthanSixMonth(greaterthanSixMonths, true);
                  setLessthanSixMonth(lessthanSixMonths, false);
                }}
                task={task}
                ind={ind}
                toggleCardBorder={
                  lessthanSixMonths
                    ? "lessthanSixMonthsClicked"
                    : greaterthanSixMonths
                    ? "greaterthanSixMonthsClicked"
                    : ""
                }
              />
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Dashboard;
