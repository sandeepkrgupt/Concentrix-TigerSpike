/*eslint-disable*/
import React, { useState, useEffect } from "react";
import AgGridTable from "../../../components/aggridtable";
import "./index.css";
import "../index.css";
import { Button } from "../../../components/@subzero/glacier/package/lib/components";
import Info from "../../../assets/icons/info.svg";
import { useHistory } from "react-router-dom";
import BoeDetails from "../../boe/details";
import AlertDialog from "../../../components/dialog";

const headCells = [
  { field: "boeNo", label: "BOE No." },
  { field: "boeDate", label: "BOE Date", smallCell: true },
  { field: "currency", label: "Currency", smallCell: true },
  { field: "amount", label: "Amount", rightAligned: true, sortable: true },
  { field: "supplierName", label: "Supplier Name", showTooltip: true },
  { field: "country", label: "Seller Country" },
];

const BOEPaymentTable = (props) => {
  const history = useHistory();
  const [selRows, setSelRows] = useState(props?.data);
  const [showError, setShowError] = useState(false);
  const [selectedRows, setSelectedRows] = useState(selRows);
  const [showBoeDetails, setShowBoeDetails] = useState(false);
  const [boeDetailsParams, setBoeDetailsParams] = useState(null);
  const [paginationInfo, setPaginationInfo] = useState({
    recordsPerPage: 5,
    reqPageIndex: 1,
  });
  const [supplierError, updateSupplierError] = useState(false);
  const [showAlert, setShowAlert] = useState(false);

  useEffect(() => {
    checkValidation();
  }, [selectedRows]);

  const checkValidation = () => {
    // const allEqual = (arr) =>
    //   arr.every((v) => v?.currency?.value === arr[0]?.currency?.value);

    const allSupplierSame = (arr) =>
      arr.every((v) => v?.supplierName?.value === arr[0]?.supplierName?.value);

    // if (allEqual(selectedRows)) {
    //   setShowError(false);
    // } else {
    //   setShowError(true);
    // }

    if (allSupplierSame(selectedRows)) {
      updateSupplierError(false);
    } else {
      updateSupplierError(true);
    }
  };

  const onClickButton = () => {
    // Do API Call or navigate
    history.push("/make-payment", { data: selectedRows });
  };
  const handleRowSelection = (selctedRow) => {
    const newArrayList = [];
    selctedRow &&
      selctedRow.length > 0 &&
      selctedRow.map((item) => {
        props?.data?.map((rowItem) => {
          if (item?.id?.value == rowItem?.id) {
            newArrayList.push(rowItem);
          }
        });
      });
    setSelectedRows(newArrayList);
  };

  const showOtherScreen = (link, params) => {
    if (link === "boe-details") {
      setShowBoeDetails(true);
      setBoeDetailsParams(params);
    }
  };
  return showBoeDetails ? (
    <BoeDetails
      onClose={() => setShowBoeDetails(false)}
      params={boeDetailsParams}
    />
  ) : (
    <>
      <div className="payment-heading-container mgTop0Table">
        <span className="modal-heading">Selected Bill Of Entry</span>
        {(showError || supplierError) && (
          <div className="error-container">
            <img src={Info} />
            <span className="error-text">
              {/* Select transactions in the same supplier name to proceed */}
              {supplierError
                ? "Please ensure to select BOEs with the same currency and Beneficiary name to proceed"
                : "Please ensure to select BOEs with the same currency and Beneficiary name to proceed"}
            </span>
          </div>
        )}
      </div>
      <AgGridTable
        tableOnly={true}
        selectedList={props?.data}
        handleRowSelection={handleRowSelection}
        headCells={headCells}
        rows={selRows}
        getSelectedRows={(selRows) => {
          setSelectedRows(selRows);
        }}
        hideActionIcon={true}
        hideMiniTopContainer={true}
        showOtherScreen={showOtherScreen}
        autoSize={true}
      />
      <div className="selected-payment">
        <span>{`Transaction selected: ${selectedRows?.length}`}</span>
        <div className="payment-buttons">
          <Button
            color="secondary"
            className="cancel-button"
            onClick={() => {
              setShowAlert(true);
            }}
          >
            Cancel
          </Button>
          <Button
            disabled={selectedRows?.length <= 0 || showError}
            onClick={onClickButton}
          >
            Make Payment
          </Button>
        </div>
      </div>

      <AlertDialog
        show={showAlert}
        onClose={() => {
          setShowAlert(false);
        }}
        onAction={() => {
          props?.toggleModal(false);
        }}
        actionButtonLabel={"Yes"}
        title={"Are you sure you want to cancel and return to Bill Of Entry"}
      />
    </>
  );
};

export default BOEPaymentTable;
