import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Drawer from "@material-ui/core/Drawer";
import Grid from "@material-ui/core/Grid";
import CloseIcon from "../../../assets/icons/close.svg";
import "./index.css";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import { Hidden } from "@material-ui/core";
// import { Button } from '../../../components/@subzero/glacier/package/lib/components';
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";
import { convertNull } from "../../../utils/ConvertNull";
import { useHistory } from "react-router-dom";

const useStyles = makeStyles({
  root: {
    background: "#F9F9F9",
    borderRadius: "8px",
    marginTop: "16px",
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
  dropdown: {
    "& .Dropdown_show__21pcz": {
      position: "absolute",
      zIndex: "999",
    },
  },
});

const BoeDetails = (props) => {
  const dispatch = useDispatch();
  const classes = useStyles();
  const history = useHistory();
  const [openModal, setOPenModal] = useState(true);
  const state = useSelector((state) => state);
  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const authData = useSelector((state) => state?.auth?.loginData);
  const isBoe = props?.params?.boe;
  const [boeDetails, setBoeDetails] = useState({});
  const toggleDrawer = (open) => {
    // if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
    //     return;
    // }
    setOPenModal(open);
    if (!open) {
      // history.goBack();
      props?.onClose();
    }
  };

  useEffect(() => {
    const item = props?.params?.item;
    if (isBoe) {
      const req = {
        corpId: authData?.corpId,
        userId: authData?.userId,
        bankCode: authData?.bankCode,
        ieCode: authData?.ieCode,
        invoiceCurrency: item?.currency,
        boeNumber: item?.boeNo?.id,
        supplierName: item?.supplierName,
      };
      // BOE DETAILS API
      dispatch(Actions.getBoeDetails(req));
    } else if (props?.params?.trans) {
      const req = {
        corpId: authData?.corpId,
        userId: authData?.userId,
        bankCode: authData?.bankCode,
        ieCode: authData?.ieCode,
        invoiceCurrency: item?.invoiceCurrency,
        boeNumber: item?.boeNumber,
        supplierName: item?.supplierName,
      };
      // BOE DETAILS API
      dispatch(Actions.getBoeDetails(req));
    } else if (props?.params?.item?.boeNumber && props?.params?.item?.invoiceDetails?.length > 0 && props?.params?.item?.invoiceDetails[0].invoiceCurrency) {
      const req = {
        corpId: authData?.corpId,
        userId: authData?.userId,
        bankCode: authData?.bankCode,
        ieCode: authData?.ieCode,
        invoiceCurrency: props?.params?.item?.invoiceDetails[0].invoiceCurrency,
        boeNumber: props?.params?.item?.boeNumber,
        supplierName: item?.supplierName,
      };
      // BOE DETAILS API
      dispatch(Actions.getBoeDetails(req));
    } else {
      const boeNumber = props?.params?.boeNo;
      const req = {
        corpId: authData?.corpId,
        userId: authData?.userId,
        bankCode: authData?.bankCode,
        invoiceCurrency: item?.currency,
        boeNumber: boeNumber,
        fidbTxnPk: item?.id,
      };
      // TI BOE DETAILS
      dispatch(Actions.getTiBoeDetails(req));
    }
  }, []);

  useEffect(() => {
    if (isBoe || props?.params?.trans || props?.params?.item?.boeNumber) {
      setBoeDetails(state?.boe?.boeDetails);
    } else {
      setBoeDetails(state?.transaction?.tiBoeDetails);
    }
  }, [state]);
  return (
    <div>
      <div>
        <React.Fragment>
          <Drawer
            classes={{
              paper: classes.paper,
            }}
            anchor={"bottom"}
            open={openModal}
            onClose={() => {
              toggleDrawer(false);
            }}
          >
            <div
              onClick={() => {
                toggleDrawer(false);
              }}
              className="close"
            >
              <img src={CloseIcon} className="close-icon" />
            </div>
            <div className="details-container">
              <span className="heading-details">Bill Of Entry Details</span>
              <div className="border-container">
                <span className="details-heading">Applicant Details</span>
                <Grid spacing={3} className="details-containers" container>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Customer ID</span>
                    <span className="detail-content">
                      {history?.location?.pathname?.includes("make-payment") && (transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId)}
                      {!history?.location?.pathname?.includes("make-payment") && (authData?.subcustId || boeDetails?.applicantDetails?.customerId)}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Name</span>
                    <span className="detail-content">
                      {boeDetails?.applicantDetails?.applicantName}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">IE Code</span>
                    <span className="detail-content">
                      {boeDetails?.applicantDetails?.ieCode}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Country</span>
                    <span className="detail-content">
                      {boeDetails?.applicantDetails?.applicantCountry}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={8}
                    sm={8}
                    xs={12}
                  >
                    <span className="detail-heading">Address</span>
                    <span className="detail-content">
                      {boeDetails?.applicantDetails?.applicantAddress}
                    </span>
                  </Grid>
                </Grid>
              </div>
              <div className="border-container">
                <span className="details-heading">Importer Details</span>
                <Grid spacing={3} className="details-containers" container>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Name(Optional)</span>
                    <span className="detail-content">
                      {boeDetails?.importerDetails?.importerName}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">
                      PAN Number (Optional)
                    </span>
                    <span className="detail-content">
                      {boeDetails?.importerDetails?.importerPanNumber}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">IE Code(Optional)</span>
                    <span className="detail-content">
                      {boeDetails?.importerDetails?.ieCode}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">AD Code</span>
                    <span className="detail-content">
                      {boeDetails?.importerDetails?.adCode}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={8}
                    sm={8}
                    xs={12}
                  >
                    <span className="detail-heading">Address(Optional)</span>
                    <span className="detail-content">
                      {boeDetails?.importerDetails?.importerAddress}
                    </span>
                  </Grid>
                </Grid>
              </div>
              <div className="border-container">
                <span className="details-heading">
                  Supplier Details (Optional)
                </span>
                <Grid spacing={3} className="details-containers" container>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Import Agency</span>
                    <span className="detail-content">
                      {boeDetails?.supplierDetails?.importAgency}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Name</span>
                    <span className="detail-content">
                      {boeDetails?.supplierDetails?.supplierName}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Country</span>
                    <span className="detail-content">
                      {boeDetails?.supplierDetails?.supplierCountry}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Address</span>
                    <span className="detail-content">
                      {boeDetails?.supplierDetails?.supplierAddress}
                    </span>
                  </Grid>
                </Grid>
              </div>
              <div className="border-container">
                <span className="details-heading">
                  Seller Details (Optional)
                </span>
                <Grid spacing={3} className="details-containers" container>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Name</span>
                    <span className="detail-content">
                      {boeDetails?.sellerDetails?.sellerName}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Country</span>
                    <span className="detail-content">
                      {boeDetails?.sellerDetails?.sellerCountry}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={12}
                  >
                    <span className="detail-heading">Address</span>
                    <span className="detail-content">
                      {boeDetails?.sellerDetails?.sellerAddress}
                    </span>
                  </Grid>
                </Grid>
              </div>
              <div className="border-container">
                <span className="details-heading">
                  Third Party Details (Optional)
                </span>
                <Grid spacing={3} className="details-containers" container>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Name</span>
                    <span className="detail-content">
                      {boeDetails?.thirdPartyDetails?.thirdPartyName}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Country</span>
                    <span className="detail-content">
                      {boeDetails?.thirdPartyDetails?.thirdPartyCountry}
                    </span>
                  </Grid>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={12}
                  >
                    <span className="detail-heading">Address</span>
                    <span className="detail-content">
                      {boeDetails?.thirdPartyDetails?.thirdPartyAddress}
                    </span>
                  </Grid>
                </Grid>
              </div>
              {boeDetails?.shipmentDetails && (
                <div className="border-container">
                  <span className="details-heading">Shipment Details</span>
                  <Grid spacing={3} className="details-containers" container>
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={4}
                      sm={4}
                      xs={6}
                    >
                      <span className="detail-heading">Port of Shipment</span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.portOFShipment}
                      </span>
                    </Grid>
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={4}
                      sm={4}
                      xs={6}
                    >
                      <span className="detail-heading">Port of Discharge</span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.portOfDischarge}
                      </span>
                    </Grid>
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={4}
                      sm={4}
                      xs={6}
                    >
                      <span className="detail-heading">
                        IGM Number (Optional)
                      </span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.igmNumber}
                      </span>
                    </Grid>

                    <Grid
                      className="sub-detail-container"
                      item
                      lg={4}
                      sm={4}
                      xs={6}
                    >
                      <span className="detail-heading">
                        IGM Date (Optional)
                      </span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.igmDate}
                      </span>
                    </Grid>
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={4}
                      sm={4}
                      xs={6}
                    >
                      <span className="detail-heading">
                        Master AWB/BL Number
                      </span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.masterAWBLNumber}
                      </span>
                    </Grid>
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={4}
                      sm={4}
                      xs={6}
                    >
                      <span className="detail-heading">Master AWB/BL Date</span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.masterAWBBLDate}
                      </span>
                    </Grid>
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={4}
                      sm={4}
                      xs={6}
                    >
                      <span className="detail-heading">
                        House AWB/BL Number (Optional)
                      </span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.houseAWBBLNumber}
                      </span>
                    </Grid>
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={8}
                      sm={8}
                      xs={6}
                    >
                      <span className="detail-heading">
                        House AWB/BL Date (Optional)
                      </span>
                      <span className="detail-content">
                        {boeDetails?.shipmentDetails?.houseAWBBLDate}
                      </span>
                    </Grid>
                  </Grid>
                </div>
              )}
              <div className="border-container invoice-details">
                <span className="details-heading">Invoice Details</span>
                {boeDetails?.invoiceDetails?.map((item, ind) => {
                  return (
                    <Accordion key={ind} className={classes.root}>
                      <AccordionSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                      >
                        <Grid
                          spacing={3}
                          className="details-containers"
                          container
                        >
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Invoice Number (Optional)
                            </span>
                            <span className="detail-content">
                              {item?.invoiceNumber}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Invoice Amount (FOB) (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(item?.invoiceAmount, "amount")}
                            </span>
                          </Grid>
                          <Hidden xsDown>
                            <Grid
                              className="sub-detail-container"
                              item
                              lg={4}
                              sm={4}
                              xs={6}
                            >
                              <span className="detail-heading">
                                Invoice Serial Number (Optional)
                              </span>
                              <span className="detail-content">
                                {item?.invoiceSerialNumber}
                              </span>
                            </Grid>
                          </Hidden>
                        </Grid>
                      </AccordionSummary>
                      <AccordionDetails>
                        <Grid
                          spacing={3}
                          className="details-containers"
                          container
                          style={{ marginRight: "26px" }}
                        >
                          <Hidden smUp>
                            <Grid
                              className="sub-detail-container"
                              item
                              lg={4}
                              sm={4}
                              xs={6}
                            >
                              <span className="detail-heading">
                                Invoice Serial Number (Optional)
                              </span>
                              <span className="detail-content">
                                {item?.invoiceSerialNumber}
                              </span>
                            </Grid>
                          </Hidden>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Insurance Amount (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(item?.insuranceAmount, "amount")}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Freight Amount (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(item?.freightAmount, "amount")}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Miscellaneous Amount (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(
                                item?.miscellaneousCharges,
                                "amount"
                              )}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Agency Commission (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(item?.agencyCommission, "amount")}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Discount Charges (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(item?.discountCharges, "amount")}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">Payment Term</span>
                            <span className="detail-content">
                              {item?.incoTerms}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={4}
                            sm={4}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Utilized Invoice Amount (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(
                                item?.utilizeInvoiceAmount,
                                "amount"
                              )}
                            </span>
                          </Grid>
                          <Grid
                            className="sub-detail-container"
                            item
                            lg={8}
                            sm={8}
                            xs={6}
                          >
                            <span className="detail-heading">
                              Outstanding Invoice Amount (Optional)
                            </span>
                            <span className="detail-content">
                              {convertNull(item?.outstandingAmount, "amount")}
                            </span>
                          </Grid>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  );
                })}
              </div>
              <div className="border-container">
                <span className="details-heading">
                  Other Details (Optional)
                </span>
                <Grid spacing={3} className="details-containers" container>
                  <Grid
                    className="sub-detail-container"
                    item
                    lg={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="detail-heading">Consignee Country</span>
                    <span className="detail-content">
                      {boeDetails?.otherDetails?.consignee}
                    </span>
                  </Grid>
                </Grid>
              </div>
            </div>
            {/* <div className="close-container">
                            <Button onClick={toggleDrawer(false)}>Close</Button>
                        </div> */}
          </Drawer>
        </React.Fragment>
      </div>
    </div>
  );
};

export default BoeDetails;
