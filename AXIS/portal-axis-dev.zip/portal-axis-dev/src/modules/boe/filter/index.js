/* eslint-disable */
import React, {useState, useEffect} from 'react';
import { Drawer } from '@material-ui/core'
import closeIcon from '../../../assets/icons/close-icon.svg';
import Customdropdown from '../../../components/customdropdown';
import Button from '../../../components/@subzero/glacier/package/lib/components/Button'
import "./index.css"
import CustomSlider from '../../../components/slider';
import { useSelector } from 'react-redux';
import customStyles from './filter.module.css';

const FilterComponent = (props) => {

    const supplierOptions = [
        {
            id: 1,
            label: 'ARM Software Media'
        },
        {
            id: 2,
            label: 'Citi Software Media'
        },
        {
            id: 3,
            label: 'BBH Software Media'
        },
        {
            id: 4,
            label: 'XYZ Software Media'
        }
    ];

    const currencyOptions = [
        {
            id:1,
            label: 'INR'
        },
        {
            id:2,
            label: 'USD'
        },
        {
            id: 3,
            label: 'GBP'
        },
        {
            id: 4,
            label: 'KWD'
        }
    ];

    const boeNumberOptions = [
        {
            id:1,
            label: 'BOE-001'
        },
        {
            id:2,
            label: 'BOE-002'
        },
        {
            id:3,
            label: 'BOE-003'
        }
    ];

    const channelRefoptions = [
        {
            id:1,
            label: 'CRN-001'
        },
        {
            id:2,
            label: 'CRN-002'
        },
        {
            id:3,
            label: 'CRN-003'
        }
    ];

    const boeStatusOptions = [
        {
            id:1,
            label: 'Fast'
        },
        {
            id:2,
            label: 'Standard'
        }
    ]

    const [selSuppOptions, setSelSuppOptions] = useState([]);
    const [selCurrencyOptions, setSelCurrencyOptions] = useState([]);
    const [selBoeOptions, setSelBoeOptions] = useState([]);
    const [selBoeStatusOptions, setSelBoeStatusOptions] = useState([]);
    const [appliedFilter, setApppliedFilter] = useState(false);
    const [disableFilter, setDisableFilter] = useState(false);
    const [amounts, setAmounts] = useState([null, null]);
    const state = useSelector((state)=> state?.boe);
    const [filterOptions, setFilterOptions] = useState(useSelector((state)=> state?.boe?.boeFilters))
    useEffect(()=>{
        setFilterOptions(state?.boeFilters)
    },[state])

    const closeFilter = (event)=>{
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }
        props.toggleDrawer();
    }

    const onApply=async(e)=>{
        setApppliedFilter(true);
    }

    const onReset=()=>{
        setSelSuppOptions([]);
        setSelCurrencyOptions([]);
        setSelBoeOptions([]);
        setSelBoeStatusOptions([]);
        setAmounts([0,0])
        props?.getFilterList([]);
    }

    const deleteFromSelected=(chip, arr, setArr)=>{
        setArr(arr?.filter((item)=> item.id !== chip.id))
    }

    useEffect(()=>{
        const suppOpts = [...selSuppOptions]?.map((selOpt)=> {
            selOpt.key = "supplierName";
            return selOpt;
        });
        const currOpts = [...selCurrencyOptions]?.map((selOpt)=> {
            selOpt.key = "currency";
            return selOpt;
        });
        const boeOpts = [...selBoeOptions]?.map((selOpt)=> {
            selOpt.key = "boeNumber";
            return selOpt;
        });
        const boeStatusOpts = [...selBoeStatusOptions]?.map((selOpt)=> {
            selOpt.key = "boeStatus";
            return selOpt;
        });

        let filterOptionsList = "";
        if(amounts[1] && amounts[1] !== 0){
            filterOptionsList = [
                ...suppOpts,
                ...currOpts,
                ...boeOpts,
                ...boeStatusOpts,
                {
                    label: "From amount " + amounts?.[0] + " - " + amounts?.[1],
                    key: "amount",
                }
            ];
        }
        else{
            filterOptionsList = [
                ...suppOpts,
                ...currOpts,
                ...boeOpts,
                ...boeStatusOpts
            ];
            
        }
        props?.getFilterList(filterOptionsList);
        let filterOpts = {
            supplierName: selSuppOptions,
            currency: selCurrencyOptions,
            boeNumber: selBoeOptions,
            boeStatus: selBoeStatusOptions,
            minAmount: (amounts[0]),
            maxAmount: amounts[1] > 0 ? (amounts[1]) : ""
        }
        props.apiFilterOpts(filterOpts);
        if(appliedFilter){
            props.toggleDrawer();
        }
    },[appliedFilter, amounts, selSuppOptions, selCurrencyOptions, selBoeOptions, selBoeStatusOptions])

    useEffect(() => {
        const filterChip = props?.deleteFilterChip;
        switch(filterChip?.key){
            case 'amount': setAmounts([null,null]); break;
            case 'supplierName': deleteFromSelected(filterChip, selSuppOptions, setSelSuppOptions);break;
            case 'currency': deleteFromSelected(filterChip, selCurrencyOptions, setSelCurrencyOptions);break;
            case 'boeNumber': deleteFromSelected(filterChip, selBoeOptions, setSelBoeOptions);break;
            case 'boeStatus': deleteFromSelected(filterChip, selBoeStatusOptions, setSelBoeStatusOptions);break;
            default:{return null}
        }

    }, [props?.deleteFilterChip]);

    useEffect(()=>{
        if(props?.clearAll){
            onReset();
        }
    },[props?.clearAll])

    return (
        <>
            <Drawer anchor="right" open={props.showDrawer} className="filter-component" onClose={closeFilter} >
                <div className="drawer-container">
                    <div className="drawer-header">
                        <h5>Filter</h5>
                        <span className="drawer-close-icon" onClick={closeFilter}><img src={closeIcon} /></span>
                    </div>
                    <Customdropdown 
                        name="BOE Status" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelBoeStatusOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.boeStatus} 
                        selectedOptions={selBoeStatusOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="Supplier Name" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelSuppOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.supplierName} 
                        selectedOptions={selSuppOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="Currency" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelCurrencyOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.currency} 
                        selectedOptions={selCurrencyOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="BOE Number"
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelBoeOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.boeNumber} 
                        selectedOptions={selBoeOptions}
                        appliedFilter={appliedFilter}
                    />
                   
                    {/* Amount range */}
                    <CustomSlider title="Amount Range"
                        getValue={(amounts)=> {setAmounts(amounts); setApppliedFilter(false)}}
                        appliedFilter={appliedFilter}
                        selectedAmounts={amounts}
                        disableFilter={(bool)=> setDisableFilter(bool)}
                    />
                </div>
                <div className="filter-buttons">
                        <span className="reset-link" onClick={(e)=>{onReset();}}>Reset Filters</span>
                        <Button classes={{root: customStyles.apply}} disabled={disableFilter} onClick={(e)=>onApply(e)}>Apply</Button>
                    </div>
            </Drawer>
        </>
    )
}
export default FilterComponent;