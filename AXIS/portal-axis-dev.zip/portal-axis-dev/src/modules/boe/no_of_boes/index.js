/*eslint-disable */
import React, {useEffect, useState} from 'react';
import AgGridTable from '../../../components/aggridtable';
import { makeStyles } from '@material-ui/core/styles';
import { Drawer, Paper } from '@material-ui/core';
import CloseIcon from '../../../assets/icons/close.svg';
import { useDispatch, useSelector } from 'react-redux';
import { Actions } from '../../../store/rootActions';

const useStyles = makeStyles((theme) => ({
    root: {
      width: '70%',
      alignItems: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignSelf: 'center',
      marginTop: '48px',
    },
    paper: {
        width: '100%',
        paddingBottom: theme.spacing(2),
        height: '92%',
        background: '#FFFFFF',
        borderRadius: '24px 24px 0px 0px',
    },
}));

const NoOfBoes=(props)=>{
    const dispatch = useDispatch();
    const classes = useStyles();
    const [openModal, setOPenModal] = useState(true);
    const [rowList, updateRowList] = useState([]);
    const state = useSelector((state)=> state?.boe);
    const authData = useSelector((state)=> state?.auth?.loginData);
    const id = props?.params?.id;
    const [sortInfo, setSortInfo] = useState({});
    const [boes, setBoes] = useState(useSelector((state)=> state?.boe?.noOfBoes ))

    useEffect(()=>{
        // Load data
        getBoes();
    },[]);

    useEffect(()=>{
        getBoes();
    },[sortInfo])

    useEffect(()=>{
        setBoes(state?.noOfBoes);
    },[state]);

    useEffect(()=>{
        generateTableData();
    },[boes])


    const getBoes = () =>{
        const req = {
            "userId": authData?.userId,
            "corpId": authData?.corpId,
            "bankCode": authData?.bankCode,
            "id": id,
            "sortInfo": sortInfo
        }
        dispatch(Actions.getNoOfBoes(req));
    }
    
    const getRows =()=>{
        if(boes?.length > 0){
            return boes?.map((resp)=>{
                const {id, boeNumber, boeDate, currency, amount, supplierName, country} = resp;
                return createData(id, boeNumber,boeDate,currency,amount,supplierName,country);
            });
        }
        else{
            return [];
        }
    } 

    const generateTableData = () => {
        const rows = getRows();
        const newArray = [...rows];
        const resultArray = [];
        newArray.map((rowItem) => {
            const newObject = {}
            Object.keys(rowItem)?.map(key => {
                const value = rowItem[key];
                switch (key) {
                    case "channelRefNo":
                        return newObject[key] = { value: value?.label, isLink: true, };
                    case "paymentRefNo":
                        return newObject[key] = { value: value?.label, isLink: false, };
                    case "boeNo":
                        return newObject[key] = { value: value?.label, isLink: true, link: `/boe-details/${value?.label}`, params:{item: rowItem, boeNo: value?.id} }
                    case 'currency':
                        return newObject[key] = { value: value, smallCell: true }
                    default:
                        return newObject[key] = { value: value }

                }
            })
            resultArray.push(newObject);
            return newObject;
        })
        updateRowList(resultArray);
    }

    function createData(id, boeNo, boeDate, currency, amount, supplierName, country) {
        return { id, boeNo, boeDate, currency, amount, supplierName, country };
    }
      
    const headCells = [
        { field: 'boeNo', label: 'BOE No.' },
        { field: 'boeDate', label: 'BOE Date' },
        { field: 'currency', label: 'Currency' },
        { field: 'amount', label: 'Amount', sortable: true, rightAligned: true },
        { field: 'supplierName', label: 'Supplier Name' },
        { field: 'country', label: 'Seller Country' },
    ];
    
    const toggleDrawer = (open) => (event) => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }
        setOPenModal(open);
        if(!open){
            props?.onClose();
        }
    };
    const getSorted=(sortBy, desc)=>{
        const receivedSortInfo = {
            "sortBy": sortBy,
            "sortType": desc ? "DESC" : "ASC"
        }
        if(JSON.stringify(receivedSortInfo) !== JSON.stringify(sortInfo)){
            setSortInfo({
                "sortBy": sortBy,
                "sortType": desc ? "DESC" : "ASC"
            })
        }
    }
    return(
        <React.Fragment>
        <Drawer 
            classes={{
                paper: classes.paper
            }} 
            anchor={"bottom"} 
            open={openModal} 
            onClose={toggleDrawer(false)}
        >
            <div onClick={toggleDrawer(false)} className="close">
                <img src={CloseIcon} className="close-icon"/>
            </div>
            <div className={classes.root}>
            <Paper className={`table-container ${classes.paper}`}>
                <AgGridTable 
                    tableOnly={true}
                    headCells={headCells} 
                    rows={rowList}
                    noRowSelection={true}
                    hideActionIcon={true}
                    onSort={(sortBy, desc)=>{
                        getSorted(sortBy, desc)
                    }}
                />
            </Paper>
            </div>
        </Drawer>
    </React.Fragment>
    )
}

export default NoOfBoes;