/*eslint-disable*/
import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Drawer from "@material-ui/core/Drawer";
import CloseIcon from "../../assets/icons/close.svg";
import {
  Breadcrumbs,
  Button,
} from "../../components/@subzero/glacier/package/lib/components";
import Card from "../../components/card";
import PreviousIcon from "../../assets/icons/prev-icon.svg";
import AgGridTable from "../../components/aggridtable";
import BOEPaymentTable from "./table/payment-table";
import FilterComponent from "./filter";
import "./index.css";
import {
  boeInqBorderColors,
  boeInqColors,
  boeInqMiniColors,
} from "../../utils/colors";
import { useLocation, useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../store/rootActions";
import Loader from "../../components/loader";
import BoeDetails from "../boe/details";
import BoeNo from "../boe/no_of_boes";
import moment from "moment";
import Footer from "../../components/stickyfooter";
import AlertPopup from "../../components/alertPopup/alertPopup";
import { Link } from 'react-router-dom';

const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
}));

const BillOfEntry = () => {
  const dispatch = useDispatch();
  const location = useLocation();
  const history = useHistory();
  const classes = useStyles();
  const [activeBoe, setActiveBoe] = useState(location?.state?.status);
  const [list, setList] = useState(
    useSelector((state) => state?.dashboard?.dashboardBoe)
  );
  const [showModal, setShowModal] = React.useState(false);
  const [rowList, updateRowList] = useState([]);
  const [showFilter, updateFilterDisplay] = React.useState(false);
  const [filterList, setFilterList] = useState([]);
  const [deleteFilterChip, setDeleteFilterChip] = useState({});
  const [clearAll, setClearAll] = useState(false);
  const [selRows, setSelRows] = useState([]);
  const [startRange, setStartRange] = useState("");
  const [endRange, setEndRange] = useState("");
  const [selectedRows, updateSelectedRows] = React.useState([]);
  const [searchText, setSearchText] = useState("");
  const state = useSelector((state) => state);
  const authData = useSelector((state) => state?.auth?.loginData);
  const [boes, setBoes] = useState(useSelector((state) => state?.boe?.boes));
  const [totalPage, setTotalPage] = useState(
    useSelector((state) => state?.boe?.totalPage)
  );
  const [filterAPIOptions, setFilterAPIOptions] = useState({});
  const [action, setAction] = useState(location?.state?.action);
  const [sortInfo, setSortInfo] = useState({});
  const [paginationInfo, setPaginationInfo] = useState({
    recordsPerPage: 5,
    reqPageIndex: 1,
  });
  const [showBoeDetails, setShowBoeDetails] = useState(false);
  const [boeDetailsParams, setBoeDetailsParams] = useState(null);
  const [showBoeNo, setShowBoeNo] = useState(false);
  const [boeNoParams, setBoeNoParams] = useState(null);
  const [toastState, updateToastState] = useState({
    toastMessage: "",
    toastType: "",
    showToast: false,
  });
  const [disableButton, setDisableButton] = useState(false);
  let [lessthanSixMonths, setLessthanSixMonth] = useState(false);
  let [greaterthanSixMonths, setGreaterthanSixMonth] = useState(false);

  // Load data initially
  useEffect(() => {
    getBoes();
    getFilterOptions();
  }, []);

  // Load data when filter changes
  useEffect(() => {
    getBoes();
    getFilterOptions();
  }, [action]);

  useEffect(() => {
    getBoes();
  }, [filterAPIOptions]);

  useEffect(() => {
    const updatedList = state?.dashboard?.dashboardBoe?.map((item, ind) => {
      item.color = boeInqColors[ind];
      item.borderColor = boeInqBorderColors[ind];
      if (item?.expired) {
        item.miniColor = boeInqMiniColors[ind];
      }
      return item;
    });
    setList(updatedList);
  }, [state?.dashboard]);

  //Update boes when change in reducer
  useEffect(() => {
    setBoes(state?.boe?.boes);
    setTotalPage(state?.boe?.totalPage);
  }, [state?.boe]);

  //Update table data when response data changes
  useEffect(() => {
    generateTableRowValues();
  }, [boes]);

  useEffect(() => {
    getBoes();
  }, [searchText, sortInfo, paginationInfo]);

  useEffect(() => {
    if (startRange && endRange) {
      getBoes();
    }
  }, [startRange, endRange]);

  useEffect(() => {
    checkValidation();
  }, [selectedRows]);

  const getFilterOptions = () => {
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      appDate: authData?.appDate,
      ieCode: authData?.ieCode,
    };
    dispatch(Actions.getBoeFilters(req, action));
  };

  //Get data from API
  const getBoes = () => {
    let pagInfo = paginationInfo;
    let filterOptions = filterAPIOptions;
    filterOptions["searchText"] = searchText;
    if (startRange && endRange) {
      filterOptions["startDate"] = moment(startRange).format("YYYY-MM-DD");
      filterOptions["endDate"] = moment(endRange).format("YYYY-MM-DD");
    }
    if (searchText) {
      pagInfo.reqPageIndex = 1;
    }
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      appDate: authData?.appDate,
      ieCode: authData?.ieCode,
      searchCriteriaInfo: filterOptions,
      sortInfo: sortInfo,
      paginationInfo: pagInfo,
    };
    dispatch(Actions.getBoeInquiry(req, action));
  };

  function createData(
    id,
    supplierName,
    country,
    boeNo,
    boeDate,
    adCode,
    currency,
    amount,
    outstandingAmount,
    portCode,
    status,
    channelRefNo
  ) {
    return {
      id,
      supplierName,
      country,
      boeNo,
      boeDate,
      adCode,
      currency,
      amount,
      outstandingAmount,
      portCode,
      status,
      channelRefNo,
    };
  }

  const getRows = () => {
    if (boes?.length > 0) {
      return boes?.map((resp) => {
        const {
          id,
          supplierName,
          country,
          boeNumber,
          boeDate,
          adCode,
          currency,
          amount,
          osAmount,
          portCode,
          status,
          channelRefNo,
        } = resp;
        return createData(
          id,
          supplierName,
          country,
          boeNumber,
          boeDate,
          adCode,
          currency,
          amount,
          osAmount,
          portCode,
          status,
          channelRefNo
        );
      });
    } else {
      return [];
    }
  };

  const searchCriteria = (filterApiOpts) => {
    Object.keys(filterApiOpts).forEach((key) => {
      if (Array.isArray(filterApiOpts[key])) {
        if (filterApiOpts[key]?.length > 0) {
          let arr = [];
          filterApiOpts[key]?.map((filt) => {
            arr.push(filt.id);
          });
          filterApiOpts[key] = arr;
        }
      }
    });
    setFilterAPIOptions(filterApiOpts);
  };

  const headCells = [
    { field: "supplierName", label: "Supplier Name", showTooltip: true },
    { field: "country", label: "Country" },
    { field: "boeNo", label: "BOE No." },
    { field: "boeDate", label: "BOE Date", sortable: true },
    { field: "adCode", label: "AD Code", sortable: true , rightAligned: true },
    { field: "currency", label: "Currency", smallCell: true, sortable: true },
    { field: "amount", label: "Amount", sortable: true, rightAligned: true },
    { field: "outstandingAmount", label: "O/S Amount", sortable: true, rightAligned: true },
    { field: "portCode", label: "Port Code" },
    { field: "status", label: "IDPMS Status" },
    { field: "channelRefNo", label: "Channel Ref. No." },
    // { field: 'action', label: '' },
  ];

  const generateTableRowValues = () => {
    const rows = getRows();
    let newArray = [...rows];
    let resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        let value = rowItem[key];
        switch (key) {
          case "channelRefNo":
            return (newObject[key] = { value: value?.label, isLink: true });
          case "paymentRefNo":
            return (newObject[key] = { value: value?.label, isLink: false });
          case "boeNo":
            return (newObject[key] = {
              value: value?.label,
              isLink: true,
              link: `boe-details`,
              params: { item: rowItem, boe: true },
            });
          case "currency":
            return (newObject[key] = { value: value, smallCell: true });
          default:
            return (newObject[key] = { value: value });
        }
      });
      resultArray.push(newObject);
    });
    if (paginationInfo?.reqPageIndex == 1) {
      updateRowList(resultArray);
    } else {
      // updateRowList(rowList.concat(resultArray));
      if (paginationInfo?.reqPageIndex !== 1) {
        // for pagination functionality binding previous data
        const arrayIndex =
          parseInt(
            paginationInfo?.reqPageIndex * paginationInfo?.recordsPerPage
          ) - parseInt(paginationInfo?.recordsPerPage);
        const mergedArray = [...rowList];
        mergedArray.length = totalPage;
        mergedArray.splice(arrayIndex, 25, ...resultArray);
        updateRowList(mergedArray);
      } else {
        updateRowList(resultArray);
      }
    }
  };

  const toggleDrawer = (open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    setShowModal(open);
  };

  const MakePaymentModal = () => {
    const paymentTableRows = [...selectedRows];
    paymentTableRows?.map((item) => {
      item.boeNo.isLink = false;
    });
    return (
      <Drawer
        classes={{
          paper: classes.paper,
        }}
        anchor={"bottom"}
        open={true}
        onClose={toggleDrawer(false)}
      >
        <div onClick={toggleDrawer(false)} className="close">
          <img src={CloseIcon} className="close-icon" />
        </div>
        <div className="modal-container">
          <BOEPaymentTable
            data={paymentTableRows}
            toggleModal={(val) => setShowModal(val)}
          />
        </div>
      </Drawer>
    );
  };

  const onClickBoe = (task) => {
    updateSelectedRows([]);
    setActiveBoe(task?.label);
    setAction(task?.action);
  };

  const onClickCardNonExp = (e, task) => {
    setActiveBoe(task?.label);
    setAction(task?.nonExpired?.action);
    e.stopPropagation();
  };

  const onClickCardExp = (e, task) => {
    setActiveBoe(task?.label);
    setAction(task?.expired?.action);
    e.stopPropagation();
  };

  const allEqual = (arr) =>
    arr.every((v) => v?.currency?.value === arr[0]?.currency?.value);
  const checkValidation = () => {
    if (selectedRows?.length > 10) {
      updateToastState({
        toastMessage:
          "Exceeding number of the BOEs Selection for a transaction",
        toastType: "",
        showToast: true,
      });
      setDisableButton(true);
    } else if (!allEqual(selectedRows)) {
      updateToastState({
        toastMessage:
          "Bill Of Entry currency are not same for selected records",
        toastType: "",
        showToast: true,
      });
      setDisableButton(true);
    } else {
      setDisableButton(false);
    }
  };

  const onMakePayment = () => {
    dispatch(Actions.clearSuccessStatus());
    dispatch(Actions.switchStandardProcessing(authData?.docUploadWaiver !== "Paperless" ? true : false));
    //clear paymentreview data store
    dispatch(Actions.clearPaymentReview());
    if (allEqual(selectedRows)) {
      setShowModal(true);
    }
  };
  const handleRowSelection = (selctedRow) => {
    const newArrayList = [];
    selctedRow &&
      selctedRow.length > 0 &&
      selctedRow.map((item) => {
        rowList?.map((rowItem) => {
          if (item?.id?.value == rowItem?.id?.value) {
            newArrayList.push(rowItem);
          }
        });
      });
    updateSelectedRows(newArrayList);
  };
  const getSorted = (sortBy, desc) => {
    const receivedSortInfo = {
      sortBy: sortBy,
      sortType: desc ? "DESC" : "ASC",
    };
    if (JSON.stringify(receivedSortInfo) !== JSON.stringify(sortInfo)) {
      setSortInfo({
        sortBy: sortBy,
        sortType: desc ? "DESC" : "ASC",
      });
    }
  };
  const callPaginationApi = (pageNo, recordsPerPage) => {
    const paginationInfo = {
      recordsPerPage: recordsPerPage,
      reqPageIndex: pageNo,
    };
    setPaginationInfo(paginationInfo);
  };

  const showOtherScreen = (link, params) => {
    if (link === "boe-details") {
      setShowBoeDetails(true);
      setBoeDetailsParams(params);
    }
    if (link === "/no-of-boes") {
      setShowBoeNo(true);
      setBoeNoParams(params);
    }
  };

  var style = {
    position: "fixed",
    left: "0",
    bottom: "50px",
    height: "60px",
    width: "100%",
  };

  var phantom = {
    display: "block",
    height: "60px",
    width: "90%",
  };

  return (
    <div style={{marginBottom: '100px'}}>
      {toastState?.showToast && (
        <AlertPopup
          alertMsg={toastState?.toastMessage}
          alertType={toastState?.toastType}
          isAlertOpen={toastState?.showToast}
          onClose={() => {
            updateToastState({
              toastMessage: "",
              toastType: "",
              showToast: false,
            });
          }}
        />
      )}
      {state?.boe?.loader && <Loader />}
      {showBoeDetails && (
        <BoeDetails
          onClose={() => setShowBoeDetails(false)}
          params={boeDetailsParams}
        />
      )}
      {showBoeNo && (
        <BoeNo onClose={() => setShowBoeNo(false)} params={boeNoParams} />
      )}
      <div className="heading-container">
        <div className="left-container">
          {/* <div className="left-img-container">
            <img src={PreviousIcon} onClick={() => history.goBack()} />
      </div> */}
          <div className="breadcrumb-container">
            <Breadcrumbs itemsAfterCollapse={3} maxItems={3}>
              <Link className="breadcrumb-link" to="/dashboard">
                Trade Overview
              </Link>
              <Link
                className="breadcrumb-link active-breadcrumb-link"
                to="/"
                active
              >
                Bill Of Entry
              </Link>
            </Breadcrumbs>
            <span className="heading-text">Bill Of Entry</span>
          </div>
        </div>
      </div>
      <div className="tileCardContainer">
        <Grid className={`${classes.root}`} container spacing={3}>
          {list?.map((task, ind) => {
            return (
              <Grid key={ind} item>
                <Card
                  boe={true}
                  ind={ind}
                  task={task}
                  onClickNonExpired={(e) => {
                    onClickCardNonExp(e, task)
                    setLessthanSixMonth(true)
                    setGreaterthanSixMonth(false)
                    console.log('Hello')
                  }}
                  onClickExpired={(e) => {
                    onClickCardExp(e, task)
                    setGreaterthanSixMonth(true)
                    setLessthanSixMonth(false)
                    console.log('Bye')
                  }}
                  onClick={() => onClickBoe(task)}
                  active={task?.label === activeBoe}
                  toggleCardBorder = {lessthanSixMonths ? 'lessthanSixMonthsClicked' : greaterthanSixMonths ? 'greaterthanSixMonthsClicked' : ''}
                />
              </Grid>
            );
          })}
        </Grid>
      </div>
      <div className="boe-table">
        <AgGridTable
          onFilter={() => {
            updateFilterDisplay(!showFilter);
          }}
          selectedList={selectedRows}
          handleRowSelection={handleRowSelection}
          startRange={startRange}
          endRange={endRange}
          setStartRange={(startRange) => {
            setStartRange(startRange);
          }}
          setEndRange={(endRange) => {
            setEndRange(endRange);
          }}
          onSearch={(search) => {
            setSearchText(search.target.value);
            callPaginationApi(1, paginationInfo?.recordsPerPage);
          }}
          lessthanSixMonths = {lessthanSixMonths}
          greaterthanSixMonths = {greaterthanSixMonths}
          setLessthanSixMonth={(lessthanSixMonths) => {
            setLessthanSixMonth(lessthanSixMonths);
          }}
          setGreaterthanSixMonth = {(greaterthanSixMonths) => {
            setGreaterthanSixMonth(greaterthanSixMonths);
          }}
          headCells={headCells}
          rows={rowList}
          moreActionMenu={[
            {
              label: "Make Payment",
              link: "",
            },
            {
              label: "Regularise BOE",
              link: "",
            },
          ]}
          filterOptions={filterList}
          deleteFilterChip={(filterChip) => setDeleteFilterChip(filterChip)}
          clearAll={() => {
            setClearAll(true);
          }}
          getSelectedRows={(selRows) => {
            // setSelRows(selRows)
            updateSelectedRows(selRows);
          }}
          hideActionIcon={true}
          onDownload={() => {}}
          onSort={(sortBy, desc) => {
            getSorted(sortBy, desc);
          }}
          callPaginationApi={callPaginationApi}
          totalPage={totalPage}
          showOtherScreen={showOtherScreen}
        />
      </div>
      <FilterComponent
        showDrawer={showFilter}
        toggleDrawer={() => {
          updateFilterDisplay(!showFilter);
          setClearAll(false);
        }}
        getFilterList={(list) => {
          callPaginationApi(1, paginationInfo?.recordsPerPage);
          setFilterList(list);
        }}
        deleteFilterChip={deleteFilterChip}
        clearAll={clearAll}
        apiFilterOpts={(filterApiOpts) => {
          searchCriteria(filterApiOpts);
        }}
      />
      <Footer>
        <div className="selected" style={action === "REGULARISEBOE" || selectedRows?.length <= 0 ? {display: 'none'} : {display: 'flex'}}>
          <span>{`Transaction Selected: ${selectedRows?.length}`}</span>
          <div className="payment-button">
            <Button
              disabled={
                action === "REGULARISEBOE" ||
                selectedRows?.length <= 0 ||
                disableButton
              }
              onClick={() => {
                // checkValidation();
                onMakePayment();
              }}
            >
              Make Payment
            </Button>
          </div>
        </div>
      </Footer>
      {showModal && <MakePaymentModal />}
    </div>
  );
};

export default BillOfEntry;
