/* eslint-disable */
import React, { useEffect, useState } from "react";
import { Button } from "../../components/@subzero/glacier/package/lib/components";
import BottomDrawer from "../../components/bottomdrawer";
import { useHistory, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import ProgressTracker from "../../components/progresstracker";
import TransactionDetails from "./transaction_details";
import { Grid, TextField } from "@material-ui/core";
import PreviousIcon from "../../assets/icons/prev-icon.svg";
import ClockIcon from "../../assets/icons/clock.svg";
import "./index.css";
import AlertDialog from "../../components/dialog";
import BeneficiaryDetails from "./beneficiary_details";
import PaymentDetails from "./payment_details";
import AttachDocuments from "./attach_documents";
import Review from "./review";
import { Actions } from "../../store/rootActions";
import Footer from "../../components/stickyfooter";
import AlertPopup from "../../components/alertPopup/alertPopup";
import moment from "moment";
import CustomBreadcrumbs from "../../components/custombreadcrumbs";
import Loader from "../../components/loader";

let count1 = 0;

const MakePayment = (params) => {
  const history = useHistory();
  const location = useLocation();
  const dispatch = useDispatch();
  const [activeStep, setActiveStep] = useState(
    params?.location?.state?.activeStep || 0
  );
  const [selectedData] = useState(location?.state?.data);
  const [currency] = useState(selectedData?.[0]?.currency?.value);
  const boeDetails = useSelector((state) => state?.boe);
  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const reviewDetails = useSelector((state) => state?.paymentReviewData);
  const [showAlert, setShowAlert] = useState(false);
  const [showPrevAlert, setShowPrevAlert] = useState(false);
  const [showAuthMatrix, setshowAuthMatrix] = useState(false);
  const [authMatrixSubmitIsDisabled] = useState(true);
  const [loader, setLoader] = useState(false);
  const [totalRemittanceAndPayableAmount, setTotalRemittanceAndPayableAmount] =
    useState({
      totalRemittanceAmount: 0,
      totalPayableAmount: 0,
      selectBeneValue: "",
      proceedToNextStepper: false,
    });
  const steps = [
    { label: "Transaction Details" },
    { label: "Beneficiary Details", error: true },
    { label: "Payment Details" },
    { label: "Attach Documents" },
    { label: "Review & Submit" },
  ];
  const [beneInfo, setBeneInfo] = useState();
  const [paymentInfo, setPaymentInfo] = useState();
  const [isBeneInfoValid, setBeneInfoValid] = useState(true);
  const authData = JSON.parse(localStorage.getItem("authData"));
  const [selectedDeclration, updateDeclation] = useState(false);
  const [selectedTermsCondition, updateTermsCondition] = useState(false);
  const [disableProceed, updateProceedDisable] = useState(false);
  const [disableAuthorize, updateAuthorizeDisable] = useState(true);
  const [validateReview, setValidateReview] = useState(false);
  // state for managing the review page from success screen
  const [successTransactionView, updateSuccessTransactionView] =
    useState(false);

  useEffect(() => {
    if (location?.state?.successTransactionView) {
      setActiveStep(4);
      updateSuccessTransactionView(location?.state?.successTransactionView);
    }

    if (location?.state?.activeStep) {
      setActiveStep(location?.state?.activeStep);
    }
  }, [location?.state]);

  useEffect(() => {
    dispatch(Actions.saveCurrency(currency));
  }, []);

  const [proceedClickInfo, setproceedClickInfo] = useState({
    proceedClick: false,
    activeStep: 0,
  });

  useEffect(() => {
    if (
      reviewDetails?.validateDeals?.status === "Success" &&
      reviewDetails?.validateTxnAmt?.status === "Success"
    ) {
      setValidateReview(true);
    } else {
      // console.log(reviewDetails?.validateDeals);

      if (reviewDetails?.validateDeals?.status === "Fail") {
        setAlertMessage(reviewDetails?.validateDeals?.errorDescription);
        setAlertStatus(true);
      } else if (reviewDetails?.validateTxnAmt?.status === "Fail") {
        setAlertMessage(reviewDetails?.validateTxnAmt?.errorDescription);
        setAlertStatus(true);
      }
    }
  }, [reviewDetails.validateDeals, reviewDetails.validateTxnAmt]);

  useEffect(() => {
    if (validateReview) onProceed();
  }, [validateReview]);

  useEffect(() => {
    if (reviewDetails?.totalAmountValidationStatus) {
      // check totalAmountValidationStatus and disable authorize,bookrate  button accordingly
      if (
        reviewDetails?.totalAmountValidationStatus !== "Success" &&
        reviewDetails?.totalAmountValidationStatus !== null
      ) {
        updateAuthorizeDisable(true);

        // show soft alert here
        setAlertMessage(reviewDetails?.totalAmountValidationStatus);
        setAlertStatus(true);
      } else {
        updateAuthorizeDisable(false);
      }
    }
  }, [reviewDetails?.totalAmountValidationStatus]);

  useEffect(() => {
    // console.log(reviewDetails);
    if (reviewDetails?.dealAmountValidationStatus) {
      // check totalAmountValidationStatus and disable authorize,bookrate  button accordingly
      if (reviewDetails?.dealAmountValidationStatus !== "Success") {
        updateAuthorizeDisable(true);

        // show soft alert here
      } else {
        updateAuthorizeDisable(false);
      }
    }
  }, [reviewDetails?.dealAmountValidationStatus]);

  useEffect(() => {
    // console.log(reviewDetails);
    if (activeStep === 4) {
      // console.log(selectedDeclration);
      if (selectedDeclration) {
        updateProceedDisable(false);
        updateAuthorizeDisable(false);
      } else if (!params?.location?.state?.fromChannelRefNo) {
        updateProceedDisable(true);
        updateAuthorizeDisable(true);
      } else {
        updateProceedDisable(false);
        updateAuthorizeDisable(false);
      }
    } else {
      updateProceedDisable(false);
      updateAuthorizeDisable(false);
    }
  }, [activeStep, selectedDeclration]);

  const fileData = useSelector((state) => state?.attachDocuments?.documents);
  const [alertStatus, setAlertStatus] = useState(false);
  const [alertMsg, setAlertMessage] = useState("");
  const [topValues, setTopValues] = useState({
    modeOFProcess: authData?.docUploadWaiver === "DOCUMENTATION" ? "NO" : "YES",
    goodsType: "CAPITAL",
  });
  const [proceedOption, setProceedOption] = useState(false);

  const onTopValuesChange = (val) => {
    setTopValues(val);
  };

  const onSuccessValidation = () => {
    setProceedOption(true);
    onProceed();
  };

  const onCancelToPrev = () => {
    history.goBack();
  };

  const setRemittanceAndPayableAmount = (val) => {
    setTotalRemittanceAndPayableAmount(val);
  };

  const onSaveAsDraft = (e) => {
    const isButtonClick = e ? true : false;
    if (activeStep === 0) {
      if (transactionDetails.recKey) {
        if (
          transactionDetails?.transDetails?.find((x) => {
            return x.status === "SAVE";
          })
        ) {
          const req = transRequest();
          dispatch(Actions.proceedFromTransDraft(req, isButtonClick));
        }
      } else {
        //Disabled as per the request TJ
        /* if(transactionDetails?.transDetails?.length > 0){
          const req = {
            appDate: authData?.appDate,
            userId: authData?.userId,
            currency: currency,
            modeOfProcess: topValues.modeOFProcess,
            customerId: authData?.corpId,
            bankCode: authData?.bankCode,
            goodsType: topValues.goodsType,
            boeRequest: transactionDetails?.transDetails?.map((item) => {
              return {
                boeNumber: item.boeNumber,
                invoiceCurrency: item.invoiceCurrency,
                supplierName: item.supplierName,
              };
            }),
          };
          dispatch(Actions.saveAsDraft(req));
        } */
      }
    } else if (activeStep === 1) {
      if (beneInfo) {
        let {
          beneName,
          beneId,
          beneAddress1,
          beneAddress2,
          isThirdParty,
          beneAddress3,
          beneCountry,
          beneAccNo,
          beneTransit,
          beneSwiftCode,
          beneBankName,
          beneBankCountry,
          beneBankAddress,
          beneForeignSwiftCode,
          beneForeignBankName,
          beneForeignBankCountry,
        } = beneInfo;
        if (typeof beneName === "object") {
          beneName = beneName?.length === 1 ? beneName[0] : beneName;
        } else if (typeof beneAccNo === "object") {
          beneAccNo = beneAccNo?.length === 1 ? beneAccNo[0] : beneAccNo;
        }
        if (
          beneId &&
          typeof beneName === "string" &&
          typeof beneAccNo === "string"
        ) {
          // Save bene API
          const req = {
            userId: authData?.userId,
            corpId: authData?.corpId,
            bankCode: authData?.bankCode,
            fidbTnxId: transactionDetails?.recKey,
            beneficiaryName: beneName,
            beneficiaryId: beneId,
            address1: beneAddress1,
            address2: beneAddress2,
            address3: beneAddress3,
            country: beneCountry,
            beneficiaryACNo: beneAccNo,
            iBanNo: beneTransit,
            biccode: beneSwiftCode,
            bankName: beneBankName,
            bankCountry: beneBankCountry,
            bankAddress: beneBankAddress,
            bankSwiftCode: beneForeignSwiftCode,
            corresBankCountry: beneForeignBankCountry,
            corresBankName: beneForeignBankName,
            isThirdParty: isThirdParty,
            isSaveAsDraft: true,
            appDate: authData.appDate,
          };
          dispatch(Actions.saveBene(req, isButtonClick));
        }
      }
    } else if (activeStep === 2) {
      const req = paymentRequest();
      dispatch(Actions.savePaymentDetails(req, isButtonClick));
    }
  };

  const fetchStepperComp = () => {
    switch (activeStep) {
      case 0: {
        return (
          <TransactionDetails
            data={selectedData}
            onTopValuesChange={onTopValuesChange}
            setTotalRemittanceAndPayableAmount={setRemittanceAndPayableAmount}
            onSaveAsDraft={onSaveAsDraft}
          />
        );
      }

      case 1:
        return (
          <BeneficiaryDetails
            getBeneInfo={getBeneInfo}
            isValid={isBeneDetailValid}
            proceedClickInfo={proceedClickInfo}
            onSuccessValidation={onSuccessValidation}
            onSaveAsDraft={onSaveAsDraft}
          />
        );
      case 2:
        return (
          <PaymentDetails
            getPaymentInfo={getPaymentInfo}
            proceedClickInfo={proceedClickInfo}
            onSuccessValidation={onSuccessValidation}
            onSaveAsDraft={onSaveAsDraft}
          />
        );
      case 3:
        // return <AttachDocuments prefill={true} />;
        return <AttachDocuments />;
      case 4: {
        return (
          <Review
            redirectToTransaction={() => {
              setActiveStep(0);
            }}
            redirectToBeneficiary={() => {
              setActiveStep(1);
            }}
            redirectToPayment={() => {
              setActiveStep(2);
            }}
            redirectToAttachments={() => {
              setActiveStep(3);
            }}
            updateDeclation={() => {
              updateDeclation(!selectedDeclration);
            }}
            updateTermsCondition={() => {
              updateTermsCondition(!selectedTermsCondition);
            }}
            selectedDeclration={selectedDeclration}
            selectedTermsCondition={selectedTermsCondition}
            recKey={
              params?.location?.state?.recKey || transactionDetails.recKey
            } // passing recKey - for checker user from params and for maker user from transactionDetails.recKey
            statusCode={params?.location?.state?.statusCode}
            channelRefNo={params?.location?.state?.channelRefNo}
            successTransactionView={successTransactionView}
            fromChannelRefNo={params?.location?.state?.fromChannelRefNo}
            authorizeDisable={disableAuthorize}
          />
        );
      }

      default:
        return null;
    }
  };

  const getBeneInfo = (beneficiary) => {
    setBeneInfo(beneficiary);
  };

  useEffect(() => {
    onSaveAsDraft();
  }, [beneInfo, paymentInfo]);

  const isBeneDetailValid = (isValid) => {
    setBeneInfoValid(isValid);
  };

  const getPaymentInfo = (payment) => {
    setPaymentInfo(payment);
  };

  const onCancel = () => {
    if (activeStep === 0) {
      setShowPrevAlert(true);
    } else {
      setShowAlert(true);
    }
    window.scrollTo(0, 0);
  };

  const ontransSuccessCall = () => {
    if (!location?.state?.activeStep) {
      setActiveStep(activeStep + 1);
      window.scrollTo(0, 0);
    }
  };

  useEffect(() => {
    if (transactionDetails.proceedFromTrans === "success") {
      ontransSuccessCall();
      dispatch(Actions.clearStatus());
    }
  }, [transactionDetails.proceedFromTrans]);

  const transRequest = () => {
    return {
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      recKey: transactionDetails.recKey,
      goodsType: topValues.goodsType,
      modeOfProcess: topValues.modeOFProcess,
      totalAmount: totalRemittanceAndPayableAmount.totalRemittanceAmount,
      isSaveAsDraft: true,
      appDate: authData?.appDate,
      userId: authData?.userId,
    };
  };

  const paymentRequest = () => {
    const eefcAccounts = paymentInfo?.amountDetails?.paymentMode?.eefcAcc?.map(
      (item) => {
        return {
          accountNumber: item?.acc_no,
          amount: item?.amount,
        };
      }
    );
    const billOfEntry = paymentInfo?.boeDelayReasons?.map((item) => {
      return {
        billOfEntryNo: item?.boe_no
          ? Array.isArray(item?.boe_no)
            ? item?.boe_no?.map((boe) => boe?.id)
            : [item?.boe_no]
          : [],
        // delayReason: item?.delay_reason?.map((delay) => delay?.id),
        delayReason: item?.delay_reason,
        specifyOtherReason: item?.other_reason,
      };
    });
    const prebookedDeals = paymentInfo?.preBookDeals?.map((item) => {
      return {
        dealId: item?.id?.value,
        currencyPair: item?.currencyPair?.value,
        exchangeRate: item?.exchangeRate?.value,
        validTill: item?.validTill?.value,
        outstandingAmount: item?.osAmount?.value,
        amountToBeUtilized: item?.amountUtilised?.value,
        amountInINR: item?.amountInr?.value,
      };
    });
    const fwcbookDeals = paymentInfo?.fwcBookDeals?.map((item) => {
      return {
        dealId: item?.id?.value,
        currencyPair: item?.currencyPair?.value,
        exchangeRate: item?.exchangeRate?.value,
        validTill: item?.validTill?.value,
        outstandingAmount: item?.osAmount?.value,
        amountToBeUtilized: item?.amountUtilised?.value,
        amountInINR: item?.amountInr?.value,
        bookingDate: item?.bookingDate?.value,
      };
    });
    return {
      bankCode: authData?.bankCode,
      transType: "PAYREQ",
      accountType: paymentInfo?.amountDetails?.paymentMode?.selectedMode,
      fidbTnxId: transactionDetails?.recKey,
      remittanceAmount: paymentInfo?.amountDetails?.totalRemittanceAmount
        ? JSON.parse(paymentInfo?.amountDetails?.totalRemittanceAmount)
        : "",
      paymentDate: paymentInfo?.amountDetails?.paymentDate || "",
      tenorPeriod: paymentInfo?.amountDetails?.tenorPeriod
        ? JSON.parse(paymentInfo?.amountDetails?.tenorPeriod)
        : "",
      tenorIndicator: paymentInfo?.amountDetails?.tenorIndicator,
      dueDate: paymentInfo?.amountDetails?.dueDate
        ? paymentInfo?.amountDetails?.dueDate?.replace(/\//g, "-")
        : "",
      branchName: paymentInfo?.amountDetails?.branchName,
      paymentMode: paymentInfo?.amountDetails?.paymentMode?.mode,
      eefcAccounts: paymentInfo?.amountDetails?.paymentMode?.mode !== "Operative Account" ? eefcAccounts : [],
      operativeAccountNo:
        paymentInfo?.amountDetails?.paymentMode?.operativeAcc?.acc_no,
      operativeAccountAmount:
        paymentInfo?.amountDetails?.paymentMode?.mode !== "EEFC Account"
          ? paymentInfo?.amountDetails?.paymentMode?.operativeAcc?.amount
          : null,
      chargesAccountNumber: paymentInfo?.charges?.chargesAccNo,
      gstNumber: paymentInfo?.charges?.selectedGSTNo,
      foriegnBankCharge: paymentInfo?.charges?.foriegnBankCharges,
      reasonInsufFund:
        paymentInfo?.amountDetails?.paymentMode?.operativeAcc?.remarks,
      boeDelayReason: billOfEntry,
      preBookedDeals: prebookedDeals,
      fwcBookDeals: fwcbookDeals,
      sendRecievInstruction:
        paymentInfo?.otherDetails?.senderToRecieverInstrution,
      fxAmountUtilized: paymentInfo?.rateInstructions?.fxAmountUtilized,
      fcCreditAmount: paymentInfo?.rateInstructions?.fcCreditAmount,
      otherInfo: "",
      isSaveAsDraft: true,
      appDate: authData?.appDate,
      bookingDate: fwcbookDeals?.bookingDate ? fwcbookDeals?.bookingDate : "",
      customerId: authData?.corpId,
      userId: authData?.userId,
      branchCode: authData?.branchCode,
      customerCode:
        transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
      ieCode: transactionDetails?.custIdAndIeCode?.ieCode || authData?.ieCode,
    };
  };

  const validateReviewSubmit = () => {
    const req = {
      fidbtxnId: transactionDetails.recKey,
    };
    dispatch(Actions.validateDeals(req));
    const request = {
      fidbtxnId: transactionDetails.recKey,
      userId: authData?.userId,
      corpId: authData?.corpId,
    };
    dispatch(Actions.validateTxnAmountRange(request));
  };

  const onProcedFromTrans = () => {
    const req = transRequest();
    dispatch(Actions.proceedFromTrans(req));
    const reqData = {
      totalRemittance: totalRemittanceAndPayableAmount.totalRemittanceAmount,
      beneficiaryName: totalRemittanceAndPayableAmount.selectBeneValue,
      goodsType: topValues.goodsType,
    };
    dispatch(Actions.saveTotalRemittanceAndBene(reqData));
  };

  const getFirstFinalCheckerData = () => {
    let firstChecker = false;
    let finalChecker = false;

    const pre_acc_count = params?.location?.state?.statusCode?.slice(7);

    // setting first checker value
    if (pre_acc_count === 1) {
      firstChecker = true;
    }

    // setting final checker value
    if (pre_acc_count === authData?.checkerCount?.toString()) {
      finalChecker = true;
    }

    return { firstChecker, finalChecker };
  };

  const onAuthorize = () => {
    const checkerDetails = getFirstFinalCheckerData();
    if (
      (!checkerDetails?.firstChecker && !checkerDetails?.finalChecker) ||
      (checkerDetails?.firstChecker && !checkerDetails?.finalChecker)
    ) {
      history.push("/workflow-details", {
        recKey: params?.location?.state?.recKey,
        fromChannelRefNo: params?.location?.state?.fromChannelRefNo,
        channelRefNo: params?.location?.state?.channelRefNo,
        statusCode: params?.location?.state?.statusCode,
        finalChecker: checkerDetails?.finalChecker,
        firstChecker: checkerDetails?.firstChecker,
      });
    } else if (!checkerDetails?.firstChecker && checkerDetails?.finalChecker) {
      // call accept-reject api
      let req = {
        reckeys: [params?.location?.state?.recKey],
        workFlowId: "",
        groupId: "",
        requestFwdTo: "",
        corpId: authData?.corpId,
        userId: authData?.userId,
        isBookLater: reviewDetails?.tridbNumber ? "N" : "Y",
        subCustId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
        process: "ACCEPT",
      };
      dispatch(Actions.acceptReject(req));

      // redirecting to success page after succesfull authorization/rejection
      history.push({
        pathname: "/authorize-success",
        state: {
          channelRefNo: params?.location?.state?.channelRefNo,
          finalChecker: checkerDetails?.finalChecker,
        },
      });
    } else if (checkerDetails?.firstChecker && checkerDetails?.finalChecker) {
      // call accept-reject api
      let req = {
        reckeys: [params?.location?.state?.recKey],
        workFlowId: "",
        groupId: "",
        requestFwdTo: "",
        corpId: authData?.corpId,
        userId: authData?.userId,
        isBookLater: reviewDetails?.tridbNumber ? "N" : "Y",
        subCustId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
        process: "ACCEPT",
      };
      dispatch(Actions.acceptReject(req));

      //call addBeneDetailsOnCheckerApproval api
      if (
        reviewDetails?.beneAccDetails !== null &&
        reviewDetails?.beneDetails !== null
      ) {
        // bank or account data available in temp, call api to move to master
        if (
          reviewDetails?.beneAccDetails?.isBankAvailableInTemp ||
          reviewDetails?.beneDetails?.isBeneAvailableInTemp
        ) {
          const req = {
            status: "approved",
            beneficiaryId: reviewDetails?.beneAccDetails?.beneficiaryId,
            beneficiaryACNo: reviewDetails?.beneAccDetails?.accountNumber,
          };
          dispatch(Actions.addBeneDetailsOnCheckerApproval(req));
        }
      }

      // redirecting to success page after succesfull authorization/rejection
      history.push({
        pathname: "/authorize-success",
        state: {
          channelRefNo: params?.location?.state?.channelRefNo,
          finalChecker: checkerDetails?.finalChecker,
        },
      });
    }
  };

  const onReject = () => {
    // on reject,  which ever checker , show workflow
    const checkerDetails = getFirstFinalCheckerData();
    history.push("/workflow-details", {
      recKey: params?.location?.state?.recKey,
      fromChannelRefNo: params?.location?.state?.fromChannelRefNo,
      channelRefNo: params?.location?.state?.channelRefNo,
      statusCode: params?.location?.state?.statusCode,
      action: "reject",
      finalChecker: checkerDetails?.finalChecker,
      firstChecker: checkerDetails?.firstChecker,
    });
  };

  const onCancelCheckerReview = () => {
    history.goBack();
  };

  const onProceed = () => {
    setproceedClickInfo({
      proceedClick: true,
      activeStep: activeStep,
    });
    if (!proceedOption && (activeStep === 1 || activeStep === 2)) {
      return false;
    }
    if (!isBeneInfoValid) {
      return false;
    }
    setProceedOption(false);
    // On transaction details proceed.
    if (activeStep === 0) {
      if (
        totalRemittanceAndPayableAmount.proceedToNextStepper &&
        transactionDetails.recKey
      ) {
        onProcedFromTrans();
        dispatch(Actions.clearSaveCounter());
        dispatch(Actions.clearBeneAccNewDetails());
      } else {
        setAlertMessage("Additional details required.");
        setAlertStatus(true);
      }
    } else if (activeStep === 2) {
      const req = paymentRequest();
      dispatch(Actions.savePaymentDetails(req));
      setActiveStep(activeStep + 1);
      window.scrollTo(0, 0);
    }
    // for attach documents screen, do mandatory file validation
    else if (activeStep === 3) {
      // if authData.docUploadWaiver == "Paperless", then it id peperless and  no attachments are mandatory else it's paper based there are two conditions 1. if any document selected is type of additional details and pdf file , then proceed to next step, else, both Invoice document and transport document need to uploaded
      if (authData.docUploadWaiver !== "Paperless") {
        // validate mandatory files
        let additionalDocFound = false;
        let additionalDocName = "";
        let transportDocFound = false;
        let invoiceDocFound = false;
        fileData.forEach((file) => {
          if (
            file.checkList === "TRANSPORT" ||
            file.checkList?.id === "Transport Document"
          ) {
            transportDocFound = true;
          }
          if (
            file.checkList === "INVOICE" ||
            file.checkList?.id === "Invoice Document"
          ) {
            invoiceDocFound = true;
          }
          if (
            file.checkList === "ADDITIONAL" ||
            file.checkList?.id === "Additional Document"
          ) {
            if (!additionalDocFound) {
              additionalDocFound = true;
              additionalDocName = file?.file?.name;
            }
          }
        });

        // if additional details selected, and file is pdf, user can proceed
        if (
          additionalDocFound &&
          (additionalDocName.slice(-4) === ".pdf" ||
            additionalDocName.slice(-4) === ".PDF")
        ) {
          setActiveStep(activeStep + 1);
          window.scrollTo(0, 0);
        } else {
          if (transportDocFound === false || invoiceDocFound === false) {
            setAlertMessage(
              "Transport and invoice documents are mandatory to attach."
            );
            setAlertStatus(true);
            setTimeout(() => {
              setAlertStatus(false);
            }, 1000);
          } else {
            setActiveStep(activeStep + 1);
            window.scrollTo(0, 0);
          }
        }
      } else {
        setActiveStep(activeStep + 1);
        window.scrollTo(0, 0);
      }
    } else {
      // from review screen, show auth matrix screen modal
      if (activeStep === 4) {
        // setshowAuthMatrix(true);
        if (validateReview) {
          setValidateReview(false);
          dispatch(Actions.clearTxmAmtAndDealsStatus());
          history.push("/auth-matrix");
        } else {
          validateReviewSubmit();
        }
      } else if (activeStep === 1) {
        let {
          beneName,
          beneId,
          beneAddress1,
          beneAddress2,
          isThirdParty,
          beneAddress3,
          beneCountry,
          beneAccNo,
          beneTransit,
          beneSwiftCode,
          beneBankName,
          beneBankCountry,
          beneBankAddress,
          beneForeignSwiftCode,
          beneForeignBankName,
          beneForeignBankCountry,
        } = beneInfo;
        if (typeof beneName === "object") {
          beneName = beneName.length === 1 ? beneName[0] : beneName;
        } else if (typeof beneAccNo === "object") {
          beneAccNo = beneAccNo.length === 1 ? beneAccNo[0] : beneAccNo;
        }
        if (beneId) {
          // Save bene API
          const req = {
            userId: authData?.userId,
            corpId: authData?.corpId,
            bankCode: authData?.bankCode,
            fidbTnxId: transactionDetails?.recKey,
            beneficiaryName: beneName,
            beneficiaryId: beneId,
            address1: beneAddress1,
            address2: beneAddress2,
            address3: beneAddress3,
            country: beneCountry,
            beneficiaryACNo: beneAccNo,
            iBanNo: beneTransit,
            biccode: beneSwiftCode,
            bankName: beneBankName,
            bankCountry: beneBankCountry,
            bankAddress: beneBankAddress,
            bankSwiftCode: beneForeignSwiftCode,
            corresBankCountry: beneForeignBankCountry,
            corresBankName: beneForeignBankName,
            isThirdParty: isThirdParty,
            isSaveAsDraft: true,
            appDate: authData.appDate,
          };
          dispatch(Actions.saveBene(req));
          const request = {
            corpId: authData?.corpId,
            bankCode: authData?.bankCode,
            beneficaryName: beneName,
            beneficiaryId: beneId,
            beneficiaryACNo: beneAccNo,
            bankSwiftCode: beneForeignSwiftCode,
            bankName: beneBankName,
          };
          dispatch(Actions.checkBeneIfExist(request));
        } else {
          // ADD BENE API
          const request = {
            corpId: authData?.corpId,
            bankCode: authData?.bankCode,
            beneficaryName: beneName,
            beneficiaryId: beneId,
            beneficiaryACNo: beneAccNo,
            bankSwiftCode: beneForeignSwiftCode,
            bankName: beneBankName,
          };
          dispatch(Actions.checkBeneIfExist(request));
        }
        setActiveStep(activeStep + 1);
        window.scrollTo(0, 0);
      } else if (activeStep !== 0) {
        setActiveStep(activeStep + 1);
        window.scrollTo(0, 0);
      }
    }
    setproceedClickInfo({
      proceedClick: false,
      activeStep: activeStep,
    });
  };

  const onCloseAlertPopup = () => {
    setAlertStatus(false);
  };

  const onProceedCancel = () => {
    setShowAlert(false);
    setShowPrevAlert(false);
    window.scrollTo(0, 0);
    dispatch(Actions.clearSaveCounter());
    if (activeStep === 0) {
      const req = {
        userId: authData?.userId,
        corpId: authData?.corpId,
        bankCode: authData?.bankCode,
        fidbtxnId: transactionDetails.recKey,
      };
      dispatch(Actions.deleteTransactions(req));
      dispatch(Actions.clearSuccessStatus());
      history.goBack();
    } else {
      setActiveStep(activeStep - 1);
      dispatch(Actions.clearTxmAmtAndDealsStatus());
    }
  };

  useEffect(() => {
    setLoader(transactionDetails.loader);
  }, [transactionDetails.loader]);

  useEffect(() => {
    if (reviewDetails) {
      if (count1 === 0) {
        count1++;
        // if paymentMode !== "EEFC Account" cacluate fxRateAmount
        if (reviewDetails?.paymentMode !== "EEFC Account") {
          //  call getCardRate api

          const req = {
            paymentDate: authData.appDate,
            fixedCurrencyCode: "INR",
            variableCurrencyCode: currency,
          };
          dispatch(Actions.getCardRate(req));
          console.log("calling getCardRate api aaa");
        }
      }
    }
  }, [reviewDetails]);

  // const convertCurrency = (amt) => {
  //   const req = {
  //     currencyTyp: reviewDetails?.paymentDetails?.currency,
  //     amount: amt,
  //     baseCurrency: "INR",
  //     bankCode: authData?.bankCode,
  //   };
  //   dispatch(Actions.currencyConvert(req));
  // };

  // useEffect(() => {
  //   if (props?.fxRateAmount) {
  //     convertCurrency(props?.fxRateAmount);
  //   }
  // }, [reviewDetails?.cardRate]);

  useEffect(() => {
    if (
      (boeDetails?.bankBeneStatus?.isNewBankAccountDetail ||
        boeDetails?.bankBeneStatus?.isNewBeneficiaryDetail) &&
      beneInfo
    ) {
      const req = {
        isBeneNewEntry: boeDetails?.bankBeneStatus?.isNewBeneficiaryDetail,
        isBankNewEntry: boeDetails?.bankBeneStatus?.isNewBankAccountDetail,
        custId: authData?.corpId,
        bankcode: authData?.bankCode,
        beneficiaryName:
          typeof beneInfo?.beneName === "object" &&
          beneInfo?.beneName.length === 1
            ? beneInfo?.beneName[0]
            : beneInfo?.beneName,
        address1: beneInfo?.beneAddress1,
        address2: beneInfo?.beneAddress2,
        country: beneInfo?.beneCountry,
        action: "ADD",
        city: "",
        branchcode: "",
        beneficiaryId: beneInfo?.beneId,
        beneficiaryACNo: beneInfo?.beneAccNo,
        iBanNo: beneInfo?.beneTransit,
        biccode: beneInfo?.beneSwiftCode,
        bankName: beneInfo?.beneBankName,
        bankCountry: beneInfo?.beneBankCountry,
        bankAddress: beneInfo?.beneBankAddress,
        createdBy: authData?.userId,
        lastUpdatedBy: authData?.userId,
      };
      dispatch(Actions.addBeneOrBankToTemp(req));
    }
  }, [boeDetails?.bankBeneStatus]);

  useEffect(() => {
    if (
      boeDetails?.tempInsertStatus &&
      boeDetails?.tempInsertStatus?.beneficiaryId && beneInfo
    ) {
      let {
        beneName,
        beneId,
        beneAddress1,
        beneAddress2,
        isThirdParty,
        beneAddress3,
        beneCountry,
        beneAccNo,
        beneTransit,
        beneSwiftCode,
        beneBankName,
        beneBankCountry,
        beneBankAddress,
        beneForeignSwiftCode,
        beneForeignBankName,
        beneForeignBankCountry,
      } = beneInfo;
      if (typeof beneName === "object") {
        beneName = beneName.length === 1 ? beneName[0] : beneName;
      } else if (typeof beneAccNo === "object") {
        beneAccNo = beneAccNo.length === 1 ? beneAccNo[0] : beneAccNo;
      }
      if (boeDetails?.tempInsertStatus?.beneficiaryId != beneId) {
        // Save bene API
        const req = {
          userId: authData?.userId,
          corpId: authData?.corpId,
          bankCode: authData?.bankCode,
          fidbTnxId: transactionDetails?.recKey,
          beneficiaryName: beneName,
          beneficiaryId: boeDetails?.tempInsertStatus?.beneficiaryId,
          address1: beneAddress1,
          address2: beneAddress2,
          address3: beneAddress3,
          country: beneCountry,
          beneficiaryACNo: beneAccNo,
          iBanNo: beneTransit,
          biccode: beneSwiftCode,
          bankName: beneBankName,
          bankCountry: beneBankCountry,
          bankAddress: beneBankAddress,
          bankSwiftCode: beneForeignSwiftCode,
          corresBankCountry: beneForeignBankCountry,
          corresBankName: beneForeignBankName,
          isThirdParty: isThirdParty,
          isSaveAsDraft: true,
          appDate: authData.appDate,
        };
        dispatch(Actions.saveBene(req));
      }
    }
  }, [boeDetails?.tempInsertStatus]);

  return (
    <div>
      {loader && <Loader />}
      <div className="heading-container">
        <div className="left-container">
          {/* <div className="left-img-container">
            <img
              src={PreviousIcon}
              onClick={() => {
                setShowPrevAlert(true);
              }}
            />
            </div> */}
          <div className="breadcrumb-container" style={{ paddingLeft: "0px" }}>
            <CustomBreadcrumbs
              items={[
                { name: "Trade Overview", path: "/dashboard" },
                { name: "Bill Of Entry", path: "/boe" },
                { name: "Make Payment", path: "/" },
              ]}
            />
            <span className="heading-text">FIDB Make Payment</span>
          </div>
        </div>
      </div>
      {/* Show stepper only for maker */}
      {!successTransactionView && authData.userRoleType === "M" && (
        <ProgressTracker steps={steps} activeStep={activeStep} />
      )}

      {fetchStepperComp()}

      {/* Maker Review start */}
      {authData.userRoleType === "M" && (
        <Footer>
          <div className="make-payment-footer">
            <Grid container spacing={3}>
              <Grid item lg={3} md={3} sm={3} xs={12}>
                {!successTransactionView &&
                  (activeStep === 0 ||
                    activeStep === 1 ||
                    activeStep === 2) && (
                    <div className="draft-container">
                      <span className="save-as-draft">
                        <Button
                          textButton={true}
                          id="saveAsDraft"
                          onClick={onSaveAsDraft}
                        >
                          SAVE AS DRAFT
                        </Button>
                      </span>
                      <div className="drafts-time-container">
                        <img src={ClockIcon} />
                        <span className="drafts-time">
                          Saved 30 seconds ago
                        </span>
                      </div>
                    </div>
                  )}
              </Grid>
              {activeStep !== 1 &&
              activeStep !== 3 &&
              activeStep !== 2 &&
              activeStep !== 4 &&
              !successTransactionView ? (
                <>
                  <Grid item lg={5} md={5} sm={3} xs={12}>
                    <div className="amount-container">
                      <div className="sub-amount-container">
                        <span>Total Remittance Amount</span>
                        <span>
                          <span className="currency">{currency} </span>
                          {
                            totalRemittanceAndPayableAmount.totalRemittanceAmount
                          }
                        </span>
                      </div>
                      <div className="sub-amount-container">
                        <span>Pending Payment Instruction</span>
                        <span>
                          <span className="currency">{currency} </span>
                          {totalRemittanceAndPayableAmount.totalPayableAmount}
                        </span>
                      </div>
                    </div>
                  </Grid>
                  <Grid
                    item
                    lg={4}
                    md={4}
                    sm={4}
                    xs={12}
                    className="make-payment-buttons-parent"
                    s
                  >
                    <div className="make-payment-buttons">
                      <Button
                        color="secondary"
                        onClick={onCancel}
                        className="cancelBtn"
                      >
                        Cancel
                      </Button>
                      <Button
                        onClick={onProceed}
                        disabled={disableProceed}
                        className="proceedBtn"
                      >
                        Proceed
                      </Button>
                    </div>
                  </Grid>
                </>
              ) : (
                <Grid
                  item
                  lg={9}
                  md={6}
                  sm={12}
                  xs={12}
                  className="make-payment-buttons-parent"
                >
                  {!params?.location?.state?.fromChannelRefNo && (
                    <div className="make-payment-buttons">
                      <Button color="secondary" onClick={onCancel}>
                        Cancel
                      </Button>
                      <Button onClick={onProceed} disabled={disableProceed}>
                        Proceed
                      </Button>
                    </div>
                  )}
                  {params?.location?.state?.fromChannelRefNo && (
                    <div className="make-payment-buttons">
                      <Button color="secondary" onClick={onCancelToPrev}>
                        Cancel
                      </Button>
                    </div>
                  )}
                </Grid>
              )}
            </Grid>
            {
              <AlertDialog
                show={showAlert || showPrevAlert}
                onClose={() => {
                  setShowPrevAlert(false);
                  setShowAlert(false);
                }}
                onAction={onProceedCancel}
                actionButtonLabel={"Yes"}
                title={
                  (showPrevAlert &&
                    activeStep === 0 &&
                    "Are you sure you want to go back to Bill Of Entry?") ||
                  ((showAlert || (showPrevAlert && activeStep !== 0)) &&
                    "Are you sure you want to cancel?")
                }
                content={"Please Save as Draft to pick up from where you left!"}
              />
            }
          </div>
        </Footer>
      )}
      {/* Maker Review End */}

      {/* Checker Review (Using faster processing (Paper-based) as master) start */}
      {authData.userRoleType === "C" && (
        <Footer>
          <div className="make-payment-footer">
            <Grid container spacing={3}>
              <Grid item lg={3} md={3} sm={12}>
                <div className="draft-container">
                  <span
                    className="save-as-draft"
                    onClick={onCancelCheckerReview}
                  >
                    Cancel
                  </span>
                </div>
              </Grid>
              <Grid item lg={9} md={6} sm={12} xs={12}>
                <div className="make-payment-buttons">
                  <Button color="secondary" onClick={onReject}>
                    Reject
                  </Button>
                  <Button onClick={onAuthorize} disabled={disableAuthorize}>
                    Authorize
                  </Button>
                </div>
              </Grid>
            </Grid>
            {
              <AlertDialog
                show={showAlert || showPrevAlert}
                onClose={() => {
                  setShowPrevAlert(false);
                  setShowAlert(false);
                }}
                onAction={onProceedCancel}
                actionButtonLabel={"Yes"}
                title={
                  (showPrevAlert &&
                    activeStep === 0 &&
                    "Are you sure you want to go back to Bill Of Entry?") ||
                  ((showAlert || (showPrevAlert && activeStep !== 0)) &&
                    "Are you sure you want to cancel?")
                }
                content={"Please Save as Draft to pick up from where you left!"}
              />
            }
          </div>
        </Footer>
      )}
      {/* Checker Review (Using faster processing (Paper-based) as master) end */}

      <BottomDrawer
        title="Workflow Details"
        showDrawer={showAuthMatrix}
        toggleDrawer={() => {
          setshowAuthMatrix(false);
        }}
        showFooterButtons={true}
        secondaryAction="Close"
        resetAction={() => {
          setshowAuthMatrix(false);
        }}
        disabledPrimary={authMatrixSubmitIsDisabled}
        primaryAction="Submit"
      >
        <div className="bottom-drawer-box">
          {/* <Grid container>
            <Grid item lg={8}> */}
          <div className="border-container">
            <Grid container>
              <Grid item lg={12} className="full-width-textField ">
                <TextField
                  inputMode="none"
                  label="Remarks for Checker (Optional)"
                  name="Remarks for Checker (Optional)"
                  type="text"
                  // variant="filled"
                  fullWidth
                  value={"lorem ipsum"}
                  maxLength={1000}
                />
              </Grid>
            </Grid>
          </div>
          {/* </Grid>
          </Grid> */}
        </div>
      </BottomDrawer>
      {alertStatus && (
        <AlertPopup
          alertMsg={alertMsg}
          alertType={"warn"}
          isAlertOpen={true}
          onClose={onCloseAlertPopup}
        />
      )}
    </div>
  );
};

export default MakePayment;
