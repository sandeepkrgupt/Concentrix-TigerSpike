/*eslint-disable */
import React, { useEffect, useState, useRef } from "react";
import { Button, Checkbox, TextField } from "../../../components/@subzero/glacier/package/lib/components";
import "./index.css";
import SearchIcon from "../../../assets/icons/search-pink.svg";
import { makeStyles } from "@material-ui/core/styles";
import { Drawer, Paper, Grid } from "@material-ui/core";
import CloseIcon from "../../../assets/icons/close.svg";
import AgGridTable from "../../../components/aggridtable";
import SearchInput from "../../../components/searchinput";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";
import Customdropdown from "../../../components/customdropdown";
import AlertPopup from "../../../components/alertPopup/alertPopup";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "64%",
    alignItems: "center",
    display: "flex",
    flexDirection: "column",
    alignSelf: "center",
    marginTop: "48px",
  },
  paper: {
    width: "100%",
    paddingBottom: theme.spacing(2),
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
}));

const BeneficiaryDetails = (props) => {
  const dispatch = useDispatch();
  const [beneNameError, setbeneNameError] = useState(false);
  const [accountFieldsDisabled, setAccountFieldsDisabled] = useState(false);
  const [searchModal, setSearchModal] = useState(false);
  const [rowList, updateRowList] = useState([]);
  const [freqRowList, updateFreqRowList] = useState([]);
  const [selRows, setSelRows] = useState([]);
  const [selFreqRows, setSelFreqRows] = useState([]);
  const classes = useStyles();
  const state = useSelector((state) => state?.boe);
  const toastState = useSelector((state) => state?.toast);
  const authData = JSON.parse(localStorage.getItem("authData"));
  const { userId, corpId, bankCode } = authData;
  const [bankSwiftCode, setSwiftCode] = useState(null);
  const [bankName, setBankName] = useState(null);
  const [bankCountry, setBankCountry] = useState(null);
  const [bankBranch, setBankBranch] = useState(null);
  const [benefOptions, setBenefOptions] = useState([]);
  const [fieldDisabled, setFieldDisabled] = useState(false);
  const [isThirdParty, setIsThirdParty] = useState(false);
  const [selectedBene, setSelectedBene] = useState({});
  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const [beneficiary, setBeneficiary] = useState({
    beneName: "",
    beneAddress1: "",
    beneAddress2: "",
    beneAddress3: "",
    beneCountry: "",
    beneAccNo: "",
    beneTransit: "",
    beneSwiftCode: "",
    beneBankName: "",
    beneBankCountry: "",
    beneBankAddress: "",
    beneForeignSwiftCode: "",
    beneForeignBankName: "",
    beneForeignBankCountry: "",
    isThirdParty: false,
  });
  const [searchBankCorr, setSearchBankCorr] = useState(null);
  const [selAccountNumbr, updateSelAccountNumbr] = useState(null);
  const [tableRowChanges, updateTableRowChanges] = useState(null);
  const paymentState = useSelector((state) => state?.paymentReviewData);
  const paymentStateRef = useRef(paymentState); //  reference value to get previous state
  const paperless = authData?.docUploadWaiver === "Paperless" ? true : false;
  const [alert, setAlert] = useState({
    alertMsg: "Fill out the mandatory fields",
    alertType: "warn",
    isAlertOpen: false,
  });

  useEffect(() =>{
    if(beneficiary?.beneAccNo === ""){
      updateSelAccountNumbr({
        label: "",
        id: "",
      });
      setAccountFieldsDisabled(false);
    }
  },[beneficiary?.beneAccNo])

  useEffect(() => {
    clearAll();
    getFetchBenefOptions(transactionDetails?.selectBeneValue ? true : false);
    if (transactionDetails?.recKey) {
      const req = {
        corpId: authData?.corpId,
        userId: authData?.userId,
        bankCode: authData?.bankCode,
        recKey: transactionDetails?.recKey,
      };
      dispatch(Actions.getBeneficiaryReviewData(req));
    }
  }, []);

  useEffect(() => {
    if (beneficiary?.beneCountry && beneficiary?.beneCountry !=="" && beneficiary?.beneBankCountry && beneficiary?.beneBankCountry !== "") {
      if (beneficiary?.beneCountry.replaceAll(" ","") !== beneficiary?.beneBankCountry.replaceAll(" ","") && 
      (beneficiary?.beneCountry?.split("-")[0].replaceAll(" ","") !== beneficiary?.beneBankCountry.replaceAll(" ",""))) {
        setAlert({
          ...alert,
          alertType: "warn",
          alertMsg:
            "Bene Country and Bene Bank country are different, please re check",
          isAlertOpen: true,
        });
      }
    }
  }, [beneficiary?.beneCountry, beneficiary?.beneBankCountry]);

  useEffect(() => {
    const beneficiaryDetails = paymentState.beneficiaryDetails;
    if (
      beneficiaryDetails &&
      paymentStateRef?.current?.beneficiaryDetails !== beneficiaryDetails
    ) {
      // updating state ref value
      paymentStateRef.current = paymentState;
      const responseData = {
        beneName: beneficiaryDetails?.beneficiaryName,
        beneAddress1: beneficiaryDetails?.beneAddress1,
        beneAddress2: beneficiaryDetails?.beneAddress2,
        beneAddress3: beneficiaryDetails?.beneAddress3,
        beneCountry: beneficiaryDetails?.countryCode,
        beneAccNo: beneficiaryDetails?.beneBankAccountNumber,
        beneTransit: beneficiaryDetails?.beneIbanNumber,
        beneSwiftCode: beneficiaryDetails?.beneBankSwiftCode,
        beneBankName: beneficiaryDetails?.beneBankName,
        beneBankCountry: beneficiaryDetails?.beneBankCountry,
        beneBankAddress: beneficiaryDetails?.beneBankAddress,
        isThirdParty: beneficiaryDetails?.thirdPartyPayment,
        beneForeignSwiftCode: beneficiaryDetails?.coresBankSwiftCode,
        beneForeignBankName: beneficiaryDetails?.corresBankName,
        beneForeignBankCountry: beneficiaryDetails?.corresBankCountry,
      };
      setBeneficiary(responseData);
      updateSelAccountNumbr({
        label: beneficiaryDetails?.beneBankAccountNumber,
        id: beneficiaryDetails?.beneBankAccountNumber,
      });
      setIsThirdParty(beneficiaryDetails?.thirdPartyPayment);
      if (beneficiaryDetails?.beneficiaryId) {
        const benfName = {
          label: beneficiaryDetails?.beneficiaryName,
          id: beneficiaryDetails?.beneficiaryId,
        };
        onSelectBenefOption(benfName);
      }
      if(beneficiaryDetails?.beneBankAccountNumber){
        setAccountFieldsDisabled(true);
      }
    }
  }, [paymentState]);

  const getFetchBenefOptions = (valueExist) => {
    let req;
    if (valueExist) {
      req = {
        userId: userId,
        custId: corpId,
        bankCode: bankCode,
        beneficiaryNames: transactionDetails?.selectBeneValue,
      };
    } else {
      req = {
        userId: userId,
        corpId: corpId,
        bankCode: bankCode,
        status: 0,
      };
    }
    dispatch(Actions.getFetchBenefDropdown(req));
  };

  const getBenefOptions = (val ,flag) => {
    //Dropdown API WHEN INPUTTING benef name
    const req = {
      userId: userId,
      corpId: corpId,
      bankCode: bankCode,
      beneficiaryName: val,
      isThirdPartyPayment: flag === undefined ? isThirdParty : flag,
    };
    dispatch(Actions.getBenefDropdown(req));
  };

  useEffect(() => {
    setBenefOptions(state?.benefOptions);
    if (state?.benefOptions?.length === 1) {
      onSelectBenefOption(state?.benefOptions[0]);
      let tempBene = { ...beneficiary };
      tempBene["beneId"] = state?.benefOptions[0]?.id;
      tempBene["beneName"] = state?.benefOptions[0]?.label;
      setBeneficiary(tempBene);
    }
  }, [state?.benefOptions]);

  useEffect(() => {
    if(!accountFieldsDisabled){
      const updatedState = { ...beneficiary};
      updatedState.beneTransit= "";
      updatedState.beneSwiftCode= "";
      updatedState.beneBankName= "";
      updatedState.beneBankCountry="";
      updatedState.beneBankAddress= "";
      setBeneficiary(updatedState);
    }
  },[accountFieldsDisabled])

  useEffect(() => {
    setbeneNameError(state?.beneNameError);
  }, [state?.beneNameError]);

  useEffect(() => {
    generateTableData();
    generateFreqTableData();
  }, [state?.fetchBankDetails]);

  useEffect(() => {
    if (selRows?.length > 0) {
      generateTableData();
      generateFreqTableData();
    }
  }, [selRows]);

  useEffect(() => {
    if (selectedBene?.id) {
      setFieldDisabled(true);
    } else {
      setFieldDisabled(false);
    }
  }, [selectedBene]);

  useEffect(() => {
    if (benefOptions?.length === 0) {
      setFieldDisabled(false);
    }
  }, [benefOptions]);

  const onSelectBenefOption = (benfOption) => {
    setSelectedBene(benfOption);
    const { id, label } = benfOption;
    if (id) {
      const req = {
        userId: userId,
        corpId: corpId,
        bankCode: bankCode,
        beneficiaryId: id,
        beneficiaryName: label,
      };
      //On select benef option API
      dispatch(Actions.getBenefDetails(req));
    }
  };

  const onSearchBank = (isCorresponding) => {
    setSearchBankCorr(isCorresponding);
    //Fetch bank details API
    dispatch(Actions.clearFetchBankDetails());
    fetchBankDetailsAPI(true);
    generateTableData();
    generateFreqTableData();
    setSearchModal(true);
  };

  const fetchBankDetailsAPI = (flag) => {
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      biccode: bankSwiftCode,
      bankName: flag ? "" : bankName,
      branchName: bankBranch,
      country: bankCountry,
    };
    dispatch(Actions.fetchBankDetails(req));
  };

  const addBankApi = () => {
    const selBank = selRows[0];
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankName: selBank?.bankName?.value,
      branchName: selBank?.branch?.value,
      address1: selBank?.address?.value,
      bicCode: selBank?.swiftCode?.value,
      country: selBank?.bankCountry?.value
        ? findCountryName(selBank?.bankCountry?.value, true)
        : "",
    };
    dispatch(Actions.addBank(req, searchBankCorr));
  };

  const bankSwiftCodeApi = (swiftVal, corresponding) => {
    if(swiftVal !== ""){
      const req = {
        bicCode: swiftVal,
        input1: "",
        input2: "",
        input3: "",
      };
      dispatch(Actions.bankSwiftCode(req, corresponding));
    }
  };

  const updateBeneAccApi = (accNo) => {
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      beneficiaryId: selectedBene?.id,
      beneficiaryACNo: accNo,
    };
    dispatch(Actions.updateBeneAcc(req));
  };

  const toggleDrawer = (open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    setSearchModal(open);
  };

  const getFreqRows = () => {
    const lastTransactions =
      state?.fetchBankDetails?.lastThreeTransactiondetails;
    if (lastTransactions?.length > 0) {
      return lastTransactions?.map((resp, id) => {
        const { bankName, branchName, address1, address2, country, biccode } =
          resp;
        const branchNameAddress = branchName
          ? branchName
          : address1
          ? `${address1} ${address2 ? `, ${address2}` : ""}`
          : "";
        return createData(
          `freq${id}`,
          bankName,
          branchNameAddress,
          country,
          biccode,
          branchName,
          address1
        );
      });
    } else {
      return [];
    }
  };

  const getRows = () => {
    const searchBanks = state?.fetchBankDetails?.beneficiaryBankDetails;
    if (searchBanks?.length > 0) {
      return searchBanks?.map((resp, id) => {
        const { bankName, branchName, address1, address2, country, bicCode, countryCode } =
          resp;
        const branchNameAddress = branchName
          ? branchName
          : address1
          ? `${address1} ${address2 ? `, ${address2}` : ""}`
          : "";
        return createData(
          `search${id}`,
          bankName,
          branchNameAddress,
          country,
          bicCode,
          branchName,
          address1,
          countryCode
        );
      });
    } else {
      return [];
    }
  };
  const generateFreqTableData = () => {
    const freqRows = getFreqRows();
    const newArray = [...freqRows];
    const resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        const value = rowItem[key];
        switch (key) {
          default:
            return (newObject[key] = { value: value });
        }
      });
      newObject["radio"] = {
        value: rowItem?.id === selRows[0]?.id?.value,
        smallCell: true,
      };
      resultArray.push(newObject);
      return newObject;
    });
    updateFreqRowList(resultArray);
  };

  const findCountryName = (code, isIdRequired) => {
    if(code){
      if (isIdRequired) {
        return state?.benefCountryOptions?.find((item) => {
          if(code.includes("-")){
            code = code.replaceAll(" ","")
          }
          return item.label.replaceAll(" ","") === code;
        })?.id;
      } else
        return state?.benefCountryOptions?.find((item) => {
          if(code.includes("-")){
            code = code.split("-")[0].trim();
          }
          return item.id === code;
        })?.label;
    }else{
      return "";
    }
  };

  const [fieldsToBeValidated, setFieldsToBeValidated] = useState({
    beneName: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneAddress1: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneAddress2: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneCountry: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneAccNo: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneSwiftCode: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneBankName: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneBankCountry: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    beneBankAddress: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
  });

  const checkFieldValidationNeeded = (item) => {
    let includeField = false;
    if (fieldsToBeValidated[item]) {
      if (paperless) {
        includeField = fieldsToBeValidated[item].mandatoryOnPaperless;
      } else {
        if (!transactionDetails?.standardProcessing) {
          includeField = fieldsToBeValidated[item].mandatoryOnFastProcessing;
        } else {
          includeField =
            fieldsToBeValidated[item].mandatoryOnStandardProcessing;
        }
      }
      if (includeField) {
        if (fieldsToBeValidated[item].mandatoryBasedOnCondition !== "") {
          includeField = eval(
            fieldsToBeValidated[item].mandatoryBasedOnCondition
          );
        }
      }
    }
    return includeField;
  };

  const validateBeneDetailsFields = () => {
    let validationStatus = true;
    const filteredFields = Object.keys(fieldsToBeValidated)?.filter((item) => {
      return checkFieldValidationNeeded(item);
    });
    if (fieldDisabled) {
      [
        "beneAddress1",
        "beneAddress2",
        "beneCountry"
      ].forEach((item) => {
        filteredFields.splice(filteredFields.indexOf(item), 1);
      });
    }
    if(accountFieldsDisabled){
      [
        "beneSwiftCode",
        "beneBankName",
        "beneBankCountry",
        "beneBankAddress",
      ].forEach((item) => {
        filteredFields.splice(filteredFields.indexOf(item), 1);
      });
    }
    filteredFields.forEach((item) => {
      if (!beneficiary[item]) {
        const newChange = { ...fieldsToBeValidated };
        newChange[item].validationFailed = true;
        setFieldsToBeValidated(newChange);
        validationStatus = false;
      }
    });
    return validationStatus;
  };

  useEffect(() => {
    if (
      props?.proceedClickInfo?.proceedClick &&
      props?.proceedClickInfo?.activeStep === 1
    ) {
      if (validateBeneDetailsFields()) {
        props.onSuccessValidation();
      } else {
        setAlert({
          ...alert,
          alertType: "warn",
          alertMsg: "Fill out the mandatory fields",
          isAlertOpen: true,
        });
      }
    }
  }, [props?.proceedClickInfo]);

  const generateTableData = () => {
    const searchRows = getRows();
    const newFreqArray = [...searchRows];
    const resultFreqArray = [];
    newFreqArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        let value = rowItem[key];
        value = value ? value : "";
        switch (key) {
          case "bankCountry":
            if (value) {
              value = rowItem["countryCode"] ? `${rowItem["countryCode"]} - ${value}` : value;
            }
            return (newObject[key] = { value: value });
          default:
            return (newObject[key] = { value: value });
        }
      });
      newObject["radio"] = {
        value: rowItem?.id === selRows[0]?.id?.value,
        smallCell: true,
      };
      resultFreqArray.push(newObject);
      return newObject;
    });
    updateRowList(resultFreqArray);
  };

  function createData(
    id,
    bankName,
    branchName,
    bankCountry,
    swiftCode,
    branch,
    address,
    countryCode
  ) {
    return {
      id,
      bankName,
      branchName,
      bankCountry,
      swiftCode,
      branch,
      address,
      countryCode
    };
  }

  const headCells = [
    { field: "radio", label: "" },
    { field: "bankName", label: "Bank Name" },
    { field: "branchName", label: "Branch Name/Address" },
    { field: "bankCountry", label: "Bank Country" },
    { field: "swiftCode", label: "Bank Swift Code" },
  ];

  useEffect(() => {
    const updatedRows = rowList?.map((rowItem) => {
      if (selRows[0]?.id?.value === rowItem?.id?.value) {
        rowItem.radio.value = true;
      } else {
        rowItem.radio.value = false;
      }
      return rowItem;
    });
    updateRowList(updatedRows);
    updateTableRowChanges(!tableRowChanges);
  }, [selRows]);

  useEffect(() => {
    const updatedFreqRows = freqRowList?.map((rowItem) => {
      if (selFreqRows[0]?.id?.value === rowItem?.id?.value) {
        rowItem.radio.value = true;
      } else {
        rowItem.radio.value = false;
      }
      return rowItem;
    });
    updateFreqRowList(updatedFreqRows);
  }, [selFreqRows]);

  const setFieldValidation = (val, keyName) => {
    const newChange = { ...fieldsToBeValidated };
    if (checkFieldValidationNeeded(keyName)) {
      if (val === "") {
        newChange[keyName].validationFailed = true;
      } else {
        newChange[keyName].validationFailed = false;
      }
    } else {
      if (newChange[keyName]) {
        newChange[keyName].validationFailed = false;
      }
    }
    setFieldsToBeValidated(newChange);
  };

  const settingBeneValue = (item, val) => {
    setFieldValidation(val, item);
    let tempBene = { ...beneficiary };
    tempBene[item] = val;
    setBeneficiary(tempBene);
  };

  useEffect(() => {
    props?.getBeneInfo(beneficiary);
  }, [beneficiary]);

  useEffect(() => {
    let tempBene = { ...beneficiary };
    let countryCode;
    if(state?.benefDetails?.country && state?.benefDetails?.country?.includes("-")){
      countryCode = state?.benefDetails?.country.split("-")[0].trim();
    }
    tempBene["beneAddress1"] = state?.benefDetails?.address1;
    tempBene["beneAddress2"] = state?.benefDetails?.address2;
    tempBene["beneAddress3"] = state?.benefDetails?.address3;
    tempBene["beneCountry"] = countryCode || state?.benefDetails?.country;
    tempBene["accountNumber"] = state?.benefDetails?.accountNumber;
    setBeneficiary(tempBene);
  }, [state?.benefDetails]);

  useEffect(() => {
    let tempBene = { ...beneficiary };
    let countryCode;
    if(state?.bankSwiftCodeDetails?.countryCode && state?.bankSwiftCodeDetails?.countryCode?.includes("-")){
      countryCode = state?.bankSwiftCodeDetails?.countryCode?.split("-")[0].trim();
    }
    tempBene["beneBankName"] = state?.bankSwiftCodeDetails?.bankName;
    tempBene["beneBankCountry"] = countryCode || state?.bankSwiftCodeDetails?.countryCode;
    tempBene["beneBankAddress"] = state?.bankSwiftCodeDetails?.bankAddress;
    setBeneficiary(tempBene);
  }, [state?.bankSwiftCodeDetails]);

  useEffect(() => {
    let tempBene = { ...beneficiary };
    tempBene["beneForeignBankName"] = state?.bankSwiftCodeCorrDetails?.bankName;
    tempBene["beneForeignBankCountry"] = state?.bankSwiftCodeCorrDetails?.countryCode;
    setBeneficiary(tempBene);
  }, [state.bankSwiftCodeCorrDetails]);

  useEffect(() => {
    let tempBene = { ...beneficiary };
    let countryCode;
    if(state?.bankDetails?.bankCountry && state?.bankDetails?.bankCountry?.includes("-")){
      countryCode = state?.bankDetails?.bankCountry?.split("-")[0].trim();
    }
    tempBene["beneSwiftCode"] = state?.bankDetails?.bankSwiftCode;
    tempBene["beneBankName"] = state?.bankDetails?.bankName;
    tempBene["beneBankCountry"] = countryCode || state?.bankDetails?.bankCountry;
    tempBene["beneBankAddress"] = state?.bankDetails?.bankAddress;
    setBeneficiary(tempBene);
  }, [state?.bankDetails]);

  useEffect(() => {
    let tempBene = { ...beneficiary };
    tempBene["beneForeignSwiftCode"] = state?.bankCorrDetails?.bankSwiftCode;
    tempBene["beneForeignBankName"] = state?.bankCorrDetails?.bankName;
    tempBene["beneForeignBankCountry"] = state?.bankCorrDetails?.bankCountry;
    setBeneficiary(tempBene);
  }, [state?.bankCorrDetails]);

  useEffect(() => {
    let updatedState = JSON.parse(JSON.stringify(beneficiary));
    let countryCode;
    if(state?.bankNewDetails?.bankCountry && state?.bankNewDetails?.bankCountry?.includes("-")){
      countryCode = state?.bankNewDetails?.bankCountry?.split("-")[0].trim();
    }
    if(state?.bankNewDetails?.bankSwiftCode){
      updatedState.beneTransit= state?.bankNewDetails?.ibanNumber;
      updatedState.beneSwiftCode= state?.bankNewDetails?.bankSwiftCode;
      updatedState.beneBankName= state?.bankNewDetails?.bankName;
      updatedState.beneBankCountry= countryCode || state?.bankNewDetails?.bankCountry;
      updatedState.beneBankAddress= state?.bankNewDetails?.bankAddress;
    }
    setBeneficiary(updatedState);
  },[state?.bankNewDetails])

  const clearAll = () => {
    setSelectedBene({});
    setBeneficiary({
      beneName: "",
      beneAddress1: "",
      beneAddress2: "",
      beneAddress3: "",
      beneCountry: "",
      beneAccNo: "",
      beneTransit: "",
      beneSwiftCode: "",
      beneBankName: "",
      beneBankCountry: "",
      beneBankAddress: "",
      beneForeignSwiftCode: "",
      beneForeignBankName: "",
      beneForeignBankCountry: "",
      isThirdParty: false,
    });
  };

  useEffect(() => {
    if (state.showSaveDraftMsg) {
      setAlert({
        ...alert,
        alertMsg: "Beneficiary Saved as Draft",
        alertType: "success",
        isAlertOpen: true,
      });
    }
  }, [state.showSaveDraftMsg]);

  return (
    <React.Fragment>
      <AlertPopup
        {...alert}
        onClose={() => {
          setAlert({ ...alert, isAlertOpen: false });
          dispatch(Actions.clearBeneDraftMsgStatus());
        }}
      />
      <Drawer
        classes={{
          paper: classes.paper,
        }}
        anchor={"bottom"}
        open={searchModal}
        onClose={toggleDrawer(false)}
      >
        <div onClick={toggleDrawer(false)} className="close">
          <img src={CloseIcon} className="close-icon" />
        </div>
        <div className={classes.root}>
          <Paper className={`table-container ${classes.paper}`}>
            <div>
              <span className="search-main-heading">
                Search Beneficiary Bank
              </span>
              <Grid
                container
                spacing={3}
                className="search-container left-pd-0"
              >
                <Grid item lg={3} sm={6} xs={12} className="">
                  <SearchInput
                    getValue={(val) => {
                      setSwiftCode(val);
                    }}
                    placeholder="Enter SWIFT Code"
                    onBlur={() => fetchBankDetailsAPI()}
                  />
                </Grid>
                <Grid item lg={3} sm={6} xs={12}>
                  <SearchInput
                    getValue={(val) => {
                      setBankName(val);
                    }}
                    placeholder="Enter Bank Name"
                    onBlur={() => fetchBankDetailsAPI()}
                  />
                </Grid>
                <Grid item lg={3} sm={6} xs={12}>
                  <SearchInput
                    getValue={(val) => {
                      val = findCountryName(val, true) || val;
                      setBankCountry(val);
                    }}
                    placeholder="Enter Bank Country"
                    onBlur={() => fetchBankDetailsAPI()}
                  />
                </Grid>
                <Grid item lg={3} sm={6} xs={12}>
                  <SearchInput
                    getValue={(val) => {
                      setBankBranch(val);
                    }}
                    placeholder="Branch Name/Address"
                    onBlur={() => fetchBankDetailsAPI()}
                  />
                </Grid>
              </Grid>
              <AgGridTable
                autoSize={true}
                tableOnly={true}
                headCells={headCells}
                rows={rowList}
                noRowSelection={true}
                hideActionIcon={true}
                selectedList={selRows}
                reloadTableRows={tableRowChanges}
                getSelectedRows={(selRows) => {
                  setSelRows(selRows);
                }}
                overlayNoRowsTemplate={
                  bankSwiftCode || bankName || bankBranch || bankCountry
                    ? null
                    : "<div><span>Please enter Bank Name/Country/Swift Code/Address to search</span></div>"
                }
              />
            </div>
            <div className="frequent-container">
              <span className="frequent-heading">
                {bankSwiftCode || bankName || bankBranch || bankCountry
                  ? "Frequently used Banks"
                  : "Suggestions from Previous Transactions"}
              </span>
              <AgGridTable
                autoSize={true}
                tableOnly={true}
                headCells={headCells}
                rows={freqRowList}
                noRowSelection={true}
                hideActionIcon={true}
                selectedList={selRows}
                reloadTableRows={tableRowChanges}
                getSelectedRows={(selRows) => {
                  setSelRows(selRows);
                }}
              />
            </div>
          </Paper>
        </div>
        <div className="close-container">
          <Button color="secondary" onClick={toggleDrawer(false)}>
            Cancel
          </Button>
          <Button
            disabled={!selRows?.length > 0}
            onClick={(e) => {
              setSearchModal(false);
              addBankApi();
            }}
          >
            Add Bank
          </Button>
        </div>
      </Drawer>
      <div className="beneficiary-details">
        <span className="details-heading d-flex mtb-16">
          Beneficiary Details
        </span>
        <div className="border-container">
          <div className="d-flex benef-checkbox">
            <Checkbox
              checked={isThirdParty}
              onChange={() => {
                if (!isThirdParty) getBenefOptions("");
                setIsThirdParty(!isThirdParty);
                settingBeneValue("isThirdParty", !isThirdParty);
                getBenefOptions(
                  typeof beneficiary?.beneName === "object"
                    ? beneficiary?.beneName[0]
                    : beneficiary?.beneName, !isThirdParty
                );
              }}
            />
            <span className="third-party">This is a third-party payment</span>
          </div>
          <span className="details-heading d-flex mtb-16">Name</span>
          <Grid spacing={3} container>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <div className="custom-dropdown">
                <Customdropdown
                  name="Beneficiary Name *"
                  isMulti={false}
                  onSelectOptions={(selOptions) => {
                    //CALL SELECT BENEF API
                    onSelectBenefOption(selOptions);
                    settingBeneValue("beneName", selOptions?.label);
                    settingBeneValue("beneId", selOptions?.id);
                  }}
                  options={benefOptions}
                  listFromAPI={true}
                  fetchOptions={(val) => {
                    if (val?.length > 1) {
                      getBenefOptions(val);
                    }
                  }}
                  max={25}
                  onValidation={(val) => {
                    let pattern = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/;
                    if (pattern.test(val)) {
                      setbeneNameError(true);
                      props.isValid(false);
                    } else {
                      setbeneNameError(false);
                      props.isValid(true);
                    }
                  }}
                  error={
                    beneNameError ||
                    fieldsToBeValidated?.beneName?.validationFailed
                  }
                  errorText={
                    beneNameError
                      ? "Special characters not allowed"
                      : "Mandatory Field"
                  }
                  onBlur={(val) => {
                    settingBeneValue("beneName", val);
                    if (!val) {
                      clearAll();
                    }
                  }}
                  selectedOptions={selectedBene}
                />
              </div>
            </Grid>
          </Grid>
          <span className="details-heading d-flex mtb-16">Address Details</span>
          <Grid spacing={3} container>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                disabled={fieldDisabled}
                label="Beneficiary Address 1 *"
                name="Beneficiary Address 1"
                type="text"
                variant="filled"
                maxLength={35}
                error={!fieldDisabled && fieldsToBeValidated?.beneAddress1?.validationFailed}
                errorMessage={"Mandatory Field"}
                value={beneficiary?.beneAddress1}
                onBlur={(e) => {
                  settingBeneValue("beneAddress1", e?.target?.value);
                }}
              />
            </Grid>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                disabled={fieldDisabled}
                label="Beneficiary Address 2 *"
                name="Beneficiary Address 2"
                type="text"
                variant="filled"
                maxLength={35}
                error={!fieldDisabled && fieldsToBeValidated?.beneAddress2?.validationFailed }
                errorMessage={"Mandatory Field"}
                value={beneficiary?.beneAddress2}
                onBlur={(e) => {
                  settingBeneValue("beneAddress2", e?.target?.value);
                }}
              />
            </Grid>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                disabled={fieldDisabled}
                label="Beneficiary Address 3"
                name="Beneficiary Address 3"
                type="text"
                variant="filled"
                maxLength={35}
                value={beneficiary?.beneAddress3}
                onBlur={(e) => {
                  settingBeneValue("beneAddress3", e?.target?.value);
                }}
              />
            </Grid>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <div className="custom-dropdown">
                {fieldDisabled ? (
                  <TextField
                    disabled={fieldDisabled}
                    label="Country Code *"
                    name="Country Code"
                    type="text"
                    variant="filled"
                    value={findCountryName(beneficiary?.beneCountry)}
                    error={!fieldDisabled && fieldsToBeValidated?.beneCountry?.validationFailed}
                    maxLength={2}
                    errorMessage={"Mandatory Field"}
                    onBlur={(e) => {
                      settingBeneValue("beneCountry", e?.target?.value);
                    }}
                  />
                ) : (
                  <Customdropdown
                    name="Country Code *"
                    isMulti={false}
                    onSelectOptions={(selOptions) => {
                      settingBeneValue("beneCountry", selOptions?.label);
                    }}
                    max={2}
                    options={state?.benefCountryOptions}
                    error={fieldsToBeValidated?.beneCountry?.validationFailed}
                    errorText={"Mandatory Field"}
                    listFromAPI={true}
                    ignoreSpecialChars={true}
                    fetchOptions={(val) => {
                      // getBenefOptions(val)
                    }}
                  />
                )}
              </div>
            </Grid>
          </Grid>
        </div>
        <div className="border-container">
          <div className="search-bank-container">
            <span className="details-heading d-flex mtb-16">
              Account Details
            </span>
            <div className="search-bank" onClick={() => onSearchBank(false)}>
              <img src={SearchIcon} />
              <span className="search-bank-text">Search for bank</span>
            </div>
          </div>
          <Grid spacing={3} container>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <div className="custom-dropdown">
                <Customdropdown
                  name="Account Number/ IBAN No. *"
                  isMulti={false}
                  onSelectOptions={(selOptions) => {
                    settingBeneValue("beneAccNo", selOptions);
                    updateSelAccountNumbr(selOptions);
                    setAccountFieldsDisabled(true);
                  }}
                  options={beneficiary?.accountNumber || []}
                  listFromAPI={true}
                  max={50}
                  error={fieldsToBeValidated?.beneAccNo?.validationFailed}
                  errorText={"Mandatory Field"}
                  onBlur={(val) => {
                    settingBeneValue("beneAccNo", val);
                    if (val && beneficiary?.beneId) {
                      //Update bene account API
                      updateBeneAccApi(val);
                    }
                    if(beneficiary?.accountNumber && beneficiary?.accountNumber?.find(item => {return item.label === val})){
                      setAccountFieldsDisabled(true);
                    }else{
                      setAccountFieldsDisabled(false);
                    }
                  }}
                  selectedOptions={selAccountNumbr}
                />
              </div>
            </Grid>
            <Grid className="sub-detail-container" item sm={6} xs={12} lg={4}>
              <TextField
                disabled={accountFieldsDisabled}
                label="Sort code/ BSB No. / Transit No."
                name="Sort code/ BSB No. / Transit No."
                type="text"
                variant="filled"
                maxLength={50}
                value={beneficiary?.beneTransit}
                onBlur={(e) => {
                  settingBeneValue("beneTransit", e?.target?.value);
                }}
              />
            </Grid>
          </Grid>
          <Grid spacing={3} container>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                disabled={accountFieldsDisabled }
                label="Bank SWIFT Code *"
                name="Bank SWIFT Code"
                type="text"
                variant="filled"
                maxLength={11}
                value={ beneficiary?.beneSwiftCode }
                onBlur={(e) => {
                  const swiftVal = e?.target?.value;
                  settingBeneValue("beneSwiftCode", swiftVal);
                  //CALL Bank swift code API
                  bankSwiftCodeApi(swiftVal, false);
                }}
                error={
                  !(fieldDisabled && beneficiary?.accountNumber) &&
                  fieldsToBeValidated?.beneSwiftCode?.validationFailed
                }
                errorMessage={"Mandatory Field"}
                onChange={(e) => {
                  if (
                    !e.target.value?.match(/^[ a-z0-9]+$/i) &&
                    e.target.value !== ""
                  ) {
                    e.target.value = e.target.value?.slice(0, -1);
                  }
                  settingBeneValue("beneSwiftCode", e?.target?.value);
                }}
              />
            </Grid>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                disabled={accountFieldsDisabled || beneficiary?.beneSwiftCode }
                label="Bank Name *"
                name="Bank Name"
                type="text"
                variant="filled"
                value={ beneficiary?.beneBankName }
                error={!(
                    (accountFieldsDisabled || beneficiary?.beneBankName || beneficiary?.beneSwiftCode ))
                    && fieldsToBeValidated?.beneBankName?.validationFailed
                }
                maxLength={35}
                errorMessage={"Mandatory Field"}
                onBlur={(e) => {
                  settingBeneValue("beneBankName", e?.target?.value);
                }}
              />
            </Grid>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <div className="custom-dropdown">
                {(accountFieldsDisabled || beneficiary?.beneSwiftCode) ? (
                  <TextField
                    disabled={accountFieldsDisabled || beneficiary?.beneSwiftCode}
                    label="Bank Country *"
                    name="Bank Country "
                    type="text"
                    variant="filled"
                    maxLength={2}
                    value={findCountryName(beneficiary?.beneBankCountry)}
                    onBlur={(e) => {
                      settingBeneValue("beneBankCountry", e?.target?.value);
                    }}
                    error={!(
                      accountFieldsDisabled || beneficiary?.beneBankCountry || beneficiary?.beneSwiftCode
                      ) && fieldsToBeValidated?.beneBankCountry?.validationFailed
                    }
                    errorMessage={"Mandatory Field"}
                  />
                ) : (
                  <Customdropdown
                    name="Bank Country *"
                    isMulti={false}
                    onSelectOptions={(selOptions) => {
                      settingBeneValue("beneBankCountry", selOptions?.id);
                    }}
                    options={state?.benefCountryOptions}
                    listFromAPI={true}
                    fetchOptions={(val) => {
                      // getBenefOptions(val)
                    }}
                    max={2}
                    ignoreSpecialChars={true}
                    error={
                      fieldsToBeValidated?.beneBankCountry?.validationFailed
                    }
                    errorText={"Mandatory Field"}
                    selectedOptions={{
                      label: findCountryName(beneficiary?.beneBankCountry),
                      id: beneficiary?.beneBankCountry,
                    }}
                  />
                )}
              </div>
            </Grid>
            <Grid className="sub-detail-container" item lg={12} sm={12} xs={12}>
              <TextField
                disabled={accountFieldsDisabled || beneficiary?.beneSwiftCode}
                label="Bank Address *"
                name="Bank Address "
                type="text"
                variant="filled"
                maxLength={35}
                value={ beneficiary?.beneBankAddress }
                onBlur={(e) => {
                  if (
                    !e.target.value?.match(/^[ a-z0-9]+$/i) &&
                    e.target.value !== ""
                  ) {
                    e.target.value = "";
                  }
                  settingBeneValue("beneBankAddress", e?.target?.value);
                }}
                onChange={(e) => {
                  if (
                    !e.target.value?.match(/^[ a-z0-9]+$/i) &&
                    e.target.value !== ""
                  ) {
                    e.target.value = e.target.value?.slice(0, -1);
                  }
                  settingBeneValue("beneBankAddress", e?.target?.value);
                }}
                error={!(
                    (accountFieldsDisabled || beneficiary?.beneBankAddress || beneficiary?.beneSwiftCode) &&
                      beneficiary?.accountNumber
                  ) && fieldsToBeValidated?.beneBankAddress?.validationFailed
                }
                errorMessage={"Mandatory Field"}
              />
            </Grid>
          </Grid>
        </div>
        <div className="border-container">
          <div className="search-bank-container">
            <span className="details-heading d-flex mtb-16">
              Corresponding Beneficiary Bank Details (Optional)
            </span>
            <div className="search-bank" onClick={() => onSearchBank(true)}>
              <img src={SearchIcon} />
              <span className="search-bank-text">Search for bank</span>
            </div>
          </div>
          <Grid spacing={3} container>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                label="Bank SWIFT Code"
                name="Bank SWIFT Code"
                type="text"
                variant="filled"
                value={beneficiary?.beneForeignSwiftCode}
                maxLength={11}
                onBlur={(e) => {
                  const swiftVal = e?.target?.value;
                  //CALL Bank swift code API
                  bankSwiftCodeApi(swiftVal, true);
                  settingBeneValue("beneForeignSwiftCode", e?.target?.value);
                }}
                onChange={(e) => {
                  if (
                    !e.target.value?.match(/^[ a-z0-9]+$/i) &&
                    e.target.value !== ""
                  ) {
                    e.target.value = e.target.value?.slice(0, -1);
                  }
                  const swiftVal = e?.target?.value;
                  //CALL Bank swift code API
                  bankSwiftCodeApi(swiftVal, true);
                  settingBeneValue("beneForeignSwiftCode", e?.target?.value);
                }}
              />
            </Grid>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                disabled={beneficiary?.beneForeignBankName}
                label="Bank Name"
                name="Bank Name"
                type="text"
                variant="filled"
                maxLength={35}
                value={ beneficiary?.beneForeignBankName }
                onBlur={(e) => {
                  settingBeneValue("beneForeignBankName", e?.target?.value);
                }}
                onChange={(e) => {
                  if (
                    !e.target.value?.match(/^[ a-z0-9]+$/i) &&
                    e.target.value !== ""
                  ) {
                    e.target.value = e.target.value?.slice(0, -1);
                  }
                  settingBeneValue("beneForeignBankName", e?.target?.value);
                }}
              />
            </Grid>
            <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
              <TextField
                disabled={beneficiary?.beneForeignBankCountry}
                label="Bank Country"
                name="Bank Country"
                type="text"
                variant="filled"
                maxLength={2}
                value={ beneficiary?.beneForeignBankCountry ? 
                  (findCountryName(beneficiary?.beneForeignBankCountry) || beneficiary?.beneForeignBankCountry) :
                  beneficiary?.beneForeignBankCountry
                }
                onBlur={(e) => {
                  settingBeneValue("beneForeignBankCountry", e?.target?.value);
                }}
              />
            </Grid>
          </Grid>
        </div>
      </div>
      {toastState?.showToast && (
        <AlertPopup
          alertMsg={toastState?.toastMessage}
          alertType={toastState?.toastType}
          isAlertOpen={toastState?.showToast}
          onClose={() => {}}
        />
      )}
    </React.Fragment>
  );
};

export default BeneficiaryDetails;