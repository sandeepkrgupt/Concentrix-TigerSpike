/* eslint-disable */
import React, { useEffect, useState } from "react";
import AgGridTable from "../../../components/aggridtable";

const rows = [
  createData("20", "Unique 16 Digit Identifier", ""),
  createData("23B", "Bank Operation Code", ""),
  createData("32A", "Value Date", ""),
  createData("32A", "Currency Code", ""),
  createData("32A", "Amount", ""),
  createData("20", "Unique 16 Digit Identifier", ""),
  createData("23B", "Bank Operation Code", ""),
  createData("32A", "Value Date", ""),
  createData("32A", "Currency Code", ""),
  createData("32A", "Amount", ""),
  createData("20", "Unique 16 Digit Identifier", ""),
  createData("23B", "Bank Operation Code", ""),
  createData("32A", "Value Date", ""),
  createData("32A", "Currency Code", ""),
  createData("32A", "Amount", ""),
];

function createData(tag, particulars, details) {
  return {
    tag,
    particulars,
    details,
  };
}

const handleUserInput = (value, refNo, listAray) => {};

const SwiftMessage = () => {
  ``;
  const [rowList, updateRowList] = React.useState([]);
  const [sortInfo, setSortInfo] = useState({});

  useEffect(() => {
    generateTableRowValues();
  }, []);

  const getSorted = (sortBy, desc) => {
    const receivedSortInfo = {
      sortBy: sortBy,
      sortType: desc ? "DESC" : "ASC",
    };
    if (JSON.stringify(receivedSortInfo) !== JSON.stringify(sortInfo)) {
      setSortInfo({
        sortBy: sortBy,
        sortType: desc ? "DESC" : "ASC",
      });
    }
  };
  const generateTableRowValues = () => {
    const newArray = [...rows];
    const resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem).map((key) => {
        const value = rowItem[key];
        switch (key) {
          case "amountUtilised":
            return (newObject[key] = {
              value: value,
              handleUserInput: handleUserInput,
            });
          default:
            newObject[key] = { value: value };
            break;
        }
      });
      resultArray.push(newObject);
    });
    updateRowList(resultArray);
  };

  return (
    <div className="swiftMessage-table-container">
      <AgGridTable
        headCells={[
          { field: "tag", label: "Tag", sortable: true, initialSort: "asc" ,flex: 1 },
          { field: "particulars", label: "Particulars", sortable: true ,flex: 1},
          { field: "details", label: "Details" ,flex: 1},
        ]}
        rows={rowList}
        tableOnly={true}
        noRowSelection={true}
        onSort={(sortBy, desc) => {
          getSorted(sortBy, desc);
        }}
        autoSize={true}
        hideViewMoreLess={true}
      />
    </div>
  );
};

export default SwiftMessage;
