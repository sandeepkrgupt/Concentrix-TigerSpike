/* eslint-disable*/
import React, { useEffect, useState, useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import Drawer from "@material-ui/core/Drawer";
import { Grid } from "@material-ui/core";
import CloseIcon from "../../../../assets/icons/close.svg";
import { useHistory } from "react-router-dom";
import {
  Button,
  Dropdown,
  RadioList,
  TextField,
} from "../../../../components/@subzero/glacier/package/lib/components";
import { Actions } from "../../../../store/rootActions";
import "./index.css";
import Loader from "../../../../components/loader";
import { truncate } from "lodash";

const useStyles = makeStyles({
  root: {
    background: "#F9F9F9",
    borderRadius: "8px",
    marginTop: "16px",
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
  dropdown: {
    "& .Dropdown_show__21pcz": {
      position: "absolute",
      zIndex: "999",
    },
  },
});

const WorkflowDetails = (props) => {
  const history = useHistory();
  const classes = useStyles();
  const dispatch = useDispatch();
  const state = useSelector((state) => state?.paymentReviewData);
  const authData = useSelector((state) => state?.auth?.loginData);
  const transactionDetails = useSelector((state) => state?.transactionDetails);

  const fxRateStatusData = useSelector((state) => state?.fxRateStatus);
  const fxRateAmountData = useSelector((state) => state?.fxRateAmount);
  const fxRateMessageIdData = useSelector((state) => state?.fxRateMessageId);
  const fidbMarginData = useSelector((state) => state?.fidbMargin);
  const fxRateResponseData = useSelector((state) => state?.fxRateResponse);

  const [loader, setLoader] = useState(false);
  const [openModal, setOPenModal] = React.useState(true);
  const [viewDetails, setViewDetails] = React.useState(true);
  const [rejectOriginalMaker, setRejectOriginalMaker] = React.useState(true);
  const [checker_sequence, setCheckerSequence] = React.useState(false);
  const [workFlowRule, updateWorkFlowRule] = React.useState([]);
  const [workFlowGroup, updateworkFlowGroup] = React.useState([]);
  const [workFlowUser, updateWorkflowUser] = React.useState([]);
  const [formInput, setFormInput] = React.useState(null);
  const [defaultWorkFlow, updateDefaultWorkFlow] = React.useState(false);
  const [workflowDetailData, updateWorkflowDetails] = React.useState(null);
  const [isLoading, updateLoading] = React.useState(false);

  const stateRef = useRef(state); //  reference value to get previous state

  useEffect(() => {
    // coming from bulk rejection window, then call getTransactionWorkflowDetails api with empty req param
    if (props?.location?.state?.recKeyList) {
      const req = {};
      dispatch(Actions.getTransactionWorkflowDetails(req));
    } else if (stateRef?.current?.paymentDetails) {
      const req = {
        makerCount: authData?.makerCount,
        checkerCount: authData?.checkerCount,
        baseCurrency: authData?.baseCurrnecy,
        bankCode: authData?.bankCode,
        userId: authData?.userId,
        customerId: authData?.corpId,
        userRoleType: authData?.userRoleType,
        recKey: props?.location?.state?.recKey,
        status: "",
        amount: state?.paymentDetails?.amount,
        currency: state?.paymentDetails?.currency,
        paymentRefNumber: "",
        tranType: "FIDB",
      };

      if (props?.location?.state?.action === "reject") {
        const req = {};
        // reject button clicked from review
        //CALL TRANSACTION WORKFLOW API
        dispatch(Actions.getTransactionWorkflowDetails(req));
        // if (
        //   authData?.userRoleType === "C" &&
        //   props?.location?.state?.channelRefNo &&
        //   props?.location?.state?.statusCode === "PRE_ACC1"
        // ) {
        //   // if(not final checker)
        //   req.userAction = "REJCT";
        //   req.status = "REJCT";
        //   req.recKey = props?.location?.state?.recKey;
        // } else if (
        //   authData?.userRoleType === "C" &&
        //   props?.location?.state?.channelRefNo &&
        //   props?.location?.state?.statusCode !== "PRE_ACC1"
        // ) {
        //   req.userAction = "REJCT";
        //   req.recKey = props?.location?.state?.recKey;
        //   req.status = "REJCT";
        // }
      } else {
        // authorize button clicked from review
        if (
          authData?.userRoleType === "C" &&
          props?.location?.state?.channelRefNo &&
          props?.location?.state?.statusCode === "PRE_ACC1"
        ) {
          // if(not final checker)
          req.userAction = "CHECKERLOAD";
          req.recKey = props?.location?.state?.recKey;
        } else if (
          authData?.userRoleType === "C" &&
          props?.location?.state?.channelRefNo &&
          props?.location?.state?.statusCode !== "PRE_ACC1"
        ) {
          req.userAction = "CHECKERMODIFY";
          req.recKey = "";
        }
        //CALL TRANSACTION WORKFLOW API
        dispatch(Actions.getTransactionWorkflowDetails(req));
      }
    }
  }, []);

  useEffect(() => {
    if (JSON.stringify(stateRef?.current) !== JSON.stringify(state)) {
      const {
        loader,
        transactionWorkflow,
        paymentSuccess,
        paymentFail,
        workflowDetails,
        beneAccDetails,
        beneDetails,
        fxRateStatus,
        fxRateAmount,
        fxRateMessageId,
        fidbMargin,
        fxRateResponse,
      } = state;
      stateRef.current = state;
      // setFxRateStatusData(fxRateStatus);
      // setFxRateAmountData(fxRateAmount);
      // setFxRateMessageIdData(fxRateMessageId);
      // setFidbMarginData(fidbMargin);
      // setFxRateResponseData(fxRateResponse);

      // if workflow details authorized or rejected by checker, call addBeneDetailsOnCheckerApproval API.
      if (paymentSuccess || paymentFail) {
        if (beneAccDetails !== null && beneDetails !== null) {
          // bank or account data available in temp, call api to move to master
          if (
            beneAccDetails?.isBankAvailableInTemp ||
            beneDetails?.isBeneAvailableInTemp
          ) {
            let status = ""; // empty for rejected
            if (paymentSuccess && !props?.location?.state?.channelRefNoList) {
              status = "approved";
            }
            const req = {
              status,
              beneficiaryId: beneAccDetails?.beneficiaryId,
              beneficiaryACNo: beneAccDetails?.accountNumber,
            };
            dispatch(Actions.addBeneDetailsOnCheckerApproval(req));
          }
        }

        // redirecting to success page after succesfull authorization/rejection
        history.push({
          pathname: "/authorize-success",
          state: {
            channelRefNo: props?.location?.state?.channelRefNo,
            channelRefNoList: props?.location?.state?.channelRefNoList,
            finalChecker: props?.location?.state?.finalChecker,
          },
        });
      } else {
        console.log("updating Workflow Details");
        // updating Workflow Details
        if (workflowDetails && workflowDetails !== null) {
          if (
            workflowDetails?.alListOfWorkflow?.[0]?.makerWorkflowType === "S"
          ) {
            setMakerSequence(true);
          }
          if (
            workflowDetails?.alListOfWorkflow?.[0]?.checkerWorkflowType === "S"
          ) {
            setCheckerSequence(true);
          }
          updateWorkflowDetails(workflowDetails);
        }
        // if workflow rule is null then call default workflow api
        if (transactionWorkflow?.workFlowList?.length > 0) {
          updateDefaultWorkFlow(false);
          updateWorkFlowRule(
            transactionWorkflow?.workFlowList.map(({ label }) => label)
          );

          // If only one rule available preselect that value
          if (transactionWorkflow?.workFlowList?.length === 1) {
            handleUserInput(
              transactionWorkflow?.workFlowList.map(({ label }) => label)[0],
              "workFlowRule"
            );
          }
        } else if (transactionWorkflow?.workFlowList === null) {
          console.log("transactionWorkflow?.workFlowList === null");
          // if workflowList is null then we have to call Default workflow API
          // check if recKeyList is available, then
          updateDefaultWorkFlow(true);
          const req = {
            makerCount: authData?.makerCount,
            checkerCount: authData?.checkerCount,
            baseCurrency: authData?.baseCurrnecy,
            bankCode: authData?.bankCode,
            userId: authData?.userId,
            customerId: authData?.corpId,
            userRoleType: authData?.userRoleType,
          };

          if (props?.location?.state?.recKeyList) {
            req.recKey = props?.location?.state?.recKeyList[0];
          } else {
            req.recKey = props?.location?.state?.recKey;
          }

          //CALL DEFAULT WORKFLOW API
          dispatch(Actions.getdefaultWorkflow(req));
        }

        updateworkFlowGroup(
          transactionWorkflow?.workflowGroupList?.length > 0 &&
            transactionWorkflow?.workflowGroupList.map(({ label }) => label)
        );

        updateWorkflowUser(
          transactionWorkflow?.workflowUserList?.length > 0 &&
            transactionWorkflow?.workflowUserList.map(({ label }) => label)
        );

        setLoader(loader);
        updateLoading(loader);
      }
    }
  }, [state]);

  const toggleDrawer = (open) => {
    setOPenModal(open);
    history.goBack();
  };

  const handleUserInput = (value, name) => {
    setFormInput({ ...formInput, [name]: value });
  };

  const fetchWorkFlowGroup = (item) => {
    if (workFlowRule?.length > 1 && item) {
      const req = {
        bankCode: authData?.bankCode,
        userId: authData?.userId,
        customerId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
        workFlowId: item,
        tranType: "FIDB",
      };
      dispatch(Actions.getWorkflowGroup(req));
    }
  };

  const fetchWorkFlowUsers = (item) => {
    if (workFlowGroup?.length > 1 && item) {
      const req = {
        bankCode: authData?.bankCode,
        userId: authData?.userId,
        customerId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
        workflowId: formInput?.workFlowGroup,
        groupId: item,
        tranType: "FIDB",
        userRoleType: authData?.userRoleType,
      };
      dispatch(Actions.getWorkflowUserList(req));
    }
  };

  const handleSubmit = (action) => {
    updateLoading(true);

    let workFlowMappedItem;
    if (state?.transactionWorkflow?.workFlowList) {
      // finding workFlowMappedItem by its label to get id
      workFlowMappedItem = state?.transactionWorkflow?.workFlowList.find(
        (item) => {
          if (item?.label === formInput?.workFlowRule) {
            return true;
          } else {
            return false;
          }
        }
      );
    }

    // let req = {
    //   bankCode: authData?.bankCode,
    //   userId: authData?.userId,
    //   corpId: authData?.corpId,
    //   tranType: "FIDB",
    //   fidbtxnId: props?.location?.state?.recKey,
    //   workFlowId: formInput?.workFlowRule,
    //   groupId: formInput?.workFlowGroup,
    //   requestForwardTo: formInput?.workFlowUser,
    //   remarksForChecker: formInput?.remarkForChecker,
    //   remarksForBank: formInput?.remarkForBank,
    //   checkerCount: authData?.checkerCount,
    //   makerCount: authData?.makerCount,
    //   baseCurrency: authData?.baseCurrency,
    //   action,
    // };
    // dispatch(Actions.submitWorkflow(req));

    // calling accept-reject api
    let process;
    if (action === "reject") {
      process = "REJECT";
    } else {
      process = "ACCEPT";
    }
    let req = {
      workFlowId: workFlowMappedItem?.id,
      groupId: formInput?.workFlowGroup,
      requestFwdTo: formInput?.workFlowUser,
      corpId: authData?.corpId,
      userId: authData?.userId,

      subCustId:
        transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
      process,
    };

    // if coming from bulk accept/reject, update req params
    if (props?.location?.state?.recKeyList) {
      req.reckeys = [...props?.location?.state?.recKeyList];
      req.isBookLater = "N";
      req.isBulk = true;
    } else {
      req.reckeys = [props?.location?.state?.recKey];
      req.isBookLater = state?.paymentDetails?.tridbNumber ? "N" : "Y";
      req.isBulk = false;
    }
    dispatch(Actions.acceptReject(req));
  };

  const fetchWorkflowDetails = () => {
    let workFlowMappedItem = state?.transactionWorkflow?.workFlowList.find(
      (item) => {
        if (item?.label === formInput?.workFlowRule) {
          return true;
        } else {
          return false;
        }
      }
    );

    const req = {
      bankCode: authData?.bankCode,
      userId: authData?.userId,
      customerId:
        transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
      workflowId: workFlowMappedItem?.id,
      tranType: "FIDB",
      groupId: formInput?.workFlowGroup,
      userRoleType: authData?.userRoleType,
    };
    dispatch(Actions.fetchWorkflowDetails(req));
  };

  if (loader) {
    return <Loader />;
  }

  return (
    <div>
      <div>
        <React.Fragment>
          <Drawer
            classes={{
              paper: classes.paper,
            }}
            anchor={"bottom"}
            open={openModal}
            onClose={() => {
              toggleDrawer(false);
            }}
          >
            <div
              onClick={() => {
                toggleDrawer(false);
              }}
              className="close"
            >
              <img src={CloseIcon} className="close-icon" />
            </div>
            <div
              className={
                props?.location?.state?.action === "reject"
                  ? "details-container-width-40"
                  : "details-container"
              }
            >
              <span className="heading-details">
                Workflow Details1{" "}
                {props?.location?.state?.action === "reject" && "(Optional)"}
              </span>

              {/* If rejected */}
              {props?.location?.state?.action === "reject" ? (
                <>
                  <Grid container>
                    <Grid
                      item
                      className="sub-detail-container"
                      item
                      lg={6}
                      md={6}
                      sm={6}
                      xs={12}
                    >
                      <div className="select-group-container">
                        <RadioList
                          onChange={(e) => {
                            if (e === "yes") {
                              setRejectOriginalMaker(true);
                            } else {
                              setRejectOriginalMaker(false);
                            }
                          }}
                          variant="filled"
                          list={{
                            title:
                              "Do you want to reject to the origianl maker? ",
                            items: [
                              {
                                label: "Yes",
                                name: "yes",
                                value: "yes",
                                checked: rejectOriginalMaker,
                              },
                              {
                                label: "No",
                                name: "no",
                                value: "no",
                                checked: !rejectOriginalMaker,
                              },
                            ],
                          }}
                        />
                      </div>
                    </Grid>

                    {props?.location?.state?.action === "reject" &&
                      !rejectOriginalMaker && (
                        <Grid
                          className="sub-detail-container"
                          item
                          lg={6}
                          md={6}
                          sm={6}
                          xs={12}
                        >
                          {/* {viewDetails ? (
                            <span
                              className="view-detail-button"
                              onClick={() => {
                                fetchWorkflowDetails();
                                setViewDetails(false);
                              }}
                            >
                              View details
                            </span>
                          ) : (
                            <span
                              className="view-detail-button"
                              onClick={() => setViewDetails(true)}
                            >
                              Hide details
                            </span>
                          )} */}
                        </Grid>
                      )}
                  </Grid>

                  {props?.location?.state?.action === "reject" &&
                    !rejectOriginalMaker && (
                      <div className="border-container">
                        <Grid
                          spacing={3}
                          className=" details-containers"
                          container
                        >
                          <Grid
                            className="sub-detail-container full-width-textField "
                            item
                            lg={12}
                            md={12}
                            sm={12}
                            xs={12}
                          >
                            <TextField
                              label="Select Rule"
                              type="text"
                              variant="filled"
                              disabled="true"
                              //   filled="true"
                              // value={props?.selectRule}
                              value={"Rule"}
                            />
                          </Grid>

                          <Grid
                            className="sub-detail-container full-width-textField "
                            item
                            lg={12}
                            md={12}
                            sm={12}
                            xs={12}
                          >
                            <Dropdown
                              label={"Select User Group"}
                              items={
                                workFlowGroup
                                  ? workFlowGroup?.filter((e) => e !== "Select")
                                  : ["Select"]
                              }
                              variant="filled"
                              fullWidth
                              name="Select User Group"
                              onChange={(e) => {
                                handleUserInput(e, "workFlowGroup");
                                fetchWorkFlowUsers(e);
                                // clearing selected values when workflow group changes
                                //  handleUserInput("", "workFlowUser");
                              }}
                              defaultValue={formInput?.workFlowGroup}
                              // defaultValue={"lorem ipsum"}
                            />
                          </Grid>

                          {workFlowUser?.length > 0 && (
                            <>
                              <Grid
                                className="sub-detail-container full-width-textField "
                                item
                                lg={12}
                                md={12}
                                sm={12}
                                xs={12}
                              >
                                <Dropdown
                                  label={"Select User (Optional)"}
                                  items={workFlowUser.filter(
                                    (e) => e !== "Select"
                                  )}
                                  variant="filled"
                                  fullWidth
                                  name="Select User (Optional)"
                                  onChange={(e) => {
                                    handleUserInput(e, "workFlowUser");
                                  }}
                                  defaultValue={formInput?.workFlowUser}
                                />
                              </Grid>
                            </>
                          )}

                          {/* {!viewDetails && workflowDetailData && (
                      <>
                        <Grid item container spacing="3">
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Corporate ID</span>
                              <span className="content">
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.customerId
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Corporate Name</span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.customerName
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Wireflow Name</span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.workflowName
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Transaction Type</span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.tranType
                                }{" "}
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">
                                Transaction from Amount
                              </span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.fromTransactionAmount
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Transaction To Amount</span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.toTransactionAmount
                                }
                              </span>
                            </div>
                          </Grid>
                        </Grid>
                        {workflowDetailData?.groupDetails?.makerGroupDetails && (
                          <Grid
                            spacing="3"
                            item
                            className="makerGroupsContainer"
                            lg={12}
                            md={12}
                            sm={12}
                            xs={12}
                          >
                            <div className="heading">Maker Groups</div>
                            <div className="select-group-container">
                              <RadioList
                                variant="filled"
                                list={{
                                  title: "Select Group",
                                  items: [
                                    {
                                      label: "Sequence",
                                      name: "sequence",
                                      value: "sequence",
                                      checked: maker_sequence,
                                      disabled: !maker_sequence,
                                    },
                                    {
                                      label: "Random",
                                      name: "random",
                                      value: "random",
                                      checked: !maker_sequence,
                                      disabled: maker_sequence,
                                    },
                                  ],
                                }}
                              />
                            </div> */}

                          {/* <div className="maker-table-container">
                              <Grid container className="header">
                                <Grid lg={4} md={4} sm={4} xs={4} item>
                                  Group Name
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  User Count
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  Sequence Number
                                </Grid>
                              </Grid>
  
                              <Grid container className="items-container">
                                {workflowDetailData?.groupDetails?.makerGroupDetails?.makerGroupName?.map(
                                  (item, key) => (
                                    <div className="item-row">
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        item
                                        className=""
                                      >
                                        {item}
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.makerGroupDetails?.makerUserCount?.[
                                            key
                                          ]
                                        }
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.makerGroupDetails
                                            ?.makerSequenceNumber?.[key]
                                        }
                                      </Grid>
                                    </div>
                                  )
                                )}
  
                                <div className="item-row">
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    item
                                    className=""
                                  >
                                    Total Makers
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.totalMakerCount
                                    }
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.makerSequenceNumber
                                    }
                                  </Grid>
                                </div>
                              </Grid>
                            </div> */}
                          {/* </Grid>
                        )}
                        {workflowDetailData?.groupDetails
                          ?.checkerGroupDetails && (
                          <Grid
                            item
                            className="makerGroupsContainer"
                            lg={12}
                            md={12}
                            sm={12}
                            xs={12}
                          >
                            <div className="heading">Checker Groups</div>
                            <div className="select-group-container">
                              <RadioList
                                variant="filled"
                                list={{
                                  title: "Select Group",
                                  items: [
                                    {
                                      label: "Sequence",
                                      name: "sequence",
                                      value: "sequence",
                                      checked: checker_sequence,
                                      disabled: !checker_sequence,
                                    },
                                    {
                                      label: "Random",
                                      name: "random",
                                      value: "random",
                                      checked: !checker_sequence,
                                      disabled: checker_sequence,
                                    },
                                  ],
                                }}
                              />
                            </div>
  
                            <div className="maker-table-container">
                              <Grid container className="header">
                                <Grid lg={4} md={4} sm={4} xs={4} item>
                                  Group Name
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  User Count
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  Sequence Number
                                </Grid>
                              </Grid>
                              <Grid container className="items-container">
                                {workflowDetailData?.groupDetails?.checkerGroupDetails?.checkerGroupName?.map(
                                  (item, key) => (
                                    <div className="item-row">
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        item
                                        className=""
                                      >
                                        {item}
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.checkerGroupDetails
                                            ?.checkerUserCount?.[key]
                                        }
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.checkerGroupDetails
                                            ?.checkerSequenceNumber?.[key]
                                        }
                                      </Grid>
                                    </div>
                                  )
                                )}
  
                                <div className="item-row">
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    item
                                    className=""
                                  >
                                    Total Checkers
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.totalCheckerCount
                                    }
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.checkerSequenceNumber
                                    }
                                  </Grid>
                                </div>
                              </Grid>
                            </div>
                          </Grid>
                        )}
                      </>
                    )} */}
                        </Grid>
                      </div>
                    )}
                </>
              ) : (
                <div className="border-container">
                  <Grid spacing={3} className=" details-containers" container>
                    {workFlowRule?.length > 0 && !defaultWorkFlow && (
                      <Grid
                        className="sub-detail-container full-width-textField "
                        item
                        lg={6}
                        md={6}
                        sm={6}
                        xs={12}
                      >
                        <Dropdown
                          label={"Select Rule"}
                          items={workFlowRule.filter((e) => e !== "Select")}
                          variant="filled"
                          fullWidth
                          name="Select Rule"
                          onChange={(e) => {
                            handleUserInput(e, "workFlowRule");
                            fetchWorkFlowGroup(e);
                            // clearing selected values when workflow rule changes
                            // handleUserInput("", "workFlowGroup");
                            // handleUserInput("", "workFlowUser");
                          }}
                          defaultValue={formInput?.workFlowRule}
                        />
                      </Grid>
                    )}

                    {workFlowRule?.length === 0 && !defaultWorkFlow && (
                      <Grid
                        className="sub-detail-container"
                        item
                        lg={6}
                        md={6}
                        sm={6}
                        xs={12}
                      >
                        {viewDetails ? (
                          <span
                            className="view-detail-button"
                            onClick={() => {
                              fetchWorkflowDetails();
                              setViewDetails(false);
                            }}
                          >
                            View details
                          </span>
                        ) : (
                          <span
                            className="view-detail-button"
                            onClick={() => setViewDetails(true)}
                          >
                            Hide details
                          </span>
                        )}
                      </Grid>
                    )}

                    {!viewDetails && workflowDetailData && (
                      <>
                        <Grid item container spacing="3">
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Corporate ID</span>
                              <span className="content">
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.customerId
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Corporate Name</span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.customerName
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Wireflow Name</span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.workflowName
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">Transaction Type</span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.tranType
                                }{" "}
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">
                                Transaction from Amount
                              </span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.fromTransactionAmount
                                }
                              </span>
                            </div>
                          </Grid>
                          <Grid item lg={4} md={4} sm={4} xs={6}>
                            <div className="workflow-details-column-container">
                              <span className="title">
                                Transaction To Amount
                              </span>
                              <span className="content">
                                {" "}
                                {
                                  workflowDetailData?.alListOfWorkflow?.[0]
                                    ?.toTransactionAmount
                                }
                              </span>
                            </div>
                          </Grid>
                        </Grid>
                        {workflowDetailData?.groupDetails
                          ?.makerGroupDetails && (
                          <Grid
                            spacing="3"
                            item
                            className="makerGroupsContainer"
                            lg={12}
                            md={12}
                            sm={12}
                            xs={12}
                          >
                            <div className="heading">Maker Groups</div>
                            <div className="select-group-container">
                              <RadioList
                                variant="filled"
                                list={{
                                  title: "Select Group",
                                  items: [
                                    {
                                      label: "Sequence",
                                      name: "sequence",
                                      value: "sequence",
                                      checked: maker_sequence,
                                      disabled: !maker_sequence,
                                    },
                                    {
                                      label: "Random",
                                      name: "random",
                                      value: "random",
                                      checked: !maker_sequence,
                                      disabled: maker_sequence,
                                    },
                                  ],
                                }}
                              />
                            </div>

                            <div className="maker-table-container">
                              <Grid container className="header">
                                <Grid lg={4} md={4} sm={4} xs={4} item>
                                  Group Name
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  User Count
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  Sequence Number
                                </Grid>
                              </Grid>

                              <Grid container className="items-container">
                                {workflowDetailData?.groupDetails?.makerGroupDetails?.makerGroupName?.map(
                                  (item, key) => (
                                    <div className="item-row">
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        item
                                        className=""
                                      >
                                        {item}
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.makerGroupDetails
                                            ?.makerUserCount?.[key]
                                        }
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.makerGroupDetails
                                            ?.makerSequenceNumber?.[key]
                                        }
                                      </Grid>
                                    </div>
                                  )
                                )}

                                <div className="item-row">
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    item
                                    className=""
                                  >
                                    Total Makers
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.totalMakerCount
                                    }
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.makerSequenceNumber
                                    }
                                  </Grid>
                                </div>
                              </Grid>
                            </div>
                          </Grid>
                        )}
                        {workflowDetailData?.groupDetails
                          ?.checkerGroupDetails && (
                          <Grid
                            item
                            className="makerGroupsContainer"
                            lg={12}
                            md={12}
                            sm={12}
                            xs={12}
                          >
                            <div className="heading">Checker Groups</div>
                            <div className="select-group-container">
                              <RadioList
                                variant="filled"
                                list={{
                                  title: "Select Group",
                                  items: [
                                    {
                                      label: "Sequence",
                                      name: "sequence",
                                      value: "sequence",
                                      checked: checker_sequence,
                                      disabled: !checker_sequence,
                                    },
                                    {
                                      label: "Random",
                                      name: "random",
                                      value: "random",
                                      checked: !checker_sequence,
                                      disabled: checker_sequence,
                                    },
                                  ],
                                }}
                              />
                            </div>

                            <div className="maker-table-container">
                              <Grid container className="header">
                                <Grid lg={4} md={4} sm={4} xs={4} item>
                                  Group Name
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  User Count
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  Sequence Number
                                </Grid>
                              </Grid>
                              <Grid container className="items-container">
                                {workflowDetailData?.groupDetails?.checkerGroupDetails?.checkerGroupName?.map(
                                  (item, key) => (
                                    <div className="item-row">
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        item
                                        className=""
                                      >
                                        {item}
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.checkerGroupDetails
                                            ?.checkerUserCount?.[key]
                                        }
                                      </Grid>
                                      <Grid
                                        lg={4}
                                        md={4}
                                        sm={4}
                                        xs={4}
                                        className="tar"
                                        item
                                      >
                                        {
                                          workflowDetailData?.groupDetails
                                            ?.checkerGroupDetails
                                            ?.checkerSequenceNumber?.[key]
                                        }
                                      </Grid>
                                    </div>
                                  )
                                )}

                                <div className="item-row">
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    item
                                    className=""
                                  >
                                    Total Checkers
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.totalCheckerCount
                                    }
                                  </Grid>
                                  <Grid
                                    lg={4}
                                    md={4}
                                    sm={4}
                                    xs={4}
                                    className="tar"
                                    item
                                  >
                                    {
                                      workflowDetailData?.alListOfWorkflow?.[0]
                                        ?.checkerSequenceNumber
                                    }
                                  </Grid>
                                </div>
                              </Grid>
                            </div>
                          </Grid>
                        )}
                      </>
                    )}

                    {workFlowGroup?.length > 0 && !defaultWorkFlow && (
                      <Grid
                        className="sub-detail-container full-width-textField "
                        item
                        lg={6}
                        md={6}
                        sm={6}
                        xs={12}
                      >
                        <Dropdown
                          label={"Select User Group"}
                          items={
                            workFlowGroup
                              ? workFlowGroup?.filter((e) => e !== "Select")
                              : ["Select"]
                          }
                          variant="filled"
                          fullWidth
                          name="Select User Group"
                          onChange={(e) => {
                            handleUserInput(e, "workFlowGroup");
                            fetchWorkFlowUsers(e);
                            // clearing selected values when workflow group changes
                            //  handleUserInput("", "workFlowUser");
                          }}
                          defaultValue={formInput?.workFlowGroup}
                          // defaultValue={"lorem ipsum"}
                        />
                      </Grid>
                    )}
                    {workFlowUser?.length > 0 && (
                      <>
                        {workFlowGroup?.length > 0 && (
                          <Grid
                            className="sub-detail-container full-width-textField hide-mob"
                            item
                            lg={6}
                            md={6}
                            sm={6}
                            xs={0}
                          >
                            <span></span>
                          </Grid>
                        )}

                        <Grid
                          className="sub-detail-container full-width-textField "
                          item
                          lg={6}
                          md={6}
                          sm={6}
                          xs={12}
                        >
                          <Dropdown
                            label={"Select User (Optional)"}
                            items={workFlowUser.filter((e) => e !== "Select")}
                            variant="filled"
                            fullWidth
                            name="Select User (Optional)"
                            onChange={(e) => {
                              handleUserInput(e, "workFlowUser");
                            }}
                            defaultValue={formInput?.workFlowUser}
                          />
                        </Grid>
                      </>
                    )}
                    {/* 
                    {workFlowUser?.length > 0 && (
                      <>
                        <Grid
                          className="sub-detail-container full-width-textField "
                          item
                          lg={6}
                          md={6}
                          sm={6}
                          xs={12}
                        >
                          <Dropdown
                            label={"Select User (Optional)"}
                            items={workFlowUser.filter((e) => e !== "Select")}
                            variant="filled"
                            fullWidth
                            name="Select User (Optional)"
                            onChange={(e) => {
                              handleUserInput(e, "workFlowUser");
                            }}
                            defaultValue={formInput?.workFlowUser}
                          />
                        </Grid>
                      </>
                    )} */}

                    <Grid
                      className="sub-detail-container full-width-textField hide-mob"
                      item
                      lg={6}
                      md={6}
                      sm={6}
                      xs={0}
                    >
                      <span></span>
                    </Grid>

                    {/* {!viewDetails && workflowDetailData && (
                    <>
                      <Grid item container spacing="3">
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Corporate ID</span>
                            <span className="content">
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.customerId
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Corporate Name</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.customerName
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Wireflow Name</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.workflowName
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Transaction Type</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.tranType
                              }{" "}
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">
                              Transaction from Amount
                            </span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.fromTransactionAmount
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Transaction To Amount</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.toTransactionAmount
                              }
                            </span>
                          </div>
                        </Grid>
                      </Grid>
                      {workflowDetailData?.groupDetails?.makerGroupDetails && (
                        <Grid
                          spacing="3"
                          item
                          className="makerGroupsContainer"
                          lg={12}
                          md={12}
                          sm={12}
                          xs={12}
                        >
                          <div className="heading">Maker Groups</div>
                          <div className="select-group-container">
                            <RadioList
                              variant="filled"
                              list={{
                                title: "Select Group",
                                items: [
                                  {
                                    label: "Sequence",
                                    name: "sequence",
                                    value: "sequence",
                                    checked: maker_sequence,
                                    disabled: !maker_sequence,
                                  },
                                  {
                                    label: "Random",
                                    name: "random",
                                    value: "random",
                                    checked: !maker_sequence,
                                    disabled: maker_sequence,
                                  },
                                ],
                              }}
                            />
                          </div> */}

                    {/* <div className="maker-table-container">
                            <Grid container className="header">
                              <Grid lg={4} md={4} sm={4} xs={4} item>
                                Group Name
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                User Count
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                Sequence Number
                              </Grid>
                            </Grid>

                            <Grid container className="items-container">
                              {workflowDetailData?.groupDetails?.makerGroupDetails?.makerGroupName?.map(
                                (item, key) => (
                                  <div className="item-row">
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      item
                                      className=""
                                    >
                                      {item}
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.makerGroupDetails?.makerUserCount?.[
                                          key
                                        ]
                                      }
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.makerGroupDetails
                                          ?.makerSequenceNumber?.[key]
                                      }
                                    </Grid>
                                  </div>
                                )
                              )}

                              <div className="item-row">
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  item
                                  className=""
                                >
                                  Total Makers
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.totalMakerCount
                                  }
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.makerSequenceNumber
                                  }
                                </Grid>
                              </div>
                            </Grid>
                          </div> */}
                    {/* </Grid>
                      )}
                      {workflowDetailData?.groupDetails
                        ?.checkerGroupDetails && (
                        <Grid
                          item
                          className="makerGroupsContainer"
                          lg={12}
                          md={12}
                          sm={12}
                          xs={12}
                        >
                          <div className="heading">Checker Groups</div>
                          <div className="select-group-container">
                            <RadioList
                              variant="filled"
                              list={{
                                title: "Select Group",
                                items: [
                                  {
                                    label: "Sequence",
                                    name: "sequence",
                                    value: "sequence",
                                    checked: checker_sequence,
                                    disabled: !checker_sequence,
                                  },
                                  {
                                    label: "Random",
                                    name: "random",
                                    value: "random",
                                    checked: !checker_sequence,
                                    disabled: checker_sequence,
                                  },
                                ],
                              }}
                            />
                          </div>

                          <div className="maker-table-container">
                            <Grid container className="header">
                              <Grid lg={4} md={4} sm={4} xs={4} item>
                                Group Name
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                User Count
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                Sequence Number
                              </Grid>
                            </Grid>
                            <Grid container className="items-container">
                              {workflowDetailData?.groupDetails?.checkerGroupDetails?.checkerGroupName?.map(
                                (item, key) => (
                                  <div className="item-row">
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      item
                                      className=""
                                    >
                                      {item}
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.checkerGroupDetails
                                          ?.checkerUserCount?.[key]
                                      }
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.checkerGroupDetails
                                          ?.checkerSequenceNumber?.[key]
                                      }
                                    </Grid>
                                  </div>
                                )
                              )}

                              <div className="item-row">
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  item
                                  className=""
                                >
                                  Total Checkers
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.totalCheckerCount
                                  }
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.checkerSequenceNumber
                                  }
                                </Grid>
                              </div>
                            </Grid>
                          </div>
                        </Grid>
                      )}
                    </>
                  )} */}
                  </Grid>
                </div>
              )}
            </div>
            <div className="close-container">
              <Button
                onClick={() => {
                  toggleDrawer(false);
                }}
                color="secondary"
              >
                Close
              </Button>
              {props?.location?.state?.action === "reject" ||
              props?.location?.state?.channelRefNoList ? (
                <Button
                  loading={isLoading}
                  onClick={() => handleSubmit("reject")}
                >
                  Reject
                </Button>
              ) : (
                <>
                  {/* {fxRateStatusData === "SUCCESS" && ( */}
                  <Button
                    loading={isLoading}
                    onClick={() => handleSubmit("authorize")}
                  >
                    Authorize
                  </Button>
                  {/* )} */}
                </>
              )}
            </div>
          </Drawer>
        </React.Fragment>
      </div>
    </div>
  );
};

export default WorkflowDetails;
