/* eslint-disable */
import React, { useState, useEffect } from "react";
import { useLocation, useHistory } from "react-router-dom";
import styles from "./index.module.css";
import {
  Box,
  Button as MuiButton,
  Container,
  Grid,
  Menu,
  MenuItem,
  Typography,
  withWidth,
} from "@material-ui/core";
import { Button } from "../../../../components/@subzero/glacier/package/lib/components";
import SuccessIcon from "../../../../assets/icons/progress-indicator.svg";
import ErrorIcon from "../../../../assets/icons/error-traingle.svg";
// import PdfIcon from "../../../../assets/icons/active-download.svg";
import CopyIcon from "../../../../assets/icons/copy.svg";
import ActiveDownloadIcon from "../../../../assets/icons/active-download.svg";

import { Actions } from "../../../../store/rootActions";
import { useDispatch, useSelector } from "react-redux";
import AlertPopup from "../../../../components/alertPopup/alertPopup";

const now = new Date();
const AuthorizeSuccess = (props) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const showDownloadOption = Boolean(anchorEl);
  const [statusData, updateStatusData] = useState(null);
  const [finalCheckerData, updateFinalCheckerData] = useState(null);
  const [channelRefNumberData, updateChannelRefNumberData] = useState(null);
  const [channelRefNumberListData, updateChannelRefNumberListData] =
    useState(null);

  const location = useLocation();
  const history = useHistory();
  const dispatch = useDispatch();
  const [alertStatus, setAlertStatus] = useState(false);
  const [alertMsg, setAlertMessage] = useState("");

  useEffect(() => {
    console.log(location?.state);
    if (location?.state) {
      updateChannelRefNumberData(location?.state?.channelRefNo);
      updateChannelRefNumberListData(location?.state?.channelRefNoList);
      updateStatusData(location?.state?.status);
      updateFinalCheckerData(location?.state?.finalChecker);
    }
  }, []);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleDownload = () => {
    const req = {
      recordStatus: "",
      id: channelRefNumberData?.id,
      refNumber: channelRefNumberData?.label,
    };

    // API for document download
    dispatch(Actions.downloadDocuments(req, "CHANNELGENDOC"));
  };

  const handleCopy = () => {
    /* Copy the text inside the text field */
    navigator.clipboard.writeText("FIDB-" + channelRefNumberData?.id);
    // alert("Service Request ID Copied");
    setAlertMessage("Service Request ID Copied");
    setAlertStatus(true);
  };

  const onCloseAlertPopup = () => {
    setAlertStatus(false);
  };

  return (
    <Container className={styles.successSection}>
      {statusData === "rejected" ? (
        <>
          <img src={ErrorIcon} alt="" style={{ width: "40px" }} />
          <Typography className={styles.successHeader}>Rejected</Typography>
          <Typography className={styles.successSubHeader}>
            FIDB Payment transaction with reference number{" "}
            {channelRefNumberListData
              ? channelRefNumberListData.map((item) => item)
              : channelRefNumberData?.label}{" "}
            has been rejected back to the maker
          </Typography>

          {!channelRefNumberListData && (
            <Box className={styles.successTable}>
              <Grid container spacing={0} direction="column">
                <Grid className={styles.successTableHead}>
                  <Typography className={styles.successTableHeader}>
                    Service Request
                  </Typography>
                  <MuiButton
                    variant="outlined"
                    id="downloadButton"
                    className={styles.successTableMuiDownloadButton}
                    endIcon={<img src={ActiveDownloadIcon} alt="" />}
                    onClick={handleClick}
                    aria-controls="basic-menu"
                    aria-haspopup="true"
                    aria-expanded={showDownloadOption ? "true" : undefined}
                  >
                    Download
                  </MuiButton>
                  <Menu
                    id="downloadButton"
                    open={showDownloadOption}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    getContentAnchorEl={null}
                    MenuListProps={{
                      "aria-labelledby": "downloadButton",
                    }}
                    className={styles.successTableMuiDownloadMenu}
                  >
                    <MenuItem
                      onClick={handleDownload}
                      className={styles.successTableMuiDownloadOptionButton}
                    >
                      <img src={ActiveDownloadIcon} alt="" />
                      <span
                        className={styles.successTableMuiDownloadOptionLabel}
                      >
                        PDF
                      </span>
                    </MenuItem>
                  </Menu>
                </Grid>
                <Grid className={styles.successTableBody}>
                  <Typography className={styles.successTableHeader}>
                    FIDB-{channelRefNumberData?.id}
                  </Typography>
                  <MuiButton
                    onClick={() => handleCopy()}
                    className={styles.successTableMuiCopyButton}
                    endIcon={<img src={CopyIcon} alt="" />}
                  >
                    Copy
                  </MuiButton>
                </Grid>
              </Grid>
            </Box>
          )}

          <Button
            color="primary"
            className={styles.successGoToDashboardButton}
            onClick={() => {
              history.push("/dashboard");
            }}
          >
            Go to Dashboard
          </Button>

          {alertStatus && (
            <AlertPopup
              alertMsg={alertMsg}
              alertType={"success"}
              isAlertOpen={true}
              onClose={() => setAlertStatus(false)}
            />
          )}
        </>
      ) : (
        <>
          <img src={SuccessIcon} alt="" />
          <Typography className={styles.successHeader}>Success</Typography>
          <Typography className={styles.successSubHeader}>
            <>
              FIDB Payment transaction with reference number{" "}
              {channelRefNumberListData
                ? channelRefNumberListData.map((item) => item)
                : channelRefNumberData?.label}{" "}
              has been successfully submitted to the{" "}
              {finalCheckerData ? (
                <>
                  bank for authorization.
                  <br />
                  Transaction shall be processed subject to internal and
                  regulatory compliance
                  {now.getHours() > 16 ||
                    (now.getHours() === 16 && now.getMinutes() >= 30)}{" "}
                  <br />
                  Note: Request submitted after cut off time; this request shall
                  be processed by the Bank only on the next working day.
                </>
              ) : (
                <>checker for authorization.</>
              )}
            </>
          </Typography>
          {!channelRefNumberListData && (
            <Box className={styles.successTable}>
              <Grid container spacing={0} direction="column">
                <Grid className={styles.successTableHead}>
                  <Typography className={styles.successTableHeader}>
                    Service Request
                  </Typography>
                  <MuiButton
                    variant="outlined"
                    id="downloadButton"
                    className={styles.successTableMuiDownloadButton}
                    endIcon={<img src={ActiveDownloadIcon} alt="" />}
                    onClick={handleClick}
                    aria-controls="basic-menu"
                    aria-haspopup="true"
                    aria-expanded={showDownloadOption ? "true" : undefined}
                  >
                    Download
                  </MuiButton>
                  <Menu
                    id="downloadButton"
                    open={showDownloadOption}
                    anchorEl={anchorEl}
                    onClose={handleClose}
                    getContentAnchorEl={null}
                    MenuListProps={{
                      "aria-labelledby": "downloadButton",
                    }}
                    className={styles.successTableMuiDownloadMenu}
                  >
                    <MenuItem
                      onClick={handleDownload}
                      className={styles.successTableMuiDownloadOptionButton}
                    >
                      <img src={ActiveDownloadIcon} alt="" />
                      <span
                        className={styles.successTableMuiDownloadOptionLabel}
                      >
                        PDF
                      </span>
                    </MenuItem>
                  </Menu>
                </Grid>
                <Grid className={styles.successTableBody}>
                  <Typography className={styles.successTableHeader}>
                    FIDB-{channelRefNumberData?.id}
                  </Typography>
                  <MuiButton
                    onClick={() => handleCopy()}
                    className={styles.successTableMuiCopyButton}
                    endIcon={<img src={CopyIcon} alt="" />}
                  >
                    Copy
                  </MuiButton>
                </Grid>
              </Grid>
            </Box>
          )}

          <Button
            color="secondary"
            className={styles.successGoToDashboardButton}
            onClick={() => {
              history.push("/dashboard");
            }}
          >
            Go to Dashboard
          </Button>
          <Button
            color="primary"
            className={styles.successNewPaymentButton}
            onClick={() => {
              history.push("/transaction-inquiry", {
                status: "Pending with Auth",
                action: "PRE_ACC",
              });
            }}
          >
            Go to new Requests
          </Button>
          {alertStatus && (
            <AlertPopup
              alertMsg={alertMsg}
              alertType={"success"}
              isAlertOpen={true}
              onClose={() => setAlertStatus(false)}
            />
          )}
        </>
      )}
    </Container>
  );
};

export default AuthorizeSuccess;
