/* eslint-disable */
import React, { useEffect, useState } from "react";
import { Divider, TextField } from "@material-ui/core";

import { makeStyles } from "@material-ui/core/styles";
import Link from "@material-ui/core/Link";
import AddIcon from "../../../assets/icons/add-icon.svg";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";

import CloseIcon from "../../../assets/icons/close.svg";
import Drawer from "@material-ui/core/Drawer";

import {
  Button,
  Checkbox,
} from "../../../components/@subzero/glacier/package/lib/components";
import Edit from "../../../assets/icons/edit-white.svg";
import Accordion from "@material-ui/core/Accordion";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import BuildingIcon from "../../../assets/icons/building.svg";
import RedDot from "../../../assets/icons/red-dot.svg";
import InfoIcon from "../../../assets/icons/info-icon.svg";
import Grid from "@material-ui/core/Grid";

import styles from "./review.module.css";
import "./index.css";
import AgGridTable from "../../../components/aggridtable";
import BookRateView from "../payment_details/BookRateView";
import PreBookedDealsView from "../payment_details/PrebookedDealsView";
import ForwardContractView from "../payment_details/ForwardContractView";
import AttachDocuments from "../../../components/attachdocuments";
import SwiftMessage from "./SwiftMessage";
import Loader from "../../../components/loader";
import RateInstruction from "../payment_details/RateInstruction";
import RateInstructionChecker from "../payment_details/RateInstructionChecker";
import AlertPopup from "../../../components/alertPopup/alertPopup";
import BoeDetails from "../../boe/details";
let count1 = 0;
let count2 = 0;
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
}));

const Review = (props) => {
  const classes = useStyles();
  const [showRemarkForm, updateFormDisplay] = React.useState([
    false,
    false,
    false,
    false,
    false,
  ]);
  const [remarks, setRemarks] = React.useState([null, null, null, null, null]);
  const [showRemarkButton, updateButtonDisplay] = React.useState([
    true,
    true,
    true,
    true,
    true,
  ]);
  const dispatch = useDispatch();
  const state = useSelector((state) => state?.paymentReviewData);
  const authData = useSelector((state) => state?.auth?.loginData);
  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const boeState = useSelector((state) => state?.boe);
  const [alertStatus, setAlertStatus] = useState(false);
  const [tempDataAlertStatus, setTempDataAlertStatus] = useState(false);
  const [tempDataAlertMsg, setTempDataAlertMsg] = useState(null);
  const [showBoeDetails, setShowBoeDetails] = useState(false);
  const [boeDetailsParams, setBoeDetailsParams] = useState(null);
  // const transactionDetailsStoreData = useSelector(
  //   (state) => state?.transactionDetails
  // );

  const [loader, setLoader] = useState(false);
  const [swiftMessageView, updateSwiftMessageView] = useState(false);
  // review data states
  const [transactionReviewDetails, setTransactionReviewDetails] =
    useState(null);
  const [paymentReviewDetails, setPaymentReviewDetails] = useState(
    state?.paymentDetails
  );
  const [bookRateData, setBookRateData] = useState(state?.bookRate);
  const [displayRateData, setDisplayRateData] = useState(state?.displayRate);
  const [fxRateStatusData, setFxRateStatusData] = useState(state?.fxRateStatus);
  const [fxRateAmountData, setFxRateAmountData] = useState(state?.fxRateAmount);
  const [fxRateMessageIdData, setFxRateMessageIdData] = useState(
    state?.fxRateMessageId
  );
  const [tridbNumberData, setTridbNumberData] = useState(state?.tridbNumber);
  const [convertedAmountData, setConvertedAmountData] = useState(
    state?.convertedAmount
  );
  const [beneficiaryReviewDetails, setBeneficiaryReviewDetails] = useState(
    state?.beneficiaryDetails
  );
  const [beneAccDetailsData, setBeneAccDetailsData] = useState(
    state?.beneAccDetails
  );
  const [beneDetailsData, setBeneDetailsData] = useState(state?.beneDetails);
  const [fidbMarginData, setFidbMarginData] = useState(state?.fidbMargin);
  const [fxRateResponseData, setFxRateResponseData] = useState(
    state?.fxRateResponse
  );
  const [attachdocumentsDetails, setAttacheddocuments] = useState(
    state?.attchedDocuments
  );
  const [openDeclarationModal, setOpenDeclarationModal] = useState(false);
  // const [alertStatus, setAlertStatus] = useState(false);

  const onCloseAlertPopup = () => {
    // setAlertStatus(false);
  };

  const toggleDeclarationDrawer = (open) => {
    // if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
    //     return;
    // }
    setOpenDeclarationModal(open);
    if (!open) {
      // history.goBack();
      // props?.onClose();
    }
  };

  useEffect(() => {
    let req;

    // // if user us checker call getBookRate API
    // if (authData?.userRoleType === "C") {
    //   // call getBookRate API
    //   // req = {
    //   //   convertedAmount: "", // dummy data
    //   //   exchangeRate: "", // dummy data
    //   // };

    //   req = {
    //     userId: authData?.userId,
    //     corpId: authData?.corpId,
    //     bankCode: authData?.bankCode,
    //     fidbtxnId: props?.recKey,
    //     exchangeRate: displayRateData,
    //     fxRateMessageId: fxRateMessageIdData,
    //     remmitanceAmount:
    //       paymentReviewDetails?.fxrateInstructionDetails[0]?.amountInInr,
    //     utilizedAmount:
    //       paymentReviewDetails?.fxrateInstructionDetails[0]?.amountToBeUtilized,
    //     fidbMargin: fidbMarginData,
    //     fxRateResponse: fxRateResponseData,
    //   };

    //   //CALL PAYMENT REVIEW API
    //   dispatch(Actions.getBookRate(req));
    // }

    req = {
      corpId: authData?.corpId,
      userId: authData?.userId,
      bankCode: authData?.bankCode,
      recKey: props?.recKey,
    };

    //CALL PAYMENT REVIEW API
    dispatch(Actions.getpaymentReviewData(req));

    //CALL BENEFICIARY REVIEW API
    dispatch(Actions.getBeneficiaryReviewData(req));

    //CALL TRANSACTION REVIEW API
    dispatch(Actions.getTransactionReviewData(req));

    //CALL ATTACH DOCUMENTS REVIEW API
    dispatch(Actions.getAttachDocumentsReviewData(req));

    //Fetch Comments
    const request = {
      recKey: props?.recKey,
      sectionId: "0",
      moduleId: "FIDB",
    };
    dispatch(Actions.fetchComments(request));
    request.sectionId = "1";
    dispatch(Actions.fetchComments(request));
    request.sectionId = "2";
    dispatch(Actions.fetchComments(request));
    request.sectionId = "3";
    dispatch(Actions.fetchComments(request));
    request.sectionId = "4";
    dispatch(Actions.fetchComments(request));
  }, []);

  useEffect(() => {
    const {
      paymentDetails,
      beneficiaryDetails,
      beneAccDetails,
      beneDetails,
      transactionDetails,
      attchedDocuments,
      bookRate,
      loader,
      displayRate,
      fxRateMessageId,
      tridbNumber,
      fxRateStatus,
      convertedAmount,
      fxRateResponse,
      fidbMargin,
      fxRateAmount,
    } = state;

    if (
      fxRateStatus ===
      "Utilized amount is exceeded/exceeding the Remittance Amount"
    ) {
      setAlertStatus(true);
    }

    // if (
    //   paymentDetails?.fxrateInstructionDetails[0]?.amountInInr &&
    //   paymentDetails?.fxrateInstructionDetails[0]?.amountToBeUtilized &&
    //   displayRate === null &&
    //   count === 0
    // ) {
    //   count++;
    //   let req = {
    //     userId: authData?.userId,
    //     corpId: authData?.corpId,
    //     currency: "USD",
    //     fidbtxnId: props?.recKey,
    //     amount: paymentDetails?.fxrateInstructionDetails[0]?.amountInInr,
    //     subCustId: authData?.subcustId,
    //     utilizationAmount:
    //       paymentDetails?.fxrateInstructionDetails[0]?.amountToBeUtilized,
    //   };

    //   dispatch(Actions.getFxRateMarginValidation(req));
    // }

    transactionDetails?.length > 0 &&
      transactionDetails?.map((item) => {
        if (item?.invoiceDetails) {
          item.invoiceList = fetchInvoiceDetails(item?.invoiceDetails);
        }
      });

    setConvertedAmountData(convertedAmount);
    setTridbNumberData(tridbNumber);
    setDisplayRateData(displayRate);
    setFxRateStatusData(fxRateStatus);
    setFxRateAmountData(fxRateAmount);
    setFxRateMessageIdData(fxRateMessageId);
    setBookRateData(bookRate);
    setPaymentReviewDetails(paymentDetails);
    setBeneficiaryReviewDetails(beneficiaryDetails);
    setBeneAccDetailsData(beneAccDetails);
    setBeneDetailsData(beneDetails);
    setFidbMarginData(fidbMargin);
    setFxRateResponseData(fxRateResponse);
    setAttacheddocuments(attchedDocuments);
    setTransactionReviewDetails(transactionDetails);
    setLoader(loader);

    // display alert message if Bank or Beneficiary data is temp
    if (beneDetails !== null) {
      let msg = "";
      if (
        beneAccDetails?.isBankAvailableInTemp === true &&
        beneDetails?.isBeneAvailableInTemp === true
      ) {
        msg =
          "Temporary Bank data and Beneficiary data will be approved while authorizing this transaction.";
      } else if (
        beneAccDetails?.isBankAvailableInTemp === true &&
        beneDetails?.isBeneAvailableInTemp === false
      ) {
        msg =
          "Temporary Bank data will be approved while authorizing this transaction.";
      } else if (
        beneAccDetails?.isBankAvailableInTemp === false &&
        beneDetails?.isBeneAvailableInTemp === true
      ) {
        msg =
          "Temporary Beneficiary data will be approved while authorizing this transaction.";
      }

      if (msg !== "") {
        setTempDataAlertStatus(true);
        setTempDataAlertMsg(msg);
        setTimeout(() => {
          setTempDataAlertStatus(false);
        }, 5000);
      }
    }
  }, [state]);

  useEffect(() => {
    if (paymentReviewDetails) {
      // if (paymentReviewDetails?.prebookInstructionDetails?.length > 0) {
      //   paymentReviewDetails?.prebookInstructionDetails.map((item) => {
      //     // call 105% api for each deal item
      //     console.log(item);
      //     const req = {
      //       dealId: item?.dealId,
      //       recKey: props?.recKey,
      //       amountToBeUtilized: item?.amountToBeUtilized,
      //     };
      //     dispatch(Actions.dealAmountValidation(req));
      //   });
      // }

      // if (paymentReviewDetails?.fxrateInstructionDetails?.length > 0) {
      //   paymentReviewDetails?.fxrateInstructionDetails.map((item) => {
      //     // call 105% api for each deal item
      //     const req = {
      //       dealId: item?.dealId,
      //       recKey: props?.recKey,
      //       amountToBeUtilized: item?.amountToBeUtilized,
      //     };
      //     dispatch(Actions.dealAmountValidation(req));
      //   });
      // }

      // ================== updateFxRateAmount should be called only once

      if (count1 === 0) {
        count1++;
        // if paymentMode !== "EEFC Account" cacluate fxRateAmount
        if (paymentReviewDetails?.paymentMode !== "EEFC Account") {
          //  call updateFxRateAmount api and getCardRate api
          // fxRateAmount = osremittance_amount(outstanding_amount) - sum of utilized amount in the deals level
          let fxRateAmountCalculated;
          // fxRateAmountCalculated =
          //   paymentReviewDetails?.fxrateInstructionDetails[0]
          //     ?.outstandingAmount; // to do - this needs to updated , dont depend on fxrateInstructionDetails param

          fxRateAmountCalculated = paymentReviewDetails?.operativeAmount; // to do - need to confirm
          paymentReviewDetails?.prebookInstructionDetails?.map((item) => {
            fxRateAmountCalculated =
              fxRateAmountCalculated - item?.amountToBeUtilized;
          });
          paymentReviewDetails?.fwcInstructionDetails?.map((item) => {
            fxRateAmountCalculated =
              fxRateAmountCalculated - item?.amountToBeUtilized;
          });
          dispatch(Actions.updateFxRateAmount(fxRateAmountCalculated));

          const req = {
            paymentDate: paymentReviewDetails?.paymentDate,
            fixedCurrencyCode: "INR",
            variableCurrencyCode: paymentReviewDetails?.currency,
          };
          dispatch(Actions.getCardRate(req));
          console.log("calling getCardRate api");
        }
      }
    }
  }, [paymentReviewDetails]);

  useEffect(() => {
    if (paymentReviewDetails) {
      if (paymentReviewDetails?.prebookInstructionDetails?.length > 0) {
        paymentReviewDetails?.prebookInstructionDetails.map((item) => {
          // call 105% api for each deal item
          if (item?.dealId && item?.amountToBeUtilized) {
            const req = {
              dealId: item?.dealId,
              recKey: props?.recKey,
              amountToBeUtilized: item?.amountToBeUtilized,
            };
            dispatch(Actions.dealAmountValidation(req));
          }
        });
      }

      if (paymentReviewDetails?.fxrateInstructionDetails?.length > 0) {
        paymentReviewDetails?.fxrateInstructionDetails.map((item) => {
          // call 105% api for each deal item
          if (item?.dealId && item?.amountToBeUtilized) {
            const req = {
              dealId: item?.dealId,
              recKey: props?.recKey,
              amountToBeUtilized: item?.amountToBeUtilized,
            };
            dispatch(Actions.dealAmountValidation(req));
          }
        });
      }
    }
  }, [
    paymentReviewDetails?.prebookInstructionDetails,
    paymentReviewDetails?.fxrateInstructionDetails,
  ]);

  useEffect(() => {
    if (transactionReviewDetails) {
      transactionReviewDetails[0]?.invoiceList?.map((item) => {
        // call 105% api for each invoice item
        const req = {
          invoiceNumber: item?.invoiceNo?.value,
          invoiceAmount: item?.invoiceAmountFOB?.value,
          outstandingAmount: item?.osInvoiceAmountFOB?.value,
          invoicePayableAmount: item?.invoicePayableAmount?.value,
          chargesPayableAmount: item?.chargesPayableAmount?.value,
        };
        dispatch(Actions.totalAmountValidation(req));
      });
    }
  }, [transactionReviewDetails]);

  // useEffect(() => {
  //   if (paymentReviewDetails?.cardRate) {
  //     const req = {
  //       currencyTyp: paymentReviewDetails?.currency,
  //       amount: paymentReviewDetails?.operativeAmount,
  //       baseCurrency: "INR",
  //       bankCode: authData?.bankCode,
  //     };
  //     dispatch(Actions.currencyConvert(req));
  //   }
  // }, [paymentReviewDetails?.cardRate]);

  // call getAccountDetails api
  useEffect(() => {
    if (beneficiaryReviewDetails !== null) {
      let req;
      if (authData?.userRoleType === "C" && count2 === 0) {
        count2++;
        req = {
          beneficiaryId: beneficiaryReviewDetails?.beneficiaryId,
          beneficiaryACNo: beneficiaryReviewDetails?.beneBankAccountNumber,
        };
        dispatch(Actions.getAccountDetails(req));
      }
    }
  }, [beneficiaryReviewDetails]);

  // when beneAccDetailsData data is available
  useEffect(() => {
    let req;
    // if user us checker call
    if (authData?.userRoleType === "C" && beneAccDetailsData !== null) {
      // call getBeneficiarytDetails API
      req = {
        beneficiaryId: beneAccDetailsData?.beneficiaryId,
      };
      //CALL getBeneficiarytDetails API
      dispatch(Actions.getBeneficiarytDetails(req));
    }
  }, [beneAccDetailsData]);

  const updateRemarksDisplay = (id, value) => {
    const newArrForm = [...showRemarkForm];
    const newArrButton = [...showRemarkButton];
    newArrForm[id] = value;
    newArrButton[id] = false;
    updateButtonDisplay(newArrButton);
    updateFormDisplay(newArrForm);
  };

  const onChangeRemarks = (e, id) => {
    const newRemarksArray = [...remarks];
    newRemarksArray[id] = e.target.value;
    setRemarks(newRemarksArray);
  };

  const onBlurRemarks = (e, id) => {
    // call save comments api
    const req = {
      recKey: props?.recKey,
      sectionId: id,
      moduleId: "FIDB",
      comments: e.target.value,
    };

    //CALL saveComments API
    dispatch(Actions.saveComments(req));
  };

  function createData(
    invoiceNo,
    invoiceDate,
    currency,
    invoiceAmountFOB,
    osInvoiceAmountFOB,
    osCharges,
    invoicePayableAmount,
    chargesPayableAmount
  ) {
    return {
      invoiceNo,
      invoiceDate,
      currency,
      invoiceAmountFOB,
      osInvoiceAmountFOB,
      osCharges,
      invoicePayableAmount,
      chargesPayableAmount,
    };
  }

  const generateTableRowValues = (rows) => {
    if (rows?.length > 0) {
      const newArray = [...rows];
      const resultArray = [];
      newArray.map((rowItem) => {
        const newObject = {};
        Object.keys(rowItem).map((key) => {
          const value = rowItem[key];
          switch (key) {
            default:
              newObject[key] = { value: value };
              break;
          }
        });
        resultArray.push(newObject);
      });
      return resultArray;
    }
  };

  const findCountryName = (code) => {
    if(code){
      return boeState?.benefCountryOptions?.find((item) => {
        if(code?.includes("-")){
          code = code.split("-")[0].trim();
        }
        return item.id === code;
      })?.label || code;
    }else{
      return "-";
    }
  };

  const fetchInvoiceDetails = (arrayDetails) => {
    const rowData = arrayDetails.map((invoiceItem) => {
      const {
        invoiceNo,
        invoiceDate,
        invoiceCurrency,
        invoiceAmunt,
        outstandingInvoiceAmount,
        outstandingChargesAmount,
        invoicePayableAmount,
        chargesPayableAmount,
      } = invoiceItem;

      return createData(
        invoiceNo,
        invoiceDate,
        invoiceCurrency,
        invoiceAmunt,
        outstandingInvoiceAmount,
        outstandingChargesAmount ? outstandingChargesAmount : 0,
        invoicePayableAmount,
        chargesPayableAmount
      );
    });
    return generateTableRowValues(rowData);
  };

  const downloadDocuments = (documentData) => {
    const req = {
      id: documentData?.id,
      bankCode: authData?.bankCode,
      fileName: documentData?.fileName,
    };

    //CALL DOWNLOAD DOCUMENT API
    dispatch(Actions.downloadAttachedDocuments(req));
  };
  if (loader) {
    return <Loader />;
  }

  return (
    <>
      <div className="review-container">
        <div className="row-sub-container">
          {!swiftMessageView ? (
            <>
              <span className="review-text">Review and Submit</span>
              <Button
                color="secondary"
                classes={{ root: styles.swiftButton }}
                onClick={() => updateSwiftMessageView(true)}
              >
                View as SWIFT Message
              </Button>
            </>
          ) : (
            <>
              <span className="review-text">Review (SWIFT Message)</span>
              <Button
                color="secondary"
                classes={{ root: styles.swiftButton }}
                onClick={() => updateSwiftMessageView(false)}
              >
                Review as Detail View
              </Button>
            </>
          )}
        </div>
        {authData?.userRoleType === "M" && state?.comments?.overall && (
          <div style={{ width: "100%" }}>
            <Grid
              container
              spacing={1}
              className={styles.reviewCommentContainer}
            >
              <Grid
                className="review-grid-container"
                item
                lg={12}
                md={12}
                sm={12}
                xs={12}
              >
                <span className="grid-content-header">
                  Remarks from Checker
                </span>
                <span className="grid-content-text">
                  {state?.comments?.overall ? state?.comments?.overall : ""}
                </span>
              </Grid>
            </Grid>
          </div>
        )}
        {/*  @todo */}
        {/* Rate not delegated to checker -- >  start */}
        {authData?.userRoleType === "C" &&
          !paymentReviewDetails?.delegateToChecker &&
          paymentReviewDetails?.paymentMode !== "EEFC Account" && (
            <div className="row-sub-container" style={{ width: "100%" }}>
              <Grid lg={12}>
                <div
                  className="error-box review-checker-info"
                  style={{ marginLeft: 0 }}
                >
                  <img src={InfoIcon} />
                  <Grid container>
                    <div>
                      <Grid item className={"heading"}>
                        Rate Booking
                      </Grid>
                      <Grid item className={"content"}>
                        Checker to provide instruction to Book Rate online as
                        Amount is more than INR 10,00,000.00 (Optional)
                      </Grid>
                    </div>
                  </Grid>
                  {/* {tridbNumberData === null && (
                  <Button
                    disabled={fxRateStatusData !== "SUCCESS"}
                    classes={{ root: styles.bookRateButton }}
                  >
                    Book Rate
                  </Button>
                )} */}
                </div>
              </Grid>
            </div>
          )}
        {/* Rate not delegated to checker -- > Greater than 10 lakhs Book Rate Online “Not booked”- end */}
        {!swiftMessageView ? (
          <>
            {/* Checker Review (Using faster processing (Paper-based) as master) start */}

            {/* show Remarks for Checker  when userRoleType = 'C' - start */}
            {authData?.userRoleType === "C" &&
              !paymentReviewDetails?.delegateToChecker &&
              paymentReviewDetails?.commentsToAuth && (
                <div className={"review-remarks-card"}>
                  <Grid container className={"labels"}>
                    <Grid item className={"left-label"}>
                      <span>Remarks for Checker </span>
                    </Grid>
                    <Grid item className={"right-label"}>
                      <span>Name, 9:00 PM</span>
                    </Grid>
                  </Grid>
                  <Grid container className={"content"}>
                    <span>{paymentReviewDetails?.commentsToAuth}</span>
                  </Grid>
                </div>
              )}
            {/* show Remarks for Checker  when userRoleType = 'C' - end */}

            {/* <div className={"review-remarks-card"}>
            <Grid container className={"labels"}>
              <Grid item className={"left-label"}>
                <span>Remarks for Checker </span>
              </Grid>
              <Grid item className={"right-label"}>
                <span>Name, 9:00 PM</span>
              </Grid>
            </Grid>
            <Grid container className={"content"}>
              <span>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam
                eu interdum risus. Pellentesque suscipit dolor viverra tellus
                sagittis blandit. Nullam neque ligula, vulputate sit amet ex id,
                interdum posuere tellus.
              </span>
            </Grid>
          </div> */}
            {/* Checker Review (Using faster processing (Paper-based) as master) end */}

            <div className="review-border-container">
              <div className="row-sub-container">
                <span className="trans-details-text">Transaction Details</span>
                {!props?.successTransactionView &&
                  !props.fromChannelRefNo &&
                  authData?.userRoleType === "M" && (
                    <Button
                      withIcon
                      endIcon={<img src={Edit} />}
                      classes={{ root: styles.editButton }}
                      onClick={props?.redirectToTransaction}
                    >
                      Edit
                    </Button>
                  )}
              </div>
              <Divider className="review-divider" />

              <div className="review-column">
                <span className="review-column-heading">Applicant Details</span>
                <Grid container spacing={3} justifyContent="flex-start">
                  <Grid
                    className="review-grid-container"
                    item
                    lg={2}
                    md={3}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Customer ID </span>
                    <span className="grid-content-text">
                      {transactionDetails?.custIdAndIeCode?.custId ||
                        authData?.subcustId ||
                        "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={5}
                    md={5}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Customer Name</span>
                    <span className="grid-content-text">
                      {(transactionReviewDetails &&
                        transactionReviewDetails[0]?.applicantName) ||
                        "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={4}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">IE Code</span>
                    <span className="grid-content-text">
                      {transactionDetails?.custIdAndIeCode?.ieCode ||
                        authData?.ieCode ||
                        "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={2}
                    md={3}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Country</span>
                    <span className="grid-content-text">
                      {(transactionReviewDetails &&
                        transactionReviewDetails[0]?.aplicantCountry) ||
                        "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={6}
                    md={6}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Address</span>
                    <span className="grid-content-text">
                      {(transactionReviewDetails &&
                        transactionReviewDetails[0]?.applicantAddress) ||
                        "-"}
                    </span>
                  </Grid>
                </Grid>
              </div>
              {transactionReviewDetails?.length > 0 &&
                transactionReviewDetails?.map((item) => (
                  <>
                    <span
                      className="review-typeOfGoods-column-heading"
                      style={{ marginBottom: "0px" }}
                    >
                      Type of goods: {item?.typesOfGood}{" "}
                    </span>
                    {/* <span className="type-of-goods"></span>
                  <span className="goods-type">{item?.typesOfGood}</span> */}
                    <Accordion className={styles.reviewGreyContainer}>
                      <AccordionSummary
                        style={{ paddingLeft: "0px" }}
                        expandIcon={
                          <ExpandMoreIcon className="expand-more-icon" />
                        }
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                      >
                        <Grid container direction="column" spacing={3}>
                          <Grid
                            spacing={3}
                            container
                            item
                            justifyContent="space-between"
                          >
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                BOE Number
                              </span>
                              <span className="grid-content-text">
                                <Link
                                  component="button"
                                  color="secondary"
                                  underline="always"
                                  onClick={() => {
                                    setShowBoeDetails(true);
                                    setBoeDetailsParams({ item: item });
                                  }}
                                >
                                  {item?.boeNumber || "-"}
                                </Link>
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                BOE Date
                              </span>
                              <span className="grid-content-text">
                                {item?.boeDate || "-"}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                Supplier Name
                              </span>
                              <span className="grid-content-text">
                                {item?.supplierName || "-"}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                Number of Invoices
                              </span>
                              <span className="grid-content-text">
                                {item?.numberOfInvoice || "-"}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={4}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                Invoice Amount- FOB
                              </span>
                              <span className="grid-content-text">
                                {item?.currency +
                                  " " +
                                  item?.totalInvoiceAmount}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                O/S Invoice Amount- FOB
                              </span>
                              <span className="grid-content-text">
                                {item?.currency +
                                  " " +
                                  item?.outstandingInvoiceAmount}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                Total Payable Amount
                              </span>
                              <span className="grid-content-text">
                                {item?.currency +
                                  " " +
                                  item?.totalPayableAmount}
                              </span>
                            </Grid>
                          </Grid>
                        </Grid>
                      </AccordionSummary>
                      <AccordionDetails
                        className="review-column"
                        style={{ padding: "0px" }}
                      >
                        <div className="review-column">
                          <span className="review-column-heading">
                            Goods Detail
                          </span>
                          <Grid
                            container
                            spacing={3}
                            justifyContent="flex-start"
                          >
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                HS Code
                              </span>
                              <span className="grid-content-text">
                                {item?.hsCode || "-"}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                Goods Description (Optional)
                              </span>
                              <span className="grid-content-text">
                                {item?.goodsDescription || "-"}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                Origin of Goods
                              </span>
                              <span className="grid-content-text">
                                {findCountryName(item?.goodsOrigin) || "-"}
                              </span>
                            </Grid>
                          </Grid>
                        </div>

                        <div className="review-column">
                          <span className="review-column-heading">
                            Shipping Details
                          </span>
                          <Grid container item spacing={3} direction="column">
                            <Grid
                              container
                              item
                              spacing={3}
                              justifyContent="space-between"
                            >
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Mode of Shipment
                                </span>
                                <span className="grid-content-text">
                                  {item?.shipmentMode || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Flight Number
                                </span>
                                <span className="grid-content-text">
                                  {item?.flightNumber}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  BL/AWB Carrier Name
                                </span>
                                <span className="grid-content-text">
                                  {item?.blAwbCarrierName || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  BL/AWB Agent (Optional)
                                </span>
                                <span className="grid-content-text">
                                  {item?.blAwbAgent || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={4}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Place of Issue of Transport Document
                                  (Optional)
                                </span>
                                <span className="grid-content-text">
                                  {item?.placeOfIssueTransport || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Voyage Number (Optional)
                                </span>
                                <span className="grid-content-text">
                                  {item?.voyageNumber || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Vessel Name
                                </span>
                                <span className="grid-content-text">
                                  {item?.vesselNumber || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Nationality of Ship Flag (Optional)
                                </span>
                                <span className="grid-content-text">
                                  {item?.nationaltyOfShipFlag || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Charter/ Owner Party Name (Optional)
                                </span>
                                <span className="grid-content-text">
                                  {item?.charterOwnerParty || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={4}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Transhipment Place (Optional)
                                </span>
                                <span className="grid-content-text">
                                  {item?.transshipmentPlace || "-"}
                                </span>
                              </Grid>
                              <Grid
                                className="review-grid-container"
                                item
                                lg={2}
                                md={4}
                                sm={6}
                                xs={6}
                              >
                                <span className="grid-content-header">
                                  Transhipment Vessel (Optional)
                                </span>
                                <span className="grid-content-text">
                                  {item?.transhipmentVessel || "-"}
                                </span>
                              </Grid>
                            </Grid>
                          </Grid>
                        </div>

                        <div className="review-column">
                          <span className="review-column-heading">
                            Notify Party Details (Optional)
                          </span>
                          <Grid
                            container
                            spacing={3}
                            justifyContent="flex-start"
                          >
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">Name</span>
                              <span className="grid-content-text">
                                {item?.notifyPartyName || "-"}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={2}
                              md={4}
                              sm={6}
                              xs={6}
                            >
                              <span className="grid-content-header">
                                Country
                              </span>
                              <span className="grid-content-text">
                                {findCountryName(item?.notifyPartyCountry) || "-"}
                              </span>
                            </Grid>
                          </Grid>
                        </div>

                        <div className="review-column">
                          <span className="review-column-heading">
                            Invoice Details
                          </span>
                          <span className="grid-content-text">
                            All amounts are in invoice currency
                          </span>

                          <div>
                            <AgGridTable
                              headCells={[
                                {
                                  field: "invoiceNo",
                                  label: "Invoice No.",
                                  width: 100,
                                  minWidth: 100,
                                },
                                {
                                  field: "invoiceDate",
                                  numeric: false,
                                  disablePadding: false,
                                  label: "Invoice Date",
                                  smallCell: true,
                                },
                                {
                                  field: "currency",
                                  numeric: false,
                                  disablePadding: false,
                                  label: "Currency",
                                  width: 100,
                                  minWidth: 100,
                                },
                                {
                                  field: "invoiceAmountFOB",
                                  numeric: false,
                                  disablePadding: false,
                                  label: "Invoice Amount - FOB",
                                  width: 170,
                                  minWidth: 170,
                                  flex: 1,
                                  rightAligned: true,
                                },
                                {
                                  field: "osInvoiceAmountFOB",
                                  numeric: false,
                                  disablePadding: true,
                                  label: "O/S Invoice Amount - FOB",
                                  minWidth: 200,
                                  flex: 1,
                                  rightAligned: true,
                                },
                                {
                                  field: "osCharges",
                                  numeric: false,
                                  disablePadding: false,
                                  label: "O/S Charges (Optional)",
                                  minWidth: 180,
                                  flex: 1,
                                  rightAligned: true,
                                },
                                {
                                  field: "invoicePayableAmount",
                                  numeric: false,
                                  disablePadding: false,
                                  label: "Invoice Payable Amount",
                                  largeCell: true,
                                  flex: 1,
                                  rightAligned: true,
                                },
                                {
                                  field: "chargesPayableAmount",
                                  numeric: false,
                                  disablePadding: false,
                                  label: "Charges Payable Amount",
                                  largeCell: true,
                                  flex: 1,
                                  rightAligned: true,
                                },
                              ]}
                              tableOnly={true}
                              noRowSelection={true}
                              rows={item?.invoiceList}
                              autoSize={true}
                            />
                          </div>
                        </div>
                      </AccordionDetails>
                    </Accordion>
                  </>
                ))}

              {/* Checker Review (Using faster processing (Paper-based) as master) start */}
              {showRemarkForm[0] && (
                <Grid container>
                  <Grid item lg={12} md={12} className="remark-box">
                    <TextField
                      fullWidth
                      label="Remarks"
                      value={remarks[0]}
                      onChange={(e) => onChangeRemarks(e, 0)}
                      onBlur={(e) => onBlurRemarks(e, 0)}
                      type="text"
                      variant="filled"
                    />
                  </Grid>{" "}
                </Grid>
              )}
              {authData?.userRoleType === "C" && showRemarkButton[0] && (
                <span
                  className="add-new"
                  onClick={() => {
                    updateRemarksDisplay(0, true);
                  }}
                >
                  <img src={AddIcon} />
                  Add Remarks
                </span>
              )}

              {authData?.userRoleType === "M" && state?.comments?.trans && (
                <div style={{ width: "100%" }}>
                  <Grid
                    container
                    spacing={1}
                    className={styles.reviewCommentContainer}
                  >
                    <Grid
                      className="review-grid-container"
                      item
                      lg={12}
                      md={12}
                      sm={12}
                      xs={12}
                    >
                      <span className="grid-content-header">
                        Remarks from Checker
                      </span>
                      <span className="grid-content-text">
                        {state?.comments?.trans ? state?.comments?.trans : ""}
                      </span>
                    </Grid>
                  </Grid>
                </div>
              )}
              {/* Checker Review (Using faster processing (Paper-based) as master) end */}
            </div>

            <div className="review-border-container">
              <div className="row-sub-container">
                <span className="trans-details-text">Beneficiary Details</span>
                {!props?.successTransactionView &&
                  !props.fromChannelRefNo &&
                  authData?.userRoleType === "M" && (
                    <Button
                      withIcon
                      endIcon={<img src={Edit} />}
                      classes={{ root: styles.editButton }}
                      onClick={props?.redirectToBeneficiary}
                    >
                      Edit
                    </Button>
                  )}
              </div>
              <Divider className="review-divider" />
              <div className="checkbox-third-party d-flex-row">
                <Checkbox
                  checked={beneficiaryReviewDetails?.thirdPartyPayment}
                  disabled={true}
                />
                <span className="third-party-text">
                  This is a third-party payment
                </span>
              </div>
              <div className="review-column">
                <Grid container spacing={3}>
                  <Grid className="review-grid-container" item>
                    <span className="grid-content-header">
                      Beneficiary Name
                    </span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneficiaryName || "-"}
                    </span>
                  </Grid>
                </Grid>
              </div>
              <div className="review-column-mid-width">
                <span className="review-column-heading">Address Details</span>
                <Grid container spacing={3}>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={12}
                    xs={12}
                  >
                    <span className="grid-content-header">
                    Beneficiary Address 1
                    </span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneAddress1 || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={12}
                    xs={12}
                  >
                    <span className="grid-content-header">
                    Beneficiary Address 2
                    </span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneAddress2 || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={12}
                    xs={12}
                  >
                    <span className="grid-content-header">
                    Beneficiary Address 3
                    </span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneAddress3 || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={12}
                    xs={12}
                  >
                    <span className="grid-content-header">Country Code</span>
                    <span className="grid-content-text">
                      {findCountryName(beneficiaryReviewDetails?.countryCode) || "-"}
                    </span>
                  </Grid>
                </Grid>
              </div>
              <div className="review-column-mid-width">
                <span className="review-column-heading">Account Details</span>
                <Grid container spacing={3}>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Account Number/ IBAN No.
                    </span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneBankAccountNumber || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={9}
                    md={8}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Sort code/ BSB No. / Transit No.
                    </span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneBankId || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={4}
                    xs={6}
                  >
                    <span className="grid-content-header">Bank SWIFT Code</span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneBankSwiftCode || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Bank Name</span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneBankName || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Bank Country</span>
                    <span className="grid-content-text">
                      {findCountryName(beneficiaryReviewDetails?.beneBankCountry) || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={12}
                    md={12}
                    sm={12}
                    xs={12}
                  >
                    <span className="grid-content-header">Bank Address</span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.beneBankAddress || "-"}
                    </span>
                  </Grid>
                </Grid>
              </div>
              <div className="review-column-mid-width">
                <span className="review-column-heading">
                  Corresponding Beneficiary Bank Details (Optional)
                </span>
                <Grid container spacing={3}>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Bank SWIFT Code</span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.coresBankSwiftCode || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Bank Name</span>
                    <span className="grid-content-text">
                      {beneficiaryReviewDetails?.corresBankName || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Bank Country</span>
                    <span className="grid-content-text">
                      {findCountryName(beneficiaryReviewDetails?.corresBankCountry) || "-"}
                    </span>
                  </Grid>
                </Grid>
              </div>

              {/* Checker Review (Using faster processing (Paper-based) as master) start */}
              {showRemarkForm[1] && (
                <Grid container>
                  <Grid item lg={12} md={12} className="remark-box">
                    <TextField
                      fullWidth
                      label="Remarks"
                      value={remarks[1]}
                      onChange={(e) => onChangeRemarks(e, 1)}
                      onBlur={(e) => onBlurRemarks(e, 1)}
                      type="text"
                      variant="filled"
                    />
                  </Grid>{" "}
                </Grid>
              )}
              {authData?.userRoleType === "C" && showRemarkButton[1] && (
                <span
                  className="add-new"
                  onClick={() => {
                    updateRemarksDisplay(1, true);
                  }}
                >
                  <img src={AddIcon} />
                  Add Remarks
                </span>
              )}

              {authData?.userRoleType === "M" && state?.comments?.bene && (
                <div style={{ width: "100%" }}>
                  <Grid
                    container
                    spacing={1}
                    className={styles.reviewCommentContainer}
                  >
                    <Grid
                      className="review-grid-container"
                      item
                      lg={12}
                      md={12}
                      sm={12}
                      xs={12}
                    >
                      <span className="grid-content-header">
                        Remarks from Checker
                      </span>
                      <span className="grid-content-text">
                        {state?.comments?.bene ? state?.comments?.bene : ""}
                      </span>
                    </Grid>
                  </Grid>
                </div>
              )}
              {/* Checker Review (Using faster processing (Paper-based) as master) end */}
            </div>

            <div className="review-border-container">
              <div className="row-sub-container">
                <span className="trans-details-text">Payment Details</span>
                {!props?.successTransactionView &&
                  !props.fromChannelRefNo &&
                  authData?.userRoleType === "M" && (
                    <Button
                      withIcon
                      endIcon={<img src={Edit} />}
                      classes={{ root: styles.editButton }}
                      onClick={props?.redirectToPayment}
                    >
                      Edit
                    </Button>
                  )}
              </div>
              <Divider className="review-divider" />

              <div className="review-column-mid-width">
                <span className="review-column-heading">Amount Details</span>
                <Grid container spacing={3}>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={12}
                    md={12}
                    sm={12}
                    xs={12}
                  >
                    <span className="grid-content-header">
                      Total Remittance Amount
                    </span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.currency +
                        " " +
                        paymentReviewDetails?.amount}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Tenor Period (in days)
                    </span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.tenorPeriod || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Tenor Indicator</span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.tenorIndicator || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={6}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Due Date </span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.dueDate || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">Payment Date</span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.paymentDate || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={9}
                    md={8}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Branch Name (Optional){" "}
                    </span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.branchName || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={12}
                    md={12}
                    sm={4}
                    xs={6}
                  >
                    <span className="grid-content-header">Payment Mode</span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.paymentMode || "-"}
                    </span>
                  </Grid>
                </Grid>
              </div>

              <div className="mt-4 mx-4 mb-20 eefc-container">
                {paymentReviewDetails?.eefcAccount?.length > 0 && (
                  <>
                    <span className="d-flex mtb-16 payment-mode-subheader">
                      <img src={BuildingIcon} />
                      EEFC Account (Amount Payable:{" "}
                      {paymentReviewDetails?.currency +
                        " " +
                        `${
                          paymentReviewDetails?.eefcAmount
                            ? paymentReviewDetails?.eefcAmount
                            : 0
                        }`}
                      )
                    </span>
                    <Grid spacing={3} container>
                      {paymentReviewDetails?.eefcAccount?.map((item) => (
                        <>
                          <Grid
                            className="review-grid-container"
                            item
                            lg={6}
                            md={6}
                            sm={6}
                            xs={6}
                          >
                            <span className="grid-content-header">
                              Account Number
                            </span>
                            <span className="grid-content-text">
                              {item?.accountNumber || "-"}
                            </span>
                          </Grid>
                          <Grid
                            className="review-grid-container"
                            item
                            lg={6}
                            md={6}
                            sm={6}
                            xs={6}
                          >
                            <span className="grid-content-header">Amount</span>
                            <span className="grid-content-text">
                              {paymentReviewDetails?.currency +
                                " " +
                                item?.amount}
                            </span>
                          </Grid>
                        </>
                      ))}
                    </Grid>
                  </>
                )}
                {paymentReviewDetails?.currentAccountNumber && (
                  <>
                    <span className="d-flex mt-4 mb-3">
                      <img src={BuildingIcon} />
                      Operative Account
                    </span>
                    <Grid spacing={3} container>
                      <Grid
                        className="review-grid-container"
                        item
                        lg={6}
                        md={6}
                        sm={6}
                        xs={6}
                      >
                        <span className="grid-content-header">
                          Account Number
                        </span>
                        <span className="grid-content-text">
                          {paymentReviewDetails?.currentAccountNumber || "-"}
                        </span>
                      </Grid>
                      <Grid
                        className="review-grid-container"
                        item
                        lg={6}
                        md={6}
                        sm={6}
                        xs={6}
                      >
                        <span className="grid-content-header">Amount</span>
                        <span className="grid-content-text">
                          {paymentReviewDetails?.currency +
                            " " +
                            `${
                              paymentReviewDetails?.operativeAmount
                                ? paymentReviewDetails?.operativeAmount
                                : 0
                            }`}
                        </span>
                      </Grid>

                      <Grid
                        className="review-grid-container"
                        item
                        lg={12}
                        md={12}
                        sm={12}
                        xs={12}
                      >
                        {paymentReviewDetails?.opeartiveAccountRemarks && (
                          <>
                            <span className="grid-content-header">
                              Remarks (Reason of low / insufficient fund)
                            </span>
                            <span className="grid-content-text">
                              {paymentReviewDetails?.opeartiveAccountRemarks}
                            </span>
                          </>
                        )}
                        <div className="checkbox-use-as-charges-account d-flex-row">
                          <Checkbox checked={paymentReviewDetails?.chargesAccount === paymentReviewDetails?.currentAccountNumber} disabled={true} />
                          <span className="third-party-text">
                            Use as Charges Account
                          </span>
                        </div>
                      </Grid>
                    </Grid>
                  </>
                )}
              </div>
              <div className="review-column-mid-width">
                <span className="review-column-heading">Charges</span>
                <Grid container spacing={3}>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Charges Account Number
                    </span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.chargesAccount || "-"}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Foreign Bank Charges{" "}
                    </span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.foreignBankCharges || "-"}
                    </span>
                    <span className="grid-content-footer">
                      To be paid by Beneficiary{" "}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={6}
                    md={4}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Selected GST Number (Optional)
                    </span>
                    <span className="grid-content-text">
                      {paymentReviewDetails?.gstNumber || "-"}
                    </span>
                  </Grid>
                </Grid>
              </div>

              {paymentReviewDetails?.paymentMode !== "EEFC Account" && (
                <Divider className="review-divider" />
              )}

              {paymentReviewDetails?.paymentMode !== "EEFC Account" &&
                fxRateAmountData &&
                fxRateAmountData > 0 && (
                  <div className="row-sub-container rate-instruction-main-container">
                    <span className="trans-details-text">Rate Instruction</span>
                    {authData?.userRoleType === "C" && (
                      <div className="checkbox-use-as-charges-account d-flex-row">
                        <Checkbox
                          disabled={true}
                          checked={paymentReviewDetails?.delegateToChecker}
                        />
                        <span className="third-party-text">
                          Delegate to Checker
                        </span>
                      </div>
                    )}
                  </div>
                )}

              {paymentReviewDetails?.paymentMode !== "EEFC Account" &&
                authData?.userRoleType === "C" && (
                  <RateInstructionChecker
                    authorizeDisable={props?.authorizeDisable}
                    fxRateAmount={fxRateAmountData}
                    fxRateStatus={fxRateStatusData}
                    fxRateMessageId={fxRateMessageIdData}
                    displayRate={displayRateData}
                    fidbtxnId={props?.recKey}
                    tridbNumber={tridbNumberData}
                    statusCode={props?.statusCode}
                    paymentMode={paymentReviewDetails?.paymentMode}
                    instructionDetails={
                      // to do - this needs to be removed. don't depent on fxrateInstructionDetails.
                      paymentReviewDetails?.fxrateInstructionDetails
                    }
                    remmitanceAmount={
                      // to do - this needs to changed. don't depent on fxrateInstructionDetails. Need seperate api or include this data as part review/payment api
                      paymentReviewDetails?.fxrateInstructionDetails[0]
                        ?.outstandingAmount
                    }
                    utilizedAmount={paymentReviewDetails?.operativeAmount}
                    amountInInr={
                      // to do - this needs to changed. don't depent on fxrateInstructionDetails. Need seperate api or include this data as part review/payment api
                      paymentReviewDetails?.fxrateInstructionDetails[0]
                        ?.amountInInr
                    }
                    convertedAmount={convertedAmountData}
                  />
                )}

              {/* after calling getFxRateMarginValidation , show alert based on status received in response*/}
              {authData?.userRoleType === "C" &&
                fxRateStatusData !== null &&
                fxRateStatusData !== "SUCCESS" &&
                alertStatus && (
                  <AlertPopup
                    alertMsg={fxRateStatusData}
                    alertType={"warn"}
                    isAlertOpen={true}
                    onClose={onCloseAlertPopup}
                  />
                )}

              {/* show alert if isBankAvailableInTemp or isBeneAvailableInTemp == true*/}
              {authData?.userRoleType === "C" &&
                beneDetailsData !== null &&
                tempDataAlertStatus && (
                  <AlertPopup
                    alertMsg={tempDataAlertMsg}
                    alertType={"warn"}
                    isAlertOpen={true}
                    onClose={onCloseAlertPopup}
                  />
                )}

              {paymentReviewDetails?.paymentMode !== "EEFC Account" && (
                <div className="rate-instruction-container">
                  {paymentReviewDetails?.prebookInstructionDetails?.length >
                    0 && (
                    <Grid>
                      <PreBookedDealsView
                        delegateChecker={
                          paymentReviewDetails?.delegateToChecker
                        }
                        instructionDetails={
                          paymentReviewDetails?.prebookInstructionDetails
                        }
                      />
                    </Grid>
                  )}
                  {paymentReviewDetails?.fwcInstructionDetails?.length > 0 && (
                    <Grid>
                      <ForwardContractView
                        delegateChecker={
                          paymentReviewDetails?.delegateToChecker
                        }
                        instructionDetails={
                          paymentReviewDetails?.fwcInstructionDetails
                        }
                      />
                    </Grid>
                  )}
                  {authData?.userRoleType === "M" &&
                    paymentReviewDetails?.fxrateInstructionDetails && (
                      <Grid>
                        <BookRateView
                          delegateChecker={
                            paymentReviewDetails?.delegateToChecker
                          }
                          instructionDetails={
                            paymentReviewDetails?.fxrateInstructionDetails
                          }
                          userType={authData?.userRoleType}
                        />
                      </Grid>
                    )}
                </div>
              )}
              {paymentReviewDetails?.delayReasons?.length > 0 && (
                <>
                  <div className="row-sub-container">
                    <span className="trans-details-text">
                      Bill Of Entry- Delay Reasons
                    </span>
                  </div>
                  <div className="ml-10">
                    <Grid
                      container
                      spacing={3}
                      className={styles.reviewGreyContainer}
                    >
                      {paymentReviewDetails?.delayReasons?.map(
                        (delayReason) => (
                          <>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={4}
                              md={6}
                              sm={12}
                              xs={12}
                            >
                              <span className="grid-content-header">
                                Bill Of Entry Number
                              </span>
                              <span className="grid-content-text">
                                {delayReason?.boeNumber}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={4}
                              md={6}
                              sm={12}
                              xs={12}
                            >
                              <span className="grid-content-header">
                                Delay Reason
                              </span>
                              <span className="grid-content-text">
                                {delayReason?.delayReason}
                              </span>
                            </Grid>
                            <Grid
                              className="review-grid-container"
                              item
                              lg={6}
                              md={12}
                              sm={12}
                              xs={12}
                            >
                              <span className="grid-content-header">
                                Specify Delay Reason
                              </span>
                              <span className="grid-content-text">
                                {delayReason?.specifyDelayReason}
                              </span>
                            </Grid>
                            <Divider className="review-divider" />
                          </>
                        )
                      )}
                    </Grid>
                  </div>
                </>
              )}

              {paymentReviewDetails?.senderToRecieverInstrution && (
                <div
                  className=""
                  style={{ width: "100%", marginBottom: "24px" }}
                >
                  <div className="row-sub-container">
                    <span className="trans-details-text">Other Details</span>
                  </div>
                  <div className="">
                    <Grid
                      container
                      spacing={3}
                      className={styles.reviewGreyContainer}
                    >
                      <Grid
                        className="review-grid-container"
                        item
                        lg={12}
                        md={12}
                        sm={12}
                        xs={12}
                      >
                        <span className="grid-content-header">
                          Sender to Receiver Instruction (Optional)
                        </span>
                        <span className="grid-content-text">
                          {paymentReviewDetails?.senderToRecieverInstrution}
                        </span>
                      </Grid>
                    </Grid>
                  </div>
                </div>
              )}

              {/* Checker Review (Using faster processing (Paper-based) as master) start */}
              {showRemarkForm[2] && (
                <Grid container>
                  <Grid item lg={12} md={12} className="remark-box">
                    <TextField
                      fullWidth
                      label="Remarks"
                      value={remarks[2]}
                      onChange={(e) => onChangeRemarks(e, 2)}
                      onBlur={(e) => onBlurRemarks(e, 2)}
                      type="text"
                      variant="filled"
                    />
                  </Grid>{" "}
                </Grid>
              )}
              {authData?.userRoleType === "C" && showRemarkButton[2] && (
                <span
                  className="add-new"
                  onClick={() => {
                    updateRemarksDisplay(2, true);
                  }}
                >
                  <img src={AddIcon} />
                  Add Remarks
                </span>
              )}
              {authData?.userRoleType === "M" && state?.comments?.payment && (
                <div style={{ width: "100%" }}>
                  <Grid
                    container
                    spacing={1}
                    className={styles.reviewCommentContainer}
                  >
                    <Grid
                      className="review-grid-container"
                      item
                      lg={12}
                      md={12}
                      sm={12}
                      xs={12}
                    >
                      <span className="grid-content-header">
                        Remarks from Checker
                      </span>
                      <span className="grid-content-text">
                        {state?.comments?.payment
                          ? state?.comments?.payment
                          : ""}
                      </span>
                    </Grid>
                  </Grid>
                </div>
              )}
              {/* Checker Review (Using faster processing (Paper-based) as master) end */}
            </div>

            <div className="review-container"></div>
          </>
        ) : (
          <>
            <SwiftMessage />
          </>
        )}
        {attachdocumentsDetails?.responseBody && (
          <div className="review-border-container">
            <div className="row-sub-container">
              <span className="trans-details-text">Attached Documents</span>
              {!props?.successTransactionView &&
                !props.fromChannelRefNo &&
                authData?.userRoleType === "M" && (
                  <Button
                    withIcon
                    endIcon={<img src={Edit} />}
                    classes={{ root: styles.editButton }}
                    onClick={props?.redirectToAttachments}
                  >
                    Edit
                  </Button>
                )}
            </div>
            <Divider className="review-divider" />
            <div className="attachDoc-column">
              <div className="attachdoc-sub-header">
                <Grid container spacing={3} className="attach-grid-container">
                  <Grid item lg={3} md={6}>
                    <span className="review-column-heading">File Name</span>
                  </Grid>
                  <Grid item lg={3} md={6} className="ml--10">
                    <span className="review-column-heading">
                      Classification
                    </span>
                  </Grid>
                </Grid>
              </div>

              {attachdocumentsDetails?.responseBody?.length > 0 &&
                attachdocumentsDetails?.responseBody?.map((documentItem) => (
                  <Grid container className={styles.attachDocGreyContainer}>
                    <Grid item lg={3} md={6}>
                      <div className="attachdoc-file-name-container">
                        <div>
                          <img src={RedDot} className="big-dot" />
                          <Link
                            className="attachdoc-file-name"
                            component="button"
                            color="secondary"
                            underline="always"
                            onClick={() => {
                              downloadDocuments(documentItem);
                            }}
                          >
                            {documentItem?.fileName}
                          </Link>
                        </div>
                        {/* <span className="file-sixe-text">399KB</span> */}
                      </div>
                    </Grid>
                    <Grid
                      item
                      lg={3}
                      md={6}
                      className="attachdoc-classification-container"
                    >
                      <span className="attachdoc-classification-title">
                        Classification
                      </span>
                      <span className="attachdoc-classification">
                        {documentItem?.checkList}
                      </span>
                    </Grid>
                  </Grid>
                ))}
            </div>

            {/* Checker Review (Using faster processing (Paper-based) as master) start */}
            {showRemarkForm[3] && (
              <Grid container>
                <Grid item lg={12} md={12} className="remark-box">
                  <TextField
                    fullWidth
                    label="Remarks"
                    value={remarks[3]}
                    onChange={(e) => onChangeRemarks(e, 3)}
                    onBlur={(e) => onBlurRemarks(e, 3)}
                    type="text"
                    variant="filled"
                  />
                </Grid>{" "}
              </Grid>
            )}
            {authData?.userRoleType === "C" && showRemarkButton[3] && (
              <span
                className="add-new"
                onClick={() => {
                  updateRemarksDisplay(3, true);
                }}
              >
                <img src={AddIcon} />
                Add Remarks
              </span>
            )}
            {authData?.userRoleType === "M" && state?.comments?.attachment && (
              <div style={{ width: "100%" }}>
                <Grid
                  container
                  spacing={1}
                  className={styles.reviewCommentContainer}
                >
                  <Grid
                    className="review-grid-container"
                    item
                    lg={12}
                    md={12}
                    sm={12}
                    xs={12}
                  >
                    <span className="grid-content-header">
                      Remarks from Checker
                    </span>
                    <span className="grid-content-text">
                      {state?.comments?.attachment
                        ? state?.comments?.attachment
                        : ""}
                    </span>
                  </Grid>
                </Grid>
              </div>
            )}
            {/* Checker Review (Using faster processing (Paper-based) as master) end */}
          </div>
        )}
        {!props?.successTransactionView && !props.fromChannelRefNo && (
          <>
            {authData?.userRoleType === "M" && (
              <div className="auto-gen-decl-container">
                <div className="row-sub-container">
                  <span className="trans-details-text">
                    Auto- Generated Declarations
                  </span>
                </div>
                <span className="auto-gen-subheader">
                  Accept the declarations to proceed further
                </span>
                <Grid container className={styles.attachDocGreyContainer}>
                  <Grid item lg={12}>
                    <div className="d-flex-row aut-gen-text-container">
                      <Checkbox
                        checked={props?.selectedDeclration}
                        onClick={() => {
                          props?.updateDeclation();
                        }}
                      />
                      <span className="third-party-text">
                        I have read and I accept the{" "}
                        <Link
                          component="button"
                          color="secondary"
                          underline="always"
                          style={{ marginTop: "-3px" }}
                          onClick={() => {
                            toggleDeclarationDrawer(true);
                          }}
                        >
                          Declarations
                        </Link>
                      </span>
                    </div>
                  </Grid>

                  {/* <Divider className="auto-gen-declare-divider" />
                  <Grid item lg={12}>
                    <div className="d-flex-row aut-gen-text-container">
                      <Checkbox
                        checked={props?.selectedTermsCondition}
                        onClick={() => {
                          props?.updateTermsCondition();
                        }}
                      />
                      <span className="third-party-text">
                        I have read and I accept the{" "}
                        <Link
                          component="button"
                          color="secondary"
                          underline="always"
                          style={{ marginTop: "-3px" }}
                        >
                          Terms and Conditions
                        </Link>
                      </span>
                    </div>
                  </Grid> */}
                </Grid>
              </div>
            )}
            {/* Checker Review (Using faster processing (Paper-based) as master) start */}
            {showRemarkForm[4] && (
              <Grid container>
                <Grid item lg={12} md={12} className="remark-box">
                  <TextField
                    fullWidth
                    label="Remarks"
                    value={remarks[4]}
                    onChange={(e) => onChangeRemarks(e, 4)}
                    onBlur={(e) => onBlurRemarks(e, 4)}
                    type="text"
                    variant="filled"
                  />
                </Grid>{" "}
              </Grid>
            )}
            {authData?.userRoleType === "C" && showRemarkButton[4] && (
              <span
                className="add-new"
                onClick={() => {
                  updateRemarksDisplay(4, true);
                }}
              >
                <img src={AddIcon} />
                Add Overall Remarks
              </span>
            )}
            {/* Checker Review (Using faster processing (Paper-based) as master) end */}
          </>
        )}
      </div>
      {showBoeDetails && (
        <BoeDetails
          onClose={() => {
            setShowBoeDetails(false);
          }}
          params={boeDetailsParams}
        />
      )}
      <Drawer
        classes={{
          paper: classes.paper,
        }}
        anchor={"bottom"}
        open={openDeclarationModal}
        onClose={() => {
          toggleDeclarationDrawer(false);
        }}
      >
        <div
          onClick={() => {
            toggleDeclarationDrawer(false);
          }}
          className="close"
        >
          <img src={CloseIcon} className="close-icon" />
        </div>
        <div className="details-container">
          <span className="heading-details">Declaration cum Undertaking</span>
          <div className="border-container">
            We hereby undertake that we shall submit the documentary evidence of
            import ( i.e. Bill of Entry for home consumption/ courier wrapper/
            Postal Appraisal Form/ Customs Assessment Certificate, as applicable
            ) within three months from the date of payment.
          </div>
        </div>
      </Drawer>
    </>
  );
};

export default Review;
