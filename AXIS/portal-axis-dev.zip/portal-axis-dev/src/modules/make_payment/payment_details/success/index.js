/* eslint-disable */
import React, { useState, useEffect } from "react";
import { useLocation, useHistory } from "react-router-dom";
import styles from "./index.module.css";
import {
  Box,
  Button as MuiButton,
  Container,
  Grid,
  Menu,
  MenuItem,
  Typography,
} from "@material-ui/core";
import { Button } from "../../../../components/@subzero/glacier/package/lib/components";
import SuccessIcon from "../../../../assets/icons/progress-indicator.svg";
// import PdfIcon from "../../../../assets/icons/active-download.svg";
import CopyIcon from "../../../../assets/icons/copy.svg";
import ActiveDownloadIcon from "../../../../assets/icons/active-download.svg";

import { Actions } from "../../../../store/rootActions";
import { useDispatch, useSelector } from "react-redux";
import AlertPopup from "../../../../components/alertPopup/alertPopup";

const AuthMatrixSuccess = (props) => {
  const [anchorEl, setAnchorEl] = useState(null);
  const location = useLocation();
  const showDownloadOption = Boolean(anchorEl);
  const [submitData, updateSubmitData] = useState(null);
  const [prevPage, setPrevPage] = useState(location?.state?.prevPage);
  const [actionPrevPage, setActionPrevPage] = useState(location?.state?.action);
  const [statusPrevPage, setStatusPrevPage] = useState(location?.state?.status);
  const history = useHistory();
  const dispatch = useDispatch();
  const [alertStatus, setAlertStatus] = useState(false);
  const [alertMsg, setAlertMessage] = useState("");

  const transactionDetails = useSelector((state) => state?.transactionDetails);

  useEffect(() => {
    if (location?.state) {
      updateSubmitData(location?.state?.submitResponse);
    }
  }, []);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleDownload = () => {
    const req = {
      recordStatus: "",
      id: transactionDetails?.recKey,
      refNumber: submitData?.channelRefernceNumber,
    };

    // API for document download
    dispatch(Actions.downloadDocuments(req, "CHANNELGENDOC"));
  };

  const handleCopy = () => {
    /* Copy the text inside the text field */
    navigator.clipboard.writeText(submitData?.serviceRequest);
    // alert("Service Request ID Copied");
    setAlertMessage("Service Request ID Copied");
    setAlertStatus(true);
  };

  const onCloseAlertPopup = () => {
    setAlertStatus(false);
  };

  return (
    <Container className={styles.successSection}>
      <img src={SuccessIcon} alt="" />
      <Typography className={styles.successHeader}>Success</Typography>
      <Typography className={styles.successSubHeader}>
        FIDB Payment transaction with reference number{" "}
        {submitData?.channelRefernceNumber}{" "}
        {/* <span
          className={styles.link}
          onClick={() => {
            history.push({
              pathname: "/make-payment",
              state: {
                successTransactionView: true,
              },
            });
          }}
        >
          
        </span> */}
        has been successfully submited to the checker for authorization.
      </Typography>
      <Box className={styles.successTable}>
        <Grid container spacing={0} direction="column">
          <Grid className={styles.successTableHead}>
            <Typography className={styles.successTableHeader}>
              Service Request
            </Typography>
            <MuiButton
              variant="outlined"
              id="downloadButton"
              className={styles.successTableMuiDownloadButton}
              endIcon={<img src={ActiveDownloadIcon} alt="" />}
              onClick={handleClick}
              aria-controls="basic-menu"
              aria-haspopup="true"
              aria-expanded={showDownloadOption ? "true" : undefined}
            >
              Download
            </MuiButton>
            <Menu
              id="downloadButton"
              open={showDownloadOption}
              anchorEl={anchorEl}
              onClose={handleClose}
              getContentAnchorEl={null}
              MenuListProps={{
                "aria-labelledby": "downloadButton",
              }}
              className={styles.successTableMuiDownloadMenu}
            >
              <MenuItem
                onClick={handleDownload}
                className={styles.successTableMuiDownloadOptionButton}
              >
                <img src={ActiveDownloadIcon} alt="" />
                <span className={styles.successTableMuiDownloadOptionLabel}>
                  PDF
                </span>
              </MenuItem>
            </Menu>
          </Grid>
          <Grid className={styles.successTableBody}>
            <Typography className={styles.successTableHeader}>
              {submitData?.serviceRequest}
            </Typography>
            <MuiButton
              onClick={() => handleCopy()}
              className={styles.successTableMuiCopyButton}
              endIcon={<img src={CopyIcon} alt="" />}
            >
              Copy
            </MuiButton>
          </Grid>
        </Grid>
      </Box>
      <Button
        color="secondary"
        className={styles.successGoToDashboardButton}
        onClick={() => {
          history.push("/dashboard");
        }}
      >
        Go to Dashboard
      </Button>
      {!prevPage && (
        <Button
          color="primary"
          className={styles.successNewPaymentButton}
          onClick={() => {
            history.push("/boe");
          }}
        >
          Initiate New Payment
        </Button>
      )}
      {prevPage && (
        <Button
          color="primary"
          className={styles.successNewPaymentButton}
          onClick={() => {
            history.push(prevPage, {
              action: actionPrevPage,
              status: statusPrevPage,
            });
          }}
        >
          Go to new Requests
        </Button>
      )}
      {alertStatus && (
        <AlertPopup
          alertMsg={alertMsg}
          alertType={"success"}
          isAlertOpen={true}
          onClose={() => setAlertStatus(false)}
        />
      )}
    </Container>
  );
};

export default AuthMatrixSuccess;
