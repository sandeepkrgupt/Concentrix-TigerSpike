/*eslint-disable */
import React, { useState } from "react";
import { Grid } from "@material-ui/core";
import { Checkbox } from "../../../components/@subzero/glacier/package/lib/components";
import PreBookedDeals from "./PreBookedDeals";
import ForwardContract from "./ForwardContract";
import BookRate from "./BookRate";

const RateInstruction = (props) => {
  const [delegateChecker, updateDelegateChecker] = useState(false);
  const authData = JSON.parse(localStorage.getItem("authData"));
  const { userRoleType } = authData;

  return (
    <>
      <div>
        <div className="border-container rateInsContaner pb-0">
          <div className="details-heading d-flex mb-24 justify-space">
            <div>Rate Instructions</div>
            {/* <Checkbox
              label="Delegate to Checker"
              checked={delegateChecker}
              onChange={() => {
                updateDelegateChecker(!delegateChecker);
              }}
            /> */}
          </div>
          <Grid>
            <PreBookedDeals
              delegateChecker={delegateChecker}
              fetchPreBookDeals={(preDeals) => {
                props?.fetchPreDeals(preDeals);
              }}
              data={props?.preBookDeals}
              fetchPreBookAmount={(preBookAmt) => props?.preBookAmt(preBookAmt)}
              balanceRemittanceAmount={props?.balanceRemittanceAmount}
              totalRemittance={props?.totalRemittance}
            />
          </Grid>
          <Grid>
            <ForwardContract
              delegateChecker={delegateChecker}
              fetchFWCBookDeals={(fwcDeals) => {
                props?.fetchFWCDeals(fwcDeals);
              }}
              data={props?.fwcBookDeals}
              fetchFwcBookAmount={(fwcBookAmt) => props?.fwcBookAmt(fwcBookAmt)}
              balanceRemittanceAmount={props?.balanceRemittanceAmount}
              totalRemittance={props?.totalRemittance}
            />
          </Grid>
            <Grid>
              <BookRate
                delegateChecker={delegateChecker}
                balanceRemittanceAmount={props?.balanceRemittanceAmount}
              />
            </Grid>
        </div>
      </div>
    </>
  );
};

export default RateInstruction;
