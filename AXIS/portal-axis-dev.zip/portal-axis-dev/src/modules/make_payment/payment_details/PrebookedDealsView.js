/* eslint-disable */
import React, { useEffect } from "react";
import AgGridTable from "../../../components/aggridtable";

const PreBookedDealsView = (props) => {
  const [rowList, updateRowList] = React.useState([]);

  useEffect(() => {
    if (props?.instructionDetails?.length > 0) {
      let resultArray = [];
      props?.instructionDetails?.map((item) => {
        const {
          dealId,
          currencyPair,
          exchangeRate,
          validTill,
          outstandingAmount,
          amountToBeUtilized,
          amountInInr
        } = item;
        resultArray.push(
          createData(
            dealId,
            currencyPair,
            exchangeRate,
            validTill,
            outstandingAmount,
            amountToBeUtilized,
            amountInInr
          )
        );
      });
      generateTableRowValues(resultArray);
    }
  }, [props?.instructionDetails]);

  function createData(
    refNo,
    currencyPair,
    exchangeRate,
    validTill,
    osAmount,
    amountUtilised,
    amountInr
  ) {
    return {
      refNo,
      currencyPair,
      exchangeRate,
      validTill,
      osAmount,
      amountUtilised,
      amountInr
    };
  }

  const generateTableRowValues = (rows) => {
    const newArray = [...rows];
    const resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem).map((key) => {
        const value = rowItem[key];
        switch (key) {
          default:
            newObject[key] = { value: value };
            break;
        }
      });
      resultArray.push(newObject);
    });
    updateRowList(resultArray);
  };

  return (
    <>
      <div
        className={
          !props?.delegateChecker
            ? "simple-card ml-0"
            : "simple-card disabled ml-0"
        }
      >
        <>
          <div className="simple-card-header">
            <h5>Pre-Booked Deals</h5>
          </div>
        </>
        <>
          <AgGridTable
            headCells={[
              { field: "refNo", label: "Deal ID" },
              { field: "currencyPair", label: "Currency Pair" },
              { field: "exchangeRate", label: "Exchange Rate" },
              { field: "validTill", label: "Valid Till" },
              { field: "osAmount", label: "Amount O/S", rightAligned: true },
              {
                field: "amountUtilised",
                label: "Amount to be Utilised",
                minWidth: 220,
                rightAligned: true
              },
              {
                field: "amountInr",
                label: "Amount in  INR", 
                rightAligned: true
              }
            ]}
            rows={rowList}
            tableOnly={true}
            noRowSelection={true}
            autoSize={true}
          />
        </>
      </div>
    </>
  );
};
export default PreBookedDealsView;
