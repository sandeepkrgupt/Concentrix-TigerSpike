/* eslint-disable  */

import React, { useState, useEffect, useRef } from "react";
import {
  Dropdown,
  TextField,
  Datepicker,
  Checkbox,
} from "../../../components/@subzero/glacier/package/lib/components";
import { Divider, Grid } from "@material-ui/core";
import "./index.css";
import InfoIcon from "../../../assets/icons/info-grey.svg";
import BillofEntryDelayReasons from "./BillofEntryDelayReasons";
import BuildingIcon from "../../../assets/icons/building.svg";
import RemoveIcon from "../../../assets/icons/remove-icon.svg";
import AddIcon from "../../../assets/icons/add.svg";
import { makeStyles } from "@material-ui/core/styles";
import RateInstruction from "./RateInstruction";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";
import AlertPopup from "../../../components/alertPopup/alertPopup";
import moment from "moment";

const useStyles = makeStyles((theme) => ({
  "&MuiFormControl-root": {
    width: "100% !important",
  },
}));

const PaymentDetails = (props) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const transactionDetailsstate = useSelector(
    (state) => state?.transactionDetails
  );
  const state = useSelector((state) => state?.payment);
  const [EEFCIndex, setEEFCIndex] = useState(null);
  const [chargesAccount, updateChargesAccount] = useState([]);
  const [fxAmountUtilized, updateFxAmountUtilized] = useState(
    state?.fxAmountUtilized
  );
  const [fcCreditAmount, updateFcCreditAmount] = useState(
    state?.fcCreditAmount
  );

  const authData = JSON.parse(localStorage.getItem("authData"));
  const [paymentDetails, setpaymentDetails] = useState({
    amountDetails: {
      totalRemittanceAmount: transactionDetailsstate?.totalRemittance,
      tenorPeriod: "",
      tenorIndicator: "",
      dueDate: "",
      paymentDate: `${new Date(authData.appDate).getDate()}-${new Date(authData.appDate).getMonth() + 1}-${new Date(authData.appDate).getFullYear()}`,
      branchName: "",
      paymentMode: {
        mode: "",
        eefcAcc: [
          {
            acc_no: "",
            amount: transactionDetailsstate?.totalRemittance || "",
            balance_amt: "",
          },
        ],
        operativeAcc: {
          acc_no: "",
          amount: transactionDetailsstate?.totalRemittance || "",
          balance_amt: "",
          remarks: "",
          isInsufficient: false,
        },
      },
    },
    charges: {
      chargesAccNo: "",
      balance_amt: "",
      selectedGSTNo: "",
      foriegnBankCharges: "",
    },
    rateInstructions: {
      delegateToChecker: "",
      bookRateOnline: {},
      fxAmountUtilized: fxAmountUtilized,
      fcCreditAmount: fcCreditAmount,
    },
    boeDelayReasons: [{}],
    otherDetails: {
      senderToRecieverInstrution: "",
    },
    useAsChargesAcc: false,
  });

  const [gstNoList, updateGstNoList] = useState([]);
  const { userId, corpId, bankCode, subcustId } = authData;

  const [selectedMode, setSelectedMode] = useState({});
  const paymentState = useSelector((state) => state?.paymentReviewData);
  const paymentStateRef = useRef(paymentState); //  reference value to get previous state
  const currency = transactionDetailsstate.currency;
  const [toastState, updateToastState] = useState({
    toastMessage: "",
    toastType: "",
    showToast: false,
  });
  const [isBillDataValid, setisBillDataValid] = useState(true);

  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const paperless = authData?.docUploadWaiver === "Paperless" ? true : false;
  const [alert, setAlert] = useState({
    alertMsg: "Fill out the mandatory fields",
    alertType: "warn",
    isAlertOpen: false,
  });

  const [fieldsToBeValidated, setFieldsToBeValidated] = useState({
    //totalRemittanceAmount: {
    //    mandatoryOnPaperless: true,
    //    mandatoryOnFastProcessing: true,
    //    mandatoryOnStandardProcessing: true,
    //    mandatoryBasedOnCondition: "",
    //    validationFailed: false,
    //},
    tenorPeriod: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    tenorIndicator: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    //paymentDate: {
    //    mandatoryOnPaperless: true,
    //    mandatoryOnFastProcessing: true,
    //    mandatoryOnStandardProcessing: true,
    //    mandatoryBasedOnCondition: "",
    //    validationFailed: false,
    //},
    //dueDate: {
    //    mandatoryOnPaperless: true,
    //    mandatoryOnFastProcessing: true,
    //    mandatoryOnStandardProcessing: false,
    //    mandatoryBasedOnCondition: "",
    //    validationFailed: false,
    //},
    paymentMode: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    acc_no: [
      {
        mandatoryOnPaperless: true,
        mandatoryOnFastProcessing: true,
        mandatoryOnStandardProcessing: true,
        mandatoryBasedOnCondition:
          "paymentDetails.amountDetails.paymentMode.mode === 'EEFC Account' || paymentDetails.amountDetails.paymentMode.mode === 'EEFC and Operative Account' ",
        validationFailed: false,
      },
    ],
    opp_acc_no: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition:
        "paymentDetails.amountDetails.paymentMode.mode === 'Operative Account' || paymentDetails.amountDetails.paymentMode.mode === 'EEFC and Operative Account' ",
      validationFailed: false,
    },
    opp_amount: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition:
        "paymentDetails.amountDetails.paymentMode.mode === 'Operative Account' || paymentDetails.amountDetails.paymentMode.mode === 'EEFC and Operative Account' ",
      validationFailed: false,
    },
    amount: [
      {
        mandatoryOnPaperless: true,
        mandatoryOnFastProcessing: true,
        mandatoryOnStandardProcessing: true,
        mandatoryBasedOnCondition:
          "paymentDetails.amountDetails.paymentMode.mode === 'EEFC Account' || paymentDetails.amountDetails.paymentMode.mode === 'EEFC and Operative Account' ",
        validationFailed: false,
      },
    ],
    chargesAccNo: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition:
        "paymentDetails.amountDetails.paymentMode.mode != '' && paymentDetails.useAsChargesAcc === false",
      validationFailed: false,
    },
    foriegnBankCharges: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition:
        "paymentDetails.amountDetails.paymentMode.mode != '' ",
      validationFailed: false,
    },
    paymentDate: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
  });

  const [balanceRemittanceAmount, setBalanceRemittanceAmount] = useState(
    transactionDetailsstate?.totalRemittance
      ? transactionDetailsstate?.totalRemittance
      : paymentDetails?.amountDetails?.totalRemittanceAmount
  );
  const [preBookAmt, setPreBookAmt] = useState(0);
  const [fwcBookAmt, setFwcBookAmt] = useState(0);
  const [eefcAccs, setEefcAccs] = useState(state?.eefcAccounts);

  useEffect(() => {
    if (
      props?.proceedClickInfo?.proceedClick &&
      props?.proceedClickInfo?.activeStep === 2
    ) {
      if (validatePaymentDetailsFields() && isBillDataValid) {
        props.onSuccessValidation();
      } else {
        setAlert({
          ...alert,
          alertMsg: "Fill out the mandatory fields",
          alertType: "warn",
          isAlertOpen: true,
        });
      }
    }
  }, [props?.proceedClickInfo]);

  useEffect(() => {
    // Branch Name API
    getPaymentBranchNames();
    // Payment mode list API
    getPaymentModeList();
    // // Api for getting charges account List
    // getChargesAccountList();
    // API for getting all accounts together
    getAllAccounts();
    // if coming from edit button, call api for prefilling attach documents data
    if (transactionDetails?.recKey) {
      const req = {
        corpId: authData?.corpId,
        userId: authData?.userId,
        bankCode: authData?.bankCode,
        recKey: transactionDetails?.recKey,
      };

      //CALL BENEFICIARY REVIEW API FOR PREFILLING DATA
      dispatch(Actions.getpaymentReviewData(req));
    }
    checkSufficientRemittanceBalance();
  }, []);

  useEffect(() => {
    const paymentDetails = paymentState?.paymentDetails;
    if (
      paymentDetails &&
      paymentStateRef?.current?.paymentDetails !== paymentDetails
    ) {
      // updating state ref value
      paymentStateRef.current = paymentState;
      let eefcAcc = paymentDetails?.eefcAccount?.map((item) => {
        return {
          acc_no: item?.accountNumber,
          amount: item?.amount,
          balance_amt: "",
        };
      });
      if (eefcAcc.length === 0) {
        eefcAcc = [
          {
            acc_no: "",
            amount: `${transactionDetailsstate?.totalRemittance || ""}`,
            balance_amt: "",
          },
        ];
      }
      const delayReasons = paymentDetails?.delayReasons?.map((item) => {
        return {
          delay_reason: item?.delayReason,
          boe_no: item?.boeNumber,
          other_reason: item?.specifyDelayReason,
        };
      });

      const responseData = {
        amountDetails: {
          totalRemittanceAmount: transactionDetailsstate?.totalRemittance
            ? transactionDetailsstate?.totalRemittance
            : paymentDetails?.amount,
          tenorPeriod: paymentDetails?.tenorPeriod,
          tenorIndicator: paymentDetails?.tenorIndicator,
          dueDate: paymentDetails?.dueDate?.includes("/") ? paymentDetails?.dueDate?.replaceAll("/","-") : paymentDetails?.dueDate,
          paymentDate:
            paymentDetails?.paymentDate?.includes("/") ? paymentDetails?.paymentDate?.replaceAll("/","-") : paymentDetails?.dueDate ||
            `${new Date(
              authData.appDate
            ).getDate()}-${new Date(authData.appDate).getMonth() + 1}-${new Date(authData.appDate).getFullYear()}`,
          branchName: paymentDetails?.branchName,
          paymentMode: {
            mode: paymentDetails?.paymentMode,
            eefcAcc: eefcAcc,
            operativeAcc: {
              acc_no: paymentDetails?.currentAccountNumber,
              amount:
                paymentDetails?.operativeAmount ||
                transactionDetailsstate?.totalRemittance,
              balance_amt: "",
              remarks: paymentDetails?.opeartiveAccountRemarks,
              isInsufficient: paymentDetails?.opeartiveAccountRemarks
                ? true
                : false,
            },
          },
        },
        charges: {
          chargesAccNo: paymentDetails?.chargesAccount,
          balance_amt: "",
          selectedGSTNo: paymentDetails?.gstNumber,
          foriegnBankCharges: paymentDetails?.foreignBankCharges,
        },
        rateInstructions: {
          delegateToChecker: paymentDetails?.delegateToChecker,
          bookRateOnline: {},
          fxAmountUtilized: fxAmountUtilized,
          fcCreditAmount: fcCreditAmount,
        },
        boeDelayReasons: delayReasons,
        otherDetails: {
          senderToRecieverInstrution:
            paymentDetails?.senderToRecieverInstrution,
        },
        useAsChargesAcc: false,
        preBookedDeals: paymentDetails?.prebookInstructionDetails,
        fwcBookedDeals: paymentDetails?.fwcInstructionDetails,
      };
      setpaymentDetails(responseData);
    }
  }, [paymentState]);

  useEffect(() => {
    props?.getPaymentInfo(paymentDetails);
  }, [paymentDetails]);

  // const getChargesAccountList = () => {
  //   const req = {
  //     customerID: subcustId,
  //   };
  //   dispatch(Actions.getChargesAccount(req));
  // };

  const getAllAccounts = () => {
    const req = {
      customerId: transactionDetailsstate?.custIdAndIeCode?.custId || subcustId,
    };
    dispatch(Actions.getAllAcc(req));
  };

  const getPaymentBranchNames = () => {
    // const req = {
    //   userId: userId,
    //   corpId: corpId,
    //   bankCode: bankCode,
    //   status: 0,
    // };
    const req = { solId: "", input1: "", input2: "", input3: "" };
    dispatch(Actions.paymentBranchName(req));
  };

  const getPaymentModeList = () => {
    const req = {
      userId: userId,
      corpId: corpId,
      bankCode: bankCode,
    };
    dispatch(Actions.paymentModeList(req));
  };

  const addEEFCAcc = () => {
    const newObj = { ...paymentDetails };
    newObj.amountDetails.paymentMode.eefcAcc = [
      ...newObj.amountDetails.paymentMode.eefcAcc,
      {
        acc_no: "",
        amount: "",
        balance_amt: "",
      },
    ];
    setpaymentDetails(newObj);
    addEEFCAccFieldvalidation();
  };

  const addEEFCAccFieldvalidation = () => {
    const newValue = { ...fieldsToBeValidated };
    newValue.acc_no = [
      ...newValue.acc_no,
      {
        mandatoryOnPaperless: true,
        mandatoryOnFastProcessing: true,
        mandatoryOnStandardProcessing: true,
        mandatoryBasedOnCondition:
          "paymentDetails.amountDetails.paymentMode.mode != 'EEFC Account' ",
        validationFailed: false,
      },
    ];
    newValue.amount = [
      ...newValue.amount,
      {
        mandatoryOnPaperless: true,
        mandatoryOnFastProcessing: true,
        mandatoryOnStandardProcessing: true,
        mandatoryBasedOnCondition:
          "paymentDetails.amountDetails.paymentMode.mode != 'EEFC Account' ",
        validationFailed: false,
      },
    ];

    setFieldsToBeValidated(newValue);
  };

  const removeEEFCAcc = (accIndex) => {
    const newObj = { ...paymentDetails };

    const newAccList = paymentDetails.amountDetails.paymentMode.eefcAcc?.filter(
      (item, index) => accIndex !== index
    );
    const tempEefcAccs = [...eefcAccs];
    if (paymentDetails.amountDetails.paymentMode?.eefcAcc[accIndex]?.acc_no) {
      tempEefcAccs.push({
        label:
          paymentDetails.amountDetails.paymentMode?.eefcAcc[accIndex]?.acc_no,
        id: paymentDetails.amountDetails.paymentMode?.eefcAcc[accIndex]?.acc_no,
        accountNumber:
          paymentDetails.amountDetails.paymentMode?.eefcAcc[accIndex]?.acc_no,
        availableBalance:
          paymentDetails.amountDetails.paymentMode?.eefcAcc[accIndex]
            ?.balance_amt,
        currencyCode:
          paymentDetails.amountDetails.paymentMode?.eefcAcc[accIndex]?.currency,
      });
    }
    setEefcOptions(newAccList, tempEefcAccs);
    newObj.amountDetails.paymentMode.eefcAcc = newAccList;
    setpaymentDetails(newObj);
    removeEEFCAccFieldvalidation(accIndex);
  };

  const removeEEFCAccFieldvalidation = (accIndex) => {
    const newObj = { ...fieldsToBeValidated };
    const newAccList = fieldsToBeValidated.acc_no.filter(
      (item, index) => accIndex !== index
    );
    newObj.acc_no = newAccList;
    const newAmtList = fieldsToBeValidated.amount.filter(
      (item, index) => accIndex !== index
    );
    newObj.amount = newAmtList;
    setFieldsToBeValidated(newObj);
  };

  const onBlurValidation = (e, key, index) => {
    const newChange = { ...fieldsToBeValidated };
    switch (key) {
      case "tenorPeriod":
        if (e.target.value === "") {
          newChange[key].validationFailed = true;
        }
        break;
      case "tenorIndicator":
        if (e.target.value === "") {
          newChange[key].validationFailed = true;
        }
        break;
      case "paymentMode_mode":
        if (e.target.value === "") {
          newChange["paymentMode"].validationFailed = true;
        }
        break;
      case "eefcAcc_acc_no":
        if (e.target.value === "") {
          newChange["acc_no"][index].validationFailed = true;
        }
        break;
      case "eefcAcc_amount":
        if (e.target.value === "") {
          newChange["amount"][index].validationFailed = true;
        }
        break;
      case "operativeAcc_acc_no":
        if (e.target.value === "") {
          newChange["opp_acc_no"].validationFailed = true;
        }
        break;
      case "operativeAcc_amount":
        if (e.target.value === "") {
          newChange["opp_amount"].validationFailed = true;
        }
        break;
      case "chargesAccNo":
        if (e.target.value === "") {
          newChange["chargesAccNo"].validationFailed = true;
        }
        break;
      case "foriegnBankCharges":
        if (e.target.value === "") {
          newChange["foriegnBankCharges"].validationFailed = true;
        }
        break;
      default:
        newObj;
        break;
    }
    setFieldsToBeValidated(newChange);
  };

  //@todo refractor code
  const onChangeValue = (value, key, index) => {
    let newObj = { ...paymentDetails };
    let newAccList = [];
    const newChange = { ...fieldsToBeValidated };
    //if (newChange[key]) {
    //  newChange[key].validationFailed = false;
    //  setFieldsToBeValidated(newChange);
    //}

    switch (key) {
      case "totalRemittanceAmount":
        newObj.amountDetails.totalRemittanceAmount = value.target.value;
        break;
      case "fxAmountUtilized":
        newObj.rateInstructions.fxAmountUtilized = value;
        break;
      case "fcCreditAmount":
        newObj.rateInstructions.fcCreditAmount = value;
        break;
      case "tenorPeriod":
        newObj.amountDetails.tenorPeriod = value.target.value;
        value.target.value != ""
          ? (newChange[key].validationFailed = false)
          : "";
        break;
      case "tenorIndicator":
        newObj.amountDetails.tenorIndicator = value;
        value != "" ? (newChange[key].validationFailed = false) : "";
        break;
      case "dueDate":
        newObj.amountDetails.dueDate = value.target.value;
        break;
      case "paymentDate":
        if (moment(value).isBefore(moment(new Date(authData.appDate)), "day")) {
          updateToastState({
            toastMessage:
              "Payment date should be greater than today's application date",
            toastType: "",
            showToast: true,
          });
        } else {
          newObj.amountDetails.paymentDate = `${value.getDate()}-${value.getMonth()+1}-${value.getFullYear()}`;
        }
        break;
      case "branchName":
        newObj.amountDetails.branchName = value;
        break;
      case "paymentMode_mode":
        newObj.amountDetails.paymentMode.mode = value;
        if (value === "EEFC and Operative Account") {
          newObj.amountDetails.paymentMode.eefcAcc =
            newObj.amountDetails.paymentMode.eefcAcc?.map((item, index) => {
              if (index === 0 && item.acc_no === "") {
                item.amount = "";
              }
              return item;
            });
        }
        if (newChange["paymentMode"]) {
          newChange["paymentMode"].validationFailed = false;
          setFieldsToBeValidated(newChange);
        }
        break;
      case "eefcAcc_acc_no":
        newAccList = paymentDetails.amountDetails.paymentMode.eefcAcc.map(
          (item, item_index) => {
            if (index === item_index) {
              item["acc_no"] = value;
              return item;
            } else {
              return item;
            }
          }
        );

        if (newChange["acc_no"][index]) {
          newChange["acc_no"][index].validationFailed = false;
          setFieldsToBeValidated(newChange);
        }
        newObj = {
          ...paymentDetails,
          amountDetails: {
            ...paymentDetails.amountDetails,
            paymentMode: {
              ...paymentDetails.amountDetails.paymentMode,
              eefcAcc: newAccList,
            },
          },
        };
        break;
      case "eefcAcc_amount":
        newAccList = paymentDetails.amountDetails.paymentMode.eefcAcc.map(
          (item, item_index) => {
            if (index === item_index) {
              item["amount"] = value.target.value;
              return item;
            } else {
              return item;
            }
          }
        );
        if (newChange["amount"][index]) {
          newChange["amount"][index].validationFailed = false;
          setFieldsToBeValidated(newChange);
        }
        newObj = {
          ...paymentDetails,
          amountDetails: {
            ...paymentDetails.amountDetails,
            paymentMode: {
              ...paymentDetails.amountDetails.paymentMode,
              eefcAcc: newAccList,
            },
          },
        };
        break;
      case "operativeAcc_acc_no":
        newObj.amountDetails.paymentMode.operativeAcc.acc_no = value;
        if (newChange["opp_acc_no"]) {
          newChange["opp_acc_no"].validationFailed = false;
          setFieldsToBeValidated(newChange);
        }
        break;
      case "operativeAcc_amount":
        newObj.amountDetails.paymentMode.operativeAcc.amount =
          value.target.value;
        if (newChange["opp_amount"]) {
          newChange["opp_amount"].validationFailed = false;
          setFieldsToBeValidated(newChange);
        }
        break;
      case "operativeAcc_remarks":
        newObj.amountDetails.paymentMode.operativeAcc.remarks =
          value.target.value;
        break;
      case "useAsChargesAcc":
        newObj.useAsChargesAcc = value?.false;
        if (!value?.false) {
          newObj.charges.chargesAccNo = "";
          newObj.charges.balance_amt = "";
          newObj.charges.selectedGSTNo = "";
        }
        else{
          newObj.charges.chargesAccNo = paymentDetails?.amountDetails?.paymentMode?.operativeAcc?.acc_no
        }
        break;
      case "chargesAccNo":
        newObj.charges.chargesAccNo = value;
        if (newChange["chargesAccNo"]) {
          newChange["chargesAccNo"].validationFailed = false;
        }
        break;
      case "selectedGSTNo":
        newObj.charges.selectedGSTNo = value;
        break;
      case "foriegnBankCharges":
        newObj.charges.foriegnBankCharges = value;
        if (newChange["foriegnBankCharges"]) {
          newChange["foriegnBankCharges"].validationFailed = false;
        }
        break;
      case "senderToRecieverInstrution":
        newObj.otherDetails.senderToRecieverInstrution = value.target.value;
        break;
      // case "delegateToChecker":
      //   newObj.rateInstructions.delegateToChecker= value[""];
      //   break;

      default:
        newObj;
        break;
    }
    setFieldsToBeValidated(newChange);
    setpaymentDetails(newObj);
  };

  // const updateEEFCAccListAccNo = (value, accIndex) => {
  //   const newAccList = paymentDetails.amountDetails.paymentMode.eefcAcc.map(
  //     (item, index) => {
  //       if (accIndex === index) {
  //         item["acc_no"] = value;
  //         return item;
  //       } else {
  //         return item;
  //       }
  //     }
  //   );
  //   const newList = {
  //     ...paymentDetails,
  //     amountDetails: {
  //       ...amountDetails,
  //       paymentMode: { ...paymentMode, eefcAcc: newAccList },
  //     },
  //   };
  //   setpaymentDetails(newList);
  // };

  // const updatePaymentMode = (value) => {
  //   const newObj = { ...paymentDetails };
  //   newObj.amountDetails.paymentMode.mode = value;
  //   setpaymentDetails(newObj);
  // };

  //@todo
  const onChangeUseAsChargesAcc = (e) => {
    //If a user checks/selects the  “Use as Charges Account” then Charges Account Number in Charges section will be auto filled non editable
    const newList = { ...paymentDetails, useAsChargesAcc: e[""] };
    setpaymentDetails(newList);
  };

  const paymentDateCheck = (date) => {
    const paymentDate = moment(date).format("DD-MM-YYYY");
    const req = {
      userId: userId,
      corpId: corpId,
      bankCode: bankCode,
      fidbTnxId: transactionDetails?.recKey,
      paymentDate: paymentDate,
    };
    dispatch(Actions.paymentDateCheck(req));
  };

  // const checkBalanceAmount = (accNo, accType) => {
  //   const req = {
  //     userId: userId,
  //     corpId: corpId,
  //     bankCode: bankCode,
  //     subCustId: subcustId,
  //     accountNumber: accNo,
  //   };
  //   dispatch(Actions.balanceCheck(req, accType));
  // };

  const setBalance = (accNo, accType, ind) => {
    const newObj = { ...paymentDetails };
    if (accType === "eefc") {
      [...state?.eefcAccounts]?.map((eefcAcc) => {
        if (eefcAcc?.id === accNo) {
          const newAccList =
            paymentDetails.amountDetails.paymentMode.eefcAcc.map(
              (item, index) => {
                if (index === ind) {
                  item["balance_amt"] = eefcAcc?.availableBalance;
                  item["currency"] = eefcAcc?.currencyCode;
                }
                return item;
              }
            );
          newObj.amountDetails.paymentMode.eefcAcc = newAccList;
          setEefcOptions(newAccList);
        }
      });
    }
    if (accType === "operative") {
      state?.operativeAccounts?.map((operativeAcc) => {
        if (operativeAcc?.id === accNo) {
          newObj.amountDetails.paymentMode.operativeAcc.balance_amt =
            operativeAcc?.availableBalance;
          newObj.amountDetails.paymentMode.operativeAcc.currency =
            operativeAcc?.currencyCode;
        }
      });
    }
    if (!newObj.amountDetails.paymentDate) {
      newObj.amountDetails.paymentDate = `${
        new Date(authData.appDate).getMonth() + 1
      }-${new Date(authData.appDate).getDate()}-${new Date(
        authData.appDate
      ).getFullYear()}`;
    }

    if (accType === "charges") {
      state?.operativeAccounts?.map((operativeAcc) => {
        if (operativeAcc?.id === accNo) {
          newObj.charges.balance_amt = operativeAcc?.availableBalance;
          newObj.charges.currency = operativeAcc?.currencyCode;
        }
      });
    }
    setpaymentDetails(newObj);
  };

  const setEefcOptions = (eefcList, tempEefcAccs) => {
    const eefcAccounts = tempEefcAccs ? tempEefcAccs : eefcAccs;
    const myArray = [...eefcAccounts].filter(
      (ar) => !eefcList.find((rm) => rm.acc_no === ar.id)
    );
    setEefcAccs(myArray);
  };

  const getEefcOptions = (ind) => {
    const tempEefcAccs = [...eefcAccs];
    if (paymentDetails.amountDetails.paymentMode?.eefcAcc[ind]?.acc_no) {
      if (
        paymentDetails.amountDetails.paymentMode?.eefcAcc?.filter((item) => {
          return item.acc_no !== "";
        })?.length === 1
      ) {
        const index =
          paymentDetails.amountDetails.paymentMode?.eefcAcc?.findIndex(
            (item) => {
              return item.acc_no !== "";
            }
          );
        if (index === ind) {
          return state?.eefcAccounts?.map((v) => v.label);
        }
      } else {
        tempEefcAccs.push({
          label: paymentDetails.amountDetails.paymentMode?.eefcAcc[ind]?.acc_no,
          id: paymentDetails.amountDetails.paymentMode?.eefcAcc[ind]?.acc_no,
          accountNumber:
            paymentDetails.amountDetails.paymentMode?.eefcAcc[ind]?.acc_no,
          availableBalance:
            paymentDetails.amountDetails.paymentMode?.eefcAcc[ind]?.balance_amt,
        });
      }
    } else {
      if (
        paymentDetails.amountDetails.paymentMode?.eefcAcc?.filter((item) => {
          return item.acc_no !== "";
        })?.length === 1
      ) {
        const index =
          paymentDetails.amountDetails.paymentMode?.eefcAcc?.findIndex(
            (item) => {
              return item.acc_no !== "";
            }
          );
        if (index === ind) {
          return state?.eefcAccounts?.map((v) => v.label);
        } else {
          const values = state?.eefcAccounts
            .filter((item) => {
              return !paymentDetails.amountDetails.paymentMode?.eefcAcc
                ?.map((item) => {
                  return item.acc_no;
                })
                ?.includes(item.id);
            })
            ?.map((v) => v.label);
          return values;
        }
      } else {
        const values = state?.eefcAccounts
          .filter((item) => {
            return !paymentDetails.amountDetails.paymentMode?.eefcAcc
              ?.map((item) => {
                return item.acc_no;
              })
              ?.includes(item.id);
          })
          ?.map((v) => v.label);
        return values;
      }
    }
    return tempEefcAccs?.map((v) => v.label);
  };
  useEffect(() => {
    const newObj = { ...paymentDetails };
    // const newAccList = paymentDetails.amountDetails.paymentMode.eefcAcc.map(
    //   (item, index) => {
    //     if (index === EEFCIndex) {
    //       item["balance_amt"] = state?.balanceAmountEefc?.balanceAmount;
    //       item["currency"] = state?.balanceAmountEefc?.currencyType;
    //     }
    //     return item;
    //   }
    // );
    // newObj.amountDetails.paymentMode.eefcAcc = newAccList;
    // if (state?.balanceAmountOperative?.balanceAmount) {
    //   newObj.amountDetails.paymentMode.operativeAcc.balance_amt =
    //     state?.balanceAmountOperative?.balanceAmount;
    //   newObj.amountDetails.paymentMode.operativeAcc.currency =
    //     state?.balanceAmountOperative?.currencyType;
    // }
    // if (state?.balanceAmountCharges?.balanceAmount) {
    //   newObj.charges.balance_amt = state?.balanceAmountCharges?.balanceAmount;
    //   newObj.charges.currency = state?.balanceAmountCharges?.currencyType;
    // }

    updateChargesAccount(state?.chargesAccount);
    updateFxAmountUtilized(state?.fxAmountUtilized);
    updateFcCreditAmount(state?.fcCreditAmount);

    onChangeValue(state?.fxAmountUtilized, "fxAmountUtilized");
    onChangeValue(state?.fcCreditAmount, "fcCreditAmount");

    updateGstNoList(
      state?.gstNo?.gstInfo
        ? state?.gstNo?.gstInfo[paymentDetails.charges.chargesAccNo]?.gstNumber
        : []
    );

    if (state?.gstNo?.gstInfo) {
      if (
        state?.gstNo?.gstInfo[paymentDetails.charges.chargesAccNo]?.gstNumber
      ) {
        if (
          state?.gstNo?.gstInfo[paymentDetails.charges.chargesAccNo]?.gstNumber
            ?.length === 1
        ) {
          newObj.charges.selectedGSTNo =
            state?.gstNo?.gstInfo[
              paymentDetails.charges.chargesAccNo
            ]?.gstNumber?.[0];
        }
      }
    }

    setpaymentDetails(newObj);
  }, [
    state?.balanceAmountEefc,
    state?.balanceAmountOperative,
    state?.chargesAccount,
    state?.gstNo,
    state?.fxAmountUtilized,
    state?.fcCreditAmount,
  ]);

  // call getDueDate API when tenorPeriod or tenorIndicator value changes, alos clear due date if any of the filed is empty
  useEffect(() => {
    const tenorPeriod = paymentDetails?.amountDetails?.tenorPeriod;
    const tenorIndicator = paymentDetails?.amountDetails?.tenorIndicator;
    if (tenorPeriod && tenorIndicator) {
      let codeTypeRequest = "";
      if (tenorIndicator === "L- Lodge Date") {
        codeTypeRequest = "ldt";
      }
      if (tenorIndicator === "S- Shipment Date") {
        codeTypeRequest = "sdt";
      }
      if (tenorIndicator === "I- Invoice Date") {
        codeTypeRequest = "idt";
      }
      //Call due date API
      const req = {
        userId: userId,
        corpId: corpId,
        bankCode: bankCode,
        codeTypeRequest: codeTypeRequest,
        fidbTNXPk: transactionDetails?.recKey,
        noOfDays: parseInt(tenorPeriod),
      };
      dispatch(Actions.getDueDate(req));
    } else {
      let tempPaymentDetails = { ...paymentDetails };
      tempPaymentDetails.amountDetails.dueDate = "";
    }
  }, [
    paymentDetails?.amountDetails?.tenorPeriod,
    paymentDetails?.amountDetails?.tenorIndicator,
  ]);

  useEffect(() => {
    let tempPaymentDetails = { ...paymentDetails };
    let tempDueDate = state?.dueDate
    if(state?.dueDate?.includes("/")){
      tempDueDate = state?.dueDate?.replaceAll("/","-");
    }
    tempPaymentDetails.amountDetails.dueDate = tempDueDate || state?.dueDate;
    setpaymentDetails(tempPaymentDetails);
  }, [state?.dueDate]);

  useEffect(() => {
    if (selectedMode?.id) {
      let tempPaymentDetails = { ...paymentDetails };
      if (selectedMode?.id === "CCA") {
        tempPaymentDetails.amountDetails.paymentMode.operativeAcc = {
          acc_no: "",
          amount: transactionDetailsstate?.totalRemittance || "",
          balance_amt: "",
          remarks: "",
          isInsufficient: false,
        };
        setBalanceRemittanceAmount(transactionDetailsstate?.totalRemittance);
        tempPaymentDetails.fwcBookDeals = [];
        tempPaymentDetails.preBookDeals = [];
      } else if (selectedMode?.id === "CAA") {
        tempPaymentDetails.amountDetails.paymentMode.eefcAcc = [
          {
            acc_no: "",
            amount: transactionDetailsstate?.totalRemittance || "",
            balance_amt: "",
          },
        ];
      } else if (selectedMode?.id === "CCA/CAA") {
        tempPaymentDetails.amountDetails.paymentMode.operativeAcc = {
          acc_no: "",
          amount: "",
          balance_amt: "",
          remarks: "",
          isInsufficient: false,
        };
        setBalanceRemittanceAmount(0);
        tempPaymentDetails.fwcBookDeals = [];
        tempPaymentDetails.preBookDeals = [];
        tempPaymentDetails.amountDetails.paymentMode.eefcAcc = [
          { acc_no: "", amount: "", balance_amt: "" },
        ];
      }
      tempPaymentDetails.amountDetails.paymentMode.selectedMode =
        selectedMode?.id;
      setpaymentDetails(tempPaymentDetails);
      // API for select payment mode
      // const req = {
      //   userId: userId,
      //   corpId: subcustId,
      //   bankCode: bankCode,
      //   paymentMode: selectedMode?.id,
      // };
      // dispatch(Actions.selectPaymentMode(req));
    }
  }, [selectedMode]);

  const getEefcAmount = () => {
    let amount = 0;
    paymentDetails.amountDetails.paymentMode.eefcAcc.map((item) => {
      amount += Number(item.amount);
    });
    return amount;
  };

  const setBilldataValid = (isValid) => {
    setisBillDataValid(isValid);
  };

  const fetchGstNoList = (accountNo) => {
    const req = {
      customerID: transactionDetailsstate?.custIdAndIeCode?.custId || subcustId,
      apiType: "ONCHANGE",
      accountNum: accountNo,
    };
    dispatch(Actions.getGstNo(req));
  };

  const handleAccountNoChange = (chargesAccountLabel) => {
    let chargesAccountList = [...state?.operativeAccounts];
    const selectedAccount = chargesAccountList?.filter((account) => {
      if (account?.label === chargesAccountLabel) {
        return account;
      }
    });
    onChangeValue(selectedAccount?.[0]?.label, "chargesAccNo");
    setBalance(selectedAccount?.[0]?.id, "charges");
    // Balance check API
    // checkBalanceAmount(selectedAccount?.[0]?.id, "charges");

    // Api for fetching GST NO List
    fetchGstNoList(selectedAccount?.[0]?.id);
  };

  const validatePaymentDetailsFields = () => {
    let validationStatus = true;
    const filteredFields = Object.keys(fieldsToBeValidated)?.filter((item) => {
      let includeField = false;
      if (paperless) {
        includeField =
          item === "acc_no" || item === "amount"
            ? fieldsToBeValidated[item][0].mandatoryOnPaperless
            : fieldsToBeValidated[item].mandatoryOnPaperless;
      }
      //else {            //    if (fastProcessing) {
      //        includeField = fieldsToBeValidated[item].mandatoryOnFastProcessing;
      //    } else {
      //        includeField = fieldsToBeValidated[item].mandatoryOnStandardProcessing;
      //    }
      //}
      if (includeField) {
        if (item === "acc_no" || item === "amount") {
          if (fieldsToBeValidated[item][0].mandatoryBasedOnCondition !== "") {
            includeField = eval(
              fieldsToBeValidated[item][0].mandatoryBasedOnCondition
            );
          }
        } else if (fieldsToBeValidated[item].mandatoryBasedOnCondition !== "") {
          includeField = eval(
            fieldsToBeValidated[item].mandatoryBasedOnCondition
          );
        }
      }
      return includeField;
    });

    const getDataTobeValidated = (item) => {
      {
      }
      if (paymentDetails.amountDetails[item] != undefined) {
        return paymentDetails.amountDetails[item];
      } else if (item === "acc_no" || item === "amount") {
        return paymentDetails.amountDetails["paymentMode"].eefcAcc;
      } else if (item === "opp_acc_no" || item === "opp_amount") {
        if (item === "opp_acc_no") {
          return paymentDetails.amountDetails["paymentMode"].operativeAcc[
            "acc_no"
          ];
        } else {
          return paymentDetails.amountDetails["paymentMode"].operativeAcc[
            "amount"
          ];
        }
      } else if (item === "chargesAccNo" || item === "foriegnBankCharges") {
        return paymentDetails["charges"][item];
      }
    };

    filteredFields.forEach((item) => {
      const dataTobeValidated = getDataTobeValidated(item);
      // const dataTobeValidated = paymentDetails.amountDetails[item] != undefined ? paymentDetails.amountDetails[item] : (((item === "acc_no" || item === "amount") ? paymentDetails.amountDetails['paymentMode'].eefcAcc : paymentDetails.amountDetails['paymentMode'].operativeAcc[item]));
      if (Array.isArray(dataTobeValidated)) {
        const newChange = { ...fieldsToBeValidated };
        dataTobeValidated.map((itemVal, index) => {
          if (!itemVal[item]) {
            newChange[item][index].validationFailed = true;
            setFieldsToBeValidated(newChange);
            validationStatus = false;
          }
        });
      }
      if (!dataTobeValidated) {
        const newChange = { ...fieldsToBeValidated };
        newChange[item].validationFailed = true;
        setFieldsToBeValidated(newChange);
        validationStatus = false;
      }
      if (item === "paymentMode" && !paymentDetails.amountDetails[item].mode) {
        const newChange = { ...fieldsToBeValidated };
        newChange[item].validationFailed = true;
        setFieldsToBeValidated(newChange);
        validationStatus = false;
      }
    });
    return validationStatus;
  };
  const checkSufficientRemittanceBalance = (prefwtFlag) => {
    const totAmount = paymentDetails?.amountDetails?.totalRemittanceAmount
      ? parseInt(paymentDetails?.amountDetails?.totalRemittanceAmount)
      : 0;
    if (totAmount > 0) {
      let eefcAmount = 0;
      if (
        paymentDetails.amountDetails.paymentMode.mode &&
        (paymentDetails.amountDetails.paymentMode.mode === "EEFC Account" ||
          paymentDetails.amountDetails.paymentMode.mode ===
            "EEFC and Operative Account")
      )
        paymentDetails?.amountDetails?.paymentMode?.eefcAcc?.map((item) => {
          eefcAmount += item?.amount === "" ? 0 : parseInt(item?.amount);
        });
      let operativeAmount =
        paymentDetails.amountDetails.paymentMode.mode &&
        paymentDetails.amountDetails.paymentMode.mode !== "EEFC Account" &&
        paymentDetails.amountDetails.paymentMode?.operativeAcc?.amount
          ? parseInt(
              paymentDetails.amountDetails.paymentMode?.operativeAcc?.amount
            )
          : 0;
      let bal = totAmount - eefcAmount - operativeAmount;
      if (prefwtFlag) {
        let bal = operativeAmount - preBookAmt - fwcBookAmt;
        setBalanceRemittanceAmount(bal > 0 ? bal : 0);
      } else {
        setBalanceRemittanceAmount(
          operativeAmount > 0 ? operativeAmount : operativeAmount
        );
      }
      if (bal < 0) {
        return false;
      } else {
        return true;
      }
    } else {
      return false;
    }
  };

  useEffect(() => {
    checkSufficientRemittanceBalance(true);
  }, [preBookAmt, fwcBookAmt]);

  useEffect(() => {
    if (state.showSaveDraftMsg) {
      setAlert({
        ...alert,
        alertType: "success",
        alertMsg: "Payment Saved as Draft",
        isAlertOpen: true,
      });
    }
  }, [state.showSaveDraftMsg]);

  return (
    <>
      <div className="payment-detail-section">
        <AlertPopup
          {...alert}
          onClose={() => {
            setAlert({ ...alert, isAlertOpen: false });
            dispatch(Actions.clearPayDraftMsgStatus());
          }}
        />
        <span className="details-heading d-flex mtb-32 payment-detail-heading">
          Payment Details
        </span>
        <div className="border-container">
          <span className="details-heading d-flex mb-24">Amount Details</span>
          <Grid spacing={3} container>
            <Grid
              className="sub-detail-container full-width-textField mb-12"
              item
              lg={4}
              md={4}
              sm={6}
              xs={12}
            >
              <TextField
                inputMode="none"
                label="Total Remittance Amount *"
                name="Total Remittance Amount"
                type="text"
                variant="filled"
                value={paymentDetails?.amountDetails?.totalRemittanceAmount}
                adornmentEnd={<img src={InfoIcon} />}
                onChange={(e) => onChangeValue(e, "totalRemittanceAmount")}
                disabled={true}
                error={
                  fieldsToBeValidated?.totalRemittanceAmount?.validationFailed
                }
                adornmentStart={currency}
                errorMessage={"Mandatory Field"}
              />
            </Grid>
          </Grid>
          <Grid spacing={3} container>
            <Grid
              className="sub-detail-container full-width-textField"
              item
              lg={4}
              md={4}
              sm={6}
              xs={12}
            >
              <TextField
                label="Tenor Period (in days) *"
                name="Tenor Period (in days)"
                type="text"
                maxLength="3"
                variant="filled"
                value={paymentDetails.amountDetails.tenorPeriod}
                errorMessage={"Mandatory Field."}
                error={fieldsToBeValidated?.tenorPeriod?.validationFailed}
                onChange={(e) => {
                  if (
                    !e.target.value?.match(/^\d+$/g) &&
                    e.target.value !== ""
                  ) {
                    e.target.value = e.target.value?.slice(0, -1);
                  }
                }}
                onBlur={(e) => {
                  e.target.value < 0 ? (e.target.value = 0) : e.target.value;
                  onBlurValidation(e, "tenorPeriod");
                  onChangeValue(e, "tenorPeriod");
                }}
              />
            </Grid>
            <Grid
              className="sub-detail-container full-width-textField fullWidthDropDown"
              item
              lg={4}
              md={4}
              sm={6}
              xs={12}
            >
              <Dropdown
                label={"Tenor Indicator *"}
                items={["L- Lodge Date", "S- Shipment Date", "I- Invoice Date"]}
                variant="filled"
                fullWidth
                name="Tenor Indicator"
                defaultValue={paymentDetails.amountDetails.tenorIndicator}
                onChange={(e) => onChangeValue(e, "tenorIndicator")}
                error={fieldsToBeValidated?.tenorIndicator?.validationFailed}
                errorMsg={"Mandatory Field"}
                onBlur={(e) => onBlurValidation(e, "tenorIndicator")}
              />
            </Grid>
            <Grid
              className="sub-detail-container full-width-textField"
              item
              lg={4}
              md={4}
              sm={6}
              xs={12}
            >
              <TextField
                label="Due Date "
                name="Due Date "
                type="text"
                variant="filled"
                value={
                  paymentDetails?.amountDetails?.tenorPeriod
                    ? paymentDetails.amountDetails.dueDate
                    : ""
                }
                disabled={true}
                /*error={fieldsToBeValidated?.dueDate?.validationFailed}*/
              />
            </Grid>
            <Grid
              className="sub-detail-container datepicker-grid full-width-textField"
              item
              lg={4}
              md={4}
              sm={6}
              xs={12}
            >
              <Datepicker
                label="Payment Date *"
                name="Payment Date"
                type="inline"
                variant="filled"
                defaultValue={
                  paymentDetails.amountDetails.paymentDate
                    ? {
                        day: Number(paymentDetails.amountDetails.paymentDate?.split("-")[0]),
                        month: Number(paymentDetails.amountDetails.paymentDate?.split("-")[1]),
                        year: Number(paymentDetails.amountDetails.paymentDate?.split("-")[2]),
                      }
                    : {
                        day: "",
                        month: "",
                        year: "",
                      }
                }
                value={paymentDetails.amountDetails.paymentDate}
                onChange={(e) => {
                  //Payment date check API
                  paymentDateCheck(e);
                  onChangeValue(e, "paymentDate");
                }}
                // error={fieldsToBeValidated?.paymentDate?.validationFailed}
                error={false}
                errorMessage={"Mandatory Field"}
              />
              {state?.validPaymentDate && <span>Invalid date</span>}
            </Grid>
            <Grid
              className="sub-detail-container full-width-textField fullWidthDropDown"
              item
              lg={4}
              md={4}
              sm={12}
              xs={12}
            >
              <Dropdown
                label={"Branch Name (Optional)"}
                items={state?.branchNames.map((v) => v.label)}
                variant="filled"
                fullWidth
                name="Branch Name (Optional)"
                defaultValue={paymentDetails.amountDetails.branchName}
                onChange={(e) => onChangeValue(e, "branchName")}
              />
            </Grid>
            {/* dummy grid item */}
            <Grid
              className="sub-detail-container full-width-box hideMobTab"
              item
              lg={4}
              md={4}
              sm={12}
              xs={12}
            ></Grid>
            <Grid
              className="sub-detail-container full-width-textField fullWidthDropDown"
              item
              lg={4}
              md={6}
              sm={6}
              xs={12}
            >
              <Dropdown
                label={"Payment Mode *"}
                items={state?.paymentModeList.map((v) => v.label)}
                variant="filled"
                fullWidth
                name="Payment Mode"
                onChange={(e) => {
                  onChangeValue(e, "paymentMode_mode");
                  // On selecting payment mode API
                  let modeList = [...state?.paymentModeList];
                  const selectedMode = modeList?.filter((mode) => {
                    if (mode.label === e) {
                      return mode;
                    }
                  });
                  setSelectedMode(selectedMode[0]);
                }}
                defaultValue={paymentDetails.amountDetails.paymentMode.mode}
                error={fieldsToBeValidated?.paymentMode?.validationFailed}
                errorMessage={"Mandatory Field"}
                onBlur={(e) => onBlurValidation(e, "paymentMode_mode")}
              />
            </Grid>
          </Grid>
          {(paymentDetails.amountDetails.paymentMode.mode === "EEFC Account" ||
            paymentDetails.amountDetails.paymentMode.mode ===
              "EEFC and Operative Account") && (
            <div className="m-40 mb-0 eefc-container">
              <span className="d-flex mb-16 ta-l">
                <img src={BuildingIcon} />
                {`EEFC Account (Amount Payable: ${currency} ${getEefcAmount()})`}
              </span>

              {paymentDetails.amountDetails.paymentMode?.eefcAcc?.map(
                (eefcAcc, index) => {
                  return (
                    <Grid spacing={3} container key={index}>
                      <Grid
                        className="sub-detail-container full-width-textField fullWidthDropDown"
                        item
                        lg={4}
                        md={4}
                        sm={6}
                        xs={12}
                      >
                        <Dropdown
                          label={"Account Number *"}
                          items={getEefcOptions(index)}
                          variant="filled"
                          fullWidth
                          name="Account Number"
                          error={
                            (eefcAcc.acc_no &&
                              eefcAcc.acc_no !== "" &&
                              eefcAcc.acc_no !== undefined &&
                              (eefcAcc.balance_amt > 0 ? false : true)) ||
                            fieldsToBeValidated?.acc_no[index]
                              ?.validationFailed ||
                            parseInt(eefcAcc.balance_amt) <
                              parseInt(eefcAcc.amount)
                          }
                          errorMsg={
                            eefcAcc.acc_no &&
                            parseInt(eefcAcc.balance_amt) <
                              parseInt(eefcAcc.amount)
                              ? `Insufficient Funds Balance: ${eefcAcc.currency} ${eefcAcc.balance_amt}`
                              : fieldsToBeValidated?.acc_no[index]
                                  ?.validationFailed
                              ? "Mandatory Field"
                              : `Insufficient Funds Balance: ${eefcAcc.currency} ${eefcAcc.balance_amt}`
                          }
                          helperText={
                            eefcAcc.acc_no &&
                            eefcAcc.balance_amt !== "" &&
                            eefcAcc.balance_amt !== undefined &&
                            (eefcAcc.balance_amt > 0
                              ? `Balance: ${eefcAcc.currency} ${eefcAcc.balance_amt}`
                              : "")
                          }
                          defaultValue={eefcAcc.acc_no}
                          onChange={(e) => {
                            onChangeValue(e, "eefcAcc_acc_no", index);
                            setEEFCIndex(index);
                            //setting balance for selected account number
                            setBalance(e, "eefc", index);
                            // Balance check API
                            // checkBalanceAmount(e, "eefc");
                          }}
                          onBlur={(e) =>
                            onBlurValidation(e, "eefcAcc_acc_no", index)
                          }
                        />
                      </Grid>
                      <Grid
                        className="sub-detail-container full-width-textField"
                        item
                        lg={4}
                        md={4}
                        sm={6}
                        xs={12}
                      >
                        <TextField
                          label={"Amount *"}
                          items={[]}
                          variant="filled"
                          fullWidth
                          name="Amount"
                          adornmentStart={currency}
                          value={eefcAcc.amount}
                          error={
                            fieldsToBeValidated?.amount[index]?.validationFailed
                          }
                          errorMessage={"Mandatory Field"}
                          onChange={(e) => {
                            if (currency === "JPY") {
                              if (e.target.value % 1 !== 0) {
                                e.target.value = parseInt(
                                  Number(e.target.value)
                                );
                                updateToastState({
                                  toastMessage:
                                    "For JPY currency, amount can not be in decimal",
                                  toastType: "",
                                  showToast: true,
                                });
                              }
                            }
                            if (
                              !e.target.value?.match(
                                /^((?!0)\d{0,20}|0|\.\d{1,2})($|\.$|\.\d{1,2}$)/g
                              ) &&
                              e.target.value !== ""
                            ) {
                              e.target.value = e.target.value?.slice(0, -1);
                            }
                            e.target.value < 0
                              ? (e.target.value = 0)
                              : e.target.value;
                            onChangeValue(e, "eefcAcc_amount", index);
                          }}
                          onBlur={(e) => {
                            if (!checkSufficientRemittanceBalance()) {
                              e.target.value = 0;
                              onChangeValue(e, "eefcAcc_amount", index);
                              updateToastState({
                                toastMessage:
                                  "Amount should not exceed the remittance amount",
                                toastType: "",
                                showToast: true,
                              });
                            }
                            onBlurValidation(e, "eefcAcc_amount", index);
                          }}
                        />
                      </Grid>
                      {index !== 0 && (
                        <Grid
                          className="sub-detail-container jc-c"
                          item
                          lg={4}
                          md={3}
                          sm={12}
                          xs={12}
                        >
                          <div
                            className="remove-text"
                            onClick={() => removeEEFCAcc(index)}
                          >
                            <img src={RemoveIcon} />
                            Remove
                          </div>
                        </Grid>
                      )}
                      <Grid
                        item
                        className="wd-none eefc-divider"
                        sm={12}
                        xs={12}
                      >
                        <Divider />
                      </Grid>
                    </Grid>
                  );
                }
              )}

              <Grid container>
                <Grid item>
                  <div
                    className="add-account-text"
                    onClick={() => addEEFCAcc()}
                  >
                    <img src={AddIcon} />
                    ADD another account
                  </div>
                </Grid>
              </Grid>
            </div>
          )}

          {(paymentDetails.amountDetails.paymentMode.mode ===
            "Operative Account" ||
            paymentDetails.amountDetails.paymentMode.mode ===
              "EEFC and Operative Account") && (
            <div className="mtrl-40 mb-0 eefc-container operative">
              <span className="d-flex mb-16">
                <img src={BuildingIcon} />
                Operative Account
              </span>
              <Grid
                spacing={3}
                container
                className="operative-account-container"
              >
                <Grid
                  className="sub-detail-container full-width-textField fullWidthDropDown"
                  item
                  lg={4}
                  md={6}
                  sm={6}
                  xs={12}
                >
                  <Dropdown
                    label={"Account Number *"}
                    items={state?.operativeAccounts?.map((v) => v.label)}
                    variant="filled"
                    fullWidth
                    name="Account Number"
                    helperText={
                      paymentDetails.amountDetails.paymentMode.operativeAcc
                        .acc_no &&
                      `Balance: ${paymentDetails.amountDetails.paymentMode.operativeAcc.currency} ${paymentDetails.amountDetails.paymentMode.operativeAcc.balance_amt}`
                    }
                    error={
                      paymentDetails.amountDetails.paymentMode.operativeAcc
                        .isInsufficient ||
                      fieldsToBeValidated?.opp_acc_no?.validationFailed ||
                      parseInt(
                        paymentDetails.amountDetails.paymentMode.operativeAcc
                          .balance_amt
                      ) <
                        parseInt(
                          paymentDetails.amountDetails.paymentMode.operativeAcc
                            .amount
                        )
                    }
                    errorMsg={
                      parseInt(
                        paymentDetails.amountDetails.paymentMode.operativeAcc
                          .balance_amt
                      ) <
                      parseInt(
                        paymentDetails.amountDetails.paymentMode.operativeAcc
                          .amount
                      )
                        ? `Insufficient Funds  Balance: ${paymentDetails.amountDetails.paymentMode.operativeAcc.currency} ${paymentDetails.amountDetails.paymentMode.operativeAcc.balance_amt}`
                        : fieldsToBeValidated?.opp_acc_no?.validationFailed
                        ? "Mandatory Field"
                        : `Insufficient Funds Balance: ${paymentDetails.amountDetails.paymentMode.operativeAcc.currency} ${paymentDetails.amountDetails.paymentMode.operativeAcc.balance_amt}`
                    }
                    defaultValue={
                      paymentDetails.amountDetails.paymentMode.operativeAcc
                        .acc_no
                    }
                    onChange={(e) => {
                      onChangeValue(e, "operativeAcc_acc_no");
                      setBalance(e, "operative");
                      // Balance check API
                      // checkBalanceAmount(e, "operative");
                    }}
                    onBlur={(e) => onBlurValidation(e, "operativeAcc_acc_no")}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container full-width-textField"
                  item
                  lg={4}
                  md={6}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label={"Amount *"}
                    variant="filled"
                    fullWidth
                    name="Amount"
                    adornmentStart={currency}
                    value={
                      paymentDetails.amountDetails.paymentMode.operativeAcc
                        .amount
                    }
                    disabled={
                      paymentDetails.amountDetails.paymentMode.mode !==
                      "EEFC and Operative Account"
                    }
                    error={fieldsToBeValidated?.opp_amount?.validationFailed}
                    errorMessage={"Mandatory Field"}
                    onChange={(e) => {
                      if (currency === "JPY") {
                        if (e.target.value % 1 !== 0) {
                          e.target.value = parseInt(Number(e.target.value));
                          updateToastState({
                            toastMessage:
                              "For JPY currency, amount can not be in decimal",
                            toastType: "",
                            showToast: true,
                          });
                        }
                      }
                      if (
                        !e.target.value?.match(
                          /^((?!0)\d{0,20}|0|\.\d{1,2})($|\.$|\.\d{1,2}$)/g
                        ) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      e.target.value < 0
                        ? (e.target.value = 0)
                        : e.target.value;
                      onChangeValue(e, "operativeAcc_amount");
                      // Checking if balance amount is less than amount
                      let tempDetails = { ...paymentDetails };
                      let { balance_amt, isInsufficient } =
                        tempDetails.amountDetails.paymentMode.operativeAcc;
                      if (e && balance_amt) {
                        if (parseInt(balance_amt) < parseInt(e)) {
                          isInsufficient = true;
                        } else {
                          isInsufficient = false;
                        }
                        setpaymentDetails(tempDetails);
                      }
                    }}
                    onBlur={(e) => {
                      if (!checkSufficientRemittanceBalance()) {
                        e.target.value = 0;
                        onChangeValue(e, "operativeAcc_amount");
                        updateToastState({
                          toastMessage:
                            "Amount should not exceed the remittance amount",
                          toastType: "",
                          showToast: true,
                        });
                      }
                      onBlurValidation(e, "operativeAcc_amount");
                    }}
                  />
                </Grid>
                {paymentDetails.amountDetails.paymentMode.operativeAcc
                  .isInsufficient ||
                  (parseInt(
                    paymentDetails.amountDetails.paymentMode.operativeAcc
                      .balance_amt
                  ) <
                    parseInt(
                      paymentDetails.amountDetails.paymentMode.operativeAcc
                        .amount
                    ) && (
                    <Grid
                      className="sub-detail-container full-width-textField shrink-text"
                      item
                      lg={12}
                      md={12}
                      sm={12}
                      xs={12}
                    >
                      <TextField
                        classes={classes}
                        label={"Remarks: Reason of low / insufficient fund"}
                        items={[]}
                        variant="filled"
                        fullWidth
                        value={
                          paymentDetails.amountDetails.paymentMode.operativeAcc
                            .remarks
                        }
                        onChange={(e) =>
                          onChangeValue(e, "operativeAcc_remarks")
                        }
                      />
                    </Grid>
                  ))}
              </Grid>
              <div className="align-left t-400  mt-0">
                <Checkbox
                  label="Use as Charges Account"
                  value={paymentDetails.useAsChargesAcc}
                  onChange={(e) => {
                    onChangeValue(e, "useAsChargesAcc");
                    if (e?.false === true) {
                      fetchGstNoList(
                        paymentDetails.amountDetails.paymentMode.operativeAcc
                          .acc_no
                      );
                    }
                  }}
                />
              </div>
            </div>
          )}
        </div>

        {paymentDetails.amountDetails.paymentMode.mode && (
          <div>
            <div className="border-container pb-40">
              <span className="details-heading d-flex mb-24">Charges</span>
              <Grid container spacing={3}>
                <Grid
                  className="sub-detail-container full-width-textField fullWidthDropDown"
                  item
                  lg={4}
                  md={4}
                  sm={6}
                  xs={12}
                >
                  {paymentDetails.useAsChargesAcc ? (
                    <TextField
                      disabled
                      label={"Charges Account Number *"}
                      variant="filled"
                      fullWidth
                      value={
                        paymentDetails.amountDetails.paymentMode.operativeAcc
                          .acc_no
                      }
                      // onChange={(e) => onChangeValue(e, "chargesAccNo")}
                    />
                  ) : (
                    <Dropdown
                      label={"Charges Account Number *"}
                      items={state?.operativeAccounts?.map(
                        ({ label }) => label
                      )}
                      variant="filled"
                      fullWidth
                      name="Charges Account Number"
                      error={
                        fieldsToBeValidated?.chargesAccNo?.validationFailed
                      }
                      errorMsg={"Mandatory Field"}
                      helperText={
                        paymentDetails.charges.chargesAccNo &&
                        `Balance: ${paymentDetails.charges.currency} ${paymentDetails.charges.balance_amt}`
                      }
                      defaultValue={paymentDetails.charges.chargesAccNo}
                      onChange={(e) => {
                        handleAccountNoChange(e);
                      }}
                      onBlur={(e) => onBlurValidation(e, "chargesAccNo")}
                    />
                  )}
                </Grid>
                <Grid
                  className="sub-detail-container full-width-textField fullWidthDropDown"
                  item
                  lg={4}
                  md={4}
                  sm={6}
                  xs={12}
                >
                  {gstNoList?.length === 1 ? (
                    <TextField
                      disabled
                      label={"Selected GST Number (Optional)"}
                      variant="filled"
                      fullWidth
                      value={paymentDetails.charges.selectedGSTNo}
                      // onChange={(e) => onChangeValue(e, "selectedGSTNo")}
                    />
                  ) : (
                    <Dropdown
                      label={"Selected GST Number (Optional)"}
                      items={gstNoList ? gstNoList : []}
                      variant="filled"
                      fullWidth
                      name="Selected GST Number (Optional)"
                      defaultValue={paymentDetails.charges.selectedGSTNo}
                      onChange={(e) => onChangeValue(e, "selectedGSTNo")}
                    />
                  )}
                </Grid>
                <Grid
                  className="sub-detail-container full-width-textField fullWidthDropDown"
                  item
                  lg={4}
                  md={4}
                  sm={12}
                  xs={12}
                >
                  <Dropdown
                    label={"Foreign Bank Charges *"}
                    items={["BEN", "SHA", "OUR"]}
                    variant="filled"
                    fullWidth
                    name="Foreign Bank Charges"
                    helperText={state?.displayCharge}
                    error={
                      fieldsToBeValidated?.foriegnBankCharges?.validationFailed
                    }
                    errorMsg={"Mandatory Field"}
                    defaultValue={paymentDetails.charges.foriegnBankCharges}
                    onChange={(e) => {
                      onChangeValue(e, "foriegnBankCharges");
                      //Call display charges API
                      dispatch(Actions.displayCharges(e));
                    }}
                    onBlur={(e) => onBlurValidation(e, "foriegnBankCharges")}
                  />
                </Grid>
              </Grid>
            </div>
          </div>
        )}
        {paymentDetails.amountDetails.paymentMode.mode === "EEFC Account" ||
          (paymentDetails.amountDetails.paymentMode.mode ===
            "EEFC and Operative Account" && (
            <>
              <BillofEntryDelayReasons
                fetchBOEDelayReasons={(delayReasonsList) => {
                  let tempPaymentDetails = { ...paymentDetails };
                  tempPaymentDetails.boeDelayReasons = delayReasonsList;
                  setpaymentDetails(tempPaymentDetails);
                }}
                data={paymentDetails.boeDelayReasons}
                proceedClickInfo={props?.proceedClickInfo}
                isBilldataValid={setBilldataValid}
              />
            </>
          ))}
        {(paymentDetails.amountDetails.paymentMode.mode ===
          "Operative Account" ||
          paymentDetails.amountDetails.paymentMode.mode ===
            "EEFC and Operative Account") && (
          <RateInstruction
            data={paymentDetails.rateInstructions}
            fetchPreDeals={(preDeals) => {
              let tempPaymentDetails = { ...paymentDetails };
              tempPaymentDetails["preBookDeals"] = preDeals;
              setpaymentDetails(tempPaymentDetails);
            }}
            preBookDeals={paymentDetails?.preBookedDeals}
            fetchFWCDeals={(fwcDeals) => {
              let tempPaymentDetails = { ...paymentDetails };
              tempPaymentDetails["fwcBookDeals"] = fwcDeals;
              setpaymentDetails(tempPaymentDetails);
            }}
            fwcBookDeals={paymentDetails?.fwcBookedDeals}
            preBookAmt={(amt) => setPreBookAmt(amt)}
            fwcBookAmt={(amt) => setFwcBookAmt(amt)}
            balanceRemittanceAmount={balanceRemittanceAmount}
            totalRemittance={
              paymentDetails?.amountDetails?.paymentMode?.operativeAcc?.amount
            }
          />
        )}
        {paymentDetails.amountDetails.paymentMode.mode && (
          <div className="border-container other-details-container">
            <span className="details-heading d-flex mb-24">Other Details</span>
            <Grid container spacing={3}>
              <Grid
                className="sub-detail-container full-width-textField"
                item
                lg={12}
                md={12}
                sm={12}
                xs={12}
              >
                <TextField
                  classes={classes}
                  label={"Sender to Receiver Instruction (Optional)"}
                  items={[]}
                  maxLength={1000}
                  variant="filled"
                  fullWidth
                  value={paymentDetails.otherDetails.senderToRecieverInstrution}
                  onChange={(e) =>
                    onChangeValue(e, "senderToRecieverInstrution")
                  }
                />
              </Grid>
            </Grid>
          </div>
        )}
        {toastState?.showToast && (
          <AlertPopup
            alertMsg={toastState?.toastMessage}
            alertType={toastState?.toastType}
            isAlertOpen={toastState?.showToast}
            onClose={() => {
              updateToastState({
                toastMessage: "",
                toastType: "",
                showToast: false,
              });
            }}
          />
        )}

        {paymentDetails.amountDetails.paymentMode.mode === "" && (
          <div style={{ height: "50px" }} />
        )}
      </div>
    </>
  );
};

export default PaymentDetails;
