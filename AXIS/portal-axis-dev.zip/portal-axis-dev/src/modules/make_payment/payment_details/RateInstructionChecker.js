/*eslint-disable */
import React, { useState, useEffect } from "react";
import { Grid } from "@material-ui/core";
// import PreBookedDeals from "./PreBookedDeals";
// import ForwardContract from "./ForwardContract";
import BookRate from "./BookRate";

import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";

const RateInstructionChecker = (props) => {
  const dispatch = useDispatch();
  const [delegateChecker, updateDelegateChecker] = useState(false);
  const authData = JSON.parse(localStorage.getItem("authData"));
  const { userRoleType } = authData;
  const {
    displayRate,
    fxRateMessageId,
    fidbMargin,
    fxRateResponse,
    fxRateStatus,
  } = useSelector((state) => state?.paymentReviewData);

  return (
    <>
      <div style={{ width: "100%" }}>
        <Grid>
          <BookRate
            // fxRateStatus={fxRateStatus}
            authorizeDisable={props?.authorizeDisable}
            displayRate={displayRate}
            fxRateMessageId={fxRateMessageId}
            fidbMargin={fidbMargin}
            fxRateResponse={fxRateResponse}
            fidbtxnId={props?.fidbtxnId}
            userRoleType={userRoleType}
            delegateChecker={delegateChecker}
            paymentMode={props?.paymentMode}
            balanceRemittanceAmount={props?.balanceRemittanceAmount}
            tridbNumber={props?.tridbNumber}
            instructionDetails={props?.instructionDetails}
            remmitanceAmount={props?.remmitanceAmount}
            utilizedAmount={props?.utilizedAmount}
            amountInInr={props?.amountInInr}
            convertedAmount={props?.convertedAmount}
            statusCode={props?.statusCode}
            fxRateAmount={props?.fxRateAmount}
          />
        </Grid>
      </div>
    </>
  );
};

export default RateInstructionChecker;
