/* eslint-disable */
import React, { useState, useEffect, useRef } from "react";
import BottomDrawer from "../../../components/bottomdrawer";
import { Button } from "../../../components/@subzero/glacier/package/lib/components";
import AgGridTable from "../../../components/aggridtable";
import AlertDialog from "../../../components/dialog";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";
import AlertPopup from "../../../components/alertPopup/alertPopup";

const PreBookedDeals = (props) => {
  const [order, setOrder] = useState("asc");
  const [orderBy, setOrderBy] = useState("calories");
  const [showPopup, updatePopupDisplay] = useState(false);
  const [rowList, updateRowList] = useState([]);
  const [selectedList, updateSelectedList] = useState([]);
  const [isDisabled, updateDisabled] = useState(true);
  const [showAlert, setshowAlert] = useState(false);
  const [currencyChangedID, setCurrencyChangedID] = useState(null);
  const [rowValueChanged, updateRowValue] = React.useState(false);
  const [sortInfo, setSortInfo] = useState({
    sortBy: "dealId",
    sortType: "ASC",
  });
  const authData = JSON.parse(localStorage.getItem("authData"));
  const { userId, corpId, bankCode, subcustId } = authData;
  const state = useSelector((state) => state?.payment);
  const preBookDealsData = useSelector(
    (state) => state?.payment.preBookedDeals
  );
  const searchResultsData = useSelector(
    (state) => state?.payment.textSearchResults
  );
  const currency = useSelector((state) => state?.transactionDetails?.currency);
  const recKey = useSelector((state) => state?.transactionDetails.recKey);
  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const [preBookedDealsList, setPreBookedDealsList] = useState([]);

  const dispatch = useDispatch();
  const [toastState, updateToastState] = useState({
    toastMessage: "",
    toastType: "",
    showToast: false,
  });
  const [prebookAmount, setPrebookAmount] = useState(0);
  // initial data fetching
  useEffect(() => {
    getPreBookedDealsList();
  }, [sortInfo]);

  //Update preBookedDealsList when response data changes
  useEffect(() => {
    setPreBookedDealsList([...preBookDealsData]);
  }, [preBookDealsData]);

  //Update table rows when searchResultsData changes
  useEffect(() => {
    generateTableRowValues();
  }, [searchResultsData]);

  useEffect(() => {
    const tempList = [...rowList]?.map((item) => {
      if (item.id.value === currencyChangedID) {
        item.amountInr.value = parseFloat(state?.inrAmount).toFixed(2)
        return item;
      } else {
        item.amountInr.value = parseFloat(item.amountInr.value).toFixed(2)
        return item;
      }
    });
    updateRowList(tempList);
    updateRowValue(!rowValueChanged);
  }, [state?.inrAmount]);

  const getPreBookedDealsList = (sortBy, sortType) => {
    const req = {
      userId: userId,
      corpId: corpId,
      bankCode: bankCode,
      customerId: transactionDetails?.custIdAndIeCode?.custId || subcustId,
      apiName: "PREE-BOOK",
      apiTyoe: "NORMAL",
      apiFlag: "explore",
      sortInfo: sortInfo,
      remitanceCurrency: currency,
    };

    dispatch(Actions.getPreBookedDeals(req));
  };

  function createData(
    id,
    refNo,
    currencyPair,
    exchangeRate,
    validTill,
    osAmount,
    amountUtilised,
    amountInr
  ) {
    return {
      id,
      refNo,
      currencyPair,
      exchangeRate,
      validTill,
      osAmount,
      amountUtilised,
      amountInr,
    };
  }

  useEffect(() => {
    generateSelectedTableRowValues();
  }, [props?.data]);

  const generateSelectedTableRowValues = () => {
    const rows = getSelectedRows();
    let newArray = [...rows];
    let resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        let value = rowItem[key];
        switch (key) {
          case "amountUtilised":
            return (newObject[key] = {
              value: value,
              handleUserInput: handleUserInput,
            });
          default:
            newObject[key] = { value: value };
            break;
        }
      });
      resultArray.push(newObject);
    });
    updateSelectedList(resultArray);
  };

  const getSorted = (sortBy, desc) => {
    switch (sortBy) {
      case "refNo":
        sortBy = "dealId";
        break;
      case "osAmount":
        sortBy = "outstandingAmount";
        break;
      case "amountUtilised":
        sortBy = "utilizedAmount";
        break;
      case "amountInr":
        sortBy = "amountInINR";
        break;
    }
    const receivedSortInfo = {
      sortBy: sortBy,
      sortType: desc ? "DESC" : "ASC",
    };
    if (JSON.stringify(receivedSortInfo) !== JSON.stringify(sortInfo)) {
      setSortInfo({
        sortBy: sortBy,
        sortType: desc ? "DESC" : "ASC",
      });
    }
  };

  const getSelectedRows = () => {
    if (props?.data?.length > 0) {
      return props?.data?.map((resp) => {
        const {
          dealId: id,
          dealId: refNo,
          currencyPair,
          exchangeRate,
          validTill,
          outstandingAmount: osAmount,
          amountToBeUtilized: amountUtilised,
          amountInInr: amountInr,
        } = resp;
        return createData(
          id,
          refNo,
          currencyPair,
          exchangeRate,
          validTill,
          osAmount,
          amountUtilised,
          amountInr
        );
      });
    } else {
      return [];
    }
  };

  const generateTableRowValues = () => {
    const rows = getRows();
    let newArray = [...rows];
    let resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        let value = rowItem[key];
        switch (key) {
          case "amountUtilised":
            return (newObject[key] = {
              value: value,
              handleUserInput: handleUserInput,
            });
          default:
            newObject[key] = { value: value };
            break;
        }
      });
      resultArray.push(newObject);
    });
    updateRowList(resultArray);
  };

  const getRows = () => {
    let dataList;
    if (searchResultsData?.length > 0) {
      dataList = searchResultsData;
    } else {
      dataList = preBookedDealsList;
    }

    if (dataList?.length > 0) {
      return dataList?.map((resp) => {
        const {
          dealId: id,
          dealId: refNo,
          currencyPair,
          exchangeRate,
          validTill,
          outstandingAmount: osAmount,
          utilizedAmount: amountUtilised,
          amountInINR: amountInr,
        } = resp;
        return createData(
          id,
          refNo,
          currencyPair,
          exchangeRate,
          validTill,
          osAmount,
          amountUtilised,
          amountInr
        );
      });
    } else {
      return [];
    }
  };

  // when drawer opened, generate table row values
  useEffect(() => {
    if (showPopup) {
      generateTableRowValues();
    }
  }, [showPopup]);

  useEffect(() => {
    props?.fetchPreBookDeals(selectedList);
    let preBookAmt = 0;
    selectedList?.map((item) => {
      preBookAmt += item?.amountUtilised?.value
        ? parseInt(item?.amountUtilised?.value)
        : 0;
    });
    props?.fetchPreBookAmount(preBookAmt);
    setPrebookAmount(preBookAmt);
  }, [selectedList]);

  useEffect(() => {
    const tempList = [...rowList]?.map((item) => {
      if (item.id.value === currencyChangedID) {
        item.amountInr.value = parseFloat(state?.inrAmount).toFixed(2);
        return item;
      } else {
        item.amountInr.value = parseFloat(item.amountInr.value).toFixed(2);
        return item;
      }
    });
    updateRowList(tempList);
  }, [state?.inrAmount]);

  function usePrevious(value) {
    const ref = useRef();
    useEffect(() => {
      ref.current = value;
    });
    return ref.current;
  }

  const handleUserInput = (value, id, field, listAray) => {
    setCurrencyChangedID(id);
    listAray?.map((item) => {
      if (item?.id?.value == id) {
        let preBookAmt = 0;
        listAray?.map((item) => {
          preBookAmt += item?.amountUtilised?.value
            ? parseInt(item?.amountUtilised?.value)
            : 0;
        });
        if (
          props?.balanceRemittanceAmount < 0 ||
          props?.balanceRemittanceAmount - preBookAmt < 0
        ) {
          updateToastState({
            toastMessage: "Amount should not exceed the remittance amount",
            toastType: "",
            showToast: true,
          });
          item[field] = { value: 0, handleUserInput: handleUserInput };
        } else if (parseInt(value) > item?.osAmount?.value) {
          updateToastState({
            toastMessage: "Amount should not exceed the O/S amount",
            toastType: "",
            showToast: true,
          });
          item[field] = { value: 0, handleUserInput: handleUserInput };
        } else {
          props?.fetchPreBookAmount(preBookAmt);
          item[field] = { value: value, handleUserInput: handleUserInput };
          // Currency convert API
          convertCurrency(value);
        }
      }
    });
    updateRowList(listAray);
  };

  useEffect(() => {
    checkIsDisabled(selectedList);
  }, [rowList]);

  const convertCurrency = (amt) => {
    const req = {
      currencyTyp: currency,
      amount: parseInt(amt),
      baseCurrency: "INR",
      bankCode: authData?.bankCode,
    };
    dispatch(Actions.currencyConvert(req));
  };

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const handleSelectAllClick = (event) => {
    if (event.target.checked) {
      const newSelecteds = rows.map((n) => n.refNo);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const headCells = [
    { field: "refNo", label: "Deal ID", largeCell: true, sortable: true },
    { field: "currencyPair", label: "Currency Pair", sortable: true },
    { field: "exchangeRate", label: "Exchange Rate", sortable: true, minWidth:120 },
    { field: "validTill", label: "Valid Till", sortable: true },
    {
      field: "osAmount",
      label: "O/S Amount",
      sortable: true,
      adornmentStart: `${currency}`,
      rightAligned: true
    },
    {
      field: "amountUtilised",
      label: "Amount to be Utilised",
      textField: true,
      adornmentStart: `${currency}`,
      numberOnly: true,
    },
    {
      field: "amountInr",
      label: "Amount in  INR",
      adornmentStart: "INR",
      rightAligned: true
    },
  ];

  // delete an item from selected list by it's id
  const handleRowDeletion = (rowId) => {
    const req = {
      dealId: rowId,
      reckey: recKey
    }
    dispatch(Actions.deleteDeal(req));
    const newArrayList = [];
    const selectedArray = JSON.parse(JSON.stringify(selectedList));
    selectedArray &&
      selectedArray.length > 0 &&
      selectedArray.map((item) => {
        if (item?.refNo?.value !== rowId) {
          newArrayList.push(item);
        }
      });
    updateSelectedList(newArrayList);
  };

  const handleRowSelection = (selctedRow) => {
    const newArrayList = [];
    const selectedArray = JSON.parse(JSON.stringify(selectedList));
    selctedRow &&
      selctedRow.length > 0 &&
      selctedRow.map((item) => {
        rowList.map((rowItem) => {
          if (item?.refNo?.value == rowItem?.refNo?.value) {
            selectedArray?.map((selectedItem) => {
              if (selectedItem?.refNo?.value === rowItem?.refNo?.value) {
                rowItem.amountUtilised = selectedItem?.amountUtilised;
                rowItem.amountInr = selectedItem?.amountInr;
              }
            });
            newArrayList.push(rowItem);
          }
        });
      });
    updateSelectedList(newArrayList);
    checkIsDisabled(newArrayList);
  };

  const updateDrawerTableData = (val) => {
    // if there is search text entered, then call search API
    if (val !== "") {
      const req = {
        userId: authData.userId,
        corpId: authData.corpId,
        bankCode: authData.bankCode,
        dealId: val,
        apiflag: "PREE-BOOK",
        customerId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
      };
      dispatch(Actions.searchTextInDrawer(req));
    } else {
      // call get prebooked deals list
      getPreBookedDealsList();
    }
  };

  // changing the book button disable state based on
  // if selected list is empty, then disable book button
  // else if any of items selected has empty value for amountUtilized or amountInr, then disable book button, else enable book button
  const checkIsDisabled = (newList) => {
    let disabled = true;
    let emptyValueFound = false;
    let newSelectedArray = JSON.parse(JSON.stringify(newList));
    if (newSelectedArray?.length > 0) {
      newSelectedArray.map((item) => {
        if (
          item?.amountUtilised.value === "" ||
          item?.amountUtilised.value === 0 ||
          item?.amountInr.value === "" ||
          item?.amountInr.value === 0
        ) {
          emptyValueFound = true;
        }
      });
      if (emptyValueFound) {
        disabled = true;
      } else {
        disabled = false;
      }
    } else {
      disabled = true;
    }
    updateDisabled(disabled);
  };

  const resetAlert = () => {
    setshowAlert(true);
  };

  const onProceedCancel = () => {
    //@todo on proceed cancel actions
    props?.fetchPreBookAmount(0);
    updateSelectedList([]);
    setshowAlert(false);
    //Clearing data
    const tempRowList = [...rowList];
    tempRowList.map((rowItem) => {
      rowItem.amountUtilised = { value: "" };
      rowItem.amountInr = { value: "" };
    });
    updateRowList(tempRowList);
    updateRowValue(true);
    // updatePopupDisplay(false);
  };

  const preBook = () => {
    const list = [...selectedList];
    const req = [];
    list.forEach((item) => {
      req.push({
        fidbtxnId: recKey,
        dealId: item?.refNo?.value,
        utiliseAmount: item?.amountUtilised?.value,
        earmarkType: "utilies",
      });
    });
    dispatch(Actions.preBookEarMarking(req));
  };

  const book = () => {
    // API Call
    const tempSelList = [...selectedList];
    let preBookAmt = 0;
    const dealIds = tempSelList?.map((item) => {
      preBookAmt += item?.amountUtilised?.value
        ? parseInt(item?.amountUtilised?.value)
        : 0;
      return {
        dealId: item?.id?.value,
      };
    });
    props?.fetchPreBookAmount(preBookAmt);
    const req = {
      userId: userId,
      corpId: corpId,
      bankCode: bankCode,
      dealIds: dealIds,
    };
    dispatch(Actions.preBookDealBook(req));
    updatePopupDisplay(false);
  };

  useEffect(() => {
    if (state?.preBookEarMark) {
      let errMsg = "";
      state?.preBookEarMark.forEach((item) => {
        if (item.statusMsg !== "Success") {
          errMsg = item.statusMsg;
          return false;
        }
      });
      if (errMsg === "") {
        book();
      } else {
        setAlert({
          ...alert,
          alertMsg: errMsg,
          isAlertOpen: true,
        });
      }
    }
  }, [state?.preBookEarMark]);

  return (
    <>
      <div
        className={
          !props?.delegateChecker ? "simple-card" : "simple-card disabled"
        }
      >
        <>
          <div className="simple-card-header">
            <h5>Pre-Booked Deals</h5>
            <Button
              disabled={props?.delegateChecker}
              color={props?.delegateChecker ? "secondary" : "primary"}
              className="exlporeBtn"
              onClick={() => {
                updatePopupDisplay(true);
              }}
            >
              Explore
            </Button>
          </div>
        </>
        {/* @todo */}
        {selectedList && selectedList.length > 0 && (
          <>
            <AgGridTable
              headCells={[
                { field: "refNo", label: "Deal ID2" },
                { field: "currencyPair", label: "Currency Pair" },
                { field: "exchangeRate", label: "Exchange Rate" },
                { field: "validTill", label: "Valid Till" },
                { field: "osAmount", label: "O/S Amount" , rightAligned: true},
                {
                  field: "amountUtilised",
                  label: "Amount to be Utilised", 
                  rightAligned: true,
                  minWidth:230
                },
                {
                  field: "amountInr",
                  label: "Amount in  INR", 
                  rightAligned: true
                },
                { field: "", deleteButton: true, smallCell: true },
              ]}
              rows={selectedList}
              tableOnly={true}
              noRowSelection={true}
              handleRowDeletion={handleRowDeletion}
              onSort={(sortBy, desc) => {
                getSorted(sortBy, desc);
              }}
            />
          </>
        )}
        <BottomDrawer
          title="Pre-Booked Deals"
          disabledPrimary={isDisabled}
          isSearchable={true}
          showDrawer={showPopup}
          toggleDrawer={(flag) => {
            if (selectedList?.length === 0) {
              props?.fetchPreBookAmount(0);
            }
            if (flag) updatePopupDisplay(false);
          }}
          showFooterButtons={true}
          secondaryAction="Reset"
          resetAction={() => {
            resetAlert();
          }}
          onSearchTextChange={(e) => {
            updateDrawerTableData(e.target.value);
          }}
          primaryAction="Utilize"
          primaryActionMethod={() => {
            preBook();
          }}
          middleComponent={
            <div className="green-container">
              <div>
                <span>Remittance from Operative</span>
                <span>Account</span>
                <span>{`${currency} ${props?.totalRemittance}`}</span>
              </div>
              <div className="mh-36">
                <span>Amount Utilised from</span>
                <span>Pre-booked Deals</span>
                <span>{`${currency} ${prebookAmount}`}</span>
              </div>
              <div>
                <span>Pending Payment Instruction</span>
                <span>{`${currency} ${props?.balanceRemittanceAmount}`}</span>
              </div>
            </div>
          }
        >
          <div className="bottom-drawer-box">
            <AgGridTable
              selectedList={[...selectedList]}
              headCells={headCells}
              rows={rowList}
              tableOnly={true}
              handleRowSelection={handleRowSelection}
              reloadTableRows={rowValueChanged}
              onSort={(sortBy, desc) => {
                getSorted(sortBy, desc);
              }}
            />
            {toastState?.showToast && (
              <AlertPopup
                alertMsg={toastState?.toastMessage}
                alertType={toastState?.toastType}
                isAlertOpen={toastState?.showToast}
                onClose={() => {
                  updateToastState({
                    toastMessage: "",
                    toastType: "",
                    showToast: false,
                  });
                }}
              />
            )}
          </div>
        </BottomDrawer>
      </div>
      {
        <AlertDialog
          show={showAlert}
          onClose={() => setshowAlert(false)}
          onAction={onProceedCancel}
          actionButtonLabel={"Yes"}
          title={"Are you sure you want to Reset?"}
          content={"Reseting will remove all entered data."}
        />
      }
    </>
  );
};
export default PreBookedDeals;
