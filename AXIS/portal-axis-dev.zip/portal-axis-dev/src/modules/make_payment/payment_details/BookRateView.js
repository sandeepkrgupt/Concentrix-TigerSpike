/* eslint-disable */
import React, { useEffect, useState } from "react";
import useStyles from "../../../components/customtable/TableStyle";
import { makeStyles } from "@material-ui/core/styles";
import CustomTableHead from "../../../components/customtable/CustomTableHead";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableRow from "@material-ui/core/TableRow";

import Edit from "../../../assets/icons/edit-white.svg";
import {
  Button,
  Dropdown,
  TextField,
  Card,
} from "../../../components/@subzero/glacier/package/lib/components";
import { Checkbox, Divider, Grid } from "@material-ui/core";
import InfoIcon from "../../../assets/icons/info-icon.svg";
import BottomDrawer from "../../../components/bottomdrawer";
import RefreshIcon from "../../../assets/icons/refresh.svg";
import styles from "../review/review.module.css";
import CheckBox from "@material-ui/icons/CheckBox";
import { useSelector } from "react-redux";

const bookRateStyles = makeStyles({
  root: {
    inputRoot: {
      "&Disabled": {
        background: "blue !important",

        "& > *": {
          background: "blue !important",
        },
      },
    },
  },

  disabled: {},
});

const BookRateView = (props) => {
  const myClasses = bookRateStyles();
  const classes = useStyles();

  const currency = useSelector((state) => state?.transactionDetails?.currency);

  return (
    <>
      <div
        className={
          !props?.delegateChecker
            ? "simple-card eefc-box ml-0"
            : "simple-card eefc-box disabled ml-0"
        }
      >
        <div className="simple-card-header d-flex justify-space book-rate-header">
          <h5>Book Rate Online</h5>
          {/* Rate not delegated to checker -- > Greater than 10 lakhs Book Rate Online “Not booked” start */}
          {props?.userType === "C" && (
            <Button classes={{ root: styles.bookRateButton }}>Book Rate</Button>
          )}

          {/* Rate not delegated to checker -- > Greater than 10 lakhs Book Rate Online “Not booked” end */}
        </div>
        <div className="simple-card-body book-rate-body body-container book-fx-rate-container">
          <div className="error-box">
            <img src={InfoIcon} />
            <span>
              Amount that is not allocated to the other modes of conversion will
              automatically be channeled to online FX Rate Booking.
            </span>
          </div>
          <Grid
            container
            spacing={3}
            className={styles.bookRateGreyContainer}
            // className="mx-0"
          >
            {props?.instructionDetails?.length > 0 &&
              props?.instructionDetails?.map((item) => (
                <>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    sm={5}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Amount to be utilized
                    </span>
                    <span className="grid-content-text">
                      {`${item?.currencyPair || currency}` + " " + item?.amountToBeUtilized}{" "}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={3}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Debit Amount (Indicative)
                    </span>
                    <span className="grid-content-text">
                      INR {item?.amountInInr}
                    </span>
                  </Grid>
                </>
              ))}
          </Grid>
        </div>
      </div>
    </>
  );
};
export default BookRateView;
