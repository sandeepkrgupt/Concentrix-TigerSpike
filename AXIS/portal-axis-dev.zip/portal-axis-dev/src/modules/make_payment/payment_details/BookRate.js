/* eslint-disable */
import React, { useEffect, useState } from "react";
import useStyles from "../../../components/customtable/TableStyle";
import { makeStyles } from "@material-ui/core/styles";
import CustomTableHead from "../../../components/customtable/CustomTableHead";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableRow from "@material-ui/core/TableRow";
import {
  Button,
  Dropdown,
  TextField,
  Card,
} from "../../../components/@subzero/glacier/package/lib/components";
import { Divider, Grid } from "@material-ui/core";
import Info from "../../../assets/icons/info.svg";
import BottomDrawer from "../../../components/bottomdrawer";
import RefreshIcon from "../../../assets/icons/refresh.svg";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";

const bookRateStyles = makeStyles({
  // inputItem:{
  //   backgroundColor:"red !important",
  //   '&$disabled': {
  //     background: 'blue !important'
  //   },
  //     //   '& .MuiTextField-root':{
  //     //     background: 'blue !important'
  //     // }
  //   },
  root: {
    inputRoot: {
      "&Disabled": {
        background: "blue !important",

        "& > *": {
          background: "blue !important",
        },
      },
    },
  },
  //   '&.TextField_inputRootDisabled': {
  //     background: 'blue !important',
  //   },
  //   background: 'blue !important',
  //   // '&$disabled': {
  //   //   background: 'blue !important'
  //   // },
  //  },
  disabled: {},
  // TextField_inputRootDisabled: {}
});

// const bookRateStyles = makeStyles({
//   inputItem:{
//     '& .MuiTextField-root':{
//       background: 'blue !important'
//   }}

// });

const headCells = [
  {
    id: "tridbNumber",
    numeric: false,
    disablePadding: false,
    label: "TR ID Number ",
  },
  {
    id: "bookingDate",
    numeric: false,
    disablePadding: false,
    label: "Booking Date",
  },
  {
    id: "vallidTill",
    numeric: false,
    disablePadding: false,
    label: "Valid Till",
  },
  { id: "rateType", numeric: false, disablePadding: false, label: "Type" },
  {
    id: "exchangeRate",
    numeric: false,
    disablePadding: false,
    label: "Exchange Rate",
  },
  {
    id: "sellUsd",
    numeric: false,
    disablePadding: false,
    label: "Amount to be Utilised",
  },
  {
    id: "buyInr",
    numeric: false,
    disablePadding: false,
    label: "Credit Amount ",
  },
];

function createData(
  tridbNumber,
  bookingDate,
  vallidTill,
  rateType,
  exchangeRate,
  sellUsd,
  buyInr
) {
  return {
    tridbNumber,
    bookingDate,
    vallidTill,
    rateType,
    exchangeRate,
    sellUsd,
    buyInr,
  };
}

const BookRate = (props) => {
  const myClasses = bookRateStyles();
  const classes = useStyles();
  const [order, setOrder] = React.useState("asc");
  const [orderBy, setOrderBy] = React.useState("calories");
  const [rows, updateRows] = React.useState([]);
  const [selectedList, updateSelectedList] = useState(false);
  const [popupDisplay, updatePopupDisplay] = useState(false);
  const dispatch = useDispatch();
  const authData = JSON.parse(localStorage.getItem("authData"));
  const state = useSelector((state) => state?.payment);
  const currency = useSelector((state) => state?.transactionDetails.currency);
  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const paymentReviewData = useSelector((state) => state?.paymentReviewData);
  const [debitAmount, setDebitAmount] = useState(0);
  const { userRoleType } = authData;
  const [balanceAmt, setBalanceAmt] = useState(props?.balanceRemittanceAmount);
  const [alertStatus, setAlertStatus] = useState(false);
  const [alertMessage, setAlertMessage] = useState(null);

  // useEffect(() => {
  //   console.log("helloooo")
  //   console.log(paymentReviewData);
  //   console.log(props);
  //   if (
  //     props?.utilizedAmount &&
  //     props?.amountInInr &&
  //     paymentReviewData?.fxRateResponse === null
  //   ) {
  //     console.log("Calling getFxRateMarginValidation");
  //     console.log(props?.amountInInr);
  //     console.log(props?.utilizedAmount);
  //     let req = {
  //       userId: authData?.userId,
  //       corpId: authData?.corpId,
  //       currency: "USD",
  //       fidbtxnId: props?.fidbtxnId,
  //       amount: props?.amountInInr,
  //       subCustId: authData?.subcustId,
  //       utilizationAmount: props?.utilizedAmount,
  //     };

  //     dispatch(Actions.getFxRateMarginValidation(req));
  //   }
  // }, []);

  useEffect(() => {
    if (
      props?.utilizedAmount &&
      Math.round(state?.inrAmount * 100) / 100 &&
      paymentReviewData?.fxRateResponse === null
    ) {
      let req = {
        userId: authData?.userId,
        corpId: authData?.corpId,
        currency: "USD",
        fidbtxnId: props?.fidbtxnId,
        amount: props?.amountInInr,
        subCustId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
        utilizationAmount: props?.utilizedAmount,
      };

      dispatch(Actions.getFxRateMarginValidation(req));
    }
  }, [paymentReviewData]);

  useEffect(() => {
    // if fxRateStatus !== null and fxRateStatus !== "SUCCESS", then display alert message
    if (
      paymentReviewData?.fxRateStatus !== null &&
      paymentReviewData?.fxRateStatus !== "SUCCESS"
    ) {
      setAlertMessage(paymentReviewData?.fxRateStatus);
      setAlertStatus(true);
      setTimeout(() => {
        setAlertStatus(false);
      }, 3000);
    }
  }, [paymentReviewData?.fxRateStatus]);

  const handleRequestSort = (event, property) => {
    const isAsc = orderBy === property && order === "asc";
    setOrder(isAsc ? "desc" : "asc");
    setOrderBy(property);
  };

  const bookFxRate = () => {
    const req = {
      userId: authData?.userId,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      fidbtxnId: props?.fidbtxnId,
      fxRateMessageId: props?.fxRateMessageId,
      exchangeRate: props?.displayRate,
      remmitanceAmount: props?.remmitanceAmount,
      utilizedAmount: props?.utilizedAmount,
      fidbMargin: props?.fidbMargin,
      branchCode: authData?.branchCode,
      currency,
      fxRateResponse: props?.fxRateResponse,
    };
    dispatch(Actions.bookFxRate(req));
  };

  const convertCurrency = (amt) => {
    const req = {
      currencyTyp: paymentReviewData?.paymentDetails?.currency,
      amount: amt,
      baseCurrency: "INR",
      bankCode: authData?.bankCode,
    };
    dispatch(Actions.currencyConvert(req));
  };

  useEffect(() => {
    setBalanceAmt(props?.balanceRemittanceAmount);
    const req = {
      fxAmountUtilized: props?.balanceRemittanceAmount,
    };
    dispatch(Actions.updateFxAmountUtilized(req));
  }, [props?.balanceRemittanceAmount]);

  useEffect(() => {
    if (props?.fxRateAmount) {
      convertCurrency(props?.fxRateAmount);
    }
  }, [paymentReviewData?.cardRate]);

  // calling currency converter for maker
  useEffect(() => {
    if (props?.balanceRemittanceAmount && paymentReviewData?.cardRate) {
      convertCurrency(props?.balanceRemittanceAmount);
    }
  }, []);

  useEffect(() => {
    console.log(state?.inrAmount);
    setDebitAmount(state?.inrAmount);
    const req = {
      fcCreditAmount: state?.inrAmount,
    };
    dispatch(Actions.updateFcCreditAmount(req));
  }, [state?.inrAmount]);

  const onCloseAlertPopup = () => {
    setAlertStatus(false);
  };

  return (
    <>
      <div
        className={
          !props?.delegateChecker
            ? "simple-card eefc-box"
            : "simple-card eefc-box disabled"
        }
        style={{ marginLeft: 0, marginRight: 0 }}
      >
        <div className="simple-card-header d-flex mtb-6 justify-space pb-6">
          <h5>Book Rate Online</h5>

          {/* show Book Rate button only if following condition matches 
          1. userRoleType = 'C' and
          2. Book Fx rate is not clicked already and (tridNumber === null) and
          3. statusCode's last number portion is equal to logged  in user checker count  and
          4. paymentMode !== 'EEFC only' and
          5. fxRateAmount > 0
          */}
          {userRoleType === "C" &&
            props?.tridbNumber === null &&
            props?.fxRateAmount > 0 &&
            props?.paymentMode !== "EEFC Account" &&
            props?.statusCode?.slice(0, 7) === "PRE_ACC" &&
            props?.statusCode?.slice(7) ===
              authData?.checkerCount?.toString() && (
              <Button
                // disabled={props?.fxRateStatus !== "SUCCESS"}
                disabled={props?.authorizeDisable}
                color="primary"
                onClick={() => {
                  updatePopupDisplay(true);
                }}
              >
                {" "}
                Book Rate{" "}
              </Button>
            )}
        </div>

        {/* <div className="simple-card-body body-container book-fx-rate-container">
          <div className="error-box">
            <img src={InfoIcon} />
            <span>
              Amount that is not allocated to other modes of conversion will
              automatically be channeled to online FX Rate Booking, which will
              be the final step before proceeding.
            </span>
          </div>
          <Grid container spacing={3}>
            <Grid
              item
              lg={4}
              md={4}
              sm={12}
              xs={12}
              className="purpose-data-column"
            >
              <TextField
                fullWidth
                disabled={userRoleType === "C" ? true : false}
                label="Amount to be utilized"
                adornmentStart={currency}
                value={balanceAmt}
                type="text"
                variant="filled"
                onChange={(e) => {
                  setBalanceAmt(e?.target?.value);
                }}
              />
            </Grid>
          </Grid>
        </div> */}

        {userRoleType === "C" && <Divider className="review-divider" />}

        {userRoleType === "C" && props?.tridbNumber !== null ? (
          <>
            <div className="simple-card-body body-container book-fx-rate-container">
              <Grid container spacing={3} justifyContent="flex-start">
                <Grid
                  className="review-grid-container"
                  item
                  lg={2}
                  md={3}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">TR ID Number </span>
                  <span className="grid-content-text">
                    {props?.tridbNumber}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={2}
                  md={5}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Booking Date</span>
                  <span className="grid-content-text">
                    {new Date().toLocaleDateString("en-GB")}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={2}
                  md={5}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Type</span>
                  <span className="grid-content-text">Spot</span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={2}
                  md={5}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Exchange Rate</span>
                  <span className="grid-content-text">
                    {props?.displayRate}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={2}
                  md={5}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Buy</span>
                  <span className="grid-content-text">
                    USD {props?.utilizedAmount}
                  </span>
                </Grid>
                <Grid
                  className="review-grid-container"
                  item
                  lg={2}
                  md={5}
                  sm={6}
                  xs={6}
                >
                  <span className="grid-content-header">Sell</span>
                  <span className="grid-content-text">
                    INR {props?.convertedAmount}
                  </span>
                </Grid>
              </Grid>
            </div>
          </>
        ) : (
          <>
            <div className="error-box">
              <div>
                <img src={Info} />
              </div>
              <span>
                Amount that is not allocated to other modes of conversion will
                automatically be channeled to online FX Rate Booking, which will
                be the final step before proceeding.
              </span>
            </div>
            {userRoleType === "M" && (
              <div className="book-rate-amount-container">
                <Grid container>
                  <Grid
                    item
                    lg={4}
                    md={4}
                    sm={6}
                    xs={6}
                    className="book-rate-amount-item"
                  >
                    <span className="label">Amount to be utilized</span>
                    <span className="value">
                      USD {props?.balanceRemittanceAmount}
                    </span>
                  </Grid>
                  <Grid
                    item
                    lg={4}
                    md={4}
                    sm={6}
                    xs={6}
                    className="book-rate-amount-item"
                  >
                    <span className="label">Debit Amount (Indicative)</span>
                    <span className="value">
                      INR {Math.round(debitAmount * 100) / 100}
                    </span>
                  </Grid>
                </Grid>
              </div>
            )}
            {userRoleType === "C" && props?.tridbNumber === null && (
              <div className="simple-card-body body-container book-fx-rate-container">
                <Grid container spacing={3} justifyContent="flex-start">
                  <Grid
                    className="review-grid-container"
                    item
                    lg={2}
                    md={3}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Amount to be utilized{" "}
                    </span>
                    <span className="grid-content-text">
                      USD {props?.fxRateAmount}
                      {/* needs to verify with seeni */}
                    </span>
                  </Grid>
                  <Grid
                    className="review-grid-container"
                    item
                    lg={5}
                    md={5}
                    sm={6}
                    xs={6}
                  >
                    <span className="grid-content-header">
                      Debit Amount (Indicative)
                    </span>
                    <span className="grid-content-text">
                      INR {Math.round(state?.inrAmount * 100) / 100}
                      {/* INR {props?.fxRateAmount * props?.displayRate} */}
                      {/* needs to verify with seeni */}
                    </span>
                  </Grid>
                </Grid>
              </div>
            )}
          </>
        )}

        <BottomDrawer
          showDrawer={popupDisplay}
          toggleDrawer={() => {
            updatePopupDisplay(false);
            // updateSelectedList(true);
          }}
          showFooterButtons={true}
          secondaryAction="Cancel"
          primaryAction="Submit"
          primaryActionMethod={() => bookFxRate()}
          handlePrimaryAction={() => {
            updateSelectedList(true);
          }}
          resetAction={() => {
            updatePopupDisplay(false);
          }}
        >
          <>
            <div className="simple-card eefc-box container-margin">
              <div className="book-fx-rate-heding">
                <p>Buy USD/INR</p>
                <div className="d-flex">
                  <span>Time to refresh</span>
                  <div className="refresh-time-span">
                    <div>Time to refresh</div>
                    10 Sec
                  </div>
                </div>
              </div>
            </div>
            <div className="simple-card eefc-box small-box-container">
              <div className="book-rate-header">
                <p>Booking Details</p>
                <div className="d-flex">
                  <span className="net-rate-web">Net Rate</span>
                  <div className="book-rate">
                    {/* <span className="net-rate">Net Rate</span> */}
                    <span>
                      {props?.displayRate ? props?.displayRate : 1}
                    </span>{" "}
                    {/* // dummy for handling api no data scenario */}
                    <div className="book-rate-image">
                      <img src={RefreshIcon} />
                    </div>
                  </div>
                </div>
              </div>
              <Grid container spacing={3} className="accont-details">
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  {/* <Datepicker
                                    variant="filled"
                                    label="Datepicker"
                                    placeholder="15/05/2021" /> */}
                  <TextField
                    type="text"
                    variant="filled"
                    value={new Date().toLocaleDateString("en-GB")}
                    label="Date"
                    disabled
                    classes={{ root: myClasses.root }}
                  />
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <Dropdown
                    defaultValue="SPOT"
                    items={["SPOT"]}
                    label="Type"
                    type="text"
                    variant="filled"
                  />
                </Grid>
              </Grid>
              <Grid container spacing={3} className="accont-details">
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <TextField
                    type="text"
                    variant="filled"
                    adornmentStart="USD"
                    value={
                      props?.instructionDetails?.[0]?.amountToBeUtilized
                        ? props?.instructionDetails?.[0]?.amountToBeUtilized
                        : 1000
                    } // dummy for handling api no data scenario
                    label="Buy"
                    disabled
                  />
                </Grid>
                <Grid item lg={6} md={6} sm={6} xs={12}>
                  <TextField
                    type="text"
                    variant="filled"
                    adornmentStart="INR"
                    value={
                      props?.instructionDetails?.[0]?.amountToBeUtilized
                        ? props?.instructionDetails?.[0]?.amountToBeUtilized *
                          (props?.displayRate ? props?.displayRate : 1)
                        : 1000
                    } // dummy for handling api no data scenario
                    label="Sell"
                    disabled
                  />
                </Grid>
              </Grid>
            </div>

            {/* after calling getFxRateMarginValidation , show alert based on status received in response*/}
            {alertStatus && (
              <AlertPopup
                alertMsg={alertMessage}
                alertType={"warn"}
                isAlertOpen={true}
                onClose={onCloseAlertPopup}
              />
            )}
          </>
        </BottomDrawer>

        {/* this only required for Review screen */}
        {selectedList &&
          // <div className="book-fx-rate">
          {
            /* <div className="book-fx-rate-container">
              <Grid container>
                <Grid item xs={6} sm={4} lg={2} className="mg-btm-10">
                  <div className="colmn-title">TR ID Number</div>
                  <div className="colmn-value">212312312313</div>
                </Grid>
                <Grid item xs={6} sm={4} lg={2} className="mg-btm-10">
                  <div className="colmn-title">Booking Date</div>
                  <div className="colmn-value">20/01/2021</div>
                </Grid>

                <Grid item xs={6} sm={4} lg={2} className="mg-btm-10">
                  <div className="colmn-title">Type</div>
                  <div className="colmn-value">Spot</div>
                </Grid>
                <Grid item xs={6} sm={4} lg={2} className="mg-btm-10">
                  <div className="colmn-title">Exchange Rate</div>
                  <div className="colmn-value">72.56</div>
                </Grid>
                <Grid item xs={6} sm={4} lg={2} className="mg-btm-10">
                  <div className="colmn-title">Buy</div>
                  <div className="colmn-value">USD 38,000 </div>
                </Grid>
                <Grid item xs={6} sm={4} lg={2} className="mg-btm-10">
                  <div className="colmn-title">Sell</div>
                  <div className="colmn-value">INR 38,000</div>
                </Grid>
              </Grid>
            </div> */
            /* Mobile view section */
            /* <div className="table-view-small">
              {rows.slice(0, 1).map((row, index) => {
                return (
                  <Card
                    key={index}
                    style={{ width: "100%", marginTop: "20px" }}
                  >
                    <div className="table-row-container">
                      <Grid container>
                        <Grid item lg={6} xs={6} sm={4} className="mg-btm-10">
                          <div className="colmn-title">TR ID Number</div>
                          <div className="colmn-value">{row.tridbNumber}</div>
                        </Grid>
                        <Grid item lg={2} xs={6} sm={4} className="mg-btm-10">
                          <div className="colmn-title">Booking Date</div>
                          <div className="colmn-value">{row.bookingDate}</div>
                        </Grid>

                        <Grid item lg={2} xs={6} sm={4} className="mg-btm-10">
                          <div className="colmn-title">Valid Till</div>
                          <div className="colmn-value">{row.vallidTill}</div>
                        </Grid>
                        <Grid item lg={2} xs={6} sm={4} className="mg-btm-10">
                          <div className="colmn-title">Type</div>
                          <div className="colmn-value">{row.rateType}</div>
                        </Grid>
                        <Grid item lg={2} xs={6} sm={4} className="mg-btm-10">
                          <div className="colmn-title">Exchange Rate</div>
                          <div className="colmn-value">{row.exchangeRate}</div>
                        </Grid>
                        <Grid item lg={2} xs={6} sm={4} className="mg-btm-10">
                          <div className="colmn-title">
                            Amount to be Utilised
                          </div>
                          <div className="colmn-value">INR {row.sellUsd}</div>
                        </Grid>
                        <Grid item lg={2} xs={6} sm={4} className="mg-btm-10">
                          <div className="colmn-title">Credit Amount</div>
                          <div className="colmn-value">INR {row.buyInr}</div>
                        </Grid>
                      </Grid>
                    </div>
                  </Card>
                );
              })}
            </div> */
            /* </div> */
          }}
      </div>
    </>
  );
};
export default BookRate;
