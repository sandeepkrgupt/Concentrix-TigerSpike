/* eslint-disable  */

import React, { useState, useEffect } from "react";
import {
  Dropdown,
  TextField
} from "../../../components/@subzero/glacier/package/lib/components";
import Customdropdown from "../../../components/customdropdown";
import { Divider, Grid } from "@material-ui/core";
import RemoveIcon from "../../../assets/icons/remove-icon.svg";
import AddIcon from "../../../assets/icons/add.svg";
import { Actions } from "../../../store/rootActions";
import { useDispatch, useSelector } from "react-redux";
import AlertPopup from "../../../components/alertPopup/alertPopup";



const delayReasons = [
  {
    delay_reason: "",
    boe_no: [],
    other_reason: ""
  }
];

const BillofEntryDelayReasons = (props) => {
  const [delayReasonsList, setdelayReasonsList] = useState(props?.data);
  const [selectedBOEIndex, setSelectedBOEIndex] = useState(null);
  const dispatch = useDispatch();
  const authData = JSON.parse(localStorage.getItem("authData"));
  const { userId, corpId, bankCode } = authData;
  const state = useSelector((state) => state?.payment);
  const transactionDetails = useSelector((state) => state?.transactionDetails);
  const paperless = authData?.docUploadWaiver === "Paperless" ? true : false;
  const [alert, setAlert] = useState({
        alertMsg: "Fill out the mandatory fields",
        alertType: "warn",
        isAlertOpen: false,
  });
    
    const [fieldsToBeValidated, setFieldsToBeValidated] = useState({
        boe_no: [
            {
                mandatoryOnPaperless: true,
                mandatoryOnFastProcessing: true,
                mandatoryOnStandardProcessing: true,
                mandatoryBasedOnCondition: "transactionDetails.goodsType  != 'CAPITAL' ",
                validationFailed: false,
            }
        ],
        delay_reason: [
            {
                mandatoryOnPaperless: true,
                mandatoryOnFastProcessing: true,
                mandatoryOnStandardProcessing: true,
                mandatoryBasedOnCondition: "transactionDetails.goodsType  != 'CAPITAL' ",
                validationFailed: false,
            }
        ]
    });

  useEffect(() => {
    // BOE numbers API
    getBOENumbers();
    // Delay Reasons API
    getDelayReasons();
  }, []);

    useEffect(() => {
        if (
            props?.proceedClickInfo?.proceedClick) {
            if (validatePaymentDetailsFields()) {
                props?.isBilldataValid(true);
                // props.onSuccessValidation();
            } else {
                setAlert({
                    ...alert,
                    isAlertOpen: true,
                });
                props?.isBilldataValid(false);
            }
        }
    }, [props?.proceedClickInfo]);


    const validatePaymentDetailsFields = () => {
        let validationStatus = true;
        const filteredFields = Object.keys(fieldsToBeValidated)?.filter(item => {
            let includeField = false;
            if (paperless) {
                includeField = fieldsToBeValidated[item][0].mandatoryOnPaperless;
            }
            //else {            //    if (fastProcessing) {
            //        includeField = fieldsToBeValidated[item].mandatoryOnFastProcessing;
            //    } else {
            //        includeField = fieldsToBeValidated[item].mandatoryOnStandardProcessing;
            //    }
            //}
            if (includeField) {
                    if (fieldsToBeValidated[item][0].mandatoryBasedOnCondition !== "") {
                        includeField = eval(fieldsToBeValidated[item][0].mandatoryBasedOnCondition);
                    }
            }
            return includeField;
        });

        filteredFields.forEach((item) => {
            if (Array.isArray(delayReasonsList)) {
                const newChange = { ...fieldsToBeValidated }
                delayReasonsList.map((itemVal, index) => {
                    if (item === "boe_no") {
                        if (itemVal[item].length === 0 ) {
                            newChange[item][index].validationFailed = true;
                            validationStatus = false;
                        }
                    }
                    if (!itemVal[item]) {
                        newChange[item][index].validationFailed = true;
                        validationStatus = false;
                    }
                });
                setFieldsToBeValidated(newChange);
            }
        });
        return validationStatus;
    }

  const getBOENumbers = () => {
    const req = {
      userId: userId,
      corpId: corpId,
      bankCode: bankCode,
      fidbTNXPk: transactionDetails?.recKey
    };
    dispatch(Actions.boeNumbers(req));
  };

  const getDelayReasons = () => {
    const req = {
      userId: userId,
      corpId: corpId,
      bankCode: bankCode
    };
    dispatch(Actions.delayReasons(req));
  };

  // add new delay reason form set
  const addDelayReason = () => {
    const newList = [
      ...delayReasonsList,
      { delay_reason: "", boe_no: [], other_reason: "" }
    ];
      setdelayReasonsList(newList);
      adddelayFieldvalidation();
    };


    const adddelayFieldvalidation = () => {
        const newValue = { ...fieldsToBeValidated };
        newValue.boe_no = [
            ...newValue.boe_no,
            {
                mandatoryOnPaperless: true,
                mandatoryOnFastProcessing: true,
                mandatoryOnStandardProcessing: true,
                mandatoryBasedOnCondition: "transactionDetails.goodsType  != 'CAPITAL' ",
                validationFailed: false,
            }
        ];
        newValue.delay_reason = [
            ...newValue.delay_reason,
            {
                mandatoryOnPaperless: true,
                mandatoryOnFastProcessing: true,
                mandatoryOnStandardProcessing: true,
                mandatoryBasedOnCondition: "transactionDetails.goodsType  != 'CAPITAL' ",
                validationFailed: false,
            }
        ];
        setFieldsToBeValidated(newValue);
    }

  // remove delay reason by index
  const removeDelayReason = (reasonIndex) => {
    const newList = [...delayReasonsList];
    newList.splice(reasonIndex, 1);
    setdelayReasonsList(newList);

    const newValue = { ...fieldsToBeValidated };
    newValue.boe_no.splice(reasonIndex, 1);
    newValue.delay_reason.splice(reasonIndex, 1);
    setFieldsToBeValidated(newValue);
  };

  const isDelayReasonAPI = (boeNo) => {
    const req = {
        "userId": userId, 
        "corpId": corpId, 
        "bankCode": bankCode, 
        "fidbTNXPk": transactionDetails?.recKey,
        "boeNumber":boeNo 
    }
    dispatch(Actions.isDelayReasonAllowed(req))
  }

  useEffect(() => {
    const newArr = delayReasonsList.map((item, index) => {
      if (selectedBOEIndex === index) {
        item.showDelay = state?.isDelayReason;
        return item;
      } else {
        return item;
      }
    });
    setdelayReasonsList(newArr);
  }, [state?.isDelayReason]);

  useEffect(() => {
    props?.fetchBOEDelayReasons(delayReasonsList);
  }, [delayReasonsList]);

  // on boe delay reason - boe field change
  const updateBoeNo = (value, reasonIndex) => {
    setSelectedBOEIndex(reasonIndex);
    if (value?.length === 1) {
      isDelayReasonAPI(value[0]?.id);
    }
    const newArr = delayReasonsList.map((item, index) => {
      if (reasonIndex === index) {
        item.boe_no = value;
        return item;
      } else {
        return item;
      }
    });
      setdelayReasonsList(newArr);
      const newValue = { ...fieldsToBeValidated };
      if (value != '') {
          newValue.boe_no[reasonIndex].validationFailed = false;
      }
      setFieldsToBeValidated(newValue);
  };

  const updateDelayReason = (value, reasonIndex) => {
    const newArr = delayReasonsList.map((item, index) => {
      if (reasonIndex === index) {
        item.delay_reason = value;
        return item;
      } else {
        return item;
      }
    });
      setdelayReasonsList(newArr);
      const newValue = { ...fieldsToBeValidated };
      if (value != '') {
          newValue.delay_reason[reasonIndex].validationFailed = false;
      }
      setFieldsToBeValidated(newValue);
  };

  const updateOtherReason = (e, reasonIndex) => {
    const newArr = delayReasonsList.map((item, index) => {
      if (reasonIndex === index) {
        item.other_reason = e?.target?.value;
        return item;
      } else {
        return item;
      }
    });
    setdelayReasonsList(newArr);
  };

  return (
      <div className="border-container bill-entry-container ">
          <AlertPopup
              {...alert}
              onClose={() => {
                  setAlert({ ...alert, isAlertOpen: false });
              }}
          />
      <span className="details-heading d-flex mb-24">
        Bill Of Entry - Delay Reasons{" "}
      </span>

      {delayReasonsList.map((item, index) => {
        return (
          <Grid spacing={3} container key={index}>
            <Grid
              className="sub-detail-container full-width-textField fullWidthDropDown"
              item
              lg={3}
              md={3}
              sm={6}
              xs={12}
            >
              {/* <Dropdown
                label={"Bill of Entry Number"}
                items={state?.boeNumbers}
                variant="filled"
                fullWidth
                name="Bill of Entry Number"
                defaultValue={item.boe_no}
                value={item.boe_no}
                onChange={(e) => updateBoeNo(e, index)}
              /> */}
              <div className="custom-dropdown">
                <Customdropdown
                  name="Bill Of Entry Number"
                  isMulti={true}
                  nonFilter={true}
                  onSelectOptions={(selOptions) => {
                    updateBoeNo(selOptions, index);
                  }}
                  options={state?.boeNumbers}
                  error={fieldsToBeValidated?.boe_no[index]?.validationFailed}
                  errorText={"Mandatory Field"}
                  selectedOptions={Array.isArray(item?.boe_no) ? item?.boe_no : []}
                />
              </div>
            </Grid>
            {item?.showDelay && (
              <Grid
                className="sub-detail-containremoveDelayReasoner full-width-textField fullWidthDropDown"
                item
                lg={3}
                md={3}
                sm={6}
                xs={12}
              >
              <Dropdown
                label={"Delay Reason"}
                items={state?.delayReasons?.map((v) => v.label)}
                variant="filled"
                fullWidth
                name="Delay Reason"
                defaultValue={item.delay_reason}
                value={item.delay_reason}
                onChange={(e) => updateDelayReason(e, index)}
                error={fieldsToBeValidated?.delay_reason[index]?.validationFailed}
                errorMsg={"Mandatory Field"}
              />
                {/* <div className="custom-dropdown">
                  <Customdropdown
                    name="Delay Reason"
                    isMulti={true}
                    nonFilter={true}
                    onSelectOptions={(selOptions) => {
                      updateDelayReason(selOptions, index);
                    }}
                    options={state?.delayReasons}
                    selectedOptions={item?.delay_reason}
                  />
                </div> */}
              </Grid>
            )}
            {/* {item.delay_reason?.some((e) => e.label === "Others") && ( */}
            {item.delay_reason === "Others" && (
              <Grid
                className="sub-detail-container large-text-box full-width-box full-width-textField"
                item
                lg={5}
                md={4}
                sm={12}
                xs={12}
              >
                <TextField
                  label={"Specify Other Reason"}
                  variant="filled"
                  fullWidth
                  name="Specify Other Reason"
                  value={item.other_reason}
                  onChange={(e) => updateOtherReason(e, index)}
                />
              </Grid>
            )}
            <Grid
              className="sub-detail-container jc-c"
              item
              lg={1}
              md={1}
              sm={12}
              xs={12}
            >
              <div
                className="remove-text"
                onClick={() => removeDelayReason(index)}
              >
                <img src={RemoveIcon} />
                Remove
              </div>
            </Grid>
            <Grid item className="wd-none" sm={12} xs={12}>
              <Divider />
            </Grid>
          </Grid>
        );
      })}

      <Grid container>
        <Grid item>
          <div
            className="add-account-text .mt-0"
            onClick={() => addDelayReason()}
          >
            <img src={AddIcon} />
            ADD delay reason
          </div>
        </Grid>
      </Grid>
    </div>
  );
};

export default BillofEntryDelayReasons;
