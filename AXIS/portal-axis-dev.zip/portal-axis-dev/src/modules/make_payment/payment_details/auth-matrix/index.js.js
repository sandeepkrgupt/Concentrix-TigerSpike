/* eslint-disable*/
import React, { useEffect, useState, useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import { useDispatch, useSelector } from "react-redux";
import Drawer from "@material-ui/core/Drawer";
import { Grid } from "@material-ui/core";
import CloseIcon from "../../../../assets/icons/close.svg";
import { useHistory, useLocation } from "react-router-dom";
import {
  Button,
  Dropdown,
  RadioList,
  TextField,
} from "../../../../components/@subzero/glacier/package/lib/components";
import { Actions } from "../../../../store/rootActions";
import "./index.css";
import Loader from "../../../../components/loader";

const useStyles = makeStyles({
  root: {
    background: "#F9F9F9",
    borderRadius: "8px",
    marginTop: "16px",
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
  dropdown: {
    "& .Dropdown_show__21pcz": {
      position: "absolute",
      zIndex: "999",
    },
  },
});

const AuthMatrix = () => {
  const history = useHistory();
  const classes = useStyles();
  const location = useLocation();
  const dispatch = useDispatch();
  const [prevPage, setPrevPage] = useState(location?.state?.from);
  const [prevPageAction, setPrevPageAction] = useState(location?.state);
  const [recKeyFromPrev, setRecKeyFromPrev] = useState(location?.state?.recKey);
  const state = useSelector((state) => state?.paymentReviewData);
  const authData = useSelector((state) => state?.auth?.loginData);
  const transactionDetails = useSelector((state) => state?.transactionDetails);

  const [loader, setLoader] = useState(false);
  const [openModal, setOPenModal] = React.useState(true);
  const [viewDetails, setViewDetails] = React.useState(true);
  const [maker_sequence, setMakerSequence] = React.useState(false);
  const [checker_sequence, setCheckerSequence] = React.useState(false);
  const [workFlowRule, updateWorkFlowRule] = React.useState([]);
  const [workFlowGroup, updateworkFlowGroup] = React.useState([]);
  const [workFlowUser, updateWorkflowUser] = React.useState([]);
  const [formInput, setFormInput] = React.useState(null);
  const [defaultWorkFlow, updateDefaultWorkFlow] = React.useState(false);
  const [workflowDetailData, updateWorkflowDetails] = React.useState(null);
  const [isLoading, updateLoading] = React.useState(false);

  const stateRef = useRef(state); //  reference value to get previous state

  useEffect(() => {
    if (stateRef?.current?.paymentDetails) {
      const req = {
        makerCount: authData?.makerCount,
        checkerCount: authData?.checkerCount,
        status: "",
        paymentRefNumber: "",
        amount: state?.paymentDetails?.amount,
        currency: state?.paymentDetails?.currency,
        baseCurrency: authData?.baseCurrnecy,
        bankCode: authData?.bankCode,
        tranType: "FIDB",
        userId: authData?.userId,
        customerId: authData?.corpId,
        userRoleType: authData?.userRoleType,
      };
      if (authData?.userRoleType === "M" && !transactionDetails?.channelRefNo) {
        req.userAction = "MAKERCREATE";
      } else if (
        authData?.userRoleType === "M" &&
        transactionDetails?.channelRefNo
      ) {
        req.userAction = "MAKERMODIFY";
        req.recKey = transactionDetails?.recKey || recKeyFromPrev;
      } else {
        req.userAction = "MAKERCREATE";
      }
      //CALL TRANSACTION WORKFLOW API
      dispatch(Actions.getTransactionWorkflowDetails(req));
    }
  }, []);

  // const getFirstFinalMakerData = () => {
  //   let firstMaker = false;
  //   let finalMaker = false;

  //   const pre_acc_count = params?.location?.state?.statusCode?.slice(7);

  //   // setting first maker value
  //   if (pre_acc_count === 1) {
  //     firstMaker = true;
  //   }

  //   // setting final checker value
  //   if (pre_acc_count === authData?.checkerCount?.toString()) {
  //     finalChecker = true;
  //   }

  //   return { firstChecker, finalChecker };
  // };

  useEffect(() => {
    if (JSON.stringify(stateRef?.current) !== JSON.stringify(state)) {
      const {
        loader,
        transactionWorkflow,
        paymentSuccess,
        workflowDetails,
        submitResponse,
      } = state;
      stateRef.current = state;

      if (paymentSuccess) {
        // redirecting to success page after succesfull payment
        history.push({
          pathname: "/auth-matrix-success",
          state: {
            // finalChecker: props?.location?.state?.finalChecker,
            submitResponse: submitResponse,
            prevPage: prevPage,
            action: prevPageAction?.action?.action,
            status: prevPageAction?.action?.status,
          },
        });
      } else {
        // updating Workflow Details
        if (workflowDetails && workflowDetails !== null) {
          if (
            workflowDetails?.alListOfWorkflow?.[0]?.makerWorkflowType === "S"
          ) {
            setMakerSequence(true);
          }
          if (
            workflowDetails?.alListOfWorkflow?.[0]?.checkerWorkflowType === "S"
          ) {
            setCheckerSequence(true);
          }
          updateWorkflowDetails(workflowDetails);
        }
        // if workflow rule is null then call default workflow api
        if (transactionWorkflow?.workFlowList?.length > 0) {
          updateDefaultWorkFlow(false);
          updateWorkFlowRule(
            transactionWorkflow?.workFlowList.map(({ label }) => label)
          );

          // If only one rule available preselect that value
          if (transactionWorkflow?.workFlowList?.length === 1) {
            handleUserInput(
              transactionWorkflow?.workFlowList.map(({ label }) => label)[0],
              "workFlowRule"
            );
          }
        } else if (transactionWorkflow?.workFlowList === null) {
          // if workflowList is null then we have to call Default workflow API
          updateDefaultWorkFlow(true);
          const req = {
            bankCode: authData?.bankCode,
            customerId: authData?.corpId,
            makerCount: authData?.makerCount,
            checkerCount: authData?.checkerCount,
            baseCurrency: authData?.baseCurrnecy,
            userId: authData?.userId,
            userRoleType: authData?.userRoleType,
            recKey: transactionDetails?.recKey || recKeyFromPrev,
          };

          //CALL DEFAULT WORKFLOW API
          dispatch(Actions.getdefaultWorkflow(req));
        }

        updateworkFlowGroup(
          transactionWorkflow?.workflowGroupList?.length > 0 &&
            transactionWorkflow?.workflowGroupList.map(({ label }) => label)
        );

        updateWorkflowUser(
          transactionWorkflow?.workflowUserList?.length > 0 &&
            transactionWorkflow?.workflowUserList.map(({ label }) => label)
        );

        setLoader(loader);
        updateLoading(loader);
      }
    }
  }, [state]);

  const toggleDrawer = (open) => {
    setOPenModal(open);
    //  if (!open) {
    if (prevPage) {
      history.push(prevPage, {
        action: prevPageAction?.action?.action,
        status: prevPageAction?.action?.status,
      });
    } else {
      history.push({
        pathname: "/make-payment",
        state: {
          activeStep: 4,
        },
      });
    }
    //  }
  };

  const handleUserInput = (value, name) => {
    setFormInput({ ...formInput, [name]: value });
  };

  const fetchWorkFlowGroup = (selected_item) => {
    let workFlowMappedItem;
    if (state?.transactionWorkflow?.workFlowList) {
      // finding workFlowMappedItem by its label to get id
      workFlowMappedItem = state?.transactionWorkflow?.workFlowList.find(
        (item) => {
          if (item?.label === formInput?.workFlowRule) {
            return true;
          } else {
            return false;
          }
        }
      );
    }
    console.log(workFlowMappedItem);
    if (workFlowRule?.length > 1 && selected_item) {
      const req = {
        bankCode: authData?.bankCode,
        userId: authData?.userId,
        customerId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
        workFlowId: workFlowMappedItem.id,
        tranType: "FIDB",
      };
      dispatch(Actions.getWorkflowGroup(req));
    }
  };

  const fetchWorkFlowUsers = (item) => {
    if (workFlowGroup?.length > 1 && item) {
      const req = {
        bankCode: authData?.bankCode,
        userId: authData?.userId,
        customerId:
          transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
        workflowId: formInput?.workFlowGroup,
        groupId: item,
        tranType: "FIDB",
        userRoleType: authData?.userRoleType,
      };
      dispatch(Actions.getWorkflowUserList(req));
    }
  };

  const handleSubmit = () => {
    let workFlowMappedItem;
    if (state?.transactionWorkflow?.workFlowList) {
      // finding workFlowMappedItem by its label to get id
      workFlowMappedItem = state?.transactionWorkflow?.workFlowList.find(
        (item) => {
          if (item?.label === formInput?.workFlowRule) {
            return true;
          } else {
            return false;
          }
        }
      );
    }

    updateLoading(true);
    const req = {
      bankCode: authData?.bankCode,
      userId: authData?.userId,
      corpId: authData?.corpId,
      tranType: "FIDB",
      fidbtxnId: transactionDetails?.recKey || recKeyFromPrev,
      workFlowId: workFlowMappedItem?.id,
      groupId: formInput?.workFlowGroup,
      requestForwardTo: formInput?.workFlowUser,
      remarksForChecker: formInput?.remarkForChecker,
      remarksForBank: formInput?.remarkForBank,
      checkerCount: authData?.checkerCount,
      makerCount: authData?.makerCount,
      baseCurrency: authData?.baseCurrnecy,
      applicationDate: authData?.appDate,
      timeZone: authData?.timeZone,
    };

    dispatch(Actions.submitWorkflow(req));
  };

  const fetchWorkflowDetails = () => {
    const req = {
      bankCode: authData?.bankCode,
      userId: authData?.userId,
      customerId:
        transactionDetails?.custIdAndIeCode?.custId || authData?.subcustId,
      workflowId: formInput?.workFlowRule,
      tranType: "FIDB",
      groupId: formInput?.workFlowGroup,
      userRoleType: authData?.userRoleType,
    };
    dispatch(Actions.fetchWorkflowDetails(req));
  };

  if (loader) {
    return <Loader />;
  }

  return (
    <div>
      <div>
        <React.Fragment>
          <Drawer
            classes={{
              paper: classes.paper,
            }}
            anchor={"bottom"}
            open={openModal}
            onClose={() => {
              toggleDrawer(false);
            }}
          >
            <div
              onClick={() => {
                toggleDrawer(false);
              }}
              className="close"
            >
              <img src={CloseIcon} className="close-icon" />
            </div>
            <div className="details-container">
              <span className="heading-details">Workflow Details</span>

              {/* when view details is clicked, show details, otherwise hide
              details */}

              <div className="border-container">
                <Grid spacing={3} className=" details-containers" container>
                  {workFlowRule?.length > 0 && !defaultWorkFlow && (
                    <Grid
                      className="sub-detail-container full-width-textField "
                      item
                      lg={6}
                      sm={6}
                      xs={12}
                    >
                      <Dropdown
                        label={"Select Rule"}
                        items={workFlowRule.filter((e) => e !== "Select")}
                        variant="filled"
                        fullWidth
                        name="Select Rule"
                        onChange={(e) => {
                          handleUserInput(e, "workFlowRule");
                          fetchWorkFlowGroup(e);
                          // clearing selected values when workflow rule changes
                          // handleUserInput("", "workFlowGroup");
                          // handleUserInput("", "workFlowUser");
                        }}
                        defaultValue={formInput?.workFlowRule}
                      />
                    </Grid>
                  )}

                  {workFlowRule?.length === 0 && !defaultWorkFlow && (
                    <Grid
                      className="sub-detail-container"
                      item
                      lg={6}
                      sm={6}
                      xs={12}
                    >
                      {viewDetails ? (
                        <span
                          className="view-detail-button"
                          onClick={() => {
                            fetchWorkflowDetails();
                            setViewDetails(false);
                          }}
                        >
                          View details
                        </span>
                      ) : (
                        <span
                          className="view-detail-button"
                          onClick={() => setViewDetails(true)}
                        >
                          Hide details
                        </span>
                      )}
                    </Grid>
                  )}
                  {!viewDetails && workflowDetailData && (
                    <>
                      <Grid item container spacing="3">
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Corporate ID</span>
                            <span className="content">
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.customerId
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Corporate Name</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.customerName
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Wireflow Name</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.workflowName
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Transaction Type</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.tranType
                              }{" "}
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">
                              Transaction from Amount
                            </span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.fromTransactionAmount
                              }
                            </span>
                          </div>
                        </Grid>
                        <Grid item lg={4} md={4} sm={4} xs={6}>
                          <div className="workflow-details-column-container">
                            <span className="title">Transaction To Amount</span>
                            <span className="content">
                              {" "}
                              {
                                workflowDetailData?.alListOfWorkflow?.[0]
                                  ?.toTransactionAmount
                              }
                            </span>
                          </div>
                        </Grid>
                      </Grid>
                      {workflowDetailData?.groupDetails?.makerGroupDetails && (
                        <Grid
                          spacing="3"
                          item
                          className="makerGroupsContainer"
                          lg={12}
                          md={12}
                          sm={12}
                          xs={12}
                        >
                          <div className="heading">Maker Groups</div>
                          <div className="select-group-container">
                            <RadioList
                              variant="filled"
                              list={{
                                title: "Select Group",
                                items: [
                                  {
                                    label: "Sequence",
                                    name: "sequence",
                                    value: "sequence",
                                    checked: maker_sequence,
                                    disabled: !maker_sequence,
                                  },
                                  {
                                    label: "Random",
                                    name: "random",
                                    value: "random",
                                    checked: !maker_sequence,
                                    disabled: maker_sequence,
                                  },
                                ],
                              }}
                            />
                          </div>

                          <div className="maker-table-container">
                            <Grid container className="header">
                              <Grid lg={4} md={4} sm={4} xs={4} item>
                                Group Name
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                User Count
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                Sequence Number
                              </Grid>
                            </Grid>

                            <Grid container className="items-container">
                              {workflowDetailData?.groupDetails?.makerGroupDetails?.makerGroupName?.map(
                                (item, key) => (
                                  <div className="item-row">
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      item
                                      className=""
                                    >
                                      {item}
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.makerGroupDetails?.makerUserCount?.[
                                          key
                                        ]
                                      }
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.makerGroupDetails
                                          ?.makerSequenceNumber?.[key]
                                      }
                                    </Grid>
                                  </div>
                                )
                              )}

                              <div className="item-row">
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  item
                                  className=""
                                >
                                  Total Makers
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.totalMakerCount
                                  }
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.makerSequenceNumber
                                  }
                                </Grid>
                              </div>
                            </Grid>
                          </div>
                        </Grid>
                      )}
                      {workflowDetailData?.groupDetails
                        ?.checkerGroupDetails && (
                        <Grid
                          item
                          className="makerGroupsContainer"
                          lg={12}
                          md={12}
                          sm={12}
                          xs={12}
                        >
                          <div className="heading">Checker Groups</div>
                          <div className="select-group-container">
                            <RadioList
                              variant="filled"
                              list={{
                                title: "Select Group",
                                items: [
                                  {
                                    label: "Sequence",
                                    name: "sequence",
                                    value: "sequence",
                                    checked: checker_sequence,
                                    disabled: !checker_sequence,
                                  },
                                  {
                                    label: "Random",
                                    name: "random",
                                    value: "random",
                                    checked: !checker_sequence,
                                    disabled: checker_sequence,
                                  },
                                ],
                              }}
                            />
                          </div>

                          <div className="maker-table-container">
                            <Grid container className="header">
                              <Grid lg={4} md={4} sm={4} xs={4} item>
                                Group Name
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                User Count
                              </Grid>
                              <Grid
                                lg={4}
                                md={4}
                                sm={4}
                                xs={4}
                                className="tar"
                                item
                              >
                                Sequence Number
                              </Grid>
                            </Grid>
                            <Grid container className="items-container">
                              {workflowDetailData?.groupDetails?.checkerGroupDetails?.checkerGroupName?.map(
                                (item, key) => (
                                  <div className="item-row">
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      item
                                      className=""
                                    >
                                      {item}
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.checkerGroupDetails
                                          ?.checkerUserCount?.[key]
                                      }
                                    </Grid>
                                    <Grid
                                      lg={4}
                                      md={4}
                                      sm={4}
                                      xs={4}
                                      className="tar"
                                      item
                                    >
                                      {
                                        workflowDetailData?.groupDetails
                                          ?.checkerGroupDetails
                                          ?.checkerSequenceNumber?.[key]
                                      }
                                    </Grid>
                                  </div>
                                )
                              )}

                              <div className="item-row">
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  item
                                  className=""
                                >
                                  Total Checkers
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.totalCheckerCount
                                  }
                                </Grid>
                                <Grid
                                  lg={4}
                                  md={4}
                                  sm={4}
                                  xs={4}
                                  className="tar"
                                  item
                                >
                                  {
                                    workflowDetailData?.alListOfWorkflow?.[0]
                                      ?.checkerSequenceNumber
                                  }
                                </Grid>
                              </div>
                            </Grid>
                          </div>
                        </Grid>
                      )}
                    </>
                  )}

                  {workFlowGroup?.length > 0 && !defaultWorkFlow && (
                    <Grid
                      className="sub-detail-container full-width-textField "
                      item
                      lg={6}
                      sm={6}
                      xs={12}
                    >
                      <Dropdown
                        label={"Select User Group"}
                        items={workFlowGroup.filter((e) => e !== "Select")}
                        variant="filled"
                        fullWidth
                        name="Select User Group"
                        onChange={(e) => {
                          handleUserInput(e, "workFlowGroup");
                          fetchWorkFlowUsers(e);
                          // clearing selected values when workflow group changes
                          //  handleUserInput("", "workFlowUser");
                        }}
                        defaultValue={formInput?.workFlowGroup}
                        // defaultValue={"lorem ipsum"}
                      />
                    </Grid>
                  )}
                  {workFlowUser?.length > 0 && (
                    <>
                      {workFlowGroup?.length > 0 && (
                        <Grid
                          className="sub-detail-container full-width-textField hide-mob"
                          item
                          lg={6}
                          sm={6}
                          xs={12}
                        >
                          <span></span>
                        </Grid>
                      )}
                      <Grid
                        className="sub-detail-container full-width-textField "
                        item
                        lg={6}
                        md={6}
                        sm={6}
                        xs={12}
                      >
                        <Dropdown
                          label={"Select User (Optional)"}
                          items={workFlowUser.filter((e) => e !== "Select")}
                          variant="filled"
                          fullWidth
                          name="Select User (Optional)"
                          onChange={(e) => {
                            handleUserInput(e, "workFlowUser");
                          }}
                          defaultValue={formInput?.workFlowUser}
                        />
                      </Grid>
                    </>
                  )}
                  <Grid
                    className="sub-detail-container full-width-textField hide-mob"
                    item
                    lg={6}
                    md={6}
                    sm={6}
                    xs={0}
                  >
                    <span></span>
                  </Grid>
                  <Grid
                    className="sub-detail-container full-width-textField "
                    item
                    lg={12}
                    md={12}
                    sm={12}
                    xs={12}
                  >
                    <TextField
                      label="Remarks for Checker (Optional)"
                      type="text"
                      variant="filled"
                      onChange={(e) => {
                        handleUserInput(e?.target?.value, "remarkForChecker");
                      }}
                      value={formInput?.remarkForChecker}
                      maxLength={1000}
                    />
                  </Grid>
                  <Grid
                    className="sub-detail-container full-width-textField "
                    item
                    lg={12}
                    md={12}
                    sm={12}
                    xs={12}
                  >
                    <TextField
                      label="Remarks for Bank (Optional)"
                      type="text"
                      variant="filled"
                      onChange={(e) => {
                        handleUserInput(e?.target?.value, "remarkForBank");
                      }}
                      value={formInput?.remarkForBank}
                      maxLength={1000}
                    />
                  </Grid>
                </Grid>
              </div>
            </div>
            <div className="close-container">
              <Button
                onClick={() => {
                  toggleDrawer(false);
                }}
                color="secondary"
              >
                Close
              </Button>
              <Button loading={isLoading} onClick={() => handleSubmit()}>
                Submit
              </Button>
            </div>
          </Drawer>
        </React.Fragment>
      </div>
    </div>
  );
};

export default AuthMatrix;
