/* eslint-disable */
import React, { useRef, useState, useEffect } from "react";
import { Button } from "../../../components/@subzero/glacier/package/lib/components";
import PropTypes from "prop-types";
import CircularProgress from "@material-ui/core/CircularProgress";
import Typography from "@material-ui/core/Typography";
import Box from "@material-ui/core/Box";
import UploadProgress from "../../../components/attachdocuments/UploadProgress";
import DocumentCheckList from "../../../components/attachdocuments/DocumentCheckList";
import ViewDocuments from "../../../components/attachdocuments/ViewDocuments";
import "./index.css";

import InfoIcon from "../../../assets/icons/info-icon.svg";
import uploadIcon from "../../../assets/icons/cloud-icon.svg";
import { Grid } from "@material-ui/core";

// import { useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";
import AlertPopup from "../../../components/alertPopup/alertPopup";

function CircularProgressWithLabel(props) {
  return (
    <Box position="relative" display="inline-flex">
      <CircularProgress variant="determinate" {...props} />
      <Box
        top={0}
        left={0}
        bottom={0}
        right={0}
        position="absolute"
        display="flex"
        alignItems="center"
        justifyContent="center"
      >
        <Typography
          variant="caption"
          component="div"
          color="textSecondary"
        >{`${Math.round(props.value)}`}</Typography>
      </Box>
    </Box>
  );
}

CircularProgressWithLabel.propTypes = {
  /**
   * The value of the progress indicator for the determinate variant.
   * Value between 0 and 100.
   */
  value: PropTypes.number.isRequired,
};

const docCheckListData = {
  headCells: [
    {
      id: "boeNo",
      label: "BOE Number",
    },
    {
      id: "addMandDocs",
      label: "Additional Mandatory Documents",
    },
    {
      id: "description",
      label: "Description",
    },
  ],
  rows: [
    {
      boeNo: "P0102",
      addMandDocs: "Transport Documents",
      description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    },
    {
      boeNo: "P0103",
      addMandDocs: "Invoices",
      description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    },
    {
      boeNo: "P0104",
      addMandDocs: "License Copy",
      description:
        "Lorem Ipsum is simply dummy text of the printing and typesetting industry. ",
    },
  ],
};

const AttachDocuments = (props) => {
  // const classes = useStyles();

  const dispatch = useDispatch();

  const inputFile = useRef(null);
  const [fileList, updateFileList] = useState([]);
  const [classifications, setClassifications] = useState([]);
  const [alertStatus, setAlertStatus] = useState(false);
  const [alertMsg, setAlertMessage] = useState("");
  const [totalTimeRemaining, setTotalTimeRemaining] = useState(0);

  const authData = useSelector((state) => state?.auth?.loginData);
  const fileData = useSelector((state) => state?.attachDocuments?.documents);
  const paymentState = useSelector((state) => state?.paymentReviewData);
  const attachmentData = useSelector(
    (state) => state?.attachDocuments?.attachments
  );
  const documentCheckListData = useSelector(
    (state) => state?.attachDocuments?.documentCheckList
  );
  const setCheckDocumentCheckListData = useSelector(
    (state) => state?.attachDocuments?.setCheckDocumentCheckListData
  );
  const transactionDetails = useSelector((state) => state?.transactionDetails);

  //Get doc check list data from API
  const getDocCheckList = () => {
    dispatch(Actions.getDocCheckList());
  };

  const checkDocumentCheckList = () => {
    dispatch(Actions.checkDocumentCheckList());
  };

  // Load data initially
  useEffect(() => {
    // if coming from edit button, call api for prefilling attach documents data
    if (transactionDetails && transactionDetails?.recKey) {
      const request = {
        bankCode: authData?.bankCode,
        recKey: transactionDetails?.recKey,
      };
      dispatch(Actions.getAllAttachments(request));
    }
    getDocCheckList();
    checkDocumentCheckList();
  }, []);

  // //when documentCheckListData available
  // useEffect(() => {
  //   if (checkDocumentCheckListData?.length > 0) {
  //     setCheckDocumentCheckListData(checkDocumentCheckListData);
  //   }
  // }, [checkDocumentCheckListData]);

  //when documentCheckListData available
  useEffect(() => {
    if (documentCheckListData?.length > 0) {
      setClassifications(documentCheckListData);
      // update file list first
      updateFileList(attachmentData);
      dispatch(Actions.updateFileData(attachmentData));
    }
  }, [documentCheckListData]);

  //when attachmentData available
  useEffect(() => {
    if (attachmentData?.length > 0) {
      // update file list first
      updateFileList(attachmentData);
      dispatch(Actions.updateFileData(attachmentData));
    }
  }, [attachmentData]);

  // on file upload complete for each file, update uploadCompletd and showUploading
  useEffect(() => {
    // this will get triggered in 3 situations
    // 1. file upload started 2. file upload completed, 3. file delete complete

    // filtering out deleted files from fileList based on fileData array
    if (fileData?.length > 0) {
      let filteredFileList = fileList.filter((file) => {
        if (file?.id) {
          if (
            fileData.find((fileItem) => fileItem?.id === file?.id) === undefined
          ) {
            return false;
          } else {
            return true;
          }
        } // @todo handle files without id - which are being uploaded and cancelled before completing upload
        else {
          return true;
        }
      });

      //when file being uploaded or file upload completed, update fileList

      // this condition happens when revisting the page, like coming from edit page, so update filteredFileList with fileData and proceed
      if (fileData.length > 0) {
        filteredFileList = [...fileData];
      }

      fileData.forEach((file, index) => {
        // if file id set, that means, file upload completed, so update current flag and in the state
        if (file?.id) {
          const newFileList = [...filteredFileList];
          newFileList[index].showUploading = false;
          newFileList[index].uploadCompleted = true;
          newFileList[index].id = file?.id;
          updateFileList(newFileList);
        } else {
          // other wise, file upload is bieng started only, so update corresponding flag
          const newFileList = [...filteredFileList];
          newFileList[index].showUploading = true;
          updateFileList(newFileList);
        }
      });
    } else {
      // if all files are deleted from store, reset fileList satate
      updateFileList([]);
    }
  }, [fileData]);

  // update each file uploading progress
  const uploadPrgress = (
    totalBytes,
    timeStarted,
    uploadedBytes,
    progressPercentage,
    fileIndex
  ) => {
    const newFileList = [...fileList];
    newFileList[fileIndex].progress = progressPercentage;

    // calculating remaining upload time
    const timeElapsed = new Date() - timeStarted; // Assuming that timeStarted is a Date Object
    const uploadSpeed = uploadedBytes / (timeElapsed / 1000); // Upload speed in second

    let timeRemaining = Math.round((totalBytes - uploadedBytes) / uploadSpeed);
    if (timeRemaining <= 0.5) {
      timeRemaining = 0;
    }
    newFileList[fileIndex].timeRemaining = timeRemaining;
    updateFileList(newFileList);

    const timeInSeconds = fileList.reduce(
      (timeTotal, file) => file.timeRemaining + timeTotal,
      0
    );
    setTotalTimeRemaining(timeInSeconds);
  };

  // handle bulk file upload
  const handleFileUpload = () => {
    const newFileList = [...fileList];

    // validate classification field
    const fileWithoutClassification = newFileList.find((file) => {
      return file.checkList ? false : true;
    });

    // calssification validation check
    if (fileWithoutClassification === undefined) {
      fileList.forEach((file, index) => {
        // filter out already uploaded files from fileList
        // this means this file is yet to upload
        if (file.id === undefined) {
          newFileList[index].showUploading = true;
          newFileList[index].uploadCompleted = false;
          updateFileList(newFileList);

          const request = {
            // userId: authData?.userId,
            // corpId: authData?.corpId,
            bankCode: authData?.bankCode,
            recKey: transactionDetails?.recKey,
            uploadFile: file.file,
            checkList: file.checkList,
            uploadPrgress: uploadPrgress,
            fileIndex: index,
          };
          dispatch(Actions.uploadDocuments(request));
        }
      });
    } else {
      setAlertMessage("Please select classification for all files !");

      setAlertStatus(true);
      setTimeout(() => {
        setAlertStatus(false);
      }, 1000);
    }
  };

  const handleFileSelection = async (event) => {
    // update file list if file selected
    if (event.target.files[0]) {
      updateFileList([
        ...fileList,
        {
          file: event.target.files[0],
          showUploading: false,
          uploadCompleted: false,
        },
      ]);
    }
    // this is for avoiding issue while selecting same file after selecting and deleting
    event.target.value = null;
  };

  //delete single file by index
  const handleFileDeletion = (fileIndex) => {
    const newFileList = [...fileList];
    newFileList.splice(fileIndex, 1);
    updateFileList(newFileList);
  };

  //delete uploaded file
  const deleteUplodedFile = (fileIndex) => {
    const request = {
      bankCode: authData?.bankCode,
      id: fileData[fileIndex]?.id,
      fileName: fileData[fileIndex]?.file?.name,
      fileIndex: fileIndex,
    };
    dispatch(Actions.deleteUploadedDoc(request));
  };

  //delete all uploaded files and reset upload states
  const deleteFilesAndReset = () => {
    const request = fileData.map((file) => {
      return {
        bankCode: authData?.bankCode,
        id: file?.id,
        fileName: file?.file?.name,
      };
    });
    dispatch(Actions.deleteAllUploadedDoc(request));
  };

  //handle file dropdown value change
  const handleUserInput = (value, name, key) => {
    let classification = documentCheckListData.find(
      (item) => item.label === value
    );
    const newFileList = fileList.map((file, index) => {
      if (key === index) {
        file[name] = classification;
      }
      return file;
    });
    updateFileList(newFileList);
  };

  return (
    <>
      <div className="attach-document-container">
        {!props?.viewMode ? (
          <>
            <div className="attachDocHeader">
              <Grid container>
                <Grid item lg={2} md={12} sm={12} xs={12}>
                  <h4>Attach Documents</h4>
                </Grid>
                {authData.docUploadWaiver !== "Paperless" && (
                  <Grid item lg={5} md={12} sm={12} xs={12}>
                    <div className="error-box">
                      <img src={InfoIcon} />
                      <span>
                        Transport and invoice documents are mandatory to attach.
                      </span>
                    </div>
                  </Grid>
                )}
              </Grid>
            </div>

            <div className="attachDocBody">
              {/* <DocumentCheckList data={docCheckListData} /> */}
              {/* <div className="error-traingle-box">
                <img src={ErrorIcon} />
                <span>
                  HS Code mentioned pertains to risk category, please attach
                  license copy in the attach document section
                </span>
              </div> */}
              <div
                className="file-uplaod-input"
                onClick={() => {
                  inputFile.current.click();
                }}
              >
                <div className="file-input-inner-container">
                  <input
                    ref={inputFile}
                    id="myInput"
                    style={{ display: "none" }}
                    type={"file"}
                    onClick={(e) => e.stopPropagation()}
                    onChange={(e) => {
                      handleFileSelection(e);
                    }}
                  />
                  <img src={uploadIcon} />
                  <label htmlFor="myInput">Choose file</label>
                  <span className="choose-file-message">
                    Click to browse or drop here to upload Supported Formats:
                    Excel, csv, txt, xml, pdf. Maximum Individual File size: 5
                    MB
                  </span>
                </div>
              </div>
              {fileList && fileList.length > 0 && (
                <div className="upload-list">
                  <div className="green-card">
                    <div className="green-card-data">
                      {
                        // hide circular progress if no files are uploaded
                        Math.round(
                          (fileList.reduce(
                            (total, file) => (file?.id ? total + 1 : total),
                            0
                          ) /
                            fileList.length) *
                            100
                        ) > 0 && (
                          <>
                            <CircularProgressWithLabel
                              value={Math.round(
                                (fileList.reduce(
                                  (total, file) =>
                                    file?.id ? total + 1 : total,
                                  0
                                ) /
                                  fileList.length) *
                                  100
                              )}
                            />
                          </>
                        )
                      }

                      <div className="card-text-area">
                        <div>
                          {fileList.reduce((total, file) => {
                            return file?.id ? total + 1 : total;
                          }, 0)}
                          /{fileList.length} Uploaded
                        </div>
                        {/* <span>
                          Time remaining:{" "}
                          {totalTimeRemaining < 60
                            ? totalTimeRemaining + " Seconds"
                            : Math.round(totalTimeRemaining / 60) + " Minutes"}
                        </span> */}
                      </div>
                    </div>
                  </div>
                  {fileList.map((item, key) => (
                    <>
                      {/* show uploading completed files */}
                      {!item.showUploading && item.uploadCompleted && (
                        //  uploading completed
                        <UploadProgress
                          showSelected={true}
                          item={item}
                          fileIndex={key}
                          onFileDelete={deleteUplodedFile}
                        />
                      )}
                    </>
                  ))}

                  {/* if some file upload completed, show delete all button */}
                  {fileData.find((file) => (file?.id ? true : false)) && (
                    <div className="direction-right">
                      <Button
                        color="secondary"
                        onClick={() => deleteFilesAndReset()}
                      >
                        Delete All
                      </Button>
                    </div>
                  )}

                  {/* section for displaying selected files and files being uploaded */}
                  {fileList.map((item, key) => (
                    <>
                      {/* file is being uploaded  and not completed */}
                      {item.showUploading
                        ? !item.uploadCompleted && (
                            <>
                              <hr />
                              <UploadProgress
                                value={item.progress}
                                item={item}
                                fileIndex={key}
                                onFileDelete={handleFileDeletion}
                              />
                            </>
                          )
                        : //  file selected for uploading, but uploading not started yet
                          !item.uploadCompleted && (
                            <UploadProgress
                              classifications={classifications}
                              showForm={true}
                              item={item}
                              fileIndex={key}
                              onFileDelete={handleFileDeletion}
                              handleUserInput={handleUserInput}
                            />
                          )}
                    </>
                  ))}

                  {/* some files are ready to be uploaded, show upload button */}
                  {fileList.find((file) =>
                    !file?.showUploading && !file?.uploadCompleted
                      ? true
                      : false
                  ) && (
                    <div className="direction-right">
                      <Button
                        onClick={() => {
                          handleFileUpload();
                        }}
                      >
                        Upload
                      </Button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        ) : (
          <ViewDocuments
            viewMode={props?.viewMode}
            showCheckList={props?.showCheckList}
            editMode={props?.editMode}
            userAccess={props?.userAccess}
            editAttachments={props?.editAttachments}
          />
        )}
      </div>
      {alertStatus && (
        <AlertPopup alertMsg={alertMsg} alertType={"warn"} isAlertOpen={true} />
      )}
    </>
  );
};
export default AttachDocuments;
