/*eslint-disable */
import React, { useEffect, useState } from "react";
import InfoIcon from "../../../assets/icons/info-grey.svg";
import Switch from "@material-ui/core/Switch";
import "./index.css";
import {
  Button,
  Dropdown,
  RadioList,
} from "../../../components/@subzero/glacier/package/lib/components";
import { Grid, TextField, Typography } from "@material-ui/core";
import AgGridTable from "../../../components/aggridtable";
import AdditionalDetails from "./additional_details";
import BoeDetails from "../../boe/details";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";
import AlertPopup from "../../../components/alertPopup/alertPopup";
import PlusBtn from "../../../assets/icons/plus_Btn.svg";

const TransactionDetails = (props) => {
  const dispatch = useDispatch();
  const authData = JSON.parse(localStorage.getItem("authData"));
  const [standardProcess, setStandardProcess] = useState(authData?.docUploadWaiver !== "Paperless" ? true : false);
  const [capital, setCapital] = useState(true);
  const [rows, setRows] = useState([]);
  const [openModal, setOpenModal] = useState(false);
  const [rowData, setRowData] = useState({});
  const [showBoeDetails, setShowBoeDetails] = useState(false);
  const [boeDetailsParams, setBoeDetailsParams] = useState(null);
  const [defaultApplicant, setDefaultApplicant] = useState({});
  const [ieCodes, setIeCodes] = useState([]);
  const [subIds, setSubIds] = useState([]);
  const [custIdAndIeCode, setCustIdAndIeCode] = useState({
    custId: "",
    ieCode: "",
  });
  const [alert, setAlert] = useState({
    alertMsg: "Additional Details have been saved",
    alertType: "success",
    isAlertOpen: false,
  });
  const state = useSelector((state) => state?.transactionDetails);
  const transDetailsData = useSelector(
    (state) => state?.transactionDetails?.transDetails
  );

  const transReviewData = useSelector(
    (state) => state?.paymentReviewData?.transactionDetails
  );

  const headCells = [
    { field: "boeNumber", label: "BOE No.", smallCell: true },
    { field: "boeDate", label: "BOE Date", smallCell: true },
    {
      field: "supplierName",
      label: "Supplier Name",
      showTooltip: true,
      largeCell: true,
    },
    {
      field: "boeCout",
      label: "No. of Invoice",
      smallCell: true,
      rightAligned: true,
    },
    { field: "invoiceCurrency", label: "Currency", smallCell: true },
    {
      field: "invoiceAmount",
      label: "Invoice Amount- FOB",
      rightAligned: true,
    },
    {
      field: "outstandingAmount",
      label: "O/S Invoice Amount- FOB",
      minWidth: 190,
      rightAligned: true,
    },
    {
      field: "totalPayableAmount",
      label: "Total Payable Amount",
      minWidth: 170,
      rightAligned: true,
    },
    { field: "actionButton", label: "Details", buttonLabel: "+ ADD" },
  ];

  const loadTransDetails = () => {
    const rowData = {
      boeNumber: [],
      currency: "",
    };
    props?.data?.map((item) => {
      rowData.boeNumber.push(item?.boeNo?.value);
      rowData.currency = item?.currency?.value;
      return true;
    });
    const req = {
      boeNumber: rowData?.boeNumber,
      currency: rowData?.currency,
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
      recKey: state?.recKey ? state?.recKey : null,
      ieCode: state?.custIdAndIeCode?.ieCode || authData?.ieCode,
    };
    dispatch(Actions.getTransactions(req));
  };

  const setTotalRemittanceAndPayableAmount = () => {
    const totalRemittanceAmount = transDetailsData?.reduce((total, item) => {
      return total + (item?.totalPayableAmount ? item.totalPayableAmount : 0);
    }, 0);
    const totalOSAmount = transDetailsData?.reduce((total, item) => {
      return total + (item?.outstandingAmount ? item.outstandingAmount : 0);
    }, 0);
    const totalPayableAmount = totalOSAmount - totalRemittanceAmount;
    const beneValues = transDetailsData?.map((item) => {
      return item.supplierName;
    });
    const proceedToNextStepper = transDetailsData?.reduce((flag, item) => {
      return flag && item?.status === "SAVE";
    }, true);
    props.setTotalRemittanceAndPayableAmount({
      totalRemittanceAmount: totalRemittanceAmount,
      totalPayableAmount: totalPayableAmount < 0 ? 0 : totalPayableAmount,
      selectBeneValue: beneValues,
      proceedToNextStepper: proceedToNextStepper,
    });
  };

  function createData(
    id,
    boeNumber,
    boeDate,
    supplierName,
    boeCout,
    invoiceCurrency,
    invoiceAmount,
    outstandingAmount,
    totalPayableAmount,
    status
  ) {
    return {
      id,
      boeNumber,
      boeDate,
      supplierName,
      boeCout,
      invoiceCurrency,
      invoiceAmount,
      outstandingAmount,
      totalPayableAmount,
      status,
      actionButton: "",
    };
  }

  const getRows = () => {
    if (transDetailsData?.length > 0) {
      return transDetailsData?.map((resp) => {
        const {
          id,
          boeNumber,
          boeDate,
          supplierName,
          boeCout,
          invoiceCurrency,
          invoiceAmount,
          outstandingAmount,
          totalPayableAmount,
          status,
        } = resp;
        return createData(
          id,
          boeNumber,
          boeDate,
          supplierName,
          boeCout,
          invoiceCurrency,
          invoiceAmount,
          outstandingAmount,
          totalPayableAmount,
          status
        );
      });
    } else {
      return [];
    }
  };

  const onActionClick = (e, data) => {
    setOpenModal(true);
    setRowData(data);
  };

  const closeHandler = () => {
    setAlert({
      ...alert,
      isAlertOpen: false,
    });
    dispatch(Actions.clearTransDraftMsgStatus());
  };

  const showOtherScreen = (link, params) => {
    if (link === "boe-details") {
      setShowBoeDetails(true);
      setBoeDetailsParams(params);
    }
  };

  const generateTableData = () => {
    const rows = getRows();
    const newArray = [...rows];
    const resultArray = [];
    newArray.map((rowItem, index, newArray) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        const value = rowItem[key];
        switch (key) {
          case "boeNumber":
            return (newObject[key] = {
              value: value,
              isLink: true,
              link: `boe-details`,
              params: { item: rowItem, trans: true },
            });
          case "supplierName":
            return (newObject[key] = { value: value, showTooltip: true });
          case "invoiceCurrency":
            return (newObject[key] = { value: value, smallCell: true });
          case "actionButton":
            if (rowItem.status === null) {
              return (newObject[key] = (
                <Button
                  textButton
                  onClick={(e) => {
                    onActionClick(e, rowItem);
                  }}
                  className="add-additionalDetails-button"
                >
                  <img src={PlusBtn} className="addIcon-transaction-screen" />{" "}
                  &nbsp;Add
                </Button>
              ));
            } else if (rowItem.status === "SAVE") {
              rowItem.UpdateBtn = true;
              return (newObject[key] = (
                <Button
                  textButton
                  onClick={(e) => {
                    onActionClick(e, rowItem);
                  }}
                  className="add-additionalDetails-button"
                >
                  <img src={PlusBtn} className="addIcon-transaction-screen" />{" "}
                  &nbsp;Update
                </Button>
              ));
            } else if (rowItem.status === "warn") {
              return (newObject[key] = (
                <Button
                  textButton
                  onClick={(e) => {
                    onActionClick(e, rowItem);
                  }}
                  className="add-additionalDetails-button"
                >
                  {" "}
                  Update
                </Button>
              ));
            }
          default:
            return (newObject[key] = { value: value });
        }
      });
      resultArray.push(newObject);
      return newObject;
    });
    setRows(resultArray);
  };

  const loadDefaultApplicantDetails = () => {
    const req = {
      corpId: authData?.corpId,
      bankCode: authData?.bankCode,
    };
    dispatch(Actions.getDefaultApplicantDetails(req));
  };

  const onChangeHandler = (val, key) => {
    if (key === "custId") {
      setCustIdAndIeCode((prev) => ({
        ...prev,
        custId: val,
      }));
      const req = {
        userId: authData.userId,
        customerId: val || authData?.subcustId,
        accountNumber: "",
        bankCode: authData?.bankCode,
        ieCode: state?.custIdAndIeCode?.ieCode || authData?.ieCode,
      };
      dispatch(Actions.getHSCodes(req));
    } else {
      setCustIdAndIeCode((prev) => ({
        ...prev,
        ieCode: val,
      }));
    }
  };

  const resizeCustomDp = () => {
    document
      .getElementById("custIDDropdown")
      .closest(".MuiTextField-root").style.width =
      document.getElementById("custIDDropdown").closest(".MuiFormControl-root")
        .parentElement.parentElement.offsetWidth + "px";
  };

  useEffect(() => {
    setStandardProcess(state?.standardProcessing);
  }, [state?.standardProcessing]);

  useEffect(() => {
    dispatch(Actions.switchStandardProcessing(authData?.docUploadWaiver !== "Paperless" ? true : false));
    dispatch(Actions.clearTrans());
    if (state?.recKey)
      dispatch(
        Actions.getTransactionReviewData({
          corpId: authData?.corpId,
          userId: authData?.userId,
          bankCode: authData?.bankCode,
          recKey: state?.recKey,
        })
      );
    dispatch(
      Actions.getSubCustIds({
        corpId: authData?.corpId,
        bankCode: authData?.bankCode,
      })
    );
    dispatch(
      Actions.getIeCodes({
        corpId: authData?.corpId,
        bankCode: authData?.bankCode,
      })
    );
    loadTransDetails();
    generateTableData();
    loadDefaultApplicantDetails();
    resizeCustomDp();
    window.addEventListener("resize", resizeCustomDp);
    return () => {
      window.removeEventListener("resize", resizeCustomDp);
    };
  }, []);

  useEffect(() => {
    if (transReviewData && transReviewData[0]) {
      setCapital(transReviewData[0].typesOfGood === "CAPITAL" ? true : false);
      setStandardProcess(
        transReviewData[0].modeOfProcess === "YES" ? false : true
      );
    }
  }, [transReviewData]);

  useEffect(() => {
    if (state.saveCounter > 0) {
      loadTransDetails();
      setAlert({
        ...alert,
        alertMsg: "Additional Details have been saved",
        isAlertOpen: true,
      });
    }
  }, [state.saveCounter]);

  useEffect(() => {
    generateTableData();
    setTotalRemittanceAndPayableAmount();
    if (state?.transDetails?.length > 0) {
      props.onSaveAsDraft();
    }
  }, [state?.transDetails]);

  useEffect(() => {
    if (state.showSaveDraftMsg) {
      setAlert({
        ...alert,
        alertMsg: "Transaction Saved as Draft",
        isAlertOpen: true,
      });
    }
  }, [state.showSaveDraftMsg]);

  useEffect(() => {
    setDefaultApplicant(state?.defaultApplicantDetails);
  }, [state?.defaultApplicantDetails]);

  useEffect(() => {
    setSubIds(state?.subCustIds);
    if (state?.subCustIds?.length === 1) {
      setCustIdAndIeCode((prev) => ({
        ...prev,
        custId: state?.subCustIds[0].id,
      }));
    }
  }, [state?.subCustIds]);

  useEffect(() => {
    setIeCodes(state?.ieCodes);
    if (state?.ieCodes?.length === 1) {
      setCustIdAndIeCode((prev) => ({
        ...prev,
        ieCode: state?.ieCodes[0].id,
      }));
    }
  }, [state?.ieCodes]);

  useState(() => {
    if (state?.custIdAndIeCode?.custId !== custIdAndIeCode?.custId) {
      setCustIdAndIeCode((prev) => ({
        ...prev,
        custId: state?.custIdAndIeCode?.custId,
      }));
    } else if (state?.custIdAndIeCode?.ieCode !== custIdAndIeCode?.ieCode) {
      setCustIdAndIeCode((prev) => ({
        ...prev,
        ieCode: state?.custIdAndIeCode?.ieCode,
      }));
    }
  }, [state?.custIdAndIeCode]);

  useEffect(() => {
    dispatch(Actions.setCustIdAndIeCode(custIdAndIeCode));
  }, [custIdAndIeCode]);

  return (
    <div style={{ marginBottom: "100px" }}>
      <div className="transaction-details-header">
        <span className="transaction-details">Transaction Details</span>
        <div className="fast-processing-container">
          <img src={InfoIcon} />
          <span className="fast-processing">STP</span>
          <Switch
            checked={!standardProcess}
            disabled={authData?.docUploadWaiver === "Paperless"}
            onChange={() => {
              setStandardProcess(!standardProcess);
              dispatch(Actions.switchStandardProcessing(!standardProcess));
              props.onTopValuesChange({
                modeOFProcess: !standardProcess ? "NO" : "YES",
                goodsType: capital ? "CAPITAL" : "NON-CAPITAL",
              });
            }}
            name=""
            inputProps={{ "aria-label": "secondary checkbox" }}
          />
        </div>
      </div>
      <div className="border-container applicant-container">
        <Typography className="applicant-details-header">
          Applicant Details
        </Typography>
        <Grid container xs={12} sm={12} md={12} spacing={2}>
          <Grid item xs={12} sm={6} md={3}>
            {custIdAndIeCode.custId !== "" && subIds?.length === 1 ? (
              <TextField
                fullWidth
                variant="filled"
                label="Customer ID *"
                type="text"
                disabled={true}
                value={custIdAndIeCode.custId ? custIdAndIeCode.custId : ""}
                InputProps={{
                  disabled: `${true}`,
                  disableUnderline: `${true}`,
                  classes: {
                    disabled: "text-field-input-disabled",
                  },
                }}
                classes={{
                  root: "text-field-root",
                }}
              />
            ) : (
              <Dropdown
                id="custIDDropdown"
                label={"Customer ID *"}
                defaultValue={
                  custIdAndIeCode.custId || authData?.subcustId || ""
                }
                items={subIds.map((x) => x.id)}
                variant="filled"
                name="Customer ID *"
                name="custId"
                onChange={(val) => {
                  onChangeHandler(val, "custId");
                }}
              />
            )}
          </Grid>
          <Grid item xs={12} sm={12} md={6}>
            <TextField
              fullWidth
              label="Customer Name *"
              type="text"
              variant="filled"
              value={
                defaultApplicant?.applicantName
                  ? defaultApplicant?.applicantName
                  : ""
              }
              InputProps={{
                disabled: `${true}`,
                disableUnderline: `${true}`,
                classes: {
                  disabled: "text-field-input-disabled",
                },
              }}
              classes={{
                root: "text-field-root",
              }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            {custIdAndIeCode.ieCode !== "" && ieCodes?.length === 1 ? (
              <TextField
                fullWidth
                label="IE Code *"
                type="text"
                variant="filled"
                value={ieCodes[0] ? ieCodes[0].id : ""}
                errorMessage={"Mandatory Field."}
                InputProps={{
                  disabled: `${true}`,
                  disableUnderline: `${true}`,
                  classes: {
                    disabled: "text-field-input-disabled",
                  },
                }}
                classes={{
                  root: "text-field-root",
                }}
              />
            ) : (
              <Dropdown
                label={"IE Code *"}
                defaultValue={custIdAndIeCode.ieCode || authData.ieCode || ""}
                items={ieCodes.map((x) => x.id)}
                variant="filled"
                name="IE Code *"
                fullWidth
                name="ieCode"
                onChange={(val) => {
                  onChangeHandler(val, "ieCode");
                }}
              />
            )}
          </Grid>
          <Grid item xs={12} sm={6} md={3}>
            <TextField
              fullWidth
              label="Country *"
              type="text"
              variant="filled"
              value={
                defaultApplicant?.countryCode
                  ? `${defaultApplicant?.countryCode}-${defaultApplicant?.countryName}`
                  : ""
              }
              errorMessage={"Mandatory Field."}
              InputProps={{
                disabled: `${true}`,
                disableUnderline: `${true}`,
                classes: {
                  disabled: "text-field-input-disabled",
                },
              }}
              classes={{
                root: "text-field-root",
              }}
            />
          </Grid>
          <Grid item xs={12} sm={12} md={9}>
            <TextField
              fullWidth
              label="Address *"
              type="text"
              variant="filled"
              value={
                defaultApplicant?.applicantAddress1
                  ? `${defaultApplicant?.applicantAddress1} ${defaultApplicant?.applicantAddress2}`
                  : ""
              }
              errorMessage={"Mandatory Field."}
              InputProps={{
                disabled: `${true}`,
                disableUnderline: `${true}`,
                classes: {
                  disabled: "text-field-input-disabled",
                },
              }}
              classes={{
                root: "text-field-root",
              }}
            />
          </Grid>
          <Grid container lg={4} xs={12} sm={6}>
            <div className="type-goods">
              <RadioList
                variant="filled"
                defaultValue={1}
                list={{
                  title: "Type of Goods",
                  items: [
                    {
                      label: "Capital",
                      name: "capital",
                      value: "capital",
                      checked: capital,
                    },
                    {
                      label: "Non-Capital",
                      name: "non-capital",
                      value: "non-capital",
                      checked: !capital,
                    },
                  ],
                }}
                onChange={(e) => {
                  if (e === "capital") {
                    setCapital(true);
                  } else {
                    setCapital(false);
                  }
                  props.onTopValuesChange({
                    modeOFProcess: standardProcess ? "NO" : "YES",
                    goodsType: !capital ? "CAPITAL" : "NON-CAPITAL",
                  });
                }}
              />
            </div>
          </Grid>
        </Grid>
      </div>
      <div>
        <AgGridTable
          tableOnly={true}
          headCells={headCells}
          rows={rows}
          noRowSelection={true}
          hideActionIcon={true}
          showOtherScreen={showOtherScreen}
          autoSize={true}
        />
      </div>
      {showBoeDetails && (
        <BoeDetails
          onClose={() => {
            setShowBoeDetails(false);
          }}
          params={boeDetailsParams}
        />
      )}
      <AdditionalDetails
        open={openModal}
        data={rowData}
        onClose={() => {
          setOpenModal(false);
        }}
        modeOFProcess={!standardProcess}
        typesOfGood={capital}
      />
      <AlertPopup {...alert} onClose={closeHandler} />
    </div>
  );
};

export default TransactionDetails;
