/* eslint-disable*/
import React, { useEffect, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import Drawer from "@material-ui/core/Drawer";
import { Grid } from "@material-ui/core";
import CloseIcon from "../../../../assets/icons/close.svg";
import InfoIcon from "../../../../assets/icons/info.svg";
import {
  Button,
  Dropdown,
  TextField,
} from "../../../../components/@subzero/glacier/package/lib/components";
import "./index.css";
import AgGridTable from "../../../../components/aggridtable";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../../store/rootActions";
import Customdropdown from "../../../../components/customdropdown";
import AlertPopup from "../../../../components/alertPopup/alertPopup";
import { useStaticState } from "@material-ui/pickers";

const useStyles = makeStyles({
  root: {
    background: "#F9F9F9",
    borderRadius: "8px",
    marginTop: "16px",
  },
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
  dropdown: {
    "& .Dropdown_show__21pcz": {
      position: "absolute",
      zIndex: "999",
    },
  },
});

const AdditionalDetails = (props) => {
  const classes = useStyles();
  const dispatch = useDispatch();
  const authData = JSON.parse(localStorage.getItem("authData"));
  const [openModal, setOPenModal] = React.useState(props.open);
  const [invoiceDetails, setInvoiceDetails] = useState([]);
  const [rowData, setRowData] = useState(props?.data);
  const [buttonClick, setButtonClick] = useState(false);
  const [goodsOrigin, setGoodsOrigin] = useState({
    id: "US",
    label: "UNITED STATES",
  });
  const [hsCode, setHsCode] = useState({ id: "", label: "" });
  const [notifyPartyCountry, setNotifyPartyCountry] = useState({
    id: "US",
    label: "UNITED STATES",
  });
  const state = useSelector((state) => state);
  const recKey = useSelector((state) => state?.transactionDetails?.recKey);
  const [response, setResponse] = useState(
    useSelector((state) => state?.transactionDetails?.additionalDetails)
  );
  const paperless = authData?.docUploadWaiver === "Paperless" ? true : false;
  const [alert, setAlert] = useState({
    alertMsg: "Fill out the mandatory fields",
    alertType: "warn",
    isAlertOpen: false,
  });
  const transactionDetailsState = useSelector(
    (state) => state?.transactionDetails
  );
  const [detailsCount, setDetailsCount] = useState(0);
  const [errMsg, setErrMsg] = useState("");
  const toggleDrawer = (open) => (event) => {
    if (
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }
    props.onClose();
  };

  const getCountryDropdownOptions = () => {
    const req = {
      userId: authData.userId,
      corpId: authData.corpId,
      bankCode: authData?.bankCode,
    };
    dispatch(Actions.getBenefCountryDropdown(req));
  };

  const getHSCode = () => {
    const req = {
      userId: authData.userId,
      customerId: transactionDetailsState?.custIdAndIeCode?.custId || authData?.subcustId,
      accountNumber: "",
      bankCode: authData?.bankCode,
      ieCode: transactionDetailsState?.custIdAndIeCode?.ieCode || authData?.ieCode,
    };
    dispatch(Actions.getHSCodes(req));
  };

  const fetchOptionFromValue = (value) => {
    if (value.includes("-")) {
      value = value.split("-")[0]?.trim();
    }
    return state?.boe?.benefCountryOptions?.find((item) => {
      return item.id === value;
    });
  };

  const setupDropDownValue = (data) => {
    if (data.goodsOrigin) {
      const dropdownValue = fetchOptionFromValue(data.goodsOrigin);
      setGoodsOrigin(dropdownValue);
    } else {
      setGoodsOrigin({ id: "", label: "" });
    }
    if (data.notifyPartyCountry) {
      const dropdownValue = fetchOptionFromValue(data.notifyPartyCountry);
      setNotifyPartyCountry(dropdownValue);
    } else {
      setNotifyPartyCountry({ id: "", label: "" });
    }
    if (data.hsCode) {
      const dropdownValue = state?.transactionDetails?.hsCode?.hsCodes?.find(
        (item) => {
          return item.id === data.hsCode;
        }
      );
      if (dropdownValue) {
        setHsCode(dropdownValue);
      } else {
        setHsCode({ id: data.hsCode, label: data.hsCode });
      }
    } else {
      setHsCode({ id: "", label: "" });
    }
  };

  const headCells = [
    { field: "invoiceNumber", label: "Invoice No. *", smallCell: true },
    {
      field: "invoiceDate",
      label: "Invoice Date *",
      dateField: true,
      sortable: false,
    },
    { field: "invoiceCurrency", label: "Currency", minWidth: 100 },
    { field: "invoiceAmount", label: "Invoice Amount - FOB", minWidth: 170 , rightAligned: true},
    {
      field: "outstandingAmount",
      label: "O/S Invoice Amount - FOB",
      minWidth: 200,
      rightAligned: true
    },
    {
      field: "outstandingCharges",
      label: "O/S Charges (Optional)",
      minWidth: 180,
      rightAligned: true
    },
    {
      field: "invoicePayableAmount",
      label: "Invoice Payable Amount *",
      numberField: true,
      sortable: false,
    },
    {
      field: "chargesPayableAmount",
      label: "Charges Payable Amount *",
      numberField: true,
      sortable: false,
    },
  ];

  function createData(
    id,
    invoiceNumber,
    invoiceDate,
    invoiceCurrency,
    invoiceAmount,
    outstandingAmount,
    outstandingCharges,
    invoicePayableAmount,
    chargesPayableAmount,
    masterAwbBLDate,
    invoiceCharges
  ) {
    return {
      id,
      invoiceNumber,
      invoiceDate,
      invoiceCurrency,
      invoiceAmount,
      outstandingAmount,
      outstandingCharges,
      invoicePayableAmount,
      chargesPayableAmount,
      masterAwbBLDate,
      invoiceCharges
    };
  }

  const getRows = () => {
    if (response?.invoiceDetails?.length > 0) {
      return response?.invoiceDetails?.map((resp) => {
        const {
          id,
          invoiceNumber,
          invoiceDate,
          invoiceCurrency,
          invoiceAmount,
          outstandingAmount,
          outstandingCharges,
          invoicePayableAmount,
          chargesPayableAmount,
          masterAwbBLDate,
          invoiceCharges
        } = resp;
        return createData(
          id,
          invoiceNumber,
          invoiceDate,
          invoiceCurrency,
          invoiceAmount,
          outstandingAmount,
          outstandingCharges,
          invoicePayableAmount,
          chargesPayableAmount,
          masterAwbBLDate,
          invoiceCharges
        );
      });
    } else {
      return [];
    }
  };

  const handleUserInput = (val, id, field, data) => {
    const resp = response;
    let msg = "";
    if (field === "invoicePayableAmount") {
      if (val === "") {
        msg = "Invoice Payable Amount is a mandatory field";
      } /* else if (Number(val) > data?.outstandingAmount?.value) {
        msg =
          "Invoice Payable amount should not be more than Outstanding Amount (FOB).";
      } */
    } else if (field === "invoiceDate") {
      if (data?.invoiceDate?.value && data?.masterAwbBLDate?.value) {
        const invdate = data?.invoiceDate?.value;
        const datearray = invdate.split("/");
        const invNewdate =
          datearray[1] + "/" + datearray[0] + "/" + datearray[2];
        const masterdate = data?.masterAwbBLDate?.value;
        const masterDatearray = masterdate.split("/");
        const masterNewdate =
          masterDatearray[1] +
          "/" +
          masterDatearray[0] +
          "/" +
          masterDatearray[2];
        if (new Date(invNewdate) > new Date(masterNewdate))
          msg = "Invoice Date should be less the Master AWB/BL date";
      }
    } else if (field === "chargesPayableAmount") {
      if (val === "") {
        msg = "Charges Payable Amount is a mandatory field";
      } else if (Number(val) > data?.outstandingCharges?.value) {
        msg =
          "Charges Payable amount should not be more than Outstanding Charges.";
      }
    }
    if (msg !== "") {
      setTimeout(() => {
        setAlert((prev) => ({
          ...prev,
          alertMsg: msg,
          isAlertOpen: true,
        }));
      }, 50);
    }
    resp?.invoiceDetails?.map((item, index) => {
      if (item.invoiceNumber === data.invoiceNumber.value) {
        if (["invoicePayableAmount", "chargesPayableAmount"].includes(field)) {
          item[field] = Number(val);
        } else {
          item[field] = val;
        }
      }
      return item;
    });
    setResponse(resp);
  };

  const [fieldsToBeValidated, setFieldsToBeValidated] = useState({
    modeOfShipment: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: false,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    flightNumber: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: false,
      mandatoryBasedOnCondition: "response?.modeOfShipment === 'Airways'",
      validationFailed: false,
    },
    blAwbCarrierName: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: false,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    vesselNumber: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: false,
      mandatoryBasedOnCondition: "response?.modeOfShipment === 'Seaways'",
      validationFailed: false,
    },
    goodsOrigin: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: false,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
    hsCode: {
      mandatoryOnPaperless: true,
      mandatoryOnFastProcessing: true,
      mandatoryOnStandardProcessing: true,
      mandatoryBasedOnCondition: "",
      validationFailed: false,
    },
  });

  const checkFieldValidationNeeded = (item) => {
    let includeField = false;
    if (fieldsToBeValidated[item]) {
      if (paperless) {
        includeField = fieldsToBeValidated[item].mandatoryOnPaperless;
      } else {
        if (!transactionDetailsState?.standardProcessing) {
          includeField = fieldsToBeValidated[item].mandatoryOnFastProcessing;
        } else {
          includeField =
            fieldsToBeValidated[item].mandatoryOnStandardProcessing;
        }
      }
      if (includeField) {
        if (fieldsToBeValidated[item].mandatoryBasedOnCondition !== "") {
          includeField = eval(
            fieldsToBeValidated[item].mandatoryBasedOnCondition
          );
        }
      }
    }
    return includeField;
  };

  const validateAdditionalDetailsFields = () => {
    let validationStatus = true;
    const filteredFields = Object.keys(fieldsToBeValidated)?.filter((item) => {
      return checkFieldValidationNeeded(item);
    });
    filteredFields.forEach((item) => {
      if (!response[item]) {
        const newChange = { ...fieldsToBeValidated };
        newChange[item].validationFailed = true;
        setFieldsToBeValidated(newChange);
        validationStatus = false;
      }
    });
    if (state?.transactionDetails?.OFACCheck !== "Success") {
      setTimeout(() => {
        setAlert({
          alertMsg:
            "Country pertains to OFAC comprehensive list, hence transaction is not allowed",
          alertType: "warn",
          isAlertOpen: true,
        });
      }, 50);
      validationStatus = false;
    }
    return validationStatus;
  };

  const validateGridField = () => {
    let msg = "";
    let validateStatus = true;
    response?.invoiceDetails?.forEach((item) => {
      const utlizedAmt =
        transactionDetailsState?.utilizedAmount?.filter((x) => {
          return x.invoiceNo === item.invoiceNumber;
        })?.[0]?.utlisedAmount || 0;
      if (!item?.invoiceDate) {
        msg = "Invoice Date is a mandatory field";
      } else if (
        item?.invoicePayableAmount !== 0 &&
        !item?.invoicePayableAmount
      ) {
        msg = "Invoice Payable Amount is a mandatory field";
      } else if (
        item?.chargesPayableAmount !== 0 &&
        !item?.chargesPayableAmount
      ) {
        msg = "Charges Payable Amount is a mandatory field";
      } /* else if (item?.invoicePayableAmount > item?.outstandingAmount) {
        msg =
          "Invoice Payable amount should not be more than Outstanding Amount (FOB)";
      } */ else if (item?.chargesPayableAmount > item?.outstandingCharges) {
        msg =
          "Charges Payable amount should not be more than Outstanding Charges";
      } else if (
        !(item?.invoicePayableAmount <= item?.invoiceAmount * 1.05 - utlizedAmt)
      ) {
        msg = "Invoice payable amount cannot be greater than 105%";
      } else if (item?.invoiceDate && item?.masterAwbBLDate) {
        const invdate = item?.invoiceDate;
        const datearray = invdate.split("/");
        const invNewdate =
          datearray[1] + "/" + datearray[0] + "/" + datearray[2];
        const masterdate = item?.masterAwbBLDate;
        const masterDatearray = masterdate.split("/");
        const masterNewdate =
          masterDatearray[1] +
          "/" +
          masterDatearray[0] +
          "/" +
          masterDatearray[2];
        if (new Date(invNewdate) > new Date(masterNewdate))
          msg = "Invoice Date should be less the Master AWB/BL date";
      }
    });
    if (msg !== "") {
      validateStatus = false;
      setTimeout(() => {
        setAlert({
          alertType: "warn",
          alertMsg: msg,
          isAlertOpen: true,
        });
      }, 50);
    }
    return validateStatus;
  };

  const generateTableRowValues = () => {
    const rows = getRows();
    let newArray = [...rows];
    let resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        let value = rowItem[key];
        switch (key) {
          case "invoiceNumber":
          case "invoiceCurrency":
            return (newObject[key] = { value: value, smallCell: true });
          case "invoiceDate":
          case "invoicePayableAmount":
          case "chargesPayableAmount":
            return (newObject[key] = {
              value: value,
              textInput: true,
              handleUserInput: handleUserInput,
              showToast: showToast,
            });
          default:
            return (newObject[key] = { value: value });
        }
      });
      resultArray.push(newObject);
      return rowItem;
    });
    setInvoiceDetails(resultArray);
  };

  const getAddDetails = () => {
    if (rowData?.boeNumber) {
      let req = {
        boeNumber: [rowData?.boeNumber],
        currency: rowData?.invoiceCurrency,
        corpId: authData?.corpId,
        bankCode: authData?.bankCode,
        recKey: recKey ? recKey : null,
        ieCode: transactionDetailsState?.custIdAndIeCode?.ieCode || authData?.ieCode,
        customerId: transactionDetailsState?.custIdAndIeCode?.custId || authData?.subcustId,
      };
      if (rowData?.UpdateBtn) {
        req = {
          boeNumber: [rowData?.boeNumber],
          currency: rowData?.invoiceCurrency,
          corpId: authData?.corpId,
          customerId: transactionDetailsState?.custIdAndIeCode?.custId || authData?.subcustId,
          bankCode: authData?.bankCode,
          recKey: recKey,
          ieCode: transactionDetailsState?.custIdAndIeCode?.ieCode || authData?.ieCode,
        };
        dispatch(Actions.getUpdatedAddDetails(req));
      } else dispatch(Actions.getAddDetails(req));
    }
  };

  const fetchUtilizedAmount = (data) => {
    if (data?.boeNumber && transactionDetailsState?.currency) {
      const req = {
        customerId: transactionDetailsState?.custIdAndIeCode?.custId || authData?.subcustId,
        boeNumber: data?.boeNumber,
        supplierName: data?.supplierName,
        invoiceCurrency: transactionDetailsState?.currency,
      };
      dispatch(Actions.fetchUtilizedAmount(req));
    }
  };

  const setFieldValidation = (val, keyName) => {
    const newChange = { ...fieldsToBeValidated };
    if (checkFieldValidationNeeded(keyName)) {
      if (val === "") {
        newChange[keyName].validationFailed = true;
      } else {
        newChange[keyName].validationFailed = false;
      }
    } else {
      if (newChange[keyName]) {
        newChange[keyName].validationFailed = false;
      }
    }
    if (keyName === "modeOfShipment") {
      newChange.flightNumber.validationFailed = false;
    }
    if (["goodsOrigin", "notifyPartyCountry"].includes(keyName)) {
      dispatch(Actions.OFACCountryCheck({ countryCode: val }));
    }
    setFieldsToBeValidated(newChange);
  };

  const showToast = (msg) => {
    setAlert({
      ...alert,
      alertMsg: msg,
      isAlertOpen: true,
    });
  };

  useEffect(() => {
    if (state?.transactionDetails?.OFACCheck !== "Success") {
      setAlert({
        alertMsg:
          "Country pertains to OFAC comprehensive list, hence transaction is not allowed",
        alertType: "warn",
        isAlertOpen: true,
      });
    }
  }, [state?.transactionDetails?.OFACCheck]);

  const onChangeHandler = (value, keyName) => {
    value = typeof value === "object" ? value?.id : value;
    setFieldValidation(value, keyName);
    const resp = response;
    if (keyName === "hsCode") {
      const hsCodeValue = state?.transactionDetails?.hsCode?.hsCodes?.find(
        (x) => {
          return x.id === value;
        }
      );
      if (hsCodeValue) {
        setHsCode(hsCodeValue);
      } else if (value === "") {
        setHsCode({ id: "", label: "" });
      } else {
        setHsCode({ id: value, label: value });
      }
      const desc = state?.transactionDetails?.hsCode?.hsnDescriptions?.find(
        (x) => {
          return x.label === value;
        }
      )?.id;
      resp["goodsDescription"] = desc || "";
    } else if (["goodsOrigin", "notifyPartyCountry"].includes(keyName)) {
      let countryValue = state?.boe?.benefCountryOptions?.find((x) => {
        return x.id === value;
      });
      if (!countryValue) {
        countryValue = state?.boe?.benefCountryOptions?.find((x) => {
          return x.label === value;
        });
        if (countryValue) {
          value = countryValue.id;
        }
      }
      if (countryValue) {
        keyName === "goodsOrigin"
          ? setGoodsOrigin(countryValue)
          : setNotifyPartyCountry(countryValue);
      } else if (value === "") {
        keyName === "goodsOrigin"
          ? setGoodsOrigin({ id: "", label: "" })
          : setNotifyPartyCountry({ id: "", label: "" });
      } else {
        keyName === "goodsOrigin"
          ? setGoodsOrigin({ id: value, label: value })
          : setNotifyPartyCountry({ id: value, label: value });
      }
    }
    resp[keyName] = value;
    setResponse(resp);
  };

  const onTextFieldChange = (event, keyName) => {
    setFieldValidation(event.target.value, keyName);
    const resp = response;
    resp[keyName] = event.target.value;
    setResponse(resp);
  };

  const onSaveHandler = () => {
    setButtonClick(false)
    if (validateAdditionalDetailsFields() && validateGridField()) {
      const req = {
        ...response,
        recKey: recKey ? recKey : null,
        bankCode: authData.bankCode,
        modeOfProcess: props?.modeOFProcess ? "YES" : "NO",
        goodsType: props?.typesOfGood ? "CAPITAL" : "NON-CAPITAL",
        customerId: transactionDetailsState?.custIdAndIeCode?.custId || authData?.subcustId,
        invoiceRequests: response.invoiceDetails,
      };
      delete req.invoiceDetails;
      dispatch(Actions.saveAddDetails(req));
      props.onClose();
    } else {
      setAlert({
        ...alert,
        alertMsg: "Fill out the mandatory fields",
        isAlertOpen: true,
      });
    }
  };

  const saveHandler = () => {
    setErrMsg("");
    setButtonClick(true);
    if(validateAdditionalDetailsFields()){
      if(response?.invoiceDetails?.length > 0){
        setDetailsCount(response?.invoiceDetails?.length)
        response?.invoiceDetails?.map((item) => {
          const req = {
            invoiceNumber : item?.invoiceNumber, 
            invoiceAmount: item?.invoiceAmount, 
            outstandingAmount: item?.outstandingAmount, 
            invoicePayableAmount: item?.invoicePayableAmount, 
            chargesPayableAmount: item?.chargesPayableAmount 
          }
          dispatch(Actions.totalAmountValidation(req));
        });
      }else{
        onSaveHandler();
      }
    }
  }

  const clearValidations = () => {
    Object.keys(fieldsToBeValidated)?.forEach((item) => {
      fieldsToBeValidated[item].validationFailed = false;
    });
  };

  useEffect(() => {
    getCountryDropdownOptions();
    getHSCode();
  }, []);

  useEffect(() => {
    setOPenModal(props.open);
    if (props.open) {
      setHsCode({ id: "", label: "" });
      setRowData(props?.data);
      // getAddDetails();
      clearValidations();
    }
  }, [props.open]);

  useEffect(() => {
    setResponse(state?.transactionDetails?.additionalDetails);
    setupDropDownValue(state?.transactionDetails?.additionalDetails);
    generateTableRowValues();
    if (state?.transactionDetails?.additionalDetails)
      fetchUtilizedAmount(state?.transactionDetails?.additionalDetails);
  }, [state?.transactionDetails?.additionalDetails]);

  useEffect(() => {
    const resp = response;
    let changed = false;
    if (resp?.invoiceDetails?.length > 0) {
      resp?.invoiceDetails?.forEach((item) => {
        if (item?.invoicePayableAmount === 0) {
          item.invoicePayableAmount = item.outstandingAmount
            ? item.invoiceCurrency === "JPY"
              ? parseInt(Number(item.outstandingAmount))
              : item.outstandingAmount
            : item.invoicePayableAmount;
          changed = true;
        }
        if (item?.chargesPayableAmount === 0) {
          item.chargesPayableAmount = item.outstandingCharges
            ? item.invoiceCurrency === "JPY"
              ? parseInt(Number(item.outstandingCharges))
              : item.outstandingCharges
            : item.chargesPayableAmount;
          changed = true;
        }
        if (!item?.invoiceDate && authData?.appDate) {
          item.invoiceDate = `${new Date(authData.appDate).getDate()}/${
            new Date(authData.appDate).getMonth() + 1
          }/${new Date(authData.appDate).getFullYear()}`;
          changed = true;
        }
        return item;
      });
      if (changed) setResponse(resp);
      generateTableRowValues();
    }
  }, [response?.invoiceDetails]);

  useEffect(() => {
    getAddDetails();
    generateTableRowValues();
    if(transactionDetailsState?.custIdAndIeCode?.custId && 
      transactionDetailsState?.custIdAndIeCode?.custId !== authData?.subcustId){
      getHSCode();
    }
  }, [rowData]);

  useEffect(() => {
    setResponse(response);
  }, [response]);

  useEffect(()=> {
    if(state?.transactionDetails?.totalAmountValidation && buttonClick){
      if(state?.transactionDetails?.totalAmountValidation?.statusMessage !== "Success"){
        setErrMsg(state?.transactionDetails?.totalAmountValidation?.statusMessage);
        setAlert({
          ...alert,
          alertMsg: state?.transactionDetails?.totalAmountValidation?.statusMessage,
          isAlertOpen: true,
        });
      }
      setDetailsCount(detailsCount - 1)
    }
  },[state?.transactionDetails?.totalAmountValidation])

  useEffect(() => {
    if(errMsg === "" && detailsCount === 0 && buttonClick){
      onSaveHandler();
    }
  }, [errMsg, detailsCount])

  return (
    <>
      <Drawer
        classes={{
          paper: classes.paper,
        }}
        anchor={"bottom"}
        open={openModal}
        onClose={toggleDrawer(false)}
      >
        <div onClick={toggleDrawer(false)} className="close">
          <img src={CloseIcon} className="close-icon" />
        </div>
        <div className="details-container add-details-container">
          <span className="heading-details">Additional Details</span>
          <div className="border-container">
            <span className="details-heading">BOE Details</span>
            <Grid spacing={3} className="details-containers" container>
              <Grid className="sub-detail-container" item lg={2} sm={4} xs={6}>
                <span className="detail-heading">BOE Number</span>
                <span className="detail-content">{response?.boeNumber}</span>
              </Grid>
              <Grid className="sub-detail-container" item lg={4} sm={4} xs={6}>
                <span className="detail-heading">Supplier Name (Optional)</span>
                <span className="detail-content">{response?.supplierName}</span>
              </Grid>
              <Grid className="sub-detail-container" item lg={2} sm={4} xs={6}>
                <span className="detail-heading">BOE Date</span>
                <span className="detail-content">{response?.boeDate}</span>
              </Grid>
              <Grid className="sub-detail-container" item lg={2} sm={4} xs={6}>
                <span className="detail-heading">Amount</span>
                <span className="detail-content">
                  {`${rowData?.invoiceCurrency} ${
                    response?.invoiceAmount ? response?.invoiceAmount : 0
                  }`}
                </span>
              </Grid>
              <Grid className="sub-detail-container" item lg={2} sm={8} xs={12}>
                <span className="detail-heading">O/S Amount</span>
                <span className="detail-content">
                  {`${rowData?.invoiceCurrency} ${
                    response?.outstandingAmount
                      ? response?.outstandingAmount
                      : 0
                  }`}
                </span>
              </Grid>
            </Grid>
          </div>
          <div className="border-container">
            <span className="details-heading">Goods Details</span>
            <Grid spacing={2} className="details-containers" container>
              <Grid
                className="sub-detail-container countrySelect"
                style={{ display: " block" }}
                item
                lg={4}
                sm={6}
                xs={12}
              >
                <Customdropdown
                  name="HS Code *"
                  isMulti={false}
                  selectedOptions={hsCode}
                  onSelectOptions={(selOptions) => {
                    onChangeHandler(selOptions, "hsCode");
                  }}
                  style={{ marginTop: "0px" }}
                  options={state?.transactionDetails?.hsCode?.hsCodes || []}
                  listFromAPI={true}
                  max={8}
                  error={fieldsToBeValidated?.hsCode?.validationFailed}
                  errorText={"Mandatory Field"}
                  onBlur={(val) => {
                    if (!val?.match(/^[a-z0-9]+$/i) && val !== "") {
                      val = "";
                    }
                    onChangeHandler(val, "hsCode");
                  }}
                />
              </Grid>
              <Grid className="sub-detail-container" item lg={4} sm={6} xs={12}>
                <TextField
                  label="Goods Description (Optional)"
                  name="Goods Description (Optional)"
                  type="text"
                  variant="filled"
                  maxLength={100}
                  value={response?.goodsDescription}
                  name="goodsDescription"
                  onBlur={(e) => {
                    if (
                      !e.target.value?.match(/^[ a-z0-9]+$/i) &&
                      e.target.value !== ""
                    ) {
                      e.target.value = "";
                    }
                    onTextFieldChange(e, "goodsDescription");
                  }}
                  onChange={(e) => {
                    if (
                      !e.target.value?.match(/^[ a-z0-9]+$/i) &&
                      e.target.value !== ""
                    ) {
                      e.target.value = e.target.value?.slice(0, -1);
                    }
                    onTextFieldChange(e, "goodsDescription");
                  }}
                />
              </Grid>
              <Grid
                className="sub-detail-container countrySelect"
                style={{ display: " block" }}
                item
                lg={4}
                sm={6}
                xs={12}
              >
                {(paperless || !transactionDetailsState.standardProcessing) && (
                  <Customdropdown
                    name="Origin of Goods *"
                    isMulti={false}
                    selectedOptions={goodsOrigin}
                    onSelectOptions={(selOptions) => {
                      onChangeHandler(selOptions, "goodsOrigin");
                    }}
                    style={{ marginTop: "0px" }}
                    options={state?.boe?.benefCountryOptions}
                    listFromAPI={true}
                    error={fieldsToBeValidated?.goodsOrigin?.validationFailed}
                    errorText={"Mandatory Field"}
                    max={2}
                    onBlur={(val) => {
                      val = val?.split("-")[0]?.trim();
                      if (!val?.match(/^[ a-z0-9]+$/i) && val !== "") {
                        val = "";
                      }
                      onChangeHandler(val, "goodsOrigin");
                    }}
                    ignoreSpecialChars={true}
                    fetchOptions={(val) => {
                      val = val?.split("-")[0]?.trim();
                      if (!val?.match(/^[ a-z0-9]+$/i) && val !== "") {
                        val = val?.slice(0, -1);
                      }
                    }}
                  />
                )}
              </Grid>
            </Grid>
          </div>
          {(paperless || !transactionDetailsState.standardProcessing) && (
            <div className="border-container">
              <span className="details-heading">Shipping Details</span>
              <Grid spacing={2} className="details-containers" container>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                  id="moSField"
                >
                  <Dropdown
                    label={"Mode of Shipment *"}
                    defaultValue={response?.modeOfShipment || ""}
                    items={["Airways", "Seaways"]}
                    variant="filled"
                    name="Mode of Shipment"
                    fullWidth
                    error={
                      fieldsToBeValidated?.modeOfShipment?.validationFailed
                    }
                    errorMsg={"Mandatory Field"}
                    name="modeOfShipment"
                    onChange={(val) => {
                      onChangeHandler(val, "modeOfShipment");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  {response?.modeOfShipment === "Airways" && (
                    <TextField
                      label="Flight Number *"
                      type="text"
                      variant="filled"
                      name="flightNumber"
                      value={response?.flightNumber}
                      error={
                        fieldsToBeValidated?.flightNumber?.validationFailed
                      }
                      errorMessage={"Mandatory Field"}
                      maxLength={50}
                      onBlur={(e) => {
                        onTextFieldChange(e, "flightNumber");
                      }}
                    />
                  )}
                </Grid>
                <Grid
                  item
                  lg={4}
                  sm={0}
                  xs={0}
                  style={{padding: '0px'}}
                ></Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="BL/AWB Carrier Name *"
                    type="text"
                    variant="filled"
                    value={response?.blAwbCarrierName}
                    name="blAwbCarrierName"
                    error={
                      fieldsToBeValidated?.blAwbCarrierName?.validationFailed
                    }
                    errorMessage={"Mandatory Field"}
                    maxLength={80}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "blAwbCarrierName");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "blAwbCarrierName");
                    }}
                  />
                </Grid>

                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="BL/AWB Agent (Optional)"
                    type="text"
                    variant="filled"
                    value={response?.blAwbAgent}
                    name="blAwbAgent"
                    maxLength={80}
                    onBlur={(e) => {
                      onTextFieldChange(e, "blAwbAgent");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="Place of Issue of Transport Document"
                    type="text"
                    variant="filled"
                    value={response?.placeOfTransportIssue}
                    name="placeOfTransportIssue"
                    maxLength={80}
                    onBlur={(e) => {
                      onTextFieldChange(e, "placeOfTransportIssue");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="Voyage Number (Optional) "
                    type="text"
                    variant="filled"
                    value={response?.voyageNumber}
                    name="voyageNumber"
                    maxLength={15}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "voyageNumber");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "voyageNumber");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label={`Vessel Name${
                      response?.modeOfShipment === "Seaways" ? " *" : ""
                    }`}
                    type="text"
                    variant="filled"
                    value={response?.vesselNumber}
                    name="vesselNumber"
                    error={fieldsToBeValidated?.vesselNumber?.validationFailed}
                    errorMessage={"Mandatory Field"}
                    maxLength={35}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "vesselNumber");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "vesselNumber");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="Nationality of Ship Flag (Optional)"
                    type="text"
                    variant="filled"
                    value={response?.nationalityOfShipmentFlag}
                    name="nationalityOfShipmentFlag"
                    maxLength={80}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "nationalityOfShipmentFlag");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "nationalityOfShipmentFlag");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                  id="charterOwnerPartyNameText"
                >
                  <TextField
                    label="Charter/Owner Party Name(Optional)"
                    type="text"
                    variant="filled"
                    value={response?.charterOwnerPartyName}
                    name="charterOwnerPartyName"
                    maxLength={80}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "charterOwnerPartyName");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "charterOwnerPartyName");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="Transhipment Place (Optional)"
                    type="text"
                    variant="filled"
                    value={response?.transhipmentPlace}
                    name="transhipmentPlace"
                    maxLength={80}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "transhipmentPlace");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "transhipmentPlace");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="Transhipment Vessel (Optional)"
                    type="text"
                    variant="filled"
                    value={response?.transhipmentVessel}
                    name="transhipmentVessel"
                    maxLength={80}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "transhipmentVessel");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "transhipmentVessel");
                    }}
                  />
                </Grid>
              </Grid>
            </div>
          )}

          {(paperless || !transactionDetailsState.standardProcessing) && (
            <div className="border-container">
              <span className="details-heading">
                Notify Party Details (Optional)
              </span>
              <Grid spacing={2} className="details-containers" container>
                <Grid
                  className="sub-detail-container"
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <TextField
                    label="Name"
                    type="text"
                    variant="filled"
                    value={response?.notifyPartyName}
                    name="notifyPartyName"
                    maxLength={50}
                    onChange={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = e.target.value?.slice(0, -1);
                      }
                      onTextFieldChange(e, "notifyPartyName");
                    }}
                    onBlur={(e) => {
                      if (
                        !e.target.value?.match(/^[a-z0-9]+$/i) &&
                        e.target.value !== ""
                      ) {
                        e.target.value = "";
                      }
                      onTextFieldChange(e, "notifyPartyName");
                    }}
                  />
                </Grid>
                <Grid
                  className="sub-detail-container countrySelect"
                  style={{ display: " block" }}
                  item
                  lg={4}
                  sm={6}
                  xs={12}
                >
                  <Customdropdown
                    name="Country"
                    isMulti={false}
                    selectedOptions={notifyPartyCountry}
                    onSelectOptions={(selOptions) => {
                      onChangeHandler(selOptions, "notifyPartyCountry");
                    }}
                    style={{ marginTop: "0px" }}
                    options={state?.boe?.benefCountryOptions}
                    listFromAPI={true}
                    onBlur={(val) => {
                      val = val?.split("-")[0]?.trim();
                      if (!val?.match(/^[ a-z0-9]+$/i) && val !== "") {
                        val = "";
                      }
                      onChangeHandler(val, "notifyPartyCountry");
                    }}
                    fetchOptions={(val) => {
                      val = val?.split("-")[0]?.trim();
                      if (!val?.match(/^[ a-z0-9]+$/i) && val !== "") {
                        val = val?.slice(0, -1);
                      }
                    }}
                    max={2}
                    ignoreSpecialChars={true}
                  />
                </Grid>
              </Grid>
            </div>
          )}
          <div>
            <div className="border-container input-bt-padding-14">
              <span className="details-heading">Invoice Details</span>
              <div className="row-container">
                <span className="info-text">
                  All amounts are in invoice currency
                </span>
                <div className="info-container">
                  <img src={InfoIcon} />
                  <span className="warning-text">
                    Aggregate Payable Amount greater than 105% of Invoice Amount
                  </span>
                </div>
              </div>
              <AgGridTable
                tableOnly
                rows={invoiceDetails}
                headCells={headCells}
                noRowSelection={true}
                hideActionIcon={true}
                autoSize={true}
              />
              <span className="note">
                *Charges calculated based on the card rate, they may vary.
              </span>
            </div>
          </div>
        </div>
        <div className="close-container">
          <Button color="secondary" onClick={toggleDrawer(false)} className="cancelBtn">
            Cancel
          </Button>
          <Button onClick={saveHandler} className="proceedBtn">Save</Button>
        </div>
        <AlertPopup
          {...alert}
          onClose={() => {
            setAlert({ ...alert, isAlertOpen: false });
          }}
        />
      </Drawer>
    </>
  );
};

export default AdditionalDetails;
