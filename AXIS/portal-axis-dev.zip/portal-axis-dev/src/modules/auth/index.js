import React, { useEffect, useState } from "react";
import {
  TextField,
  Button,
} from "../../components/@subzero/glacier/package/lib/components";
import CustomModal from "../../components/modal";
import "./index.css";
import { useHistory } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../store/rootActions";

const Login = (props) => {
  const dispatch = useDispatch();
  const history = useHistory();
  const [userId, updateUserId] = useState("");
  const [corporateId, updateCorporateId] = useState("");
  const [password, updatePassword] = useState("");
  const state = useSelector((state) => state?.auth);

  useEffect(() => {
    const query = props.location.search;
    const queryParam = query.slice(0, 9);
    const encodedCredential = query.slice(9);
    if (queryParam === "?fidbenc=") {
      const decodedMessage = atob(encodedCredential);
      const credentials = decodedMessage.split(",");

      if (credentials.length === 3) {
        const request = {
          corpId: credentials[0].split("corpId:")[1],
          userId: credentials[1].split("userId:")[1],
          password: credentials[2].split("password:")[1],
        };
        dispatch(Actions.requestLogin(request));
      }
    }
  }, []);

  const handleReset = () => {
    updateCorporateId("");
    updateUserId("");
    updatePassword("");
  };

  useEffect(() => {
    if (state?.loginSuccess === true) {
      history.push("/dashboard");
    }
    // if(state?.loginSuccess === false){
    //     alert("Invalid credentials")
    // }
  }, [state]);

  const handleSubmit = () => {
    if (userId && corporateId) {
      const request = {
        corpId: corporateId,
        userId: userId,
        password: password,
      };
      dispatch(Actions.requestLogin(request));
    }
  };

  return (
    <>
      <CustomModal
        showModal={true}
        closeModal={() => {
          console.log(false);
        }}
      >
        <div className="login-box">
          <h3>Login</h3>

          <TextField
            label="Corporate Id"
            value={corporateId}
            type="text"
            variant="filled"
            required
            fullWidth
            onChange={(e) => {
              updateCorporateId(e.target.value);
            }}
          />

          <TextField
            label="User Id"
            value={userId}
            type="text"
            variant="filled"
            fullWidth
            onChange={(e) => {
              updateUserId(e.target.value);
            }}
          />

          <TextField
            label="Password"
            value={password}
            type="password"
            variant="filled"
            fullWidth
            onChange={(e) => {
              updatePassword(e.target.value);
            }}
          />

          <div className="login-buttons">
            <Button color="secondary" onClick={handleReset}>
              Reset
            </Button>
            <Button color="primary" onClick={handleSubmit}>
              Login
            </Button>
          </div>
          {state?.loginSuccess === false && (
            <span
              style={{
                color: "red",
                margin: "10px 0px",
                display: "flex",
                justifyContent: "center",
              }}
            >
              Please enter valid credentials
            </span>
          )}
        </div>
      </CustomModal>
    </>
  );
};

export default Login;
