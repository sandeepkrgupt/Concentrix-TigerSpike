/* eslint-disable import/first */
/*eslint-disable */
import React from 'react';
import {Accordion, Breadcrumbs, Button, Card,
     Checkbox, CheckboxList, Divider,
      Chip,
       Datepicker,
        DigitalInput, Dropdown,
       FileUploader, Header, InputHelper, Link,
        Menu, ProgressIndicator, ProgressTracker,
        Radio, RadioList, Skrim, TextField, Toggle,Typography,YesNoSwitch
    } from '../../components/@subzero/glacier/package/lib/components';
// import { makeStyles } from '@material-ui/core/styles';

// const useStyles = makeStyles((theme) => ({

// }));
const Glacier = () => {
    // const classes = useStyles();
    return (
        <div style={{marginTop: "2%"}}>
            {/* <h1>Accordion</h1>
            <Accordion
            items={
                [
                    {
                        title: 'Accordion 1',
                        description: 'This is a sample accordion'
                    },
                    {
                        title: 'Accordion 2',
                        description: 'This is a sample accordion'
                    },
                    {
                        title: 'Accordion 3',
                        description: 'This is a sample accordion'
                    }
                ]
            }
            />
            <Divider/>
            <br/>
            <h1>Breadcrumbs</h1>
            <div>

            <Breadcrumbs
            maxItems={2}
            />
            </div>
            <Divider/>
            <br/>
            <h1>Button</h1>
            <Button
            color="secondary"
            // color="default"
            size="small"
            variant="text"
            // hasIconOnly
            withIcon
            // isFlushButton
            >
                Button
            </Button>
            <Divider/>
            <br/>
            <h1>Card</h1>
            <Card 
            assets="No"
            cardType="display"
            title="Card"
            content="content"
            subheader="Label"
            />
            <Card 
            assets="No"
            cardType="display"
            title="Card"
            type="extended"
            cardData={
                [
                    {
                        avatar:'A',
                        content:'Testing card'
                    }
                ]
            }
            content="content"
            subheader="Label"
            />
            <Divider/>
            <br/>
            <h1>Checkbox</h1>
            <Checkbox
            title="Checkbox"
            checked={true}
            // disabled
            />
            <Divider/>
            <br/>
            <h1>Checkbox List</h1>
            <CheckboxList
            title="Checkbox List"
            list={{
                items:[
                    {
                        label:'opt 1'
                    },
                    {
                        label:'opt 2'
                    }
                ]
            }}
            />
            <Divider/>
            <br/>
            <h1>Chip</h1>
            <Chip
            className={{root:{background: "red"}}}
            chipType="nudge"
            label="Make Payment"
            type="default"
            // variant="outlined"
            />
            <Divider/> */}
            <br/>
            {/* <h1>Date range picker</h1>
            <Datepicker
            label="Datepicker"
            placeholder="04/06/2021-04/06/2022"
            rangePicker={true}
            />
            <Divider/>
            <br/>
            <h1>Digital Input</h1>
            <DigitalInput
            length={4}
            size="small"
            // error
            />
            <Divider/>
            <br/> */}
             <h1>Textfield</h1>
            <TextField
            label="Textfield"
            // type="number"
            variant="filled"
            // value={null}
            maxLength={2}
            />
            <p >onclick</p>
            <h1>Toggle</h1>
            <Toggle
            buttonType="Selected"
            checked
            />
             <h1>Dropdown</h1>
            <Dropdown
            items={
                [
                    'Item 1',
                    'Item 2',
                    'Item 3',
                    'Item 4',
                    'Item 5',

                ]
            }
            label="Dropdown"
            placeholder="placeholder text"
            type="text"
            variant="filled"
            helperText="Hint"
            // onChange
            />
            <h1>Datepicker</h1>
            <Datepicker
                variant="filled"
                label="Datepicker"
                placeholder="04/05/2021"
            />
            <Divider/>
            <br/>
           
            <Divider/>
            <br/>
            {/* <h1>File Uploader</h1>
            <FileUploader
            type="image"
            value={50}
            // error
            />
              <Divider/>
              <br/>
            <h1>Header</h1>
            <Header
            size="medium"
            />
            <Divider/>
            <br/>
            <h1>Input helper</h1>
            <InputHelper
            inputValues={
                [
                    1000, 2000, 3000
                ]
            }
            label="Amount"
            prefix="$"
            placeholder="Text"
            />
            <Divider/>
            <br/>
            <h1>Link</h1>
            <Link
            // display="initial"
            to="/"
            inlineLink
            // active
            />
            <Divider/>
            <br/>
            <h1>Menu</h1>
            <Menu
            items={[
                {
                    title:'A',
                    value: 1
                },
                {
                    title:'B',
                    value: 2
                }
            ]}
            />
            <Divider/>
            <br/>
            <h1>Progress Indicator</h1>
            <ProgressIndicator
            type="progress"
            progressIndicatorType="step"
            progressStepLabel="progressing"
            value={50}
            />
            <Divider/>
            <br/>
            <h1>Progress Tracker</h1>
            <ProgressTracker
            open
            opened
            currentStep={1}
            steps={[
                {
                    status:'current',
                    title:'Verification',
                    variant:'first'
                },
                {
                    status:'unvisited',
                    title:'Verification - 1',
                    variant:'middle'
                }
            ]}
            />
            <Divider/>
            <br/>
            <h1>Radio</h1>
            <Radio
            label="Radio Option"
            checked={false}
            onChange={(e)=> console.log(e?.target?.checked)}
            />
            <Divider/>
            <br/>
            <h1>Radio List</h1>
            <RadioList
            list={{
                title:'RaDIO List',
                items:[
                    {
                        label:'Opt 1',
                        name:'opt',
                        value:1
                    },
                    {
                        label:'Opt 2',
                        name:'opt',
                        value:2
                    }
                ]    
            }
            }
            />
            <Divider/>
            <br/>
            <h1>Skrim</h1>
            <Skrim type="modal2" >
                <p style={{background:"red"}}>asjdkasdh</p>
            </Skrim>
            <Divider/>
            <br/>
            <h1>Textfield</h1>
            <TextField
            label="Textfield"
            placeholder="PLaceholder"
            type="text"
            variant="filled"
            adornmentStart="$"
            adornmentSuffix="Rupees only"
            helperText="Enter amount"

            />
            <Divider/>
            <br/>
            <h1>Toggle</h1>
            <Toggle
            buttonType="Selected"
            checked
            />
            <Divider/>
            <br/>
            <h1>Typography</h1>
            <Typography type="h1">
                Heading
            </Typography>
            <Typography type="subheading">
                Subheading
            </Typography>
            <Typography type="body-1"> 
                Body
            </Typography>
            <Typography type="subtitle">
                Subtitle
            </Typography>
            <Typography type="caption">
                Caption
            </Typography>
            <Typography type="helper">
                Helper
            </Typography>
            <Divider/>
            <br/>
            <h1>YesNoSwitch</h1>
            <YesNoSwitch
            defaultChecked
            /> */}

            </div>
    );
};

export default Glacier;