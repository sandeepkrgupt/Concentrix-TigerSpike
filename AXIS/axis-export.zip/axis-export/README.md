For development,staging,production like
npm run dev, npm run sta, npm run prod
The Build commands are,
npm run build-dev, npm run build:sta, npm run build:prod
