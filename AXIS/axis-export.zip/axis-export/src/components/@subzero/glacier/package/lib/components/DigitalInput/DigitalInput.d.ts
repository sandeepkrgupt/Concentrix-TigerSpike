/// <reference types="react" />
import { DigitalInputProps } from './DigitalInput.type';
declare function DigitalInput({ length, isNumberInput, size, disabled, onChange, error, ...rest }: DigitalInputProps): JSX.Element;
export default DigitalInput;
