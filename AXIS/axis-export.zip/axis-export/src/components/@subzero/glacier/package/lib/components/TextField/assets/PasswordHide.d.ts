/// <reference types="react" />
declare const PasswordHide: () => JSX.Element;
export default PasswordHide;
