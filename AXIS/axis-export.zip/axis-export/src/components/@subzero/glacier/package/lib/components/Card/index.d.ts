import Card from './Card';
import { CardProps } from './Card.type';
export type { CardProps };
export default Card;
