import Breadcrumbs from './Breadcrumbs';
import { BreadcrumbsProps } from './Breadcrumbs.type';
export type { BreadcrumbsProps };
export default Breadcrumbs;
