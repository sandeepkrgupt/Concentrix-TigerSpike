import { FC } from 'react';
import { BreadcrumbsProps } from './Breadcrumbs.type';
declare const BreadcrumbsComp: FC<BreadcrumbsProps>;
export default BreadcrumbsComp;
