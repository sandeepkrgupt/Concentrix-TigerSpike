import { FC } from 'react';
import { BreadcrumbsProps } from './Breadcrumbs.type';
declare const Breadcrumbs: FC<BreadcrumbsProps>;
export default Breadcrumbs;
