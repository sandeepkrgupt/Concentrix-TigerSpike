import { BreadcrumbsProps as MuiBreadcrumbsProps, BreadcrumbsClassKey } from '@material-ui/core/Breadcrumbs';
export interface BreadcrumbsStylingProps extends Partial<Record<BreadcrumbsClassKey, string>> {
}
export interface BreadcrumbsProps extends MuiBreadcrumbsProps {
    maxItems?: number;
}
