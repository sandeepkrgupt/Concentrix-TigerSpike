/// <reference types="react" />
declare const Chip: (props: any) => JSX.Element;
export default Chip;
