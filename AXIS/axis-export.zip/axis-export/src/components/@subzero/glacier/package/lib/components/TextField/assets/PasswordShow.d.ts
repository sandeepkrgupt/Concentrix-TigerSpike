/// <reference types="react" />
declare const PasswordShow: () => JSX.Element;
export default PasswordShow;
