export { default as CurrentIcon } from './CurrentIcon';
export { default as SuccessIcon } from './SuccessIcon';
export { default as PendingIcon } from './PendingIcon';
export { default as OnholdIcon } from './OnholdIcon';
