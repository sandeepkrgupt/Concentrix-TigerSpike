/// <reference types="react" />
declare const ImageComp: () => JSX.Element;
export default ImageComp;
