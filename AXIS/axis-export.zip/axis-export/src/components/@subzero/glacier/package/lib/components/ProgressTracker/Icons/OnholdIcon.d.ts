import { FC } from 'react';
import { IconProps } from '../ProgressTracker.type';
declare const OnholdIcon: FC<IconProps>;
export default OnholdIcon;
