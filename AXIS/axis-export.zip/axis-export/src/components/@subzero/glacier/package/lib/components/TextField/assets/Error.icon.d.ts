/// <reference types="react" />
declare const Error: () => JSX.Element;
export default Error;
