import Radio from './Radio';
import { RadioProps } from './Radio.type';
export type { RadioProps };
export default Radio;
