import DigitalInput from './DigitalInput';
import { DigitalInputProps } from './DigitalInput.type';
export type { DigitalInputProps };
export default DigitalInput;
