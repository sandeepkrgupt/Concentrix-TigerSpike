import Menu from './Menu';
import { MenuProps } from './Menu.type';
export type { MenuProps };
export default Menu;
