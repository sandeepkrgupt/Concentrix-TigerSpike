/// <reference types="react" />
declare const Card: (props: any) => JSX.Element;
export default Card;
