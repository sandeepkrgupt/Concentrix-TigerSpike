/// <reference types="react" />
declare const Success: () => JSX.Element;
export default Success;
