/// <reference types="react" />
declare const Dropdown: (props: any) => JSX.Element;
export default Dropdown;
