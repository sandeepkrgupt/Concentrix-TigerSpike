/// <reference types="react" />
declare const CheckSelectedComp: () => JSX.Element;
export default CheckSelectedComp;
