import { TypographyProps as MuiTypographyProps } from '@material-ui/core/Typography';
export interface TypographyStylingProps {
    h1?: string;
    h2?: string;
    h3?: string;
    h4?: string;
    h5?: string;
    h6?: string;
    subheading?: string;
    body1?: string;
    body2?: string;
    body3?: string;
    subtitle?: string;
    caption?: string;
    helper?: string;
    label1?: string;
    label2?: string;
    cta1?: string;
    cta2?: string;
    cta3?: string;
    link?: string;
    info1?: string;
    info2?: string;
    color?: string;
    styl?: string;
}
export interface TypographyProps extends MuiTypographyProps {
    type: 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'subheading' | 'body-1' | 'body-2' | 'body-3' | 'subtitle' | 'caption' | 'helper' | 'label-1' | 'label-2' | 'body-bold-1' | 'body-bold-2' | 'body-bold-3' | 'link' | 'info-1' | 'info-2';
}
