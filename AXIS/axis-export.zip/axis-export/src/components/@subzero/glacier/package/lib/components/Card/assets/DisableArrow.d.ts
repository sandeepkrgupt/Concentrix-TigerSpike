/// <reference types="react" />
declare const DisapleArrow: () => JSX.Element;
export default DisapleArrow;
