/// <reference types="react" />
declare const Ruppee: () => JSX.Element;
export default Ruppee;
