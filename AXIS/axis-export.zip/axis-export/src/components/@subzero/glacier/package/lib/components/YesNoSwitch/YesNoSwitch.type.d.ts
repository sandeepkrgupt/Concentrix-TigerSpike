export interface YesNoSwitchStylingProps {
    YesNoSwitch?: string;
    YesNoSwitchContainer?: string;
    YesNoSwitchContainerBtn?: string;
    active?: string;
    inactive?: string;
    disabledActive?: string;
    disabledInactive?: string;
    YesNoSwitchDisabled?: string;
    disabledBtn?: string;
}
export interface YesNoSwitchProps {
    onChange?: (value: any) => void;
    classes?: {};
    value?: boolean;
    disabled?: boolean;
}
