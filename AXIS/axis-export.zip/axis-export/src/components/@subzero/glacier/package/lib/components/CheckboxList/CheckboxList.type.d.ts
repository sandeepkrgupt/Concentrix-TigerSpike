import { CheckboxProps as MuiCheckboxProps, CheckboxClassKey } from '@material-ui/core/Checkbox';
export interface CheckboxListStylingProps extends Partial<Record<CheckboxClassKey, string>> {
    formControl?: string;
    formLabel?: string;
    label?: string;
    disabledChecked?: string;
    checked?: string;
}
export interface CheckboxListProps extends MuiCheckboxProps {
    list: {
        title: string;
        items: {
            label: string;
            value: boolean;
            name: string;
            checked?: boolean;
            disabled?: boolean;
        }[];
    };
    onChange?: (value: any, event: any) => void;
}
