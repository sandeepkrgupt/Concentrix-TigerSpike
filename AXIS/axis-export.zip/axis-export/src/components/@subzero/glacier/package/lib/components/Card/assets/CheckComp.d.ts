/// <reference types="react" />
declare const CheckComp: () => JSX.Element;
export default CheckComp;
