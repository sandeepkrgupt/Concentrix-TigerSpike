import { Ref } from 'react';
import { LinkProps as MuiLinkProps, LinkClassKey } from '@material-ui/core/Link';
export interface LinkStylingProps extends Partial<Record<LinkClassKey, string>> {
    root?: string;
    inlineLink?: string;
    disabled?: string;
    active?: string;
}
export interface LinkProps extends MuiLinkProps {
    innerRef: Ref<HTMLAnchorElement>;
    disabled?: boolean;
    inlineLink?: boolean;
    active?: boolean;
    to?: string;
    component?: any;
    onClick?: (val?: any) => void;
}
