/// <reference types="react" />
declare const Header: (props: any) => JSX.Element;
export default Header;
