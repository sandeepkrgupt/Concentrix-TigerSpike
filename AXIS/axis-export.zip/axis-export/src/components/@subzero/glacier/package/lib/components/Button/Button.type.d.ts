import { Ref } from 'react';
import { ButtonProps as MuiButtonProps, ButtonClassKey } from '@material-ui/core/Button';
export interface ButtonStylingProps extends Partial<Record<ButtonClassKey, string>> {
    loadingLabel?: string;
    doneLabel?: string;
    doneLabelVisible?: string;
    doneRoot?: string;
    secondary?: string;
    textBtn?: string;
    flushButton?: string;
    label_large?: string;
    label_medium?: string;
    label_small?: string;
    label_secondary_large?: string;
    label_secondary_medium?: string;
    label_secondary_small?: string;
    label_icon_large?: string;
    label_icon_medium?: string;
    label_icon_small?: string;
    label_icon_large_secondary?: string;
    label_icon_medium_secondary?: string;
    label_icon_small_secondary?: string;
    endIcon?: string;
    onlyIconLarge?: string;
    onlyIconMedium?: string;
    onlyIconSmall?: string;
    label_disabled?: string;
    padding?: string;
}
export interface ButtonProps extends MuiButtonProps {
    innerRef: Ref<HTMLButtonElement>;
    loading?: boolean;
    done?: boolean;
    withIcon?: boolean;
    hasIconOnly?: boolean;
    isFlushButton?: boolean;
    textButton?: boolean;
    progressButton?: boolean;
    progressValue?: number;
    fullWidth?: boolean;
    icon?: any;
    onClick?: (event: any) => void;
    doneCallback?: () => void;
}
