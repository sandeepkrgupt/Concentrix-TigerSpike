import { FC } from 'react';
import { FileUploaderProps } from './FileUploader.type';
declare const FileUploader: FC<FileUploaderProps>;
export default FileUploader;
