/// <reference types="react" />
declare const CloseIcon: () => JSX.Element;
export default CloseIcon;
