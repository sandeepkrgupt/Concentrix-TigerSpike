/// <reference types="react" />
declare const UpArrow: () => JSX.Element;
export default UpArrow;
