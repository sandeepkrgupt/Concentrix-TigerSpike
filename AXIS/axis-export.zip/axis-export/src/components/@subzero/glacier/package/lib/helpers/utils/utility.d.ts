declare const isNotString: <T>(value: T) => boolean;
export default isNotString;
