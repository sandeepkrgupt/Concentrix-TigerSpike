/// <reference types="react" />
declare const Tabs: (props: any) => JSX.Element;
export default Tabs;
