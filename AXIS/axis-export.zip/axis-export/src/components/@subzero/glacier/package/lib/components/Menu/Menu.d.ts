/// <reference types="react" />
declare const Menu: (props: any) => JSX.Element;
export default Menu;
