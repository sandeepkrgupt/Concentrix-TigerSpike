/// <reference types="react" />
declare const ErrorStep: () => JSX.Element;
export default ErrorStep;
