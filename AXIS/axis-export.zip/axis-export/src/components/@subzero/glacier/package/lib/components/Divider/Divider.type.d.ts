import { DividerProps as MuiDividerProps, DividerClassKey } from '@material-ui/core/Divider';
export interface DividerStylingProps extends Partial<Record<DividerClassKey, string>> {
    root?: string;
    smallHorizontal?: string;
    largeHorizontal?: string;
    largeVertical?: string;
    smallVertical?: string;
}
export interface DividerProps extends MuiDividerProps {
    size?: 'small' | 'large';
}
