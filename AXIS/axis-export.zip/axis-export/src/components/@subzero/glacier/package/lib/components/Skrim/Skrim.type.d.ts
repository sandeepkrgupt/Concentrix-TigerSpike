import { TypographyProps as MuiTypographyProps, TypographyClassKey } from '@material-ui/core/Typography';
export interface SkrimStylingProps extends Partial<Record<TypographyClassKey, string>> {
    root?: string;
    modal1?: string;
    modal2?: string;
    nonModal?: string;
}
export interface SkrimProps extends MuiTypographyProps {
    type: 'modal1' | 'modal2' | 'nonModal';
    children?: any;
}
