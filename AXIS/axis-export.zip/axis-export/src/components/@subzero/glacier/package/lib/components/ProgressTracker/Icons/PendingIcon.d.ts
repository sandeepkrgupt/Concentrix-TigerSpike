import { FC } from 'react';
import { IconProps } from '../ProgressTracker.type';
declare const PendingIcon: FC<IconProps>;
export default PendingIcon;
