/// <reference types="react" />
declare const Button: (props: any) => JSX.Element;
export default Button;
