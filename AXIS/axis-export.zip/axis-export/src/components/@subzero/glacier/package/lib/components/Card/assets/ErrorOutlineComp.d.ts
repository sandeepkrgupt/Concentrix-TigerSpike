/// <reference types="react" />
declare const ErrorOutlineComp: () => JSX.Element;
export default ErrorOutlineComp;
