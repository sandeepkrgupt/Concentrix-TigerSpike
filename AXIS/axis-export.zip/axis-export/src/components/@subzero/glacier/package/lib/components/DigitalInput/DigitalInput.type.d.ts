export interface DigitalInputStylingProps {
    containerSmall?: string;
    container?: string;
    focus?: string;
    error?: string;
    disabled?: string;
    separator?: string;
}
export interface DigitalInputProps {
    size: 'medium' | 'small';
    length: number;
    error?: boolean;
    disabled?: boolean;
    isNumberInput?: boolean;
    onChange?: (otp: string) => any;
}
