/// <reference types="react" />
declare const ProgressIndicator: (props: any) => JSX.Element;
export default ProgressIndicator;
