import { FC } from 'react';
import 'date-fns';
import { DatepickerProps } from './Datepicker.type';
declare const Datepicker: FC<DatepickerProps>;
export default Datepicker;
