export interface ProgressTrackerStylingProps {
    main?: string;
    border?: string;
    wrapper?: string;
    wrapperIndicator?: string;
    wrapperIndicatorAlwaysClosed?: string;
    wrapperRightTitles?: string;
    wrapperRightTitlesTitle?: string;
    wrapperRightTitlesSubtitle?: string;
    hide?: string;
    unhide?: string;
    wrapperTitleWithIcon?: string;
    headerIcon?: string;
}
export interface ProgressTrackerProps {
    steps: {
        title: string;
        variant: 'first' | 'middle' | 'last';
        status: 'current' | 'success' | 'pending' | 'onhold' | 'unvisited';
        chip?: boolean;
    }[];
    currentStep: number;
    onClick?: (val: any) => {};
    open?: boolean;
    alwaysClosed?: boolean;
    error?: boolean;
    separator?: string;
    classes?: {};
    toggleIcon?: boolean;
}
export interface StepItemProps {
    stepTitle: string;
    stepVariant: 'first' | 'middle' | 'last';
    stepStatus: 'current' | 'success' | 'pending' | 'onhold' | 'unvisited';
    stepNumber?: number;
    isChip?: boolean;
    error?: boolean;
    classes?: {};
    curr?: number;
}
export interface StepItemStylingProps {
    stepItem?: string;
    stepItemLeft?: string;
    stepItemLeftLinetop?: string;
    stepItemLeftLinetopLast?: string;
    hidden?: string;
    stepItemLeftLinebottom?: string;
    stepItemLeftLinebottomFirst?: string;
    stepItemTitleWrapper?: string;
    stepItemTitleWrapperText?: string;
    inactive?: string;
}
export interface IconProps {
    position: 'first' | 'middle' | 'last';
    stepNumber?: number;
}
