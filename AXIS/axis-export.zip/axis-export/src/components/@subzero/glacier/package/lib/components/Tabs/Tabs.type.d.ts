import { Ref } from 'react';
import { TabProps as MuiTabProps, TabClassKey } from '@material-ui/core/Tab';
export interface TabStylingProps extends Partial<Record<TabClassKey, string>> {
    rootContainer?: string;
    disabledContainer?: string;
    defaultTextSelected?: string;
    containedTextSelected?: string;
    containerBorder?: string;
    indicatorColor?: string;
    textColorInheritContainer?: string;
}
export interface TabProps extends MuiTabProps {
    innerRef: Ref<HTMLButtonElement>;
    type: 'default' | 'container';
    items: {
        title: string;
        href?: string;
        disabled?: boolean;
    }[];
    onTabClick?: (e: any, title: any) => {};
}
