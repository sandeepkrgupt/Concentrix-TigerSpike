import FileUploader from './FileUploader';
import { FileUploaderProps } from './FileUploader.type';
export type { FileUploaderProps };
export default FileUploader;
