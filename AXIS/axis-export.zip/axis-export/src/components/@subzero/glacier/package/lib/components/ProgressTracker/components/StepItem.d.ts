import { FC } from 'react';
import { StepItemProps } from '../ProgressTracker.type';
declare const StepItem: FC<StepItemProps>;
export default StepItem;
