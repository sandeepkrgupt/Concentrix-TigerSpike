import YesNoSwitch from './YesNoSwitch';
import { YesNoSwitchProps } from './YesNoSwitch.type';
export type { YesNoSwitchProps };
export default YesNoSwitch;
