import Chip from './Chip';
import { ChipProps } from './Chip.type';
export type { ChipProps };
export default Chip;
