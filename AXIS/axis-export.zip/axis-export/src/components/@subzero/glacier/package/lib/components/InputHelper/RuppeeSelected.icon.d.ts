/// <reference types="react" />
declare const RuppeeSelected: () => JSX.Element;
export default RuppeeSelected;
