import Link from './Link';
import { LinkProps } from './Link.type';
export type { LinkProps };
export default Link;
