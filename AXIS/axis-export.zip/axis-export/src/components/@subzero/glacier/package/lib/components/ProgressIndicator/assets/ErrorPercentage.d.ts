/// <reference types="react" />
declare const ErrorPercentage: () => JSX.Element;
export default ErrorPercentage;
