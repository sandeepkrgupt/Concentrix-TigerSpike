import { Ref } from 'react';
import { ChipProps as MuiChipProps, ChipClassKey } from '@material-ui/core/Chip';
export interface ChipStylingProps extends Partial<Record<ChipClassKey, string>> {
    rootStatus?: string;
    rootNudge?: string;
    successStatus?: string;
    pendingStatus?: string;
    warningStatus?: string;
    info?: string;
    successNudge?: string;
    pendingNudge?: string;
    warningNudge?: string;
}
export interface ChipProps extends MuiChipProps {
    innerRef: Ref<HTMLDivElement>;
    type: 'default' | 'success' | 'pending' | 'warning' | 'info';
    chipType: 'status' | 'nudge';
    doneCallback?: () => void;
}
