/// <reference types="react" />
declare const DocumentComp: () => JSX.Element;
export default DocumentComp;
