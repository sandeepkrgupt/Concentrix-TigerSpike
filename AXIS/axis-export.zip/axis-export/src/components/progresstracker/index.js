/* eslint-disable */
import React, { useState, useEffect } from 'react';
import './index.css';
import { makeStyles } from '@material-ui/core/styles';
import Stepper from '@material-ui/core/Stepper';
import Step from '@material-ui/core/Step';
import StepLabel from '@material-ui/core/StepLabel';
import CheckIcon from '../../assets/icons/check-icon.svg'
import WhiteDot from '../../assets/icons/white-dot.svg';
import GreyDot from '../../assets/icons/grey-dot.svg';
import ProgressIndicator from '../@subzero/glacier/package/lib/components/ProgressTracker';
import UpArrow from '../../assets/icons/up-arrow.svg';
import DownArrow from '../../assets/icons/down-arrow.svg';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
    },
    active: {
        color: "#1FC24E"
    },
    completed: {
        color: "#1FC24E"
    },
    backButton: {
        marginRight: theme.spacing(1),
    },
    instructions: {
        marginTop: theme.spacing(1),
        marginBottom: theme.spacing(1),
    },
}));

const useQontoStepIconStyles = makeStyles({
    root: {
        color: '#eaeaf0',
        display: 'flex',
        height: 22,
        alignItems: 'center',
        marginBottom: "20px"
    },
    active: {
        color: "#1FC24E"
    },
    circle: {
        borderRadius: '50%',
        width: "30px",
        height: "30px",
        background: "#1FC24E"
    },
    completed: {
        color: "#FFFFFF",
        zIndex: 1,
        borderRadius: '50%',
        width: "30px",
        height: "30px",
        background: "#1FC24E"
    },

});

function QontoStepIcon(props) {
    const classes = useQontoStepIconStyles();
    const { active, completed } = props;
    return (
        <div
            className={(classes.root, {
                [classes.active]: active,
            })}
        >
            {completed ? <div className={classes.completed} >
                <img src={CheckIcon} />
            </div> : active ?
                <div className={classes.circle} >
                    <img src={WhiteDot} />
                </div>
                : <div>
                    <img src={GreyDot} /></div>}
        </div>
    );
}


export default function ProgressTracker(props) {
    const classes = useStyles();

    const [stepList, updateStepList] = useState([{
        label: "", status: ""
    }])
    const [showDetails, updateDisplay] = useState(false)

    useEffect(() => {
        fetchSteps()
    }, [props.activeStep])

    const fetchSteps = () => {
        let newArray = []
        props?.steps.map((item, key) => {
            let newStepObjet = {
                status: props.activeStep == key ? 'current' :
                    props.activeStep > key ? 'success' :
                        'unvisited',
                variant: key == 0 ? 'first' : key == props.steps.length - 1 ? 'last' : 'middle',
                title: item.label,

            };
            newArray.push(newStepObjet);
        })
        updateStepList(newArray);
    }

    return (
        <>
            <div className="progress-tracker-short">
                <ProgressIndicator
                    // open={false}
                    // fullWidth
                    currentStep={props.activeStep + 1}
                    steps={stepList}
                />
                {/* <img src={showDetails ? UpArrow : DownArrow} onClick={() => {
                    updateDisplay(!showDetails)
                }} /> */}
            </div>
            <div className="progress-tracker-expand">
                <div className={classes.root} >
                    <Stepper activeStep={props.activeStep} alternativeLabel>
                        {props.steps.map((stepItem, index) => (
                            <Step key={index}>
                                <StepLabel StepIconComponent={QontoStepIcon} >{stepItem.label}</StepLabel>
                            </Step>
                        ))}
                    </Stepper>
                </div>
            </div>

        </>
    );
}
