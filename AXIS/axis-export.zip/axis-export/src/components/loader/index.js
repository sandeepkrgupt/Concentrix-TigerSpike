import React from "react";
import Logo from "../../assets/icons/Axis-Bank-Logo.svg";
import './styles.css';

const Loader = () => {
  return (
    <div 
    className="loader-container"
    >
      <img src={Logo} className="loader-icon"/>
    </div>
  );
};
export default Loader;
