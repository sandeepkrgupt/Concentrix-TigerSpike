import React from 'react';
import './index.css';

const AccordionComp = (props)=>{
    return(
        <div className={`accordion-container`}>
            {props?.children}
        </div>
    )
}

export default AccordionComp;