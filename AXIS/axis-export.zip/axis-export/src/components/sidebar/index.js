/*eslint-disable */
import React from "react";
import AppBar from "@material-ui/core/AppBar";
import CssBaseline from "@material-ui/core/CssBaseline";
import Drawer from "@material-ui/core/Drawer";
import Hidden from "@material-ui/core/Hidden";
import IconButton from "@material-ui/core/IconButton";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import Toolbar from "@material-ui/core/Toolbar";
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import { makeStyles, useTheme, withStyles } from "@material-ui/core/styles";
import Badge from '@material-ui/core/Badge';
import clsx from "clsx";
import NamedLogo from '../../assets/icons/Named-Logo.svg';
import Union from '../../assets/icons/Union.svg';
import MenuSidebar from '../../assets/icons/Menu-Sidebar.svg';
import MenuMob from '../../assets/icons/Menu-Mob.svg';
import PaymentIcon from "../../assets/icons/icon-1.svg";
import DashboardIcon from "../../assets/icons/dashboard-icon.svg";
import DashboardIconActive from "../../assets/icons/dashboard-active.svg";
import ServiceIcon from "../../assets/icons/service-icon.svg";
import TreasuryIcon from "../../assets/icons/treasury-icon.svg";
import SettingsIcon from "../../assets/icons/settings.svg";
import ClockIcon from "../../assets/icons/clock.svg";
import TradeIcon from "../../assets/icons/trade.svg";
import TradeIconActive from "../../assets/icons/trade-icon-active.svg";
import HelpIcon from "../../assets/icons/help.svg";
import NotificationIcon from "../../assets/icons/notification.svg";
import SearchIcon from "../../assets/icons/search.svg";
import Avatar from "../../assets/icons/avatar.svg";
import './index.css';
import Divider from "@material-ui/core/Divider";
import { useHistory } from "react-router-dom";
import { useSelector } from "react-redux";

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    background: "#FFFFFF",
  },
  drawer: {
    display: "none",
    background: "#FFFFFF",
    boxShadow: '0px 4px 50px rgba(25, 31, 48, 0.03)',
    [theme.breakpoints.up("lg")]: {
      display: "flex",
      width: drawerWidth,
      flexShrink: 0,
      whiteSpace: "nowrap",
      height: "100%"
    }
  },

  appBar: {
    [theme.breakpoints.up("lg")]: {
      // width: `calc(100% - ${theme.spacing(12) + 1}px)`
      width: `calc(100%)`
    },
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    background:'white'
  },
  appBarShift: {
    // marginLeft: drawerWidth,
    [theme.breakpoints.up("lg")]: {
    // width: `calc(100% - ${drawerWidth}px)`
    width: `calc(100%)`
    },
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up("lg")]: {
      display: "none"
    }
  },
  drawerPaper: {
    width: drawerWidth,
    flexShrink: 0,
    whiteSpace: "nowrap",
  },
  rootMobDrawer:{
    background: "rgba(0,0,0,0.1)",

  },
  drawerOpen: {
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  drawerClose: {
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    overflowX: "hidden",
    width: theme.spacing(7) + 1,
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(12) + 1
    }
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(3)
  },
  toolbar: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: theme.spacing(0, 1),
    // necessary for content to be below app bar
    ...theme.mixins.toolbar
  }
}));

function SideBar(props) {
  const { window } = props;
  const history = useHistory();
  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [open, setOpen] = React.useState(true);
  const [selectedMenu] = React.useState("Dashboard");
  const [value, setValue] = React.useState(0);
  const lastLoginTime = useSelector((state)=>state?.auth?.lastLoginTime)

   const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const handleDrawerOpen = () => {
    setOpen(true);
    document.getElementsByClassName("container-component")[0].style.marginLeft = '240px';
  };

  const handleDrawerClose = () => {
    document.getElementsByClassName("container-component")[0].style.marginLeft = '100px';
    setOpen(false);
  };

  const getIcon=(menu)=>{
    switch (menu) {
      case "Dashboard": 
          return <img src={menu === selectedMenu ? DashboardIconActive : DashboardIcon}/>
      case "Payments":
        return <img src={PaymentIcon}/>;
      case "Trade":
        return <img src={menu === selectedMenu ? TradeIconActive : TradeIcon}/>;
      case "Service":return <img src={ServiceIcon}/>;
      case "Treasury":return <img src={TreasuryIcon}/>;
      case "Settings":
        return <img src={SettingsIcon}/>;
      default:
        break;
    }
  }
  const StyledTabs = withStyles({
    indicator: {
      display: 'flex',
      justifyContent: 'center',
      backgroundColor: 'transparent',
      height: '2.2px',
      minWidth: 'auto',
      '& > span': {
        width: '99px',
        backgroundColor: '#97144D',
      },
    },
  })((props) => <Tabs {...props} TabIndicatorProps={{ children: <span /> }} />);
  
  const StyledTab = withStyles((theme) => ({
    root: {
      textTransform: 'none',
      fontFamily: "Lato",
      fontStyle: "normal",
      fontWeight: "normal",
      fontSize: "14px",
      lineHeight: "20px",
      letterSpacing: "0.26px",
      color: "#858585",
      margin: theme.spacing(1),
      // padding: "20px",
      minWidth: 'auto',
      '&.Mui-selected': {
        color: '#282828',
      },
      '&:focus': {
        opacity: 1,
      },
    },
  }))((props) => <Tab disableRipple {...props} />);

  const drawer = (
    <div className="drawer">
      <div>
      <List className="drawer-list">
      <div className="item-container">
            <div className={open ? "item-sub-container": "item-sub-container-small"}>
              <ListItem className="drawer-logo">
                <ListItemIcon className="sidebar-menu-icon" onClick={open ? handleDrawerClose : handleDrawerOpen}>
                  <div >
                      <img src={MenuSidebar}/>
                  </div>
                </ListItemIcon>
                  {open && <img  src={NamedLogo}/>}
                </ListItem>
              </div>
        </div>
        <Divider className="divider"/>
        {["Dashboard", "Payments", "Trade", "Service", "Treasury", "Settings"].map((text, index) => (
          <div key={text} className="item-container" >
            <div className={open ?"item-sub-container": "item-sub-container-small"}>
              <ListItem 
              onClick={()=>{
                if(text === "Dashboard"){
                  history.push('/dashboard');
                }
              }}
              button className={`drawer-list-item ${selectedMenu === text ? open ? "drawer-list-item-active" : "drawer-list-item-active drawer-list-item-active-small" : ''}`}>
                <ListItemIcon>
                  {getIcon(text)}
                </ListItemIcon>
                {(!open && selectedMenu === text) &&
                <ListItemIcon>
                  <div className="active-indicator"/>
                </ListItemIcon>
                  }
                {open && 
                  <span className={selectedMenu === text ? "drawer-list-item-name-active" : "drawer-list-item-name"} >
                    {text}
                  </span>
                }
              </ListItem>
            </div>
           {selectedMenu === text &&
            <div className="active-indicator indicator-margin"/>}
          </div>
        ))}
      </List>
      </div>
      <div>
        <img src={Union} className={open ? "union-icon" : "union-icon-small"} />
        {open && <div className="time-container">
          <div className="time-sub-container">
          <img src={ClockIcon}/>
            <div className="time">
              <span className="time-text">Last Login :</span>
              <span className="time-text date-time">{lastLoginTime}</span>
            </div>

          </div>
        </div>}
        <div className={open ? "help-container" : "help-container-small"}>
          <div className={open ? "help-row" : "help-column"}>
          <img src={HelpIcon} className="help-icon"/>
          <p className="need-help">Need Help?</p>
          </div>
          {open && <p className="help-text">Duis finibus turpis ac
            <br/>
            lobortis tincidunt dignissi
          </p>}
        </div>
        </div>
    </div>
  );

  const appBar = (
    <AppBar
      position="fixed"
      className={["appbar",clsx(classes.appBar, {
        [classes.appBarShift]: open
      })]}
    >
      <Toolbar className="toolbar">
        {/* <IconButton
          color="inherit"
          aria-label="open drawer"
          edge="start"
          onClick={handleDrawerToggle}
          className={classes.menuButton}
        >
          <img className="header-menu" src={MenuSidebar}/>
          <img className="header-menu-mob" src={MenuMob}/>
        </IconButton>
        <img className="header-logo" src={NamedLogo}/> */}
       <StyledTabs className="tabs" value={value} onChange={handleChange} aria-label="styled tabs example">
          <StyledTab label="Trade Overview" />
          <StyledTab label="Imports" />
          <StyledTab label="Exports" />
          <StyledTab label="Remittances" />
          <StyledTab label="Foreign Bank Guarantees" />
          <StyledTab label="Inland trade" />
          <StyledTab label="Advices" />
          <StyledTab label="Analytics" />
        </StyledTabs>
        {/* <div className="header-right">
          <IconButton className="header-icon" aria-label="search" color="inherit">
                <img src={ SearchIcon}/>
            </IconButton>
          <IconButton className="header-icon" aria-label="notification" color="inherit">
              <Badge badgeContent={3} color="secondary">
                <img src={NotificationIcon}/>
              </Badge>
            </IconButton>
            <IconButton className="header-icon"  aria-label="avatar" color="inherit">
              <img src={Avatar}/>
            </IconButton>
          </div> */}
      </Toolbar>
    </AppBar>
  );
  const container =
    window !== undefined ? () => window().document.body : undefined;

  return (
    <div className={`${classes.root} sidebar`}>
      <CssBaseline />
     {appBar}
     {/* Mob & Tab Drawer */}
      {/* <nav>
        <Hidden smUp implementation="css">
          <Drawer
            container={container}
            variant="temporary"
            anchor={theme.direction === "rtl" ? "right" : "left"}
            open={mobileOpen}
            onClose={handleDrawerToggle}
            classes={{
              paper: classes.drawerPaper,
              root: classes.rootMobDrawer
            }}
          >
            {drawer}
          </Drawer>
        </Hidden> */}
    {/* Desktop drawer */}
        {/* <Hidden xsDown implementation="css">
          <Drawer
            variant="permanent"
            className={clsx(classes.drawer, {
              [classes.drawerOpen]: open,
              [classes.drawerClose]: !open
            })}
            classes={{
              paper: clsx({
                [classes.drawerOpen]: open,
                [classes.drawerClose]: !open
              })
            }}
          >
            {drawer}
          </Drawer>
        </Hidden>
      </nav> */}
      <div className="content-container">
        <StyledTabs className="tabs-small" value={value} onChange={handleChange} aria-label="styled tabs example">
          <StyledTab label="Trade Overview" />
          <StyledTab label="Imports" />
          <StyledTab label="Exports" />
          <StyledTab label="Remittances" />
          <StyledTab label="Foreign Bank Guarantees" />
        </StyledTabs>
        <Divider/>
      </div>
    </div>
  );
}

export default SideBar;
