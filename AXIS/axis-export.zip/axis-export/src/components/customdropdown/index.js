/* eslint-disable */
import React, { useState, useEffect } from "react";
import Autocomplete from "@material-ui/lab/Autocomplete";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import Checkbox from "@material-ui/core/Checkbox";
import CheckBoxOutlineBlankIcon from "@material-ui/icons/CheckBoxOutlineBlank";
import CheckBoxIcon from "@material-ui/icons/CheckBox";
import RadioButtonCheckedIcon from "@material-ui/icons/RadioButtonChecked";
import RadioButtonUncheckedIcon from "@material-ui/icons/RadioButtonUnchecked";

const useStyles = makeStyles((theme) => ({
  root: {
    color: "black",
    backgroundColor: "#F2F7F6",
    borderRadius: "4px 4px 0px 0px",
    "&:hover": {
      backgroundColor: "#E6F8F4"
    },
    "&.Mui-focused": {
      backgroundColor: "#E6F8F4",
      color: "black"
    },
    "& .MuiOutlinedInput-notchedOutline": {
      borderWidth: "2px",
      borderColor: "#71B7B2",
      borderLeft: "none",
      borderTop: "none",
      borderRight: "none",
      padding: "27px 12px 10px"
    },
    "&:hover .MuiOutlinedInput-notchedOutline": {
      borderWidth: "2px",
      borderColor: "#71B7B2"
    },
    "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
      borderWidth: "2px",
      borderColor: "#71B7B2"
    },
    "& .MuiInput-underline": {
      "&:before": {
        borderWidth: "2px",
        borderColor: "#71B7B2",
        borderLeft: "none",
        borderTop: "none",
        borderRight: "none"
      },
      "&:after": {
        borderColor: "#12877F"
      }
    },
    "& .MuiAutocomplete-inputRoot": {
      padding: "9px 15px"
    },
    "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-input": {
      color: "#12877f"
    },
    "& .MuiInputLabel-root.Mui-focused": {
      color: "#12877f"
    },
    "& .MuiInputLabel-shrink": {
      position: "absolute",
      top: "23%"
    }
  }
}));

const Customdropdown = (props) => {
  const classes = useStyles();
  const [options, setOptions] = useState(props?.options ? props?.options : []);
  const [selOptions, setSelectedOptions] = useState(props?.selectedOptions);

  const handleUserSelect = (value) => {
    setSelectedOptions(value);
  };

  useEffect(() => {
    if (props?.appliedFilter) {
      props.onSelectOptions(selOptions);
    }
  }, [props?.appliedFilter]);

  useEffect(() => {
    if (props?.options) setOptions(props?.options);
  }, [props?.options]);

  useEffect(() => {
    setSelectedOptions(props?.selectedOptions);
  }, [props?.selectedOptions]);

  const fetchSelectedValues = (selectedOptionsList) => {
    let result = "";
    selectedOptionsList?.length > 0 &&
      selectedOptionsList.map((item, key) => {
        if (
          selectedOptionsList?.length > 1 &&
          key !== selectedOptionsList?.length - 1
        ) {
          result = result + item.label + ", ";
        } else {
          result = result + item.label;
        }
      });
    if (result.length > 30) {
      return <React.Fragment>{result.substr(0, 30) + "..."}</React.Fragment>;
    } else return <React.Fragment>{result}</React.Fragment>;
  };
  return (
    <div className="m-t-25">
      <Autocomplete
        clearOnBlur={!props?.listFromAPI}
        multiple={props.isMulti}
        id="tags-standard"
        disableCloseOnSelect={props.isMulti}
        options={options}
        getOptionLabel={(option) =>
          option?.label === null ? "" : option?.label
        }
        classes={classes}
        onChange={(event, newValue) => {
          if (props?.listFromAPI) {
            if (newValue !== null) {
              props.onSelectOptions(newValue);
            }
          } else {
            const ids = newValue.map((o) => o?.id);
            const filtered = newValue.filter(
              ({ id }, index) => !ids.includes(id, index + 1)
            );
            handleUserSelect(filtered);
          }
        }}
        onBlur={() => {
          if (props?.nonFilter) {
            props.onSelectOptions(selOptions);
          }
        }}
        renderTags={() => fetchSelectedValues(selOptions)}
        value={selOptions}
        getOptionSelected={(option, value) => value?.id === option?.id}
        renderOption={(option, { selected }) => {
          return (
            <React.Fragment>
              {!props?.listFromAPI && (
                <Checkbox
                  icon={
                    props.isMulti ? (
                      <CheckBoxOutlineBlankIcon fontSize="small" />
                    ) : (
                      <RadioButtonUncheckedIcon fontSize="small" />
                    )
                  }
                  checkedIcon={
                    props.isMulti ? (
                      <CheckBoxIcon fontSize="small" />
                    ) : (
                      <RadioButtonCheckedIcon fontSize="small" />
                    )
                  }
                  style={{ marginRight: 8 }}
                  checked={selected}
                />
              )}
              <span className="dropdown-item-text">{option?.label}</span>
            </React.Fragment>
          );
        }}
        renderInput={(params) => (
          <TextField
            {...params}
            variant="outlined"
            label={props.name}
            inputProps={{
              ...params.inputProps,
              maxLength: props?.max
            }}
            onInput={(e) => props?.onValidation?.(e?.target?.value)}
            onChange={(e) => {
              if (props?.listFromAPI) {
                //Call API
                props?.fetchOptions?.(e?.target?.value);
              }
            }}
            error={props.error}
            helperText={props.error ? props.errorText : ""}
            onBlur={(e) => {
              if (props?.listFromAPI) {
                props?.onBlur?.(e?.target?.value);
              }
            }}
          />
        )}
      />
    </div>
  );
};
export default Customdropdown;
