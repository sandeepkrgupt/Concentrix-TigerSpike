import { makeStyles } from '@material-ui/core';
import React from 'react';
import Chip from '@material-ui/core/Chip'
import './index.css';

const useStyles = makeStyles({
    root: {
        background:' #E7F3F2',
        borderRadius: '4px',
        height: '32px',
        marginRight: '16px'
    },
    label:{
        fontFamily: "Lato",
        fontStyle: "normal",
        fontWeight: "normal",
        fontSize: "14px",
        lineHeight: "20px",
        letterSpacing: "0.26px",
        color: "#12877F",
        flex: "none",
        order: 0,
        flexGrow: 0,
        margin: "0px 4px"
}
  });

const SubMenu = (props) => {
    const {name} = props;
    const styles = useStyles();
    return (
        // <div className="menu-container">
        //     <span className="menu-name">{name}</span>
        // </div>
         <Chip
         classes={{root: styles.root, label: styles.label}}
         chipType="nudge"
         label={name}
         type="default"
         // variant="outlined"
         />
    );
};

export default SubMenu;