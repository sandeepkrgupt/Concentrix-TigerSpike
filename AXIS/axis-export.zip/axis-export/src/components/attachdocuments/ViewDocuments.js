import React from "react";
import EditBox from "../../components/editbox";
import BlueDot from "../../assets/icons/red-dot.svg";
import DocumentCheckList from "./DocumentCheckList";
import { Grid } from "@material-ui/core";
import AddIcon from "../../assets/icons/add-icon.svg";
import { TextField } from "../@subzero/glacier/package/lib/components";

const ViewDocuments = (props) => {
  const [showRemarkForm, updateFormDisplay] = React.useState(false);

  return (
    <>
      <EditBox
        title="Attached Documents"
        hideEditButton={!props?.editMode}
        onEdit={props?.editAttachments}
      >
        {props?.showCheckList && (
          <>
            <div className="checklist-box">
              <DocumentCheckList />
            </div>
            <div className="document-list-title">
              <Grid item lg={4} md={4} sm={4} xs={12}>
                <p>File Name</p>
              </Grid>
              <Grid item lg={4} md={4} sm={4} xs={12}>
                <p>Purpose Code</p>
              </Grid>
              <Grid item lg={4} md={4} sm={4} xs={12}>
                <p>Classification</p>
              </Grid>
            </div>
          </>
        )}
        <div className="document-container grey-bg">
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <p>
              {" "}
              <img src={BlueDot} />
              Johndoe_resume.dox
            </p>
            <span className="file-sixe-text">399KB</span>
          </Grid>
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <span className="file-classification">Purpose Code</span>
            <h4>P0103</h4>
          </Grid>
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <span className="file-classification">Classification</span>
            <h4> Transport Documents </h4>
          </Grid>
        </div>
        <div className="document-container grey-bg">
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <p>
              {" "}
              <img src={BlueDot} />
              Johndoe_resume.dox
            </p>
            <span className="file-sixe-text">399KB</span>
          </Grid>
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <span className="file-classification">Purpose Code</span>
            <h4>P0103</h4>
          </Grid>
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <span className="file-classification">Classification</span>
            <h4> Invoice Attachments </h4>
          </Grid>
        </div>
        <div className="document-container grey-bg">
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <p>
              {" "}
              <img src={BlueDot} />
              Johndoe_resume.dox
            </p>
            <span className="file-sixe-text">399KB</span>
          </Grid>
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <span className="file-classification">Purpose Code</span>
            <h4>P0103</h4>
          </Grid>
          <Grid item lg={4} md={4} sm={4} xs={12}>
            <span className="file-classification">Classification</span>
            <h4> Additional </h4>
          </Grid>
        </div>
        {showRemarkForm && (
          <Grid container>
            <Grid item lg={12} md={12} className="remark-box">
              <TextField
                fullWidth
                label="Remarks"
                value="Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam Lorem ipsum dolor sit amet, consectetur adipiscing elit ut aliquam"
                type="text"
                variant="filled"
              />
            </Grid>{" "}
          </Grid>
        )}
        {props?.userRole === "C" && !showRemarkForm && props?.editMode && (
          <span
            className="add-new"
            onClick={() => {
              updateFormDisplay(true);
            }}
          >
            <img src={AddIcon} />
            Add Remarks
          </span>
        )}
      </EditBox>
    </>
  );
};

export default ViewDocuments;
