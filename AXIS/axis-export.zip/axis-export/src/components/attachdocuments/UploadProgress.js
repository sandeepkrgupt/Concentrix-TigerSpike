/* eslint-disable */

import React, { useEffect, useState } from "react";
import CloseIcon from "../../assets/icons/close-icon.svg";
import { makeStyles } from "@material-ui/core/styles";
import LinearProgress from "@material-ui/core/LinearProgress";
import ImgFile from "../../assets/icons/image-file.png";
import Customdropdown from "../../components/customdropdown";
import TrashIcon from "../../assets/icons/delete-icon.svg";
import DeleteIcon from "../../assets/icons/delete.svg";
import Grid from "@material-ui/core/Grid";
import { Dropdown } from "../@subzero/glacier/package/lib/components";
import SuccessIcon from "../../assets/icons/success-check.png";

const useStyles = makeStyles({
  root: {
    width: "100%",
    paddingRight: "50px",
    "@media (max-width: 600px) and (min-width: 320px) ": {
      paddingRight: "0px",
    },
    marginTop: "10px",
  },
});

const UploadProgress = (props) => {
  const classes = useStyles();
  const [classficationLabelList, setClassficationLabelList] = useState([]);

  useEffect(() => {
    //creating classification list if available
    const classifications = props?.classifications;
    if (classifications) {
      const newList = classifications.map((item) => item.label);
      setClassficationLabelList(newList);
    }
  }, []);

  const fetchFileSize = (file) => {
    if (!file?.size) {
      return "";
    } else {
      let size = file?.size;
      const fSExt = ["Bytes", "KB", "MB", "GB"];
      let i = 0;
      while (size > 900) {
        size /= 1024;
        i++;
      }
      const exactSize = Math.round(size * 100) / 100 + " " + fSExt[i];
      return exactSize;
    }
  };

  return (
    <div className="green-card d-flex">
      <Grid container className="fd-column ">
        <Grid item className="file-box fd-row wd-100" spacing={3}>
          <Grid item className="fd-column wd-100">
            <Grid item className="fd-row wd-100">
              <Grid item lg={3} md={4} sm={5} xs={10} className="fd-row">
                <div>
                  <img src={ImgFile} />
                </div>
                <div className="card-text-area">
                  <div>{props?.item?.file?.name}</div>
                  <span>{fetchFileSize(props?.item?.file)}</span>
                </div>
              </Grid>
              <Grid item lg={3} md={4} sm={5} xs={0}>
                {props.showForm && (
                  <>
                    <div className="document-form green-card-data-expand">
                      <Grid item lg={12} className="mg-rght-10">
                        <Dropdown
                          items={classficationLabelList}
                          // defaultValue="Transport Documents"
                          label="Classification"
                          placeholder="Classification"
                          type="text"
                          variant="filled"
                          onChange={(e) => {
                            props?.handleUserInput(
                              e,
                              "checkList",
                              props?.fileIndex
                            );
                          }}
                          value={props?.item?.checkList}
                          fullWidth
                          name="Classification"
                          isMulti={false}
                        />
                      </Grid>
                    </div>
                  </>
                )}
                {props.showSelected && (
                  <Grid item lg={12} className="selected-details">
                    <div>
                      <span className="hideTab">Classification: </span>
                      {props?.item?.checkList?.label || props?.item?.checkList}
                    </div>
                  </Grid>
                )}
              </Grid>
              <Grid item lg={6} md={4} sm={2} xs={2} className="jc-f-end">
                <div className="as-center">
                  {/*if file is being uploaded or not started uploading, show close button*/}
                  {props.showForm ? (
                    <img
                      className="close-icon"
                      // className="flt-right"
                      src={CloseIcon}
                      onClick={() => {
                        props?.onFileDelete(props.fileIndex);
                      }}
                    />
                  ) : props.value ? (
                    ""
                  ) : (
                    // else show delete button and success icon
                    props.showSelected && (
                      <>
                        <Grid container spacing={2}>
                          <Grid item className="as-center">
                            <div className="delete-button hideMobTab">
                              <img
                                // className="flt-right"
                                src={TrashIcon}
                                onClick={() => {
                                  props?.onFileDelete(props.fileIndex);
                                }}
                              />
                            </div>
                          </Grid>
                          <Grid item className="as-center">
                            <img src={SuccessIcon} />
                          </Grid>
                        </Grid>
                      </>
                    )
                  )}
                </div>
              </Grid>
            </Grid>

            {props.showSelected && (
              <Grid item className="selected-details-mob">
                <div>Classification: {props?.item?.checkList.label}</div>
              </Grid>
            )}
            {/* <Grid item className="selected-details-mob">
              <div>Classification: Invoice Attachments</div>
            </Grid> */}
          </Grid>

          {/* <Grid item></Grid> */}
          {/* <div className="green-card-data wd-100">
            <div>
              <img src={ImgFile} />
            </div>
            <div className="card-text-area">
              <div>{props?.item?.file?.name}</div>
              <span>{fetchFileSize(props?.item?.file)}</span>
            </div> */}
          {/* <> */}
          {/* if file is selected and not started uploading, show classification dropdown */}
          {/* {props.showForm && (
                <>
                  <div className="document-form green-card-data-expand ">
                    <Grid item lg={3} className="mg-rght-10">
                      <Dropdown
                        items={[
                          "Transport Documents",
                          "Invoice Documents",
                          "Additional",
                        ]}
                        // defaultValue="Transport Documents"
                        label="Classification"
                        placeholder="Classification"
                        type="text"
                        variant="filled"
                        onChange={(e) => {
                          props?.handleUserInput(
                            e,
                            "classification",
                            props?.fileIndex
                          );
                        }}
                        value={props?.item?.classification}
                        fullWidth
                        name="Classification"
                        isMulti={false}
                      />
                    </Grid>
                  </div>
                </>
              )} */}
          {/* </> */}
          {/* </div> */}

          {/* {!props.showForm && !props.value && (
            <Grid item lg={2} className="selected-details">
              <div>Classification: Invoice Attachments</div>
            </Grid>
          )} */}
          {/* <div className="green-card-data-short"></div> */}
          {/* {props.showForm && (
        <div className="document-form">
          <Grid item lg={3} className="mg-rght-10">
            <Dropdown
              items={["Transport Documents", "Invoice Documents", "Additional"]}
              defaultValueTrashIconled"
              fullWidth
              name="Classification"
              isMulti={false}
            />
          </Grid>
        </div>
      )} */}

          {/* show linearprogress if uploading on progress */}

          {/* for different uploading progress and uploading complete colors */}
          {/* {props.value &&
        (props.value < 100 ? (
          <div className={classes.root}>
            <LinearProgress
              variant="determinate"
              color="secondary"
              value={props.value}
            />
          </div>
        ) : (
          <div className={classes.root}>
            <LinearProgress variant="determinate" value={props.value} />
          </div>
        ))} */}
        </Grid>
        <Grid item>
          <div className="green-card-data-short">
            {props.showForm && (
              <Dropdown
                items={classficationLabelList}
                // defaultValue="Transport Documents"
                label="Classification"
                placeholder="Classification"
                type="text"
                variant="filled"
                onChange={(e) => {
                  props?.handleUserInput(e, "checkList", props?.fileIndex);
                }}
                value={props?.item?.checkList}
                fullWidth
                name="Classification"
                isMulti={false}
              />
            )}
          </div>
        </Grid>
        {props.showSelected && (
          <>
            <Grid item className="fd-row jc-f-end">
              <div
                className="viewMobTab-flex delete-btn"
                onClick={() => {
                  props?.onFileDelete(props.fileIndex);
                }}
              >
                <img
                  style={{ alignSelf: "center" }}
                  // className="flt-right"
                  src={DeleteIcon}
                />
                <span className="delete-file">Delete</span>
              </div>
            </Grid>
          </>
        )}

        <Grid item className="fd-row">
          {props.value && (
            <div className={classes.root}>
              <LinearProgress variant="determinate" value={props.value} />
            </div>
          )}
        </Grid>
      </Grid>
    </div>
  );
};

export default UploadProgress;
