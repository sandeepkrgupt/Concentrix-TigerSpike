import React from "react";
import { Drawer } from "@material-ui/core";
import "./index.css";
import closeIcon from "../../assets/icons/close-icon.svg";
import { makeStyles } from "@material-ui/core/styles";
import { Button, TextField } from "../@subzero/glacier/package/lib/components";

const useStyles = makeStyles({
  paper: {
    width: "100%",
    height: "92%",
    background: "#FFFFFF",
    borderRadius: "24px 24px 0px 0px",
  },
  dropdown: {
    "& .Dropdown_show__21pcz": {
      position: "absolute",
      zIndex: "999",
    },
  },
});

const BottomDrawer = (props) => {
  const classes = useStyles();
  return (
    <>
      <Drawer
        anchor="bottom"
        open={props.showDrawer}
        className="bottom-drawer"
        classes={{
          paper: classes.paper,
        }}
      >
        <div className="drawer-container">
          <div className="drawer-header">
            <h5>{props.title}</h5>
            {props.isSearchable && (
              <div className="search-box search-expand" id="search-icon">
                <TextField
                  label="Find Field Name"
                  onBlur={props?.onSearchTextChange}
                />
              </div>
            )}
            <span
              className="drawer-close-icon"
              onClick={() => {
                props.toggleDrawer();
              }}
            >
              <img src={closeIcon} />
            </span>
          </div>

          {props.isSearchable && (
            <div className=" search-box search-short" id="search-icon">
              <TextField label="Find Field Name" />
            </div>
          )}

          {props.children}
        </div>
        {props.showFooterButtons && (
          <>
          <div className="footer-buttons">
            {props.utilisedData && (
              <div className="footer-data-box">
                <div>
                  Utilised
                  <br />
                  <span>USD</span> 0.00
                </div>
                <div>
                  Outstanding
                  <br />
                  <span>USD</span> 10,000,000
                </div>
              </div>
            )}
            {props?.middleComponent}
            <div className="action-buttons">
              <Button
                color="secondary"
                onClick={() => {
                  props?.resetAction();
                }}
              >
                {props.secondaryAction}
              </Button>
              <Button
                disabled={props?.disabledPrimary}
                onClick={() => {
                  props.toggleDrawer();
                  props.primaryActionMethod();
                }}
              >
                {props.primaryAction}
              </Button>
              {/* <Button onClick={() => { props?.handlePrimaryAction && props.handlePrimaryAction() }}>{props.primaryAction}</Button> */}
            </div>
          </div>
          </>
        )}
      </Drawer>
    </>
  );
};

export default BottomDrawer;
