/*eslint-disable */
import React from 'react';
import { useLocation } from "react-router-dom";
import HomeIcon from '../../assets/icons/home.svg';
import RedDot from '../../assets/icons/red-dot.svg';
import './index.css';

const Card = (props) => {
    const { count, label, expired, color, borderColor, dueFlag} = props.task;
    const location = useLocation();

    return (
        <div className={`card-container ${expired ? `extended ${props.boe && "boe-extended-card-container"}` : props.boe && "boe-card-container"} `}
        style={{
            backgroundColor: color,
            border: props?.active ? `3px solid ${borderColor}` : null
        }}
        onClick={()=>props?.onClick ? props?.onClick() : null}
        >
            <div className="card-sub-container" >
                {!props.boe && <img src={HomeIcon} className="card-icon"/>}
                <span className={`count ${props.boe && "boe-count"}`} >{count}</span>
                <span className="status">{label}</span>
            </div>
            <div className="right-card-container">
                {dueFlag && <img src={RedDot} className="card-red-dot"/>}
                {expired && <MiniCard onClickNonExpired={props.onClickNonExpired} onClickExpired={props.onClickExpired} task={props.task} boe={props.boe} ind={props.ind}/>}
            </div>
        </div>
    );
};

const MiniCard = (props) => {
    const { expired, nonExpired, miniColor } = props.task;
    return (
        <div>
            <div onClick={(e) => props?.onClickExpired ? props?.onClickExpired(e,props.task) : null} className={`mini-sub-card ${props.boe && 'boe-sub-card'}`} style={{backgroundColor: miniColor}}>
            <span className={`extended-count  ${props.boe && 'boe-sub-count'}`}>{expired?.count}</span>
            <span className={`months ${props.boe && 'boe-months'}`}>{expired?.label}</span>
        </div>
            <div onClick={(e) => props?.onClickNonExpired ? props?.onClickNonExpired(e,props.task) : null} className={`mini-sub-card ${props.boe && 'boe-sub-card'}`} style={{backgroundColor: miniColor}}>
            <span className={`extended-count  ${props.boe && 'boe-sub-count'}`}>{nonExpired?.count}</span>
            <span className={`months ${props.boe && 'boe-months'}`}>{nonExpired?.label}</span>
        </div>
    </div>
    )
}


export default Card;