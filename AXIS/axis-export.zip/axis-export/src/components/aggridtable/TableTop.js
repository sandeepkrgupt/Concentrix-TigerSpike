import React, { useRef } from "react";
import FilterIcon from "../../assets/icons/filter.svg";
import RightArrow from "../../assets/icons/arrow-right.svg";
import CloseIcon from "../../assets/icons/close.svg";
import ClearAllIcon from "../../assets/icons/clear.svg";
import {
  Datepicker,
  TextField
} from "../@subzero/glacier/package/lib/components";
import { Chip, Grid } from "@material-ui/core";
import moment from "moment";

const TableTop = (props) => {
  const {
    isDefaultDateRange,
    onSearch,
    onFilter,
    filterList,
    startRange,
    endRange,
    setStartRange,
    setEndRange,
    clearFilters,
    onDeleteChip,
    classes,
    openInvoiceDrawer
  } = props;
  const ref = useRef();

  return (
    <>
      {/* Table top container */}
      <div className="table-top-container">
        <div className="sub-top-container">
          <div className="search-box" id="search-icon">
            <TextField
              // label="Search"
              placeholder="Search"
              type="text"
              onChange={(e) => onSearch(e)}
            />
          </div>
          {openInvoiceDrawer === false && <div className="filter-button" onClick={onFilter}>
            <span>Filter</span>
            {filterList?.length > 0 && (
              <div className="filter-count">
                <p>
                  {isDefaultDateRange
                    ? filterList?.length
                    : filterList?.length > 0 && startRange && endRange
                    ? filterList?.length + 1
                    : !(startRange && endRange) && filterList?.length > 0
                    ? filterList?.length
                    : startRange && endRange
                    ? 1
                    : null}
                  {/* {filterList?.length} */}
                </p>
              </div>
            )}
            <img src={FilterIcon} />
          </div>}
          
        </div>
        {openInvoiceDrawer === false &&
          <div className="sub-top-container">
          <Grid container spacing={3}>
            <Grid item sm={6}>
              <div className="datepicker-container">
                <Datepicker
                  defaultValue={
                    startRange === ""
                      ? {
                          day: "",
                          month: "",
                          year: ""
                        }
                      : {
                          day: startRange.getDate(),
                          month: startRange.getMonth() + 1,
                          year: startRange.getFullYear()
                        }
                  }
                  variant="filled"
                  label="Start Date"
                  onChange={(e) => {
                    setStartRange(e);
                  }}
                />
              </div>
            </Grid>
            <Grid item sm={6}>
              <div className="datepicker-container">
                <Datepicker
                  defaultValue={
                    endRange === ""
                      ? {
                          day: "",
                          month: "",
                          year: ""
                        }
                      : {
                          day: endRange.getDate(),
                          month: endRange.getMonth() + 1,
                          year: endRange.getFullYear()
                        }
                  }
                  value={endRange}
                  variant="filled"
                  label="End Date"
                  onChange={(e) => setEndRange(e)}
                />
              </div>
            </Grid>
          </Grid>
        </div>
        }
        
      </div>
      <span
        style={{
          color: "red",
          fontSize: "14px",
          display: "flex",
          justifyContent: "flex-end"
        }}
      >
        {endRange > new Date() || startRange > new Date()
          ? "Start Date/End Date should not be greater than Application Date"
          : startRange > endRange
          ? "End date should not be lesser than Start Date"
          : null}
      </span>
      <div
        className="reset-date"
        onClick={() => {
          if (isDefaultDateRange) {
            // CT
            const priorDate = new Date().setMonth(new Date().getMonth() - 6);
            setStartRange(new Date(priorDate));
            setEndRange(new Date());
          } else {
            setStartRange("");
            setEndRange("");
            onDeleteChip({
              label:
                "FROM " +
                moment(startRange).format("DD-MM-YYYY") +
                " TO " +
                moment(endRange).format("DD-MM-YYYY"),
              key: "amount"
            });
          }
        }}
      >
        {props?.isShippingBillDB ? '' : <span>RESET DATE</span>}
      </div>
      {/* Filter Chips container */}
      {filterList?.length > 0 ||
      (startRange &&
        endRange &&
        startRange &&
        endRange &&
        endRange <= new Date() &&
        startRange <= new Date() &&
        startRange <= endRange) ? (
        filterList?.length === 0 && isDefaultDateRange ? (
          ""
        ) : (
          <div className="chip-list">
            <div className="cursor-pointer" onClick={clearFilters}>
              <img src={ClearAllIcon} />
            </div>
            <div
              className="left-arrow"
              onClick={() => {
                ref.current.scrollLeft -= 400;
              }}
            >
              <img src={RightArrow} />
            </div>
            <div className="filter-chip-list" ref={ref}>
              {filterList?.map((filter, ind) => {
                return (
                  <Chip
                    key={ind}
                    className={classes.chip}
                    label={filter?.label}
                    onDelete={(e) => onDeleteChip(filter)}
                    deleteIcon={<img className="delete-icon" src={CloseIcon} />}
                  />
                );
              })}
              {startRange &&
                endRange &&
                !isDefaultDateRange &&
                startRange &&
                endRange &&
                endRange <= new Date() &&
                startRange <= new Date() &&
                startRange <= endRange && (
                  <Chip
                    key="start-end"
                    className={classes.chip}
                    onDelete={(e) => {
                      onDeleteChip({
                        label:
                          "FROM " +
                          moment(startRange).format("DD-MM-YYYY") +
                          " TO " +
                          moment(endRange).format("DD-MM-YYYY"),
                        key: "amount"
                      });
                      setStartRange("");
                      setEndRange("");
                    }}
                    label={
                      "FROM " +
                      moment(startRange).format("DD-MM-YYYY") +
                      " TO " +
                      moment(endRange).format("DD-MM-YYYY")
                    }
                    deleteIcon={<img className="delete-icon" src={CloseIcon} />}
                  />
                )}
            </div>
            <div
              className="right-arrow"
              onClick={() => {
                ref.current.scrollLeft += 400;
                document.getElementsByClassName("left-arrow")[0].style.display =
                  "block";
              }}
            >
              <img src={RightArrow} />
            </div>
          </div>
        )
      ) : (
        ""
      )}
    </>
  );
};

export default TableTop;
