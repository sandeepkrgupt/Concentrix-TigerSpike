/* eslint-disable */
import React, { useState, useEffect } from "react";
import { Grid, Hidden, Radio as MuiRadio } from "@material-ui/core";
import { Link, useHistory } from "react-router-dom";
import DownArrow from "../../../assets/icons/down-arrow.svg";
import UpArrow from "../../../assets/icons/up-arrow.svg";
import {
  Checkbox,
  Button,
  TextField,
  Divider,
} from "../../@subzero/glacier/package/lib/components";
import OrangeDot from "../../../assets/icons/orange-dot.svg";
import HamburgerIcon from "../../../assets/icons/hamburger.svg";
const TableRow = (props) => {
  const {
    expired,
    hideActionIcon,
    onMoreCellClick,
    isSelected,
    handleRowSelection,
    handleRowDeletion,
    fetchTextFieldValue,
    moreActionMenu,
    columnData,
    index,
    selectedList,
    noRowSelection,
    getSelectedRows,
    updateSelectedList,
    showOtherScreen,
  } = props;
  const [viewMore, setViewMore] = useState(false);
  const [displayData, updateDisplayData] = useState([]);
  const history = useHistory();
  const [item, setItem] = useState(props?.item);
  useEffect(() => {
    columnData?.map((item, ind) => {
      if (item?.field === "boeList") {
        let boeList = columnData.splice(ind, 1);
        columnData.unshift(item);
      }
    });
    if (viewMore) {
      updateDisplayData(columnData);
    } else {
      updateDisplayData(columnData.slice(0, 4));
    }
  }, [viewMore]);

  useEffect(() => {
    setItem(props?.item);
  }, [props?.item]);
  return (
    <>
      <div>
        <div className="accordion-header">
          {!noRowSelection && (
            <Checkbox
              className="accordion-checkbox"
              checked={isSelected(item?.id?.value)}
              onClick={() => {
                ``;
                handleRowSelection(item);
              }}
            />
          )}
          {item?.["radio"] && (
            <div
              onClick={() => {
                if (item?.["radio"]?.value) {
                  getSelectedRows([]);
                  updateSelectedList([]);
                } else {
                  getSelectedRows([item]);
                  updateSelectedList(item);
                }
              }}
            >
              <MuiRadio checked={item?.["radio"]?.value} />
            </div>
          )}
          {props?.isShippingBillDB ? <span className="accordion-heading">
            {item?.["shippingBillno"]?.value}
          </span> : 
          <span className="accordion-heading">
            {item?.["supplierName"]?.value ||
              item?.["beneficiaryName"]?.value ||
              item?.["bankName"]?.value}
          </span> }
          {!hideActionIcon && (
            <div className="accordion-action-menu">
              <img
                onClick={(e) => {
                  e.stopPropagation();
                  onMoreCellClick(e, item?.["paymentStatus"]);
                }}
                style={{ cursor: "pointer" }}
                className="hamburger-icon"
                src={HamburgerIcon}
              />
            </div>
          )}
        </div>
        <div className="accordion-status">
          {item?.["statusCode"]?.statusBox && (
            <>
              <span
                className={
                  item?.["statusCode"]?.type === "info"
                    ? "transaction-status-box  info-status"
                    : item?.["statusCode"]?.type === "success"
                    ? "payment-status-box success-status"
                    : item?.["statusCode"]?.type === "warning"
                    ? "transaction-status-box warning"
                    : item?.["statusCode"]?.type === "processed"
                    ? "transaction-status-box proccessed-status"
                    : item?.["statusCode"]?.type === "rejected"
                    ? "transaction-status-box rejected"
                    : " payment-status-box rejected-status"
                }
              >
                <span
                  className={
                    item?.["statusCode"]?.type === "info"
                      ? "status-text info-status"
                      : item?.["statusCode"]?.type === "success"
                      ? "payment-status-text success-status"
                      : item?.["statusCode"]?.type === "warning"
                      ? "status-text warning"
                      : item?.["statusCode"]?.type === "processed"
                      ? "status-text proccessed-status"
                      : item?.["statusCode"]?.type === "rejected"
                      ? "status-text rejected"
                      : "payment-status-text rejected-status"
                  }
                >
                  {item?.["statusCode"]?.value}
                </span>
              </span>
            </>
          )}
        </div>

        <div>
          <Grid container spacing={3}>
            {displayData?.map((disp, ind) => {
              return (
                disp?.field !== "radio" && (
                  <>
                    {!disp?.hideCell && disp?.textField && (
                      <Grid item className="column" key={index}>
                        <div className="column-name">{disp?.label}</div>
                        <div className="column-value">
                          <TextField
                            type="text"
                            variant="filled"
                            value={fetchTextFieldValue(
                              item?.id?.value,
                              disp?.field
                            )}
                            onBlur={(e) => {
                              e.stopPropagation();
                              item[column?.field]?.handleUserInput(
                                e.target.value,
                                item?.id?.value,
                                selectedList
                              );
                              // debounceRedrawRows()
                            }}
                          />
                        </div>
                      </Grid>
                    )}
                    {disp?.field !== "actionButton" &&
                    item[disp?.field]?.multiValues ? (
                      <Grid
                        key={ind}
                        item
                        sm={viewMore ? 12 : 4}
                        xs={viewMore ? 12 : 6}
                      >
                        <div className="accordion-array-main">
                          <span className="accordion-sub-heading">
                            {disp?.label}
                          </span>
                          <div className="accordion-array">
                            {item[disp?.field]?.value?.map((val, ind) => {
                              return (
                                <span
                                  key={ind}
                                  className="table-cell-link"
                                  onClick={() => {
                                    history.push(val?.link, {
                                      item: item[disp?.field]?.params?.item,
                                      boeNo: val?.id,
                                    });
                                  }}
                                >
                                  {viewMore
                                    ? ` ${val?.label},`
                                    : item[disp?.field]?.value?.length >= 2
                                    ? ind < 2 && ind === 0
                                      ? ` ${val?.label}, `
                                      : ` ${val?.label?.slice(0, 5)}...`
                                    : ` ${val?.label}`}
                                </span>
                              );
                            })}
                          </div>
                        </div>
                      </Grid>
                    ) : (
                      !disp?.textField &&
                      disp?.field !== "actionButton" && (props.isShippingBillDB && disp?.field != 'shippingBillno') &&(
                        <Grid key={ind} item sm={4} xs={6}>
                          <div className="col-container">
                            <span className="accordion-sub-heading">
                              {disp?.label}
                            </span>
                            <span
                              onClick={() => {
                                if (item[disp?.field]?.isLink) {
                                  showOtherScreen(
                                    item[disp?.field]?.link,
                                    item[disp?.field].params
                                  );
                                }
                              }}
                              className={
                                item[disp?.field]?.isLink ||
                                item[disp?.field]?.multiValues
                                  ? "table-cell-link"
                                  : "accordion-text-value"
                              }
                            >
                              {item[disp?.field]?.value}
                            </span>
                          </div>
                        </Grid>
                      )
                    )}
                  </>
                )
              );
            })}
          </Grid>
          {<div className="action-button">{item?.actionButton}</div>}
          {expired && (
            <Grid item xs={12} key={index}>
              <div className="highlight-box">
                <img src={OrangeDot} />
                <span>Expiring on 12/12/2021</span>
              </div>
            </Grid>
          )}
        </div>
        <Divider />
        <div
          className="view-more-container"
          onClick={() => {
            setViewMore(!viewMore);
          }}
        >
          <span className="view-more">
            {`View ${!viewMore ? "More" : "Less"}`}
          </span>
          <img
            src={DownArrow}
            className={`view-more-arrow ${!viewMore ? "" : "arrow-up"}`}
          />
        </div>
      </div>
    </>
  );
};

export default TableRow;
