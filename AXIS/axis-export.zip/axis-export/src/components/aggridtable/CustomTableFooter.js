import React from 'react';
import Dropdown from '../../assets/icons/dropdown.svg';
import { Pagination } from '@material-ui/lab';
import { Menu, MenuItem } from '@material-ui/core';

const CustomTableFooter = (props) => {

    const { rowsPerPage, onClickRows, classes, anchorElRows,
        handleCloseRows, handleChangeRowsPerPage, handleChangePage, page, totalPage
    } = props;
    return (
        <>
            <div className="table-footer-container">
                <div>
                    <span className="entries">{totalPage} entries found</span>
                </div>
                <div className="pagination-container">
                    <span className="per-page">Rows per page</span>
                    <div className="count-dropdown" onClick={onClickRows}>
                        <span className="rowsPerPage">{rowsPerPage}</span>
                        <img src={Dropdown} />
                    </div>
                    <Menu
                        className={classes.menuRows}
                        anchorEl={anchorElRows}
                        id="simple-menu"
                        keepMounted
                        open={Boolean(anchorElRows)}
                        onClose={handleCloseRows}
                    >
                        {
                            [5, 10, 20, 30]?.map((count, index) => {
                                return (
                                    <MenuItem key={index} value={count} onClick={handleChangeRowsPerPage}>{count}</MenuItem>
                                )
                            })
                        }
                    </Menu>
                    <Pagination
                        page={page}
                        onChange={handleChangePage}
                        // onRowsPerPageChange={handleChangeRowsPerPage}
                        className={classes.pagination}
                        count={totalPage < rowsPerPage ? 1 : Math.ceil(totalPage / rowsPerPage)}
                        shape="rounded" />
                </div>
            </div>
        </>
    )
}

export default CustomTableFooter;