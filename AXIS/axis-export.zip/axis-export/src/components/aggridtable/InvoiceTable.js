/* eslint-disable */
import React, { useEffect } from "react";
// import AgGridTable from "../../../components/aggridtable";
import AgGridTable from "./index";
import { AgGridColumn, AgGridReact } from "ag-grid-react";
const InvoiceTable = (props) => {
  const [rowList, updateRowList] = React.useState([]);
   useEffect(() => {
    if (props?.invoiceData?.length > 0) {
      let resultArray = [];
      props?.invoiceData?.map((item) => {
        const {
          invoiceSerialNumber,
          invoiceNumber,
          invDate,
          invoiceCurrency,
          invoiceAmount,
          invoiceAmountAvailable,
          invoiceAmountOutstanding
        } = item;
        resultArray.push(
          createData(
          invoiceSerialNumber,
          invoiceNumber,
          invDate,
          invoiceCurrency,
          invoiceAmount,
          invoiceAmountAvailable,
          invoiceAmountOutstanding
          )
        );
      });
      generateTableRowValues(resultArray);
    }
  }, [props?.invoiceData]);

  const createData = (
    invoiceSerialNumber,
    invoiceNumber,
    invDate,
    invoiceCurrency,
    invoiceAmount,
    invoiceAmountAvailable
  ) => {
    return {
          invoiceSerialNumber,
          invoiceNumber,
          invDate,
          invoiceCurrency,
          invoiceAmount,
          invoiceAmountAvailable
    };
  };

  const generateTableRowValues = (rows) => {
    const newArray = [...rows];
    const resultArray = [];
    newArray.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem).map((key) => {
        const value = rowItem[key];
        switch (key) {
          default:
            newObject[key] = { value: value };
            break;
        }
      });
      resultArray.push(newObject);
    });
    updateRowList(resultArray);
  };

  return (
    <>
      <div
        className=""
      >
        <div className="simple-card-header">
          {/* <h5>Forward Contract</h5> */}
        </div>

        <>
          <AgGridTable
            headCells={[
              { field: "invoiceSerialNumber", label: "S. No." },
              { field: "invoiceNumber", label: "Invoice No." },
              { field: "invDate", label: "Invoice Date" },
              { field: "invoiceCurrency", label: "Invoice CCY" },
              { field: "invoiceAmount", label: "Invoice Amount" },
              { field: "invoiceAmountAvailable", label: "Invoice Amount Available" }
            ]}
            rows={rowList}
            tableOnly={true}
            noRowSelection={true}
          >
             <AgGridReact
            >
               {props.invoiceData.map((item, index) => {
                  return (
                    <AgGridColumn
                      key={index}
                      maxWidth={50}
                      headerName={item?.label}
                      sortable={false}
                      field=""
                      cellStyle={{ padding: "0" }}
                      cellRendererFramework={(item) => {
                        const cellValue = item
                        return (
                          <div
                            style={{ lineHeight: "normal", textAlign: "left" }}
                          >
                            {cellValue}
                          </div>
                        );
                      }}
                    />
                    )
               })
               }
            </AgGridReact>
          </AgGridTable>
        </>
      </div>
    </>
  );
};
export default InvoiceTable;
