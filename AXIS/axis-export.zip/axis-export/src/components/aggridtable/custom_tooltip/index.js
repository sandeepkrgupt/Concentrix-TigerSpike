/* eslint-disable */
import React, { useState, forwardRef, useImperativeHandle } from 'react';
import './index.css';

const CustomToolTip = forwardRef((props, ref) => {

    const [data, setData] = useState(
        props.api.getDisplayedRowAtIndex(props.rowIndex).data
    );
   
    useImperativeHandle(ref, () => {
        return {
            getReactContainerClasses() {
                return ['custom-tooltip'];
            },
        };
    });

    return (
        <div
            className="custom-tooltip"
        >
            <p>
                <span  
                style={{whiteSpace: "normal"}}
                className="tooltip-span" >{data[props.field]?.value}</span>
            </p>
        </div>
    );
});

export default CustomToolTip;