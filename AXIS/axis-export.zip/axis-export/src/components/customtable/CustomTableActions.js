import React, { useRef, useState } from 'react'
import CloseIcon from '../../assets/icons/close.svg';
import SearchIcon from '../../assets/icons/search.svg';
import FilterIcon from '../../assets/icons/filter.svg';
import RightArrow from '../../assets/icons/arrow-right.svg';
import DownloadIcon from '../../assets/icons/download.svg';
import DownloadIconActive from '../../assets/icons/download-active.svg';
import DeleteIcon from '../../assets/icons/delete-icon.svg';
import EditIcon from '../../assets/icons/edit-icon.svg';
import { Chip, Menu, MenuItem } from '@material-ui/core';
import { TextField } from '../../components/@subzero/glacier/package/lib/components';

const CustomTableActions = (props) => {

    const ref = useRef()
    const {
        classes, updateFilterDisplay,
        handleClose, onClickDownload,
        anchorElDownload, filterValues,
        showDelete, showEdit,
        showFilter, showDownload
    } = props;

    const [searchOpen, setSearchOpen] = useState(false);

    return (<>

        <div className="row-container table-top">
            <div className="row-container">
                {filterValues && filterValues.length > 0 &&
                    <div className="chip-list">
                        <div className="left-arrow"
                            onClick={() => {
                                ref.current.scrollLeft -= 400;
                            }}
                        >
                            <img src={RightArrow} />
                        </div>
                        <div className="filter-chip-list" ref={ref}>
                            {
                                filterValues.map((filter, index) => {
                                    return (
                                        <Chip
                                            key={index}
                                            className={classes.chip}
                                            label={filter}
                                            onDelete={() => { }}
                                            deleteIcon={<img className="delete-icon" src={CloseIcon} />}
                                        />
                                    )
                                })
                            }
                        </div>
                        {filterValues.length > 5 &&
                            <div className="right-arrow"
                                onClick={() => {
                                    ref.current.scrollLeft += 400;
                                    document.getElementsByClassName("left-arrow")[0].style.display = "block";
                                }}
                            >
                                <img src={RightArrow} />
                            </div>}
                    </div>}
            </div>
            <div className={`row-container table-actions-container ${searchOpen ? 'search-open' : ''}`}>
                {searchOpen ? <div className="transaction-search" id="search-icon">
                    <TextField label="Find Field Name" />
                </div> : <>

                    <img onClick={() => setSearchOpen(!searchOpen)} src={SearchIcon} />
                    {showDelete && <img src={DeleteIcon} />}
                    {showEdit && <img src={EditIcon} />}
                    {showFilter && <img src={FilterIcon} onClick={() => { updateFilterDisplay() }} />}
                    {showDownload && <img onClick={onClickDownload} src={anchorElDownload ? DownloadIconActive : DownloadIcon} />}
                </>}
            </div>
            <Menu
                className={classes.menu}
                anchorEl={anchorElDownload}
                id="simple-menu"
                keepMounted
                open={Boolean(anchorElDownload)}
                onClose={handleClose}
            >
                <MenuItem onClick={handleClose}>XLS</MenuItem>
                <MenuItem onClick={handleClose}>XLSX</MenuItem>
                <MenuItem onClick={handleClose}>PDF</MenuItem>
            </Menu>
        </div>
    </>)
}

export default CustomTableActions;