import React from 'react';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableRow from '@material-ui/core/TableRow';
import Checkbox from '@material-ui/core/Checkbox';
import HamburgerIcon from '../../assets/icons/hamburger.svg';
import { Menu, MenuItem } from '@material-ui/core';
import CustomTableCell from './CustomTableCell';
import { Link } from 'react-router-dom'

const CustomTableBody = (props) => {
    const { classes, rows, order, orderBy, page, rowsPerPage, isSelected, moreActionMenu,
        hideActionIcon,
        handleClick } = props;

    const [morePopup, setMorePopup] = React.useState(false)
    const [selectedcell, setSelectedcell] = React.useState(null)

    function descendingComparator(a, b, orderBy) {
        if (b[orderBy] < a[orderBy]) {
            return -1;
        }
        if (b[orderBy] > a[orderBy]) {
            return 1;
        }
        return 0;
    }
    const onMoreCellClick = (event, refNo) => {
        setMorePopup(event.currentTarget)
        setSelectedcell(refNo)
    }
    const onCloseMorePopup = () => {
        setMorePopup(false)
        setSelectedcell(null)
    }


    function getComparator(order, orderBy) {
        return order === 'desc'
            ? (a, b) => descendingComparator(a, b, orderBy)
            : (a, b) => -descendingComparator(a, b, orderBy);
    }

    function stableSort(array, comparator) {
        const stabilizedThis = array.map((el, index) => [el, index]);
        stabilizedThis.sort((a, b) => {
            const order = comparator(a[0], b[0]);
            if (order !== 0) return order;
            return a[1] - b[1];
        });
        return stabilizedThis.map((el) => el[0]);
    }

    return (
        <>
            <TableBody>
                {rows && rows.length > 0 &&
                    stableSort(rows, getComparator(order, orderBy))
                        .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                        .map((row, index) => {
                            const isItemSelected = isSelected(row.refNo.value);
                            const labelId = `enhanced-table-checkbox-${index}`;

                            return (
                                <TableRow
                                    hover
                                    role="checkbox"
                                    aria-checked={isItemSelected}
                                    tabIndex={-1}
                                    key={row?.refNo?.value}
                                    selected={isItemSelected}
                                    key={index}
                                >
                                    <TableCell
                                        onClick={(event) => handleClick(event, row?.refNo?.value)}
                                        padding="checkbox">
                                        <Checkbox
                                            checked={isItemSelected}
                                            inputProps={{ 'aria-labelledby': labelId }}
                                        />
                                    </TableCell>


                                    {Object.keys(row).map((key, index) => (
                                        <CustomTableCell key={index} cellValue={row[key]} classes={classes} labelId={labelId} row={row} />
                                    ))

                                    }

                                    {!hideActionIcon &&
                                        <TableCell
                                            onClick={(e) => { onMoreCellClick(e, row?.refNo?.value) }}
                                            align="left">
                                            <img style={{ cursor: "pointer" }}
                                                className="hamburger-icon" src={HamburgerIcon} />
                                        </TableCell>}
                                    {moreActionMenu &&
                                        <Menu
                                            className={classes.morepopup}
                                            anchorEl={morePopup}
                                            id="simple-menu"
                                            keepMounted
                                            open={Boolean(morePopup)}
                                            onClose={onCloseMorePopup}
                                        >
                                            {moreActionMenu.map((item, key) => (
                                                <Link
                                                    to={{
                                                        pathname: item?.link,
                                                        search: item?.search,
                                                        state: item?.state
                                                    }}
                                                    key={key} >
                                                    <MenuItem >
                                                        <span className="more-text">
                                                            {item.label}
                                                        </span>
                                                    </MenuItem>
                                                </Link>

                                            ))}

                                        </Menu>}
                                </TableRow>
                            );
                        })}
            </TableBody>
        </>
    )
}

export default CustomTableBody;