import axios from "axios";
import { getCookie } from "../utils/Cookies";
import { ErrorHandling } from "../utils/ApiErrorHandling";

let BASE_URL;
if (process.env.REACT_APP_ENV === "production") {
  BASE_URL = window.globalConfig.baseUrlFromConfig.prod;
} else if (process.env.REACT_APP_ENV === "development") {
  BASE_URL = window.globalConfig.baseUrlFromConfig.dev;
}

const apiInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 3000,
  headers: {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*"
  }
});

apiInstance.interceptors.request.use(
  (config) => {
    const cfg = { ...config };
    const token = getCookie("accessToken");
    if (token) {
      cfg.headers.Authorization = `Bearer ${token}`;
    }
    return cfg;
  },
  (error) => {
    console.log(error);
  }
);

const get = async (url, params = {}) => {
  try {
    const response = await apiInstance({
      url,
      method: "GET",
      params
    });
    return response?.data;
  } catch (error) {
    ErrorHandling(error);
    return error?.response?.data;
  }
};

const post = async (url, data = {}) => {
  try {
    const response = await apiInstance({
      url,
      method: "POST",
      data
    });
    return {
      data: response?.data,
      status: response?.status
    };
  } catch (error) {
    ErrorHandling(error);
    throw error;
  }
};

const patch = async (url, data = {}) => {
  try {
    const response = await apiInstance({
      url,
      method: "PATCH",
      data
    });
    return {
      data: response?.data,
      status: response?.status
    };
  } catch (error) {
    ErrorHandling(error);
    throw error;
  }
};

const put = async (url, data = {}) => {
  try {
    const response = await apiInstance({
      url,
      method: "PUT",
      data
    });
    return {
      data: response?.data,
      status: response?.status
    };
  } catch (error) {
    ErrorHandling(error);
    return {
      data: error?.response?.data,
      status: error?.response?.status
    };
  }
};

const httpService = { get, post, patch, put };

export default httpService;
