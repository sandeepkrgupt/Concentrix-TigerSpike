import React from "react";
// import { Link } from '../../components/@subzero/glacier/package/lib/components';




const CustomizedTick = (props) => {

    

    return (
        <a xmlns="http://www.w3.org/2000/svg" id="anchor" xlinkHref="/" xmlnsXlink="http://www.w3.org/1999/xlink" target="_top">
     fgfg
</a>
        
     
    )
}

export default CustomizedTick;
