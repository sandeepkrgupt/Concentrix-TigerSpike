import React, { useState, useEffect } from "react";
import './index.css';
import { AgChartsReact } from 'ag-charts-react';
import { Button, Dropdown } from '../../components/@subzero/glacier/package/lib/components';
import ClockIcon from '../../assets/icons/orange-clock.svg';
import DetailViewIcon from "../../assets/icons/dotted-square.svg";
import DownloadIcon from "../../assets/icons/pink-download.svg";
import uploadIcon from "../../assets/icons/cloud-icon.svg";
import DownloadIconbLack from "../../assets/icons/download-black.svg";
import httpService from "../../services";
import { AgGridColumn, AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-theme-material.css";
import "ag-grid-community/dist/styles/ag-grid.css";
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';
import { useHistory } from "react-router-dom";
import { Link } from '@material-ui/core';
import { ApiEndpoints } from "../../constants/ApiEndpoints";






const TaskBoard = (props) => {
const [rowList, updateRowList] = useState([]);
const history = useHistory();
const [chartData, updatechartData] = useState([]);
const [irmChartData, updateirmChartData] = useState([]);
const [regulatoryStatusData, updateregulatoryStatusData] = useState([]);
const [irmstatusdata, updateirmstatusdata] = useState([]);
const [settledView, setsettledView] = useState(false);
const [settledViewIrm, setsettledViewIrm] = useState(false);
const [dateRangeIrm, setdateRangeIrm] = useState('Data for 12 months');
const [dateRangeSB, setdateRangeSB] = useState('Data for 12 months');
const [threeMonthData, setthreeMonthData] = useState([]);
const [sixMonthData, setsixMonthData] = useState([]);
const [twelveMonthData, settwelveMonthData] = useState([]);
const [chartdataSettled, setchartdataSettled] = useState([]);




useEffect(() => {
  getTransactionStatusDetails();
  getShippingBillChartDetail();
  getIrmData();
  generateTableRowValues();
}, []);


const getTransactionStatusDetails = async () => {
  const requestPayload = {
    "header": {
        "requestId": "35776161",
        "appId": "IRM"
    },
    "body": {
            "request": {
                "corpId": "CORP1",
                "userId": "MAK1"
            },
        "exportBody": {
          "exportTaskBoardRequest": {
          "corpId": "CORP1",
          "userId": "MAK1",
          "ieCode": "3292014743"
          }
          }
    }
}
  // console.log(requestPayload);
  // updateLoading(true);
  try {
    const response = await httpService.post(
      ApiEndpoints?.shippingBillTransactionStatus,
      requestPayload
    );
    // console.log(response);
    if (
      response?.status === 200 &&
      response?.data?.body?.response?.shippingBillsTransactionVO?.length > 0
    ) { 
      console.log("data for transaction status shipping bill", response?.data?.body?.response?.shippingBillsTransactionVO);
     generateTableRowValues(response?.data?.body?.response?.shippingBillsTransactionVO);
    } else {
      // updateLoading(false);
      console.log("here");
    }
  } catch (err) {
    // updateLoading(false);
  }
};

const getShippingBillChartDetail = async () => {
  const requestPayload = {
    "header": {
        "requestId": "35776161",
        "appId": "IRM"
    },
    "body": {
        "exportBody": {
          "exportTaskBoardRequest": {
          "corpId": "CORP1",
          "userId": "MAK1",
          "ieCode": "3292014743"
          }
          } 
    }
}
  // console.log(requestPayload);
  // updateLoading(true);
  try {
    const response = await httpService.post(
      ApiEndpoints?.shippingBillChartRegulatoryData,
      requestPayload
    );
    // console.log(response);
    if (
      response?.status === 200 &&
      response?.data?.body?.response?.exportRegulatoryStatusDashBoardListVO.exportRegulatoryStatusDashBoardDetails?.length > 0
    ) { 
      console.log("chart and regulatory data", response?.data?.body?.response);
      updateregulatoryStatusData(response?.data?.body?.response?.exportRegulatoryStatusDashBoardListVO.exportRegulatoryStatusDashBoardDetails);
      updatechartData(response?.data?.body?.response?.exportShippingBillDashBoardListVO.exportShippingBillDashBoardDetails);
    } else {
      // updateLoading(false);
      console.log("here");
    }
  } catch (err) {
    // updateLoading(false);
  }

};

const getsettledData = async () => {

  const requestPayload = {
    "header": {
      "requestId": "35776161",
      "appId": "IRM"
      },
      "body": {
      "exportBody": {
      "exportDashboardRequest": {
      "corpId": "CORP1",
      "userId": "MAK1",
      "ieCode": "3292014743"
      }
      }
      }
  }

  try {
    const response = await httpService.post(
      ApiEndpoints?.settledData,
      requestPayload
    );
    // console.log(response);
    if (
      response?.status === 200 &&
      response?.data?.body?.response?.threeMonthsDetails?.length > 0
    ) { 
      console.log("chart and regulatory data", response?.data?.body?.response);

      setthreeMonthData(response?.data?.body?.response.threeMonthsCount);
      setsixMonthData(response?.data?.body?.response.sixMonthsCount);
      settwelveMonthData(response?.data?.body?.response.twelveMonthsCount);

      if (dateRangeSB === "Data for 12 months") {
        setchartdataSettled(response?.data?.body?.response.twelveMonthsCount);
      } else if (dateRangeSB === "Data for 6 months") {
        setchartdataSettled(response?.data?.body?.response.sixMonthsCount);
      } else {
        setchartdataSettled(response?.data?.body?.response.threeMonthsCount);
      }
    } else {
      // updateLoading(false);
      console.log("here");
    }
  } catch (err) {
    // updateLoading(false);
  }

}

const getIrmData = async () => {
  const requestPayload = {
    "header": {
        "requestId": "35776161",
        "appId": "IRM"
    },
    "body": {
        "exportBody": {
          "exportTaskBoardRequest": {
          "corpId": "CORP1",
          "userId": "MAK1",
          "ieCode": "3292014743"
          }
          }
    }
}
  // console.log(requestPayload);
  // updateLoading(true);
  try {
    const response = await httpService.post(
      ApiEndpoints?.irmdata,
      requestPayload
    );
    // console.log(response);
    if (
      response?.status === 200 &&
      response?.data?.body?.response?.exportIRMDashBoardListVO.exportIRMDashBoardDetails?.length > 0
    ) { 
      console.log("chart and regulatory data", response?.data?.body?.response);
      updateirmstatusdata(response?.data?.body?.response?.exportIRMDashBoardCountListVO.exportIRMDashBoardCountDetails);
      updateirmChartData(response?.data?.body?.response?.exportIRMDashBoardListVO.exportIRMDashBoardDetails);
     
    } else {
      // updateLoading(false);
      console.log("here");
    }
  } catch (err) {
    // updateLoading(false);
  }

}


const generateTableRowValues = (shippingBillsTransactionVO) => {
  // const rows = getRows();
  const newArray = shippingBillsTransactionVO;
  const resultArray = [];
  
  newArray?.forEach((rowItem) => {
    const newObject = {};
    Object.keys(rowItem)?.map((key) => {
      const value = rowItem[key];
      switch (key) {
        case "shipmentStatus":
          (value === "Lodgment Regualarization" ? newObject[key] = {value : "Lodgment + Regularization", isLink: false} : newObject[key] = {value: value, isLink: false});
           return newObject[key];
        case "transactionStatusVO":
            Object.keys(value)?.map((subkey) => {
              const subValue = value[subkey];
              return (newObject[subValue.status] = {value : subValue.count, isLink: true});    
            });
      }
      return "";
    });
    resultArray.push(newObject);
  });
    updateRowList(resultArray);
    console.log("resultArray------------>>>", resultArray);
};


    const headCells = [
      { field: "shipmentStatus", label: "", sortable: false, bigCell: true },
      { field: "Drafts", label: "Drafts (Including Bulk Uploads)", sortable: false, },
      { field: "PendingAction", label: "Pending Action ", sortable: false } ,
      { field: "Processed", label: "Processed", sortable: false},
    ];

      var options = {
        autoSize: true,
        data: chartData,
        title: {
          text: '',
          fontSize: 18,
        },
        bar: {

        },
        subtitle: {
          text: '',
        },
        series: [
          {
            type: 'column',
            xKey: 'status',
            yKeys: ['count'],
            fills: ['#A81352'],
            strokes: [],
            shadow: {
              enabled: true,
              xOffset: 3,
            },
            label: {
              color: 'white',
              formatter: function (params) {
                return params.value;
              },
            }
          },
        ],
        axes: [
          {
            type: 'category',
            position: 'bottom',
            title: { text: 'Status' },
            label: {
              formatter: function (params) {
                return ' ';
              }
            }
          },
          {
            type: 'number',
            position: 'left',
            title: { text: 'Count' },
            tick: {
              count: 3
            },
            label: {
              formatter: function (params) {     
                  return params.value > 100000 ? params.value / 100000 + 'M' : params.value ;
              },
            },
          },
        ],
        legend: { enabled: false },
      };

      const irmChartSettledData = [
          { status: 'Jan', count: 78},
          { status: 'Feb', count: 70},
          { status: 'Mar', count: 60},
          { status: 'Apr', count: 60},
          { status: 'May', count: 60},
          { status: 'Jun', count: 60},
          { status: 'Jul', count: 60},
          { status: 'Aug', count: 60},
          { status: 'Sep', count: 60},
          { status: 'Oct', count: 60},
          { status: 'Nov', count: 60},
          { status: 'Dec', count: 60},
      ];


    var optionsSettledSB = {
      width: 200,
      data: chartdataSettled,   
      title: {
        text: '',
        fontSize: 18,
      },
      subtitle: {
        text: '',
      },
      series: [
        {
          type: 'column',
          xKey: 'month',
          yKeys: ['count'],
          fills: ['#A81352'],
          strokes: [],
          shadow: {
            enabled: true,
            xOffset: 3,
          },
          // label: {
          //   color: 'white',
          //   formatter: function (params) {
          //     return params.value;
          //   },
          // }
        },
      ],
      axes: [
        {
          type: 'category',
          position: 'bottom',
          title: { text: 'Status' },
        },
        {
          type: 'number',
          position: 'left',
          title: { text: 'Count' },
          tick: {
            count: 3
          },
          label: {
            formatter: function (params) {     
                return params.value > 100000 ? params.value / 100000 + 'M' : params.value ;
            },
          },
        },
      ],
      legend: { enabled: false 
    }
  };

      var optionsSettledIrm = {
        width: 200,
        data: irmChartSettledData,   
        title: {
          text: '',
          fontSize: 18,
        },
        subtitle: {
          text: '',
        },
        series: [
          {
            type: 'column',
            xKey: 'status',
            yKeys: ['count'],
            fills: ['#A81352'],
            strokes: [],
            shadow: {
              enabled: true,
              xOffset: 3,
            },
            // label: {
            //   color: 'white',
            //   formatter: function (params) {
            //     return params.value;
            //   },
            // }
          },
        ],
        axes: [
          {
            type: 'category',
            position: 'bottom',
            title: { text: 'Status' },
          },
          {
            type: 'number',
            position: 'left',
            title: { text: 'Count' },
            tick: {
              count: 3
            },
            label: {
              formatter: function (params) {     
                  return params.value > 100000 ? params.value / 100000 + 'M' : params.value ;
              },
            },
          },
        ],
        legend: { enabled: false 
      }
    };
    

      var optionsIrm = {
        autoSize: true,
        data: irmChartData,   
        title: {
          text: '',
          fontSize: 18,
        },
        subtitle: {
          text: '',
        },
        series: [
          {
            type: 'column',
            xKey: 'status',
            yKeys: ['count'],
            fills: ['#A81352'],
            strokes: [],
            shadow: {
              enabled: true,
              xOffset: 3,
            },
            label: {
              color: 'white',
              formatter: function (params) {
                return params.value;
              },
            }
          },
        ],
        axes: [
          {
            type: 'category',
            position: 'bottom',
            title: { text: 'Status' },
            label: {
              formatter: function (params) {
                return ' ';
              }
            }
          },
          {
            type: 'number',
            position: 'left',
            title: { text: 'Count' },
            tick: {
              count: 4
            },
            label: {
              formatter: function (params) {     
                  return params.value > 100000 ? params.value / 100000 + 'M' : params.value ;
              },
            },
          },
        ],
        legend: { enabled: false },
      };

      const getSettledChartData = () => {
        setsettledView(true);
        getsettledData();
      }

      const updateSettledChartData = (dateRangeSB) => {
        switch (dateRangeSB) {
          case "Data for 12 months" :
            setchartdataSettled(twelveMonthData);
            break;
          case "Data for 6 months" :
            setchartdataSettled(sixMonthData);
            break;
          case "Data for 3 months" : 
          setchartdataSettled(threeMonthData);
          break;
        }
        

      }

      const getSettledChartDataIrm = () => {
        setsettledViewIrm(true);
      }

    return (
        <div className="main-container">
          <h1>Shipping Bills</h1>
          <div className="task-board-main-container">
                <div className="task-board task-board-sub-shipping">
                    <div className="task-board-subcontainer-title task-board-title">Shipping Bills<span>EDPMS Status</span>
                    <div
                        className="customize-button customize-button-pos-right"
                        onClick={() => {
                          if (settledView) {
                            history.push('/shipping-bills', {
                              status: "Settled",
                              action: "SETTLED",
                            });
                          } else {
                          history.push('/shipping-bills', {
                            status: "Pending Lodgment",
                            action: "PENDINGLODGEMENT",
                          });
                        }
                      }}
                      >
                      {" "}
                    Detailed View &nbsp;
                    <img src={DetailViewIcon} />
          </div>
          <div
                        className="customize-button customize-button-pos-right-view"
                        onClick={() => {
                          history.push('/shipping-bills', {
                            status: "Pending Lodgment",
                            action: "PENDINGLODGEMENT",
                          });
                      }}
                      >
                      {" "}
                    View &nbsp;
                    <img src={DetailViewIcon} />
          </div>
                    </div>
                    <div className="sub-right-container">
          <div>
          <Button
                className="outstanding-button"
                color="secondary"
                 
                  onClick={() => {
                    setsettledView(false);
                    // setApprove(true);
                    // setShowModal(true);
                  }}
                >
                Outstanding
            </Button>
            <Button
                className="reject-button"
                color="secondary"
                  onClick={() => {
                    getSettledChartData();
                    setsettledView(true)
                    // setApprove(true);
                    // setShowModal(true);
                  }}
                >
                Settled
            </Button>
          </div>
        </div>
        {settledView ? <div> 
          <div className="date_range_dropdown">
          <Dropdown
                    items={
                        [
                            'Data for 12 months',
                            'Data for 6 months',  
                            'Data for 3 months' 
                        ]
                    }
                    defaultValue={dateRangeSB}
                    value={dateRangeSB}
                    label=""
                    placeholder=""
                    type="text"
                    variant="filled"
                    fullWidth
                    name="DateRange"
                    onChange={(e) => {
                      setdateRangeSB(e)
                      updateSettledChartData(e);
                    }}
                />
                </div>
                <div>
          <AgChartsReact class="shipping-bill-chart" options={optionsSettledSB} />
          </div>
                </div>:<div className="task-board-chart">
                      <AgChartsReact class="shipping-bill-chart" options={options} />
                      <div className="link">
                      <Link component="button" variant="body2"
                          onClick={() => {
                            history.push('/shipping-bills', {
                              status: "Pending Lodgment",
                              action: "PENDINGLODGEMENT",
                            });
                        }}
                        className="status-link"
                      >
                      Pending Lodgment
                      </Link>
                      <Link component="button" variant="body2"
                          onClick={() => {
                            history.push('/shipping-bills', {
                              status: "Pending Payment",
                              action: "PENDINGPAYMENT",
                            });
                        }}
                        className="status-link"
                      >
                      Pending Payment
                      </Link>
                      <Link component="button" variant="body2"
                          onClick={() => {
                            history.push('/shipping-bills', {
                              status: "Partially Paid",
                              action: "PARTIALPAID",
                            });
                        }}
                        className="status-link"
                      >
                      Partially Paid
                      </Link>
                      </div>
                      </div>}

                      {settledView ? '' :<div className="task-board-regularity-table">

                    <div className="task-board-reg-title">Regulatory Status <span>From Shipping Bill Date</span></div>

                    {regulatoryStatusData.map((item,key) => {
                      return   <div className="simple-card" key={item.code}>
                      <div className="simple-card-header">
                          <div className="card_icon"><img src={ClockIcon} /></div>
                          <div className="card_heading">
                            <h5>{item.status}</h5>
                            {key === 0 ? <span>only for Pending Lodgments</span> : ''}
                          </div>
                          <div className="card_link">

                          <Link component="button" variant="body2"
                          onClick={() => {
                            history.push('/shipping-bills', {
                              status: "Pending Lodgment",
                              action: "PENDINGLODGEMENT",
                            });
                        }}
                        className="status-link"
                      >
                      {item.count}
                      </Link>
                            </div>
                      </div>
                      </div>
                    })
                    }
                  </div>}
                </div>
                <div className="task-board task-board-sub-irm">
                    <div className="task-board-sub-irm-title task-board-title">Inward Remittances<span>EDPMS Status</span>
                    <div
                        className="customize-button customize-button-pos-right"
                         onClick={() => {
                        // updateCustomizePopupDisplay(true)
                      }}
                      >
                      {" "}
                    Detailed View &nbsp;
                    <img src={DetailViewIcon} />
          </div>
          <div
                        className="customize-button customize-button-pos-right-view"
                        onClick={() => {
                          history.push('/shipping-bills', {
                            status: "Pending Lodgment",
                            action: "PENDINGLODGEMENT",
                          });
                      }}
                      >
                      {" "}
                    View &nbsp;
                    <img src={DetailViewIcon} />
          </div>
                    </div>
                    <div className="sub-right-container">
                      
          <div>
          <Button
                className="outstanding-button"
                color="secondary"
                 
                  onClick={() => {
                    setsettledViewIrm(false);
                    // setApprove(true);
                    // setShowModal(true);
                  }}
                >
                Outstanding
            </Button>
            <Button
                className="reject-button"
                color="secondary"
                  onClick={() => {
                    getSettledChartDataIrm();
                    // setApprove(true);
                    // setShowModal(true);
                  }}
                >
                Settled
            </Button>
          </div>
        </div>
        {settledViewIrm ? 
        <div>
          <div className="date_range_dropdown">
          <Dropdown
                    items={
                        [
                            'Data for 12 months',
                            'Data for 6 months',  
                            'Data for 3 months' 
                        ]
                    }
                    defaultValue={dateRangeIrm}
                    value={dateRangeIrm}
                    label=""
                    placeholder=""
                    type="text"
                    variant="filled"
                    fullWidth
                    name="DateRange"
                    onChange={(e) => {
                      setdateRangeIrm(e);
                    }}
                />
                </div>
          <div>
          <AgChartsReact class="shipping-bill-chart" options={optionsSettledIrm} />
          </div>
        </div> : 
        <div className="task-board-chart-irm">
                    <AgChartsReact class="shipping-bill-chart" options={optionsIrm} />
                    <div className="link-irm">
                    <Link component="button" variant="body2"
                          onClick={() => {
                            // history.push('/shipping-bills', {
                            //   status: "Pending Lodgment",
                            //   action: "PENDINGLODGEMENT",
                            // });
                        }}
                        className="status-link-irm"
                      >
                      Unutilised
                      </Link>
                      <Link component="button" variant="body2"
                          onClick={() => {
                            // history.push('/shipping-bills', {
                            //   status: "Pending Lodgment",
                            //   action: "PENDINGLODGEMENT",
                            // });
                        }}
                        className="status-link-irm"
                      >
                      Partially utilised
                      </Link>
                      </div>
                      </div>}
                  {settledViewIrm ? '' : <div>
                  <div className="task-board-reg-title">Inward Remittances<span>From Shipping Bill Date</span></div>

                  {irmstatusdata.map((item,key) => {
                    return <div className="simple-card" key={item.code}>
                    <div className="simple-card-header">
                    <div className="card_heading-irm">
                      <h5>{item.status}</h5>
                      </div>
                    
                    <div className="card_link">
                    <Link component="button" variant="body2"
                        onClick={() => {
                          // history.push('/shipping-bills', {
                          //   status: "Pending Lodgment",
                          //   action: "PENDINGLODGEMENT",
                          // });
                      }}
                      className="status-link"
                    >
                    {item.count}
                    </Link>
                      </div>
                    </div>
                    </div>

                  })}
                  </div> }
                </div>      
                <div className="task-board task-board-sub-trans">
                    <div className="task-board-sub-irm-title task-board-title">Transaction Status
                    <div
                        className="customize-button customize-button-pos-right"
                         onClick={() => {
                        // updateCustomizePopupDisplay(true)
                      }}
                      >
                      {" "}
                    Detailed View &nbsp;
                    <img src={DetailViewIcon} />
          </div>
          <div
                        className="customize-button customize-button-pos-right-view"
                        onClick={() => {
                          history.push('/shipping-bills', {
                            status: "Pending Lodgment",
                            action: "PENDINGLODGEMENT",
                          });
                      }}
                      >
                      {" "}
                    View &nbsp;
                    <img src={DetailViewIcon} />
          </div>
          </div>
          <div className="transaction-status-table-container">
      <div
            id="myGrid"
            className="ag-theme-alpine"
            style={{ height: "272px", width: "549px", maxHeight: "500px" }}
          >
           <AgGridReact
               rowData={rowList}
               rowHeight={50}
               headerHeight={70}
               >
                 {headCells.map((item, index) => {
                   return  item.bigCell ? (<AgGridColumn
                   key={index}
                   maxWidth={127}
                   minWidth={100}
                   headerName={item?.label}
                   sortable={false}
                   field={item?.field}
                   cellStyle={{ padding: "11px 10px 0px 20px" }}
                   cellRendererFramework={(props) => {
                    const cellValue = props?.value;
                    return cellValue?.isLink ? (
                      <div
                        className="table-cell-link"
                        // onClick={() => {
                        //   if (cellValue?.link) {
                        //     showOtherScreen?.(
                        //       cellValue?.link,
                        //       cellValue?.params
                        //     );
                        //     // history.push(
                        //     //     cellValue?.link,
                        //     //     cellValue?.params
                        //     // );
                        //   }
                        // }}
                      >
                        {/* {" "} */}
                        {cellValue?.value}
                      </div>
                    ) : <div>{cellValue?.value}</div>
                   }}
                 />) : (
                  <AgGridColumn
                  key={index}
                  maxWidth={140}
                  minWidth={100}
                  headerName={item?.label}
                  sortable={false}
                  field={item?.field}
                  cellStyle={{ padding: "10px 10px 10px 20px" }}
                  cellRendererFramework={(props) => {
                    const cellValue = props?.value;
                    return cellValue?.isLink ? (
                      <div
                        className="table-cell-link"
                        // onClick={() => {
                        //   if (cellValue?.link) {
                        //     showOtherScreen?.(
                        //       cellValue?.link,
                        //       cellValue?.params
                        //     );
                        //     // history.push(
                        //     //     cellValue?.link,
                        //     //     cellValue?.params
                        //     // );
                        //   }
                        // }}
                      >
                        {/* {" "} */}
                        {cellValue?.value}
                      </div>
                    ) : <div>{cellValue?.value}</div>
                   }}
                />)
                 })}
           </AgGridReact>
       </div>
          </div>
                </div>
                <div className="task-board-bulk-ebrc">
                <div className="task-board-sub-bulk">
                    <div className="task-board-sub-irm-title">Bulk Template Download</div>
                    <div className="template-container">
                      <div className="template">
                        <div className="header">Template01.xls</div>
                      <div className="flex-container">
                        <div className="container-span"><span>STANDARD</span></div>
                        <div className="empty-div"></div>
                        <div className="container-icon"><img src={DownloadIconbLack} /></div>
                      </div>
                      </div>
                      <div className="template">
                      <div className="header">Template01.xls</div>
                      <div className="flex-container">
                      <div className="container-span"><span>CUSTOM</span></div>
                      <div className="empty-div"></div>
                      <div className="container-icon"></div><img src={DownloadIconbLack} /></div>     
                      </div>
                      </div>
                   
                    <div className="task-board-sub-irm-upload task-board-blk">
                      <div className="bulk-upload">Bulk Template Upload</div>
                    <span className="download_reports"><span className="dw-icon"><img src={uploadIcon} /></span>UPLOAD FILE</span>
                    </div>
                    </div>
                    <div className="task-board-sub-ebrc">
                    <div className="ebrc-flex-container">
                    <div className="task-board-sub-irm-ebrc">EBRC Report</div>
                    <div className="ebrc-icon"><img src={DownloadIcon} /></div>
                      <div className="ebrc-download">DOWNLOAD</div>
                    </div>          
                </div>
                </div>
            </div>
        </div>
      );
};




export default TaskBoard;
