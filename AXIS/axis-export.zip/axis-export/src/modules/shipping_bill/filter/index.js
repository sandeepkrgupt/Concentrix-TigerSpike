/* eslint-disable */
import React, {useState, useEffect} from 'react';
import { Drawer } from '@material-ui/core'
import closeIcon from '../../../assets/icons/close-icon.svg';
import Customdropdown from '../../../components/customdropdown';
import Button from '../../../components/@subzero/glacier/package/lib/components/Button'
import "./index.css"
import CustomSlider from '../../../components/slider';
import { useSelector } from 'react-redux';
import customStyles from '../../boe/filter/filter.module.css';
import shippingBillSampleData from "../shippingBill.json";



const FilterComponent = (props) => {

    const [transactionStatusOptions] = useState([
        {
            id:1,
            label: 'All Tasks'
        },
        {
            id:2,
            label: 'Rejected by Auth'
        },
        {
            id:3,
            label: 'Rejected by Bank'
        },
        {
            id:4,
            label: 'Drafts'
        },
        {
            id:5,
            label: 'Scheduled'
        },
        {
            id:6,
            label: 'Pending with Bank'
        },
        {
            id: 7,
            label: 'Pending with Auth'
        }
    ])

    const [beneficiaryOptions] = useState([
        {
            id: 1,
            label: 'ARM Software Media'
        },
        {
            id: 2,
            label: 'Citi Software Media'
        },
        {
            id: 3,
            label: 'BBH Software Media'
        },
        {
            id: 4,
            label: 'XYZ Software Media'
        }
    ]);

    const [currencyOptions] = useState([
        {
            id:1,
            label: 'INR'
        },
        {
            id:2,
            label: 'USD'
        },
        {
            id: 3,
            label: 'GBP'
        },
        {
            id: 4,
            label: 'KWD'
        }
    ]);

    const [boeNumberOptions] = useState([
        {
            id:1,
            label: 'BOE-001'
        },
        {
            id:2,
            label: 'BOE-002'
        },
        {
            id:3,
            label: 'BOE-003'
        }
    ]);

    const channelRefoptions = useState([
        {
            id:1,
            label: 'CRN-001'
        },
        {
            id:2,
            label: 'CRN-002'
        },
        {
            id:3,
            label: 'CRN-003'
        }
    ]);

    const paymentRefOptions = useState([
        {
            id:1,
            label: 'PRN-001'
        },
        {
            id:2,
            label: 'PRN-002'
        },
        {
            id:3,
            label: 'PRN-003'
        }
    ])

    const awbNumOptions = useState([
        {
            id:1,
            label: 'AWB-001'
        },
        {
            id:2,
            label: 'AWB-002'
        },
        {
            id:3,
            label: 'AWB-003'
        }
    ])

    const modeOptions = useState([
        {
            id:1,
            label: 'Fast'
        },
        {
            id:2,
            label: 'Standard'
        }
    ])

    const [ selTransactionOptions, setSelTransactionOptions ] = useState([]);
    const [selBenOptions, setSelBenOptions] = useState([]);
    const [selCurrencyOptions, setSelCurrencyOptions] = useState([]);
    const [selBoeOptions, setSelBoeOptions] = useState([]);
    const [selChannelOptions, setSelChannelOptions] = useState([]);
    const [selPaymentOptions, setSelPaymentOptions] = useState([]);
    const [selAwbOptions, setSelAwbOptions] = useState([]);
    const [selModeOptions, setSelModeOptions] = useState([]);
    const [appliedFilter, setApppliedFilter] = useState(false);
    const [disableFilter, setDisableFilter] = useState(false);
    const [amounts, setAmounts] = useState([null, null]);
    const state = useSelector((state)=> state?.transaction);
    const [filterOptions, setFilterOptions] = useState(shippingBillSampleData.filterOptions);
    
    useEffect(()=>{
        setFilterOptions(state?.transactionFilters)
    },[state])

    const closeFilter = (event)=>{
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
            return;
        }
        props.toggleDrawer();
    }

    const onApply=async(e)=>{
        setApppliedFilter(true);
    }

    const onReset=()=>{
        setSelTransactionOptions([]);
        setSelBenOptions([]);
        setSelCurrencyOptions([]);
        setSelBoeOptions([]);
        setSelChannelOptions([]);
        setSelPaymentOptions([]);
        setSelAwbOptions([]);
        setSelModeOptions([]);
        setAmounts([0,0])
        props?.getFilterList([]);
    }

    const deleteFromSelected=(chip, arr, setArr)=>{
        setArr(arr?.filter((item)=> item.id !== chip.id))
    }

    useEffect(()=>{

        const transactionOpts = [...selTransactionOptions]?.map((selOpt)=>{
            selOpt.key = "transactionStatus";
            return selOpt;
        });
        const benOpts = [...selBenOptions]?.map((selOpt)=> {
            selOpt.key = "beneficiaryName";
            return selOpt;
        });
        const currOpts = [...selCurrencyOptions]?.map((selOpt)=> {
            selOpt.key = "currency";
            return selOpt;
        });
        const boeOpts = [...selBoeOptions]?.map((selOpt)=> {
            selOpt.key = "boeNumber";
            return selOpt;
        });
        const channelOpts = [...selChannelOptions]?.map((selOpt)=> {
            selOpt.key = "channelReferenceNumber";
            return selOpt;
        });
        const paymentOpts = [...selPaymentOptions]?.map((selOpt)=> {
            selOpt.key = "paymentReferenceNumber";
            return selOpt;
        });
        const awbOpts = [...selAwbOptions]?.map((selOpt)=> {
            selOpt.key = "awbNumber";
            return selOpt;
        });
        const modeOpts = [...selModeOptions]?.map((selOpt)=> {
            selOpt.key = "processingMode";
            return selOpt;
        });
        let filterOptionsList = "";
        if(amounts[1] && amounts[1] !== 0){
            filterOptionsList = [
                ...transactionOpts,
                ...benOpts,
                ...currOpts,
                ...boeOpts,
                ...channelOpts,
                ...paymentOpts,
                ...awbOpts,
                ...modeOpts,
                {
                    label: "From amount " + amounts?.[0] + " - " + amounts?.[1],
                    key: "amount",
                }
            ];
        }
        else{
            filterOptionsList = [
                ...transactionOpts,
                ...benOpts,
                ...currOpts,
                ...boeOpts,
                ...channelOpts,
                ...paymentOpts,
                ...awbOpts,
                ...modeOpts
            ];
        }
        props?.getFilterList(filterOptionsList);
        let filterOpts = {
            transactionStatus: selTransactionOptions,
            beneficiaryName: selBenOptions,
            currency: selCurrencyOptions,
            boeNumber: selBoeOptions,
            channelNumber: selChannelOptions,
            paymentNumber: selPaymentOptions,
            awbNumber: selAwbOptions,
            modeOfProcressing: selModeOptions,
            minAmount: (amounts[0]),
            maxAmount: amounts[1] > 0 ? (amounts[1]) : ""
        }
        {props?.allTransactions !== true &&
        delete filterOpts["transactionStatus"]}
        props.apiFilterOpts(filterOpts);
        if(appliedFilter){
            props.toggleDrawer();
        }
    },[appliedFilter, amounts, selTransactionOptions, selBenOptions, selCurrencyOptions, selBoeOptions, selChannelOptions, selPaymentOptions, selAwbOptions, selModeOptions])

    useEffect(() => {
        const filterChip = props?.deleteFilterChip;
        switch(filterChip?.key){
            case 'amount': setAmounts([null,null]); break;
            case 'transactionStatus': deleteFromSelected(filterChip, selTransactionOptions, setSelTransactionOptions);break;
            case 'beneficiaryName': deleteFromSelected(filterChip, selBenOptions, setSelBenOptions);break;
            case 'currency': deleteFromSelected(filterChip, selCurrencyOptions, setSelCurrencyOptions);break;
            case 'boeNumber': deleteFromSelected(filterChip, selBoeOptions, setSelBoeOptions);break;
            case 'channelReferenceNumber': deleteFromSelected(filterChip, selChannelOptions, setSelChannelOptions);break;
            case 'paymentReferenceNumber': deleteFromSelected(filterChip, selPaymentOptions, setSelPaymentOptions);break;
            case 'awbNumber': deleteFromSelected(filterChip, selAwbOptions, setSelAwbOptions);break;
            case 'processingMode': deleteFromSelected(filterChip, selModeOptions, setSelModeOptions);break;
            default:{return null}
        }

    }, [props?.deleteFilterChip]);

    useEffect(()=>{
        if(props?.clearAll){
            onReset();
        }
    },[props?.clearAll])

    return (
        <>
            <Drawer anchor="right" open={props.showDrawer} className="filter-component" onClose={closeFilter} >
                <div className="drawer-container">
                    <div className="drawer-header">
                        <h5>Filter</h5>
                        <span className="drawer-close-icon" onClick={closeFilter}><img src={closeIcon} /></span>
                    </div>

                   {props?.allTransactions && <Customdropdown 
                        name="Shipping Bill No." 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelTransactionOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.shippingBillNumber} 
                        selectedOptions={selTransactionOptions}
                        appliedFilter={appliedFilter}
                    />}

                    <Customdropdown 
                        name="Status" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelBenOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.status} 
                        selectedOptions={selBenOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="Form No." 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelCurrencyOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.formNumber} 
                        selectedOptions={selCurrencyOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="Date Range"
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelBoeOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.dateRange} 
                        selectedOptions={selBoeOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="Pending Since" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelChannelOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.pendingSince} 
                        selectedOptions={selChannelOptions}
                        appliedFilter={appliedFilter}
                        />
                    <Customdropdown 
                        name="Port Code" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelPaymentOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.portCode} 
                        selectedOptions={selPaymentOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="Currency" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelAwbOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.currency} 
                        selectedOptions={selAwbOptions}
                        appliedFilter={appliedFilter}
                    />
                    <Customdropdown 
                        name="Importer" 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelModeOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.importor} 
                        selectedOptions={selModeOptions}
                        appliedFilter={appliedFilter}
                    />
                     <Customdropdown 
                        name="Bank Ref. No." 
                        isMulti={true} 
                        onSelectOptions={(selOptions)=> {setSelModeOptions(selOptions); setApppliedFilter(false)}} 
                        options={filterOptions?.bankRefrenceNumber} 
                        selectedOptions={selModeOptions}
                        appliedFilter={appliedFilter}
                    />
                    {/* Amount range */}
                    <CustomSlider title="Amount Range"
                        getValue={(amounts)=> {setAmounts(amounts); setApppliedFilter(false)}}
                        appliedFilter={appliedFilter}
                        selectedAmounts={amounts}
                        disableFilter={(bool)=> setDisableFilter(bool)}
                    />
                </div>
                <div className="filter-buttons">
                        <span className="reset-link" onClick={(e)=>{onReset();}}>Reset Filters</span>
                        <Button classes={{root}} disabled={disableFilter} onClick={(e)=>onApply(e)}>Apply</Button>
                    </div>
            </Drawer>
        </>
    )
}
export default FilterComponent;