/*eslint-disable */
import React, { useState, useEffect } from "react";
import AgGridTable from "../../../components/aggridtable";
import { useDispatch, useSelector } from "react-redux";
import { Actions } from "../../../store/rootActions";
import FilterComponent from "../filter";
import "../index.css";
// import BoeDetails from "../../boe/details";
//import BoeNo from "../../boe/no_of_boes";
import moment from "moment";
import Footer from '../../../components/stickyfooter';
import { Button } from '../../../components/@subzero/glacier/package/lib/components';



const ShippingBillTable = (props) => {
  const dispatch = useDispatch();
  const [rowList, updateRowList] = useState([]);
  const [showFilter, updateFilterDisplay] = React.useState(false);
  const [filterList, setFilterList] = useState([]);
  const [deleteFilterChip, setDeleteFilterChip] = useState({});
  const [clearAll, setClearAll] = useState(false);
  const [actionItemMenu, setActionItemMenu] = useState([]);
  const [startRange, setStartRange] = useState("");
  const [endRange, setEndRange] = useState("");
  const [selectedRows, updateSelectedRows] = React.useState([]);
  const [selRows, setSelRows] = useState([]);
  const [searchText, setSearchText] = useState("");
  const state = useSelector((state) => state?.transaction);
  const authData = useSelector((state) => state?.auth?.loginData);
  const [transactions, setTransactions] = useState(
    useSelector((state) => state?.transaction?.transactions)
  );
  const [totalPage, setTotalPage] = useState(
    useSelector((state) => state?.transaction?.totalPage)
  );
  const [filterAPIOptions, setFilterAPIOptions] = useState({});
  const [sortInfo, setSortInfo] = useState({});
  const [paginationInfo, setPaginationInfo] = useState({
    recordsPerPage: 5,
    reqPageIndex: 1
  });
  
  // Load data initially
  useEffect(() => {
    //getTransactions();
    //getFilterOptions();
  }, []);

  // Load data when transaction dropdown value changes
  useEffect(() => {
    //getTransactions();
    //getFilterOptions();
  }, [props?.transaction]);

  useEffect(() => {
    //getTransactions();
  }, [filterAPIOptions]);

  //Update transactions when change in reducer
  // useEffect(() => {
  //   setTransactions(state?.transactions);
  //   setTotalPage(state?.totalPage);
  //   if (state?.deleteTransaction) {
  //     getTransactions();
  //   }
  // }, [state]);

  //Update table data when response data changes
  useEffect(() => {
    generateTableRowValues();
  }, [props?.shippingBillData, props?.activeTI]);

  // useEffect(() => {
  //   getTransactions();
  // }, [searchText, sortInfo, paginationInfo]);

  // useEffect(() => {
  //   if (startRange && endRange) {
  //     getTransactions();
  //   }
  // }, [startRange, endRange]);

  // const getFilterOptions = () => {
  //   const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY";
  //   const req = {
  //     userId: authData?.userId,
  //     corpId: authData?.corpId,
  //     bankCode: authData?.bankCode,
  //     toggleType: toggleType
  //   };
  //   dispatch(Actions.getTransactionFilters(req, props?.action));
  // };

  //Get data from API
  // const getTransactions = () => {
  //   const toggleType = props?.transaction === "All Transactions" ? "ALL" : "MY";
  //   let filterOptions = filterAPIOptions;
  //   filterOptions["searchText"] = searchText;
  //   if (startRange && endRange) {
  //     filterOptions["startDate"] = moment(startRange).format("YYYY-MM-DD");
  //     filterOptions["endDate"] = moment(endRange).format("YYYY-MM-DD");
  //   }

  //   const req = {
  //     userId: authData?.userId,
  //     corpId: authData?.corpId,
  //     bankCode: authData?.bankCode,
  //     toggleType: toggleType,
  //     searchCriteriaInfo: filterOptions,
  //     sortInfo: sortInfo,
  //     paginationInfo: paginationInfo
  //   };
  //   dispatch(Actions.getTransactionInquiry(req, props?.action));
  // };

  function createData(
    billReferenceNo,
    id,
    shippingBillno,
    formNo,
   
    importorName,
    statusCode,
    billCurrency,
    billAmount,
    billDate,
    portDestination,
    outStandingAmount,
    dueIn,
    ieCode,
    ieName,
    ebrc
  ) {
    return {
      billReferenceNo,
      id,
      shippingBillno,
      formNo,
     
      importorName,
      statusCode,
      billCurrency,
      billAmount,
      billDate,
      portDestination,
      outStandingAmount,
      dueIn,
      ieCode,
      ieName,
      ebrc
    };
  }

  const settingHeadCells = () => {
    var data = [];

    switch (props?.activeTI) {
      case "Pending Lodgment":
        data = [
          { field: "shippingBillno", label: "Shipping Bill No.", sortable: true, largeCell: true},
          { field: "formNo", label: "Form No.", sortable: true},
          { field: "billDate", label: "Bill Date ", sortable: true},
          { field: "billCurrency", label: "Bill CCY", sortable: true, smallCell: true},
          { field: "billAmount", label: "Bill Amount", sortable: true },
          { field: "outStandingAmount", label: "O/S Amount", sortable: true },
          { field: "portDestination", label: "Port of Destination", sortable: true },
          { field: "statusCode", label: "Lodgement Status",  sortable: true },
          { field: "dueIn", label: "Due In", sortable: true },
          { field: "ieCode", label: "IE Code", sortable: true},
          { field: "ieName", label: "IE Name", sortable: true },
          { field: "action", label: "" }
        ];
        break;
      case "Pending Payment":
          data = [
            { field: "billReferenceNo", label: "Bill Ref. No.", sortable: true},
            { field: "shippingBillno", label: "Shipping Bill No.", sortable: true},
            { field: "formNo", label: "Form No.", sortable: true},
            { field: "importorName", label: "Importer Name", sortable: true},
            { field: "billDate", label: "Bill Date ", sortable: true},
            { field: "billCurrency", label: "Bill CCY", sortable: true, smallCell: true},
            { field: "billAmount", label: "Bill Amount", sortable: true },
            { field: "outStandingAmount", label: "O/S Amount", sortable: true },
            { field: "portDestination", label: "Port of Destination", sortable: true },
            { field: "ieCode", label: "IE Code", sortable: true},
            { field: "ieName", label: "IE Name", sortable: true },
            { field: "action", label: "" }
          ]
          break;
      case "Partially Paid":
          data = [
            { field: "billReferenceNo", label: "Bill Ref. No.", sortable: true},
            { field: "shippingBillno", label: "Shipping Bill No.", sortable: true},
            { field: "formNo", label: "Form No.", sortable: true},
            { field: "importorName", label: "Importer Name", sortable: true},
            { field: "billDate", label: "Bill Date ", sortable: true},
            { field: "billCurrency", label: "Bill CCY", sortable: true, smallCell: true},
            { field: "billAmount", label: "Bill Amount", sortable: true },
            { field: "outStandingAmount", label: "O/S Amount", sortable: true },
            { field: "ebrc", label: "EBRC", sortable: true, isArray: true },
            { field: "portDestination", label: "Port of Destination", sortable: true },
            { field: "statusCode", label: "Lodgement Status",  sortable: true },
            { field: "ieCode", label: "IE Code", sortable: true},
            { field: "ieName", label: "IE Name", sortable: true },
            { field: "action", label: "" }
          ]
          break;
      case "Settled":
          data = [
            { field: "billReferenceNo", label: "Bill Ref. No.", sortable: true},
            { field: "shippingBillno", label: "Shipping Bill No.", sortable: true},
            { field: "formNo", label: "Form No.", sortable: true},
            { field: "importorName", label: "Importer Name", sortable: true},
            { field: "billDate", label: "Bill Date ", sortable: true},
            { field: "billCurrency", label: "Bill CCY", sortable: true, smallCell: true},
            { field: "billAmount", label: "Bill Amount", sortable: true },
            { field: "outStandingAmount", label: "O/S Amount", sortable: true },
            { field: "ebrc", label: "EBRC", sortable: true, isArray: true },
            { field: "portDestination", label: "Port of Destination", sortable: true },
            { field: "ieCode", label: "IE Code", sortable: true},
            { field: "ieName", label: "IE Name", sortable: true },
            { field: "action", label: "" }
          ]
          break;
    }
    return data;

  }

  const getRows = () => {
    if (props?.shippingBillData?.length > 0) {
      return props?.shippingBillData?.map((resp) => {
        const {
          id,
          shippingBillno,
          formNo,
          billReferenceNo,
          importorName,
          statusCode,
          billCurrency,
          billAmount,
          billDate,
          portDestination,
          outStandingAmount,
          dueIn,
          ieCode,
          ieName,
          ebrc
        } = resp;
        // const updatedBoeList = [...boeNumbers]?.map((item) => {
        //   item.link = `boe-details`;
        //   return item;
        // });

        // let processingModeData =
        //   processingMode === "FAST"
        //     ? "Yes"
        //     : processingMode === "STANDARD"
        //     ? "No"
        //     : processingMode;

        return createData(
          billReferenceNo,
          id,
          shippingBillno,
          formNo,
          
          importorName,
          statusCode,
          billCurrency,
          billAmount,
          billDate,
          portDestination,
          outStandingAmount,
          dueIn,
          ieCode,
          ieName,
          ebrc
        );
      });
    } else {
      return [];
    }
  };

  // const searchCriteria = (filterApiOpts) => {
  //   Object.keys(filterApiOpts).forEach((key) => {
  //     if (Array.isArray(filterApiOpts[key])) {
  //       if (filterApiOpts[key]?.length > 0) {
  //         let arr = [];
  //         filterApiOpts[key]?.map((filt) => {
  //           arr.push(filt.id);
  //         });
  //         filterApiOpts[key] = arr;
  //       }
  //     }
  //   });
  //   setFilterAPIOptions(filterApiOpts);
  // };

  // const headCells = [
  //   { field: "shippingBillNo", label: "Shipping Bill No.", sortable: true},
  //   { field: "formNo", label: "Form No.", sortable: true},
  //   { field: "billDate", label: "Bill Date ", sortable: true},
  //   { field: "billCurrency", label: "Bill CCY", sortable: true, smallCell: true},
  //   { field: "billAmount", label: "Bill Amount", sortable: true },
  //   { field: "outStandingAmount", label: "O/S Amount", sortable: true },
  //   { field: "portDestination", label: "Port of Destination", sortable: true },
  //   { field: "statusCode", label: "Lodgement Status",  sortable: true },
  //   { field: "dueIn", label: "Due In", sortable: true },
  //   { field: "ieCode", label: "IE Code", sortable: true},
  //   { field: "ieName", label: "IE Name", sortable: true },
  // ];


    const headCells =  settingHeadCells();

    console.log('headCell------------------------->>>', headCells);
    // {
    //   field: "initiatedBy",
    //   label: "Initiated By",
    //   hideCell:
    //     props?.user === "maker"
    //       ? props?.transaction === "My Transactions"
    //       : false
    // },
    // {
    //   field: "assignedTo",
    //   label: "Assigned To",
    //   hideCell: props?.user === "checker"
    // },
    // { field: "doc", label: "" },
    // { field: "action", label: "" }
 

  const generateTableRowValues = () => {
    const rows = getRows();
    console.log("generated rows----->>", rows);
    let newArray = [...rows];
    let resultArray = [];
    function getStatusType(status) {
      switch (status) {
        case "Document Warehoused":
          return "info";
        case "REJ_CM":
        case "REJ_BO":
          return "rejected";
        case "ACC":
        case "pending With Bank":
          return "warning";
        case "SCHEDULED":
          return "success";
      }
    }
    newArray?.map((rowItem) => {
      const newObject = {};
      Object.keys(rowItem)?.map((key) => {
        let value = rowItem[key];
        switch (key) {
         
         
            case "billReferenceNo":
              return (newObject[key] = { value: value, isLink: false, smallCell: true });
              case "shippingBillno":
                return (newObject[key] = { value: value, isLink: false, largeCell: true });
          case "formNo":
            return (newObject[key] = { value: value, isLink: false });
          case "importorName":
            return (newObject[key] = { value: value, isLink: false, smallCell: true});
          case "billDate":
            return (newObject[key] = { value: value, isLink: false });
          case "billCurrency":
            return (newObject[key] = { value: value, isLink: false, smallCell: true});
          case "billAmount":
            return (newObject[key] = { value: value, isLink: false});
          case "ebrc": 
            return (newObject[key] = { value: value, isLink: false, isArray: true});
          case "outStandingAmount":
            return (newObject[key] = { value: value, isLink: false});
            case "portDestination":
            return (newObject[key] = { value: value, isLink: false});
            case "statusCode":
              return (newObject[key] = {
                value: value,
                statusBox: true,
                type: getStatusType(rowItem?.statusCode)
              });
          default:
            return (newObject[key] = { value: value });
        }
      });
      resultArray.push(newObject);
    });
    if (paginationInfo?.reqPageIndex == 1) {
      updateRowList(resultArray);
      //props?.rows(resultArray);
    } else {
      updateRowList(rowList.concat(resultArray));
      //props?.rows(rowList.concat(resultArray));
    }
  };

  const handleRowSelection = (selctedRow) => {
    const newArrayList = [];
    selctedRow &&
      selctedRow.length > 0 &&
      selctedRow.map((item) => {
        rowList.map((rowItem) => {
          if (item?.id?.value == rowItem?.id?.value) {
            newArrayList.push(rowItem);
          }
        });
      });
    updateSelectedRows(newArrayList);
  };
  const download = () => {
    //API Call
    const action = props?.action;
    const actionRequests = [];

    if (selectedRows.length === 0 ) {
      rowList?.map((row) => {
        actionRequests.push({
          id: row?.id?.value
        });
      });

    } else {
    selectedRows?.map((selRow) => {
      actionRequests.push({
        id: selRow?.id?.value
      });
    });
  }
    // const req = {
    //   userId: authData?.userId,
    //   corpId: authData?.corpId,
    //   bankCode: authData?.bankCode,
    //   toggleType: toggleType,
    //   actionRequests: actionRequests
    // };
    // dispatch(Actions.exportRecord(req, action));
  };

  const getSorted = (sortBy, desc) => {
    const receivedSortInfo = {
      sortBy: sortBy,
      sortType: desc ? "DESC" : "ASC"
    };
    if (JSON.stringify(receivedSortInfo) !== JSON.stringify(sortInfo)) {
      setSortInfo({
        sortBy: sortBy,
        sortType: desc ? "DESC" : "ASC"
      });
    }
  };

  const callPaginationApi = (pageNo, recordsPerPage) => {
    const paginationInfo = {
      recordsPerPage: recordsPerPage,
      reqPageIndex: pageNo
    };
    setPaginationInfo(paginationInfo);
  };

  // const showOtherScreen = (link, params) => {
  //   if (link === "boe-details") {
  //     setShowBoeDetails(true);
  //     setBoeDetailsParams(params);
  //   }
  //   if (link === "/no-of-boes") {
  //     setShowBoeNo(true);
  //     setBoeNoParams(params);
  //   }
  // };

  return (
    <div className="boe-table">
      {console.log("rowList finallllllllyyy", rowList)}
      <AgGridTable
        onFilter={() => {
          updateFilterDisplay(!showFilter);
        }}
        selectedList={selectedRows}
        handleRowSelection={handleRowSelection}
        startRange={startRange}
        endRange={endRange}
        setStartRange={(startRange) => {
          setStartRange(startRange);
        }}
        setEndRange={(endRange) => {
          setEndRange(endRange);
        }}
        onSearch={(search) => {
          setSearchText(search.target.value);
          callPaginationApi(1, paginationInfo?.recordsPerPage);
        }}
        headCells={headCells}
        rows={rowList}
        reloadTableRows={true}
        getItem={(item) => {
          switch (item) {
            case "All Tasks":
            case "Draft":
            case "Rejected by Auth":
            case "Rejected By Bank":
              setActionItemMenu([
                { label: "Edit", link: "" },
                { label: "Delete", link: "" }
              ]);
              break;
            case "Pending With Bank":
            case "Pending with Auth1":
              setActionItemMenu([{ label: "Withdraw", link: "" }]);
              break;
            case "Scheduled":
              setActionItemMenu([
                { label: "Withdraw", link: "" },
                { label: "Reschedule", link: "" }
              ]);
              break;
            default:
              null;
          }
        }}
        moreActionMenu={[{ label: "View Invoice", link: ""}]}
        docActionMenu={[
        ]}
        filterOptions={filterList}
        deleteFilterChip={(filterChip) => setDeleteFilterChip(filterChip)}
        clearAll={() => {
          setClearAll(true);
        }}
        getSelectedRows={(selRows) => {
          props?.selRows(selRows);
        }}
        ti={props?.user === "maker" ? true : false}
        onDownload={() => download()}
        onSort={(sortBy, desc) => {
          getSorted(sortBy, desc);
        }}
        callPaginationApi={callPaginationApi}
        totalPage={totalPage}
        isShippingBillDB={true}
        noRowSelection={false}
      />
      <FilterComponent
        showDrawer={showFilter}
        toggleDrawer={() => {
          updateFilterDisplay(!showFilter);
          setClearAll(false);
        }}
        getFilterList={(list) => {
          callPaginationApi(1, paginationInfo?.recordsPerPage);
          setFilterList(list);
        }}
        deleteFilterChip={deleteFilterChip}
        clearAll={clearAll}
        apiFilterOpts={async (filterApiOpts) => {
          //searchCriteria(filterApiOpts);
        }}
        allTransactions={true}
      />
      {props?.activeTI != "Settled" && <Footer>
            <div className="selected">
                <span>
                {/* {`Transaction Selected: ${selectedRows?.length}`} */}
                </span>
                {props?.activeTI === "Pending Lodgment" ? <div className="payment-button">
                <Button
                className="reject-button"
                color="secondary"
                  disabled={selectedRows?.length <= 0}
                  onClick={() => {
                    // setApprove(true);
                    // setShowModal(true);
                  }}
                >
                Lodge
            </Button>
                    <Button 
                    disabled={selectedRows?.length <= 0}
                    onClick={()=>{
                        // checkValidation();
                        //onMakePayment();
                    }} 
                    >
                        Lodge & Regularise
                    </Button>
                </div> : <div className="payment-button">
                <Button
                className="reject-button"
                color="secondary"
                  disabled={selectedRows?.length <= 0}
                  onClick={() => {
                    // setApprove(true);
                    // setShowModal(true);
                  }}
                >
                Realize
            </Button> </div>}
            </div>
            </Footer> }
    </div>
  );
};
export default ShippingBillTable;
