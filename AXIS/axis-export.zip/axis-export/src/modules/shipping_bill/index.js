/*eslint-disable */
import React, { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Breadcrumbs, Dropdown, Link, Button } from '../../components/@subzero/glacier/package/lib/components';
import Drawer from '@material-ui/core/Drawer';
import CloseIcon from '../../assets/icons/close.svg';
import PreviousIcon from '../../assets/icons/prev-icon.svg';
import Grid from '@material-ui/core/Grid';
import './index.css';
import CustomizeStatusTitles from './CustomizeStatusTitles'
import { tiColors, tiBorderColors } from '../../utils/colors';
import { useLocation, useHistory } from "react-router-dom";
import ShippingBillTable from './shipping_bill_table';
import ApproveReject from './approve_reject';
import { useSelector, useDispatch } from 'react-redux';
import { Actions } from '../../store/rootActions';
import Loader from '../../components/loader';
import { ApiEndpoints } from "../../constants/ApiEndpoints";
//import Customdropdown from '../../components/customdropdown';
import InfoIcon from "../../assets/icons/info-icon.svg";
import shippingBillSampleData from "./shippingBill.json";
import httpService from "../../services";



const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    paper:{
        width: '100%',
        height: '92%',
        background: '#FFFFFF',
        borderRadius: '24px 24px 0px 0px',
    },
}));

const ShippingBills = () => {
    const classes = useStyles();
    const location = useLocation();
    const history = useHistory();
    const [showCustomizePopup, updateCustomizePopupDisplay] = useState(false);
    const [activeTI, setActiveTI] = useState(location?.state?.status);
    const [action, setAction] = useState(location?.state?.action);
    const [userRole] = useState("maker");
    const [selRows, setSelRows] = useState([]);
    const [rows, setRows] = useState([]);
    const [showModal, setShowModal] = useState(false);
    const [approve, setApprove] = useState(false);
    const state = useSelector((state)=> state?.transaction)
    const [tasks, setTasks] = useState([]);
    const dispatch = useDispatch();
    const authData = useSelector((state) => state?.auth?.loginData);
    const [billReference, setBillReference] = useState('Use individual Bill reference');
    const [shippingBillData, setshippingBillData] = useState([]);
    const [shippingBillCardData, updateshippingBillCardData] = useState([]);
    const [shippingBillTabledata, updateshippingBillTabledata] = useState([]);

    //useEffect(() => {
    //    getStatistics()
    //}, [])


    // const task = [
    //     {
    //         "count": 78,
    //         "status": "Pending Lodgment",
    //         "code": "PENDINGLODGEMENT"
    //     },
    //     {
    //         "count": 70,
    //         "status": "Pending Payment",
    //         "code": "PENDINGPAYMENT"
    //     },
    //     {
    //         "count": 60,
    //         "status": "Partially Paid",
    //         "code": "PARTIALPAID"
    //     },
    //     {
    //         "count": 4,
    //         "status": "Settled",
    //         "code": "SETTLED"
    //     }
    // ];

    useEffect(() => {
        getShippingBillData();
        getTransactions();
       /* getFilterOptions();*/
    }, []);

    useEffect(() => {
        getShippingBillData();
        getTransactions();
        /* getFilterOptions();*/
    }, [activeTI, action]);


    useEffect(() => {
        getTransactions();
        /* getFilterOptions();*/
    }, [activeTI, shippingBillTabledata, action]);


    const getShippingBillData = async () => {
        const requestPayload = {
            "header": {
            "requestId": "35776161",
            "appId": "IRM"
            },
            "body": {
                "exportBody": {
                "request": {
                "corpId": "CORP1",
                "userId": "MAK1"
            },
            "exportShippingBillDBRequestDTO": {
                "corpId": "CORP1", 
                "userId": "MAK1",
                "subCustId": "1",
                "status": "Pending Lodgment",
                "statusCode": "PENDINGLODGEMENT"
            }}}
            }
          // console.log(requestPayload);
          // updateLoading(true);
          try {
            const response = await httpService.post(
              ApiEndpoints?.shippingBillTableData,
              requestPayload
            );
            // console.log(response);
            if (
              response?.status === 200 &&
              response?.data?.body?.response?.exportDashBoardVOList?.length > 0
            ) { 
              console.log("chart and regulatory data", response?.data?.body?.response);
              updateshippingBillTabledata(response?.data?.body?.response);
              // getTransactions();
              updateshippingBillCardData(response?.data?.body?.response?.exportDashBoardVOList);
            } else {
              // updateLoading(false);
              console.log("here");
            }
          } catch (err) {
            // updateLoading(false);
          }
    };

    useEffect(()=>{
        const updatedTasks = shippingBillCardData?.map((item, ind)=>{
            item.color = tiColors[ind];
            item.borderColor = tiBorderColors[ind];
            return item;
        });
        setTasks(updatedTasks);
        
    },[shippingBillCardData])

    //useEffect(()=>{
    //    getStatistics()
    //},[transaction])

    //useEffect(()=>{
    //    setAction(location?.state?.action);
    //},[location?.state?.action])
    
    //const getStatistics=()=>{
    //    const toggleType = transaction === "All Transactions" ? "ALL" : "MY"
    //    const req = {
    //        "userId":authData?.userId,
    //        "corpId":authData?.corpId,
    //        "bankCode":authData?.bankCode,
    //        "appDate":authData?.appDate,
    //        "ieCode":authData?.ieCode,
    //        "userRoleType":authData?.userRoleType,
    //        "toggleType": toggleType
    //    }
    //    dispatch(Actions.getTransactionStatistics(req))
    //}

    const getTransactions = () => {
        var data = [];                             

        switch (activeTI) {
            case "Pending Lodgment":
                data = shippingBillTabledata['pendingLodgment'];
                break;
            case "Pending Payment":
                data = shippingBillTabledata['pendingPayment'];
                break;
            case "Partially Paid":
                data = shippingBillTabledata['partiallyPaid'];
                break;
            case "Settled":
                data = shippingBillTabledata['settled'];
                break;
            default:
                data = [];
        }
        setshippingBillData(data);
        console.log("shipping bill data  activeTI", activeTI);
    }

    const fetchTables=()=>{
            return <ShippingBillTable 
                action={action} user={userRole} selRows={(rows)=> setSelRows(rows)} activeTI={activeTI} shippingBillData={shippingBillData}/>;
        }
    
    const toggleDrawer = (open) => (event) => {
        if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
          return;
        }
        setShowModal(open);
    };
    const ApproveRejectModal =()=>{
        return(
            <Drawer classes={{
                paper: classes.paper
              }} anchor={"bottom"} open={true} onClose={toggleDrawer(false)}>
                <div onClick={toggleDrawer(false)} className="close">
                  <img src={CloseIcon} className="close-icon"/>
                </div>
                <div className="modal-container">
                    <ApproveReject approve={approve} transaction={transaction} data={selRows} toggleModal={(val)=> setShowModal(val)}/>
                </div>
                
            </Drawer>
        )
    }
    // if(loader){
    //     return <Loader/>
    // }
    return (
        <div className="transaction-inquiry-container">
            <div className="heading-container">
                <div className="left-container">
                    <div className="left-img-container">
                        <img src={PreviousIcon} onClick={()=> history.push("/taskBoard")}/>
                    </div>
                    <div className="breadcrumb-container">
                    <Breadcrumbs
                            itemsAfterCollapse={3}
                            maxItems={3}
                        >
                            <Link className="breadcrumb-link"
                                to="/export"
                            >
                                Home
                            </Link>
                            <Link className="breadcrumb-link"
                                to="/export"
                            >
                                Export
                            </Link>
                            <Link className="breadcrumb-link active-breadcrumb-link"
                                active
                            >
                                Shipping Bills
                            </Link>
                        </Breadcrumbs>
                        <span className="heading-text">Shipping Bills</span>
                    </div>
                </div>
                {/*<div className="right-container">*/}
                {/*     <Dropdown*/}
                {/*        items={*/}
                {/*            userRole === "maker" ? [*/}
                {/*                'All Transactions',*/}
                {/*                'My Transactions',*/}
                {/*            ] : ["All Transactions"]*/}
                {/*        }*/}
                {/*        defaultValue={transaction}*/}
                {/*        value={transaction}*/}
                {/*        label=""*/}
                {/*        placeholder=""*/}
                {/*        type="text"*/}
                {/*        variant="filled"*/}
                {/*        fullWidth*/}
                {/*        name="All Transactions" */}
                {/*        onChange={(e)=> {*/}
                {/*            setTransaction(e);*/}
                {/*        }}*/}
                {/*    />*/}
                {/*</div>*/}
            </div>
            {/*<div className="sub-heading-container">*/}
            {/*    <div className="left-container">*/}
            {/*        <span className="sub-heading-text">Transaction Status</span>*/}

            {/*    </div>*/}
            {/*    <div className="sub-right-container">*/}
            {/*        <div className="customize-button" onClick={() => { */}
            {/*            // updateCustomizePopupDisplay(true) */}
            {/*            }}> Customize &nbsp;<img src={CustomIcon} /></div>*/}
            {/*    </div>*/}
            {/*</div>*/}

            <Grid container spacing={1}>
                {
                    tasks?.map((task, ind) => {
                        return (
                            <Grid key={ind} item
                            // lg={2} sm={3} xs={6}
                            >
                                <div className={`card-container transaction-stats-box`}
                                    style={{
                                        backgroundColor: task.color,
                                        border: activeTI === task?.status ? `3px solid ${task?.borderColor}` : null
                                    }}
                                    onClick={()=>{ setActiveTI(task?.status); setAction(task?.code)}}
                                >
                                    <div className="card-sub-container">
                                        <span className="transaction-count">{task.count}</span>
                                        <span className="transaction-status">{task.status}</span>
                                    </div>
                                    <div>
                                    </div>
                                </div>
                            </Grid>
                        )
                    })
                }
            </Grid>
            {activeTI === "Pending Lodgment" ? <div className="row-container">
                <Dropdown
                    items={
                        [
                            'Use individual Bill reference',
                            'Combine bills into a Single Bill Reference',   
                        ]
                    }
                    defaultValue={billReference}
                    value={billReference}
                    label=""
                    placeholder=""
                    type="text"
                    variant="filled"
                    fullWidth
                    name="All Transactions"
                    onChange={(e) => {
                        setBillReference(e);
                    }}
                />
                {billReference === 'Use individual Bill reference' ?
                    <div className="info-container">
                        <img src={InfoIcon} />
                        <span className="warning-text">
                            Each shipping bill will be lodged separately with an individual bill reference number.
                        </span>
                    </div> : <div className="info-container2">
                        <img src={InfoIcon} />
                        <span className="warning-text">
                            Multiple shipping bills will be lodged together with a single bill reference number (applicable for same currency + same payment terms + same tenor period + same importer.)
                        </span>
                    </div>}
            </div> : ' '}
            <div className="boe-table">
                {fetchTables()}
            </div>
            {userRole === "checker" && <div className="selected">
                    <span>
                        {`Transaction Selected: ${selRows?.length}`}
                    </span>
                    <div className="payment-button">
                        <Button 
                        className="reject-button"
                        color="secondary"
                        disabled={selRows?.length <= 0}
                        onClick={()=>{
                            setApprove(false);
                            setShowModal(true);
                        }} 
                        >
                            Reject
                        </Button>
                        <Button 
                        disabled={selRows?.length <= 0}
                        onClick={()=>{
                            setApprove(true);
                            setShowModal(true);
                        }} 
                        >
                            Approve
                        </Button>
                    </div>
                </div>}
            {showModal && <ApproveRejectModal/>}
            {showCustomizePopup && <CustomizeStatusTitles showDrawer={showCustomizePopup} toggleDrawer={() => { updateCustomizePopupDisplay(false) }} />}
            {state?.loader && <Loader/>}
        </div>
    );
}
export default ShippingBills;
