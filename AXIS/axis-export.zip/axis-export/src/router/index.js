import React from "react";
import { Route, Switch } from "react-router-dom";
import routes from "../utils/routes";
// import { PublicRoute} from "./routerComponent";
import ShippingBills from "../modules/shipping_bill";
// import Login from "../modules/auth";
import Taskboard from "../modules/taskBoard";


const router = () => {
  return (
    <>
      <Switch>
        <Route exact path={routes.login} component={Taskboard} />
        <Route
          exact
          path={routes.taskboard}
          component={Taskboard}
        />
        <Route
          exact
          path={routes.shippingBills}
          component={ShippingBills}
        />
      </Switch>
    </>
  );
};

export default router;
