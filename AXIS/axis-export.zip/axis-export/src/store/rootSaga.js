import { all, fork } from "redux-saga/effects";
import { login, lastLogin } from "./auth/saga";
import {
  getTransactions,
  getTransactionStatistics,
} from "./transaction/saga";

export default function* rootSaga() {
  yield all([
    fork(login),
    fork(lastLogin),
    fork(getTransactions),
    fork(getTransactionStatistics), 
  ]);
}
