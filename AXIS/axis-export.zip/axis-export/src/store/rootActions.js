
import * as auth from "./auth/actions";
import * as transaction from "./transaction/actions";

export const Actions = Object.assign(
  {},
  auth,
  transaction,
);
