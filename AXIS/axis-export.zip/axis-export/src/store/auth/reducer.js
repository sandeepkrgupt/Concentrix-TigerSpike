import * as TYPES from "../../utils/types";

const initialState = {
  loginSuccess: null,
  loginData: localStorage.getItem('authData') !== "undefined" ?  JSON.parse(localStorage.getItem('authData')) :{}
};
export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQUEST_LOGIN:
      return { ...state };
    case TYPES.LOGIN_SUCCESS: {
      localStorage.setItem('authData', JSON.stringify(action.payload))
      return {
        ...state,
        loginData: action?.payload,
        loginSuccess: true
      };
    }
    case TYPES.LOGIN_ERROR:{
      return{...state, loginSuccess: false}
    }
    case TYPES.LAST_LOGIN_SUCCESS:{
      return{...state, lastLoginTime: action?.payload}
    }
    default:
      return { ...state };
  }
}
