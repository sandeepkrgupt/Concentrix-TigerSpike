import * as TYPES from "../../utils/types";
import { takeLatest, put } from "redux-saga/effects";
import { loginService, lastLoginService } from "./service";

function* authLogin(action) {
  try {
    const params = action.payload;
    const response = yield loginService(params);
    if (response?.data?.statusCode === 0) {
      yield put({
        type: TYPES.LOGIN_SUCCESS,
        payload: response?.data,
      });
    } else {
      yield put({
        type: TYPES.LOGIN_ERROR,
      });
    }
  } catch (error) {
    yield put({
      type: TYPES.LOGIN_ERROR,
      payload: error,
    });
  }
}

export function* login() {
  yield takeLatest(TYPES.REQUEST_LOGIN, authLogin);
}

function* authLastLogin(action) {
  try {
    const params = action.payload;
    const response = yield lastLoginService(params);
    yield put({
      type: TYPES.LAST_LOGIN_SUCCESS,
      payload: response?.data,
    });
  } catch (error) {
    yield put({
      type: TYPES.LAST_LOGIN_ERROR,
      payload: error,
    });
  }
}

export function* lastLogin() {
  yield takeLatest(TYPES.REQUEST_LAST_LOGIN, authLastLogin);
}
