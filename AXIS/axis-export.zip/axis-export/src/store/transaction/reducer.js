import * as TYPES from "../../utils/types";

const initialState = {
  loader: false,
  transactions:[],
  statistics:[],
  transactionFilters:{},
  tiBoeDetails:{},
  deleteTransaction: false
};
export default function reducer(state = initialState, action) {
  switch (action.type) {
    case TYPES.REQUEST_TRANSACTION_INQUIRY:
      return { ...state, loader: true,deleteTransaction: false };
    case TYPES.TRANSACTION_INQUIRY_SUCCESS: {
      return {
        ...state,
        transactions: action.payload?.transactionList,
        totalPage: action?.payload?.transactionPagination?.totalRecordSize,
        loader: false,
      };
    }
    case TYPES.REQUEST_TRANSACTION_STATISTICS:
      return { ...state, loader: true, statistics: [] };
    case TYPES.TRANSACTION_STATISTICS_SUCCESS: {
      return {
        ...state,
        statistics: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_TRANSACTION_FILTERS:
      return { ...state, loader: true };
    case TYPES.TRANSACTION_FILTERS_SUCCESS: {
      return {
        ...state,
        transactionFilters: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_TIBOE_DETAILS:
      return { ...state, loader: true };
    case TYPES.TIBOE_DETAILS_SUCCESS: {
      return {
        ...state,
        tiBoeDetails: action.payload,
        loader: false
      };
    }
    case TYPES.REQUEST_DELETE_TRANSACTION:{
      return{
        ...state,
        deleteTransaction: false
      }
    }
    case TYPES.DELETE_TRANSACTION_SUCCESS:{
      return{
        ...state,
        deleteTransaction: true
      }
    }
    case TYPES.DELETE_TRANSACTION_ERROR:{
      return{
        ...state,
        deleteTransaction: false
      }
    }
    default:
      return { ...state };
  }
}