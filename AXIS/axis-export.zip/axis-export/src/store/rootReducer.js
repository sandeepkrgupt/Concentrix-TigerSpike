import { combineReducers } from "redux";
import auth from "./auth/reducer";
import transaction from "./transaction/reducer";


const reducers = combineReducers({
  auth,
  transaction,
});

export default reducers;
