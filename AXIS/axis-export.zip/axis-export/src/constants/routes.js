

const routes = {
  inwardRemittances: "/inward-remittance",
  provideDi: "/provide-di",
  successPage: "/success",
  failurePage: "/failure",
  eefcConversionPage: '/eefc-conversion',
  eefcPage: '/eefc',
  holdBalance: '/hold-balance',
  directEefc: '/direct-eefc',
  reviewEefc: '/review-eefc',
  login: '/'
};

export default routes;

