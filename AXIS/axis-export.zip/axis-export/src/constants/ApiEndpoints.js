export const ApiEndpoints = {
  // auth
  userLogin: "/login",
  shippingBillTransactionStatus: "/getTransactionStatus",
  shippingBillChartRegulatoryData: "/getShipplingBillsDashBoard",
  irmdata: "/getIRMdashBoard",
  shippingBillTableData : "/getShipplingBillDashBoardDetails",
  settledData: "/getShippingBillsSettledDetails",
  shippingBillInvoiceData: "/getViewInvoiceDetails"
};
