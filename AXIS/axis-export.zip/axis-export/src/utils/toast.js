import React from 'react';
import AlertPopup from "../components/alertPopup/alertPopup"

const callSuccess=()=>{
        return(
            <AlertPopup
                alertMsg="Yayyyy successssssss"
                alertType="success"
                isAlertOpen={true}
            />
        )
}

const toast = {
    success: callSuccess
}

export default toast;