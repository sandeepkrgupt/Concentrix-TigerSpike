const routes = {
  login: "/",
  taskboard: "/taskboard",
  completedTransactions: "/completed-transactions",
  currencyConvertor: "/currency-convertor",
  boe: "/boe",
  boeDetails: "/boe-details/:id",
  boeNo: "/no-of-boes",
  shippingBills: "/shipping-bills",
  makePayment: "/make-payment",
  additionalDetails: "/additional-details",
  success: "/success",
  authMatrix: "/auth-matrix",
  authMatrixSuccess: "/auth-matrix-success",
};

export default routes;
