import { clearCookie } from "./Cookies";

export function ErrorHandling(error) {
  if (error?.response && error?.response?.status) {
    switch (error?.response?.status) {
      case 401:
        clearCookie();
        
    }
  }
}
