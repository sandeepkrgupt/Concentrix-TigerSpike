window.globalConfig = {
  baseUrlFromConfig: {
    prod: "https://10.225.235.21:9445/neoexportbills",
    dev: "https://10.225.235.21:9445/neoexportbills",
  },
};
